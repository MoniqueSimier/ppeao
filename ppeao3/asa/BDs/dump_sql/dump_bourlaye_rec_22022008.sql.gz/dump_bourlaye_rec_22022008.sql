--
-- PostgreSQL database dump
--

SET client_encoding = 'LATIN9';
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: 
--

CREATE PROCEDURAL LANGUAGE plpgsql;


SET search_path = public, pg_catalog;

--
-- Name: dblink_pkey_results; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE dblink_pkey_results AS (
	"position" integer,
	colname text
);


ALTER TYPE public.dblink_pkey_results OWNER TO postgres;

--
-- Name: dblink(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink(text, text) RETURNS SETOF record
    AS '$libdir/dblink', 'dblink_record'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink(text, text) OWNER TO postgres;

--
-- Name: dblink(text, text, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink(text, text, boolean) RETURNS SETOF record
    AS '$libdir/dblink', 'dblink_record'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink(text, text, boolean) OWNER TO postgres;

--
-- Name: dblink(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink(text) RETURNS SETOF record
    AS '$libdir/dblink', 'dblink_record'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink(text) OWNER TO postgres;

--
-- Name: dblink(text, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink(text, boolean) RETURNS SETOF record
    AS '$libdir/dblink', 'dblink_record'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink(text, boolean) OWNER TO postgres;

--
-- Name: dblink_build_sql_delete(text, int2vector, integer, text[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_build_sql_delete(text, int2vector, integer, text[]) RETURNS text
    AS '$libdir/dblink', 'dblink_build_sql_delete'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_build_sql_delete(text, int2vector, integer, text[]) OWNER TO postgres;

--
-- Name: dblink_build_sql_insert(text, int2vector, integer, text[], text[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_build_sql_insert(text, int2vector, integer, text[], text[]) RETURNS text
    AS '$libdir/dblink', 'dblink_build_sql_insert'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_build_sql_insert(text, int2vector, integer, text[], text[]) OWNER TO postgres;

--
-- Name: dblink_build_sql_update(text, int2vector, integer, text[], text[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_build_sql_update(text, int2vector, integer, text[], text[]) RETURNS text
    AS '$libdir/dblink', 'dblink_build_sql_update'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_build_sql_update(text, int2vector, integer, text[], text[]) OWNER TO postgres;

--
-- Name: dblink_close(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_close(text) RETURNS text
    AS '$libdir/dblink', 'dblink_close'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_close(text) OWNER TO postgres;

--
-- Name: dblink_close(text, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_close(text, boolean) RETURNS text
    AS '$libdir/dblink', 'dblink_close'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_close(text, boolean) OWNER TO postgres;

--
-- Name: dblink_close(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_close(text, text) RETURNS text
    AS '$libdir/dblink', 'dblink_close'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_close(text, text) OWNER TO postgres;

--
-- Name: dblink_close(text, text, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_close(text, text, boolean) RETURNS text
    AS '$libdir/dblink', 'dblink_close'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_close(text, text, boolean) OWNER TO postgres;

--
-- Name: dblink_connect(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_connect(text) RETURNS text
    AS '$libdir/dblink', 'dblink_connect'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_connect(text) OWNER TO postgres;

--
-- Name: dblink_connect(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_connect(text, text) RETURNS text
    AS '$libdir/dblink', 'dblink_connect'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_connect(text, text) OWNER TO postgres;

--
-- Name: dblink_current_query(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_current_query() RETURNS text
    AS '$libdir/dblink', 'dblink_current_query'
    LANGUAGE c;


ALTER FUNCTION public.dblink_current_query() OWNER TO postgres;

--
-- Name: dblink_disconnect(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_disconnect() RETURNS text
    AS '$libdir/dblink', 'dblink_disconnect'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_disconnect() OWNER TO postgres;

--
-- Name: dblink_disconnect(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_disconnect(text) RETURNS text
    AS '$libdir/dblink', 'dblink_disconnect'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_disconnect(text) OWNER TO postgres;

--
-- Name: dblink_exec(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_exec(text, text) RETURNS text
    AS '$libdir/dblink', 'dblink_exec'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_exec(text, text) OWNER TO postgres;

--
-- Name: dblink_exec(text, text, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_exec(text, text, boolean) RETURNS text
    AS '$libdir/dblink', 'dblink_exec'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_exec(text, text, boolean) OWNER TO postgres;

--
-- Name: dblink_exec(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_exec(text) RETURNS text
    AS '$libdir/dblink', 'dblink_exec'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_exec(text) OWNER TO postgres;

--
-- Name: dblink_exec(text, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_exec(text, boolean) RETURNS text
    AS '$libdir/dblink', 'dblink_exec'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_exec(text, boolean) OWNER TO postgres;

--
-- Name: dblink_fetch(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_fetch(text, integer) RETURNS SETOF record
    AS '$libdir/dblink', 'dblink_fetch'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_fetch(text, integer) OWNER TO postgres;

--
-- Name: dblink_fetch(text, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_fetch(text, integer, boolean) RETURNS SETOF record
    AS '$libdir/dblink', 'dblink_fetch'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_fetch(text, integer, boolean) OWNER TO postgres;

--
-- Name: dblink_fetch(text, text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_fetch(text, text, integer) RETURNS SETOF record
    AS '$libdir/dblink', 'dblink_fetch'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_fetch(text, text, integer) OWNER TO postgres;

--
-- Name: dblink_fetch(text, text, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_fetch(text, text, integer, boolean) RETURNS SETOF record
    AS '$libdir/dblink', 'dblink_fetch'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_fetch(text, text, integer, boolean) OWNER TO postgres;

--
-- Name: dblink_get_pkey(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_get_pkey(text) RETURNS SETOF dblink_pkey_results
    AS '$libdir/dblink', 'dblink_get_pkey'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_get_pkey(text) OWNER TO postgres;

--
-- Name: dblink_open(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_open(text, text) RETURNS text
    AS '$libdir/dblink', 'dblink_open'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_open(text, text) OWNER TO postgres;

--
-- Name: dblink_open(text, text, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_open(text, text, boolean) RETURNS text
    AS '$libdir/dblink', 'dblink_open'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_open(text, text, boolean) OWNER TO postgres;

--
-- Name: dblink_open(text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_open(text, text, text) RETURNS text
    AS '$libdir/dblink', 'dblink_open'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_open(text, text, text) OWNER TO postgres;

--
-- Name: dblink_open(text, text, text, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dblink_open(text, text, text, boolean) RETURNS text
    AS '$libdir/dblink', 'dblink_open'
    LANGUAGE c STRICT;


ALTER FUNCTION public.dblink_open(text, text, text, boolean) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: art_debarquement; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_debarquement (
    id integer DEFAULT nextval(('"public"."art_debarquement_id_seq"'::text)::regclass) NOT NULL,
    art_millieu_id integer,
    art_vent_id integer,
    art_etat_ciel_id integer,
    art_agglomeration_id integer,
    art_lieu_de_peche_id integer,
    art_unite_peche_id integer,
    art_grand_type_engin_id character varying(10),
    art_type_sortie_id integer,
    date_depart date,
    heure_depart time without time zone,
    heure time without time zone,
    heure_pose_engin time without time zone,
    nbre_coups_de_peche integer,
    poids_total real,
    glaciere integer,
    distance_lieu_peche real,
    annee integer,
    mois integer,
    memo text,
    code integer,
    nbre_hommes integer,
    nbre_femmes integer,
    nbre_enfants integer,
    date_debarquement date
);


ALTER TABLE public.art_debarquement OWNER TO postgres;

--
-- Name: art_fraction; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_fraction (
    id character varying(15) NOT NULL,
    code integer,
    poids real,
    nbre_poissons integer,
    debarquee integer,
    ref_espece_id character varying(10),
    art_debarquement_id integer,
    prix double precision,
    CONSTRAINT art_fraction_debarquee_check CHECK (((debarquee = 0) OR (debarquee = 1)))
);


ALTER TABLE public.art_fraction OWNER TO postgres;

--
-- Name: art_poisson_mesure; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_poisson_mesure (
    id integer DEFAULT nextval(('"public"."art_poisson_mesure_id_seq"'::text)::regclass) NOT NULL,
    code integer,
    taille integer,
    art_fraction_id character varying(15)
);


ALTER TABLE public.art_poisson_mesure OWNER TO postgres;

--
-- Name: Bour02; Type: VIEW; Schema: public; Owner: devpechartexp
--

CREATE VIEW "Bour02" AS
    SELECT art_debarquement.code, art_debarquement.id, art_debarquement.mois, art_debarquement.art_grand_type_engin_id AS grdtyp, art_debarquement.poids_total AS pt, art_fraction.ref_espece_id AS esp, art_fraction.poids AS fdbq, art_fraction.nbre_poissons AS nfdbq, count(art_poisson_mesure.taille) AS nbdft FROM art_debarquement, art_fraction, art_poisson_mesure WHERE ((art_fraction.art_debarquement_id = art_debarquement.id) AND ((art_poisson_mesure.art_fraction_id)::text = (art_fraction.id)::text)) GROUP BY art_debarquement.code, art_debarquement.id, art_debarquement.mois, art_debarquement.art_grand_type_engin_id, art_debarquement.poids_total, art_fraction.ref_espece_id, art_fraction.poids, art_fraction.nbre_poissons ORDER BY art_debarquement.code;


ALTER TABLE public."Bour02" OWNER TO devpechartexp;

--
-- Name: art_activite; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_activite (
    id integer DEFAULT nextval(('"public"."art_activite_id_seq"'::text)::regclass) NOT NULL,
    art_unite_peche_id integer,
    art_agglomeration_id integer,
    art_type_sortie_id integer,
    art_grand_type_engin_id character varying(10),
    art_millieu_id integer,
    date_activite date,
    nbre_unite_recencee integer,
    annee integer,
    mois integer,
    code integer,
    nbre_hommes integer,
    nbre_femmes integer,
    nbre_enfants integer,
    art_type_activite_id character varying(10)
);


ALTER TABLE public.art_activite OWNER TO postgres;

--
-- Name: art_agglomeration; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_agglomeration (
    id integer NOT NULL,
    art_type_agglomeration_id integer,
    ref_secteur_id integer,
    nom character varying(50),
    longitude character varying(50),
    latitude character varying(50),
    memo text
);


ALTER TABLE public.art_agglomeration OWNER TO postgres;

--
-- Name: ref_pays; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_pays (
    id character varying(10) NOT NULL,
    nom character varying(50)
);


ALTER TABLE public.ref_pays OWNER TO postgres;

--
-- Name: ref_secteur; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_secteur (
    id integer NOT NULL,
    id_dans_systeme integer,
    nom character varying(50),
    superficie real,
    ref_systeme_id integer
);


ALTER TABLE public.ref_secteur OWNER TO postgres;

--
-- Name: ref_systeme; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_systeme (
    id integer NOT NULL,
    libelle character varying(50),
    ref_pays_id character varying(10),
    superficie real
);


ALTER TABLE public.ref_systeme OWNER TO postgres;

--
-- Name: ComptACT02; Type: VIEW; Schema: public; Owner: devpechartexp
--

CREATE VIEW "ComptACT02" AS
    SELECT ref_pays.nom AS pays, ref_systeme.libelle, ref_secteur.nom AS secteur, art_agglomeration.nom AS agglo, art_agglomeration.id AS num1, count(art_activite.id) AS n1 FROM ref_pays, ref_systeme, ref_secteur, art_agglomeration, art_activite WHERE (((((ref_pays.id)::text = (ref_systeme.ref_pays_id)::text) AND (ref_systeme.id = ref_secteur.ref_systeme_id)) AND (ref_secteur.id = art_agglomeration.ref_secteur_id)) AND (art_agglomeration.id = art_activite.art_agglomeration_id)) GROUP BY ref_pays.nom, ref_systeme.libelle, ref_secteur.nom, art_agglomeration.nom, art_agglomeration.id ORDER BY ref_pays.nom, ref_systeme.libelle, ref_secteur.nom, art_agglomeration.nom;


ALTER TABLE public."ComptACT02" OWNER TO devpechartexp;

--
-- Name: art_activite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_activite_id_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_activite_id_seq OWNER TO postgres;

--
-- Name: art_activite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_activite_id_seq', 203, true);


--
-- Name: art_agglomeration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_agglomeration_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_agglomeration_id_seq OWNER TO postgres;

--
-- Name: art_agglomeration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_agglomeration_id_seq', 1, false);


--
-- Name: art_caracteristiques_unite_peche_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_caracteristiques_unite_peche_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_caracteristiques_unite_peche_id_seq OWNER TO postgres;

--
-- Name: art_caracteristiques_unite_peche_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_caracteristiques_unite_peche_id_seq', 1, false);


--
-- Name: art_categorie_socio_professionnelle; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_categorie_socio_professionnelle (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.art_categorie_socio_professionnelle OWNER TO postgres;

--
-- Name: art_categorie_socio_professionnelle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_categorie_socio_professionnelle_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_categorie_socio_professionnelle_id_seq OWNER TO postgres;

--
-- Name: art_categorie_socio_professionnelle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_categorie_socio_professionnelle_id_seq', 1, false);


--
-- Name: art_condition_physico_chimique_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_condition_physico_chimique_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_condition_physico_chimique_id_seq OWNER TO postgres;

--
-- Name: art_condition_physico_chimique_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_condition_physico_chimique_id_seq', 1, false);


--
-- Name: art_debarquement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_debarquement_id_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_debarquement_id_seq OWNER TO postgres;

--
-- Name: art_debarquement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_debarquement_id_seq', 83, true);


--
-- Name: art_debarquement_rec; Type: TABLE; Schema: public; Owner: devppeao; Tablespace: 
--

CREATE TABLE art_debarquement_rec (
    id character varying(20) NOT NULL,
    poids_total real NOT NULL,
    art_debarquement_id character varying(20) NOT NULL
);


ALTER TABLE public.art_debarquement_rec OWNER TO devppeao;

--
-- Name: art_effort_gt; Type: TABLE; Schema: public; Owner: devppeao; Tablespace: 
--

CREATE TABLE art_effort_gt (
    id integer,
    effort_tot real,
    effort_gt real,
    rapport_gt real,
    art_grand_type_engin character varying,
    secteur character varying
);


ALTER TABLE public.art_effort_gt OWNER TO devppeao;

--
-- Name: art_effort_gt_sp; Type: TABLE; Schema: public; Owner: devppeao; Tablespace: 
--

CREATE TABLE art_effort_gt_sp (
    id integer,
    effort_tot real,
    effort_gt_sp real,
    rapport_gt_sp real,
    art_grand_type_engin character varying,
    ref_espece_id character varying,
    secteur character varying
);


ALTER TABLE public.art_effort_gt_sp OWNER TO devppeao;

--
-- Name: art_effort_sp; Type: TABLE; Schema: public; Owner: devppeao; Tablespace: 
--

CREATE TABLE art_effort_sp (
    id integer,
    effort_tot real,
    effort_sp real,
    rapport_sp real,
    ref_espece_id character varying,
    secteur character varying
);


ALTER TABLE public.art_effort_sp OWNER TO devppeao;

--
-- Name: art_effort_taille; Type: TABLE; Schema: public; Owner: devppeao; Tablespace: 
--

CREATE TABLE art_effort_taille (
    id integer,
    xi real,
    ni real,
    secteur character varying
);


ALTER TABLE public.art_effort_taille OWNER TO devppeao;

--
-- Name: art_engin_activite; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_engin_activite (
    id integer DEFAULT nextval(('"public"."art_engin_activite_id_seq"'::text)::regclass) NOT NULL,
    code integer,
    nbre integer,
    art_activite_id integer,
    art_type_engin_id character varying(10)
);


ALTER TABLE public.art_engin_activite OWNER TO postgres;

--
-- Name: art_engin_activite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_engin_activite_id_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_engin_activite_id_seq OWNER TO postgres;

--
-- Name: art_engin_activite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_engin_activite_id_seq', 162, true);


--
-- Name: art_engin_peche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_engin_peche (
    id integer DEFAULT nextval(('"public"."art_engin_peche_id_seq"'::text)::regclass) NOT NULL,
    code integer,
    longueur integer,
    hauteur real,
    nbre_nap real,
    nombre real,
    nbre_eff integer,
    nbre_mail_ham real,
    num_ham integer,
    proprietaire integer,
    art_type_engin_id character varying(10),
    art_debarquement_id integer
);


ALTER TABLE public.art_engin_peche OWNER TO postgres;

--
-- Name: art_engin_peche_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_engin_peche_id_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_engin_peche_id_seq OWNER TO postgres;

--
-- Name: art_engin_peche_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_engin_peche_id_seq', 101, true);


--
-- Name: art_enqueteur_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_enqueteur_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_enqueteur_id_seq OWNER TO postgres;

--
-- Name: art_enqueteur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_enqueteur_id_seq', 1, false);


--
-- Name: art_etat_ciel; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_etat_ciel (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.art_etat_ciel OWNER TO postgres;

--
-- Name: art_etat_ciel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_etat_ciel_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_etat_ciel_id_seq OWNER TO postgres;

--
-- Name: art_etat_ciel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_etat_ciel_id_seq', 1, false);


--
-- Name: art_fraction_debarquee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_fraction_debarquee_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_fraction_debarquee_id_seq OWNER TO postgres;

--
-- Name: art_fraction_debarquee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_fraction_debarquee_id_seq', 1, false);


--
-- Name: art_fraction_id1_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_fraction_id1_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_fraction_id1_seq OWNER TO postgres;

--
-- Name: art_fraction_id1_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_fraction_id1_seq', 1, false);


--
-- Name: art_fraction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_fraction_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_fraction_id_seq OWNER TO postgres;

--
-- Name: art_fraction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_fraction_id_seq', 1, false);


--
-- Name: art_fraction_non_debarquee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_fraction_non_debarquee_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_fraction_non_debarquee_id_seq OWNER TO postgres;

--
-- Name: art_fraction_non_debarquee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_fraction_non_debarquee_id_seq', 1, false);


--
-- Name: art_fraction_rec; Type: TABLE; Schema: public; Owner: devppeao; Tablespace: 
--

CREATE TABLE art_fraction_rec (
    id character varying(20) NOT NULL,
    poids real NOT NULL,
    nbre_poissons integer NOT NULL,
    ref_espece_id character varying(10) NOT NULL
);


ALTER TABLE public.art_fraction_rec OWNER TO devppeao;

--
-- Name: art_grand_type_engin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_grand_type_engin (
    id character varying(10) NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.art_grand_type_engin OWNER TO postgres;

--
-- Name: art_lieu_de_peche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_lieu_de_peche (
    id integer DEFAULT nextval(('"public"."art_lieu_de_peche_id_seq"'::text)::regclass) NOT NULL,
    ref_secteur_id integer,
    libelle character varying(50),
    code integer
);


ALTER TABLE public.art_lieu_de_peche OWNER TO postgres;

--
-- Name: art_lieu_de_peche_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_lieu_de_peche_id_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_lieu_de_peche_id_seq OWNER TO postgres;

--
-- Name: art_lieu_de_peche_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_lieu_de_peche_id_seq', 355, true);


--
-- Name: art_millieu; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_millieu (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.art_millieu OWNER TO postgres;

--
-- Name: art_millieu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_millieu_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_millieu_id_seq OWNER TO postgres;

--
-- Name: art_millieu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_millieu_id_seq', 1, false);


--
-- Name: art_mode_calcul_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_mode_calcul_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_mode_calcul_id_seq OWNER TO postgres;

--
-- Name: art_mode_calcul_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_mode_calcul_id_seq', 1, false);


--
-- Name: art_origine_kb_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_origine_kb_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_origine_kb_id_seq OWNER TO postgres;

--
-- Name: art_origine_kb_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_origine_kb_id_seq', 1, false);


--
-- Name: art_poisson_mesure_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_poisson_mesure_id_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_poisson_mesure_id_seq OWNER TO postgres;

--
-- Name: art_poisson_mesure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_poisson_mesure_id_seq', 2592, true);


--
-- Name: art_stat_gt; Type: TABLE; Schema: public; Owner: devppeao; Tablespace: 
--

CREATE TABLE art_stat_gt (
    id integer NOT NULL,
    obs_gt_min real,
    obs_gt_max real,
    pue_gt_ecart_type real,
    pue_gt real,
    fpe_gt real,
    fm_gt real,
    cap_gt real,
    art_grand_type_engin_id character varying(10) NOT NULL,
    art_stat_totale_id integer NOT NULL,
    nbre_enquete_gt integer
);


ALTER TABLE public.art_stat_gt OWNER TO devppeao;

--
-- Name: art_stat_gt_sp; Type: TABLE; Schema: public; Owner: devppeao; Tablespace: 
--

CREATE TABLE art_stat_gt_sp (
    id integer NOT NULL,
    obs_gt_sp_min real,
    obs_gt_sp_max real,
    pue_gt_sp_ecart_type real,
    pue_gt_sp real,
    cap_gt_sp real,
    ref_espece_id character varying(10) NOT NULL,
    art_stat_gt_id integer NOT NULL,
    nbre_enquete_gt_sp integer
);


ALTER TABLE public.art_stat_gt_sp OWNER TO devppeao;

--
-- Name: art_stat_sp; Type: TABLE; Schema: public; Owner: devppeao; Tablespace: 
--

CREATE TABLE art_stat_sp (
    id integer NOT NULL,
    obs_sp_min real,
    obs_sp_max real,
    pue_sp_ecart_type real,
    pue_sp real,
    cap_sp real,
    ref_espece_id character varying(10) NOT NULL,
    art_stat_totale_id integer NOT NULL,
    nbre_enquete_sp integer
);


ALTER TABLE public.art_stat_sp OWNER TO devppeao;

--
-- Name: art_stat_totale; Type: TABLE; Schema: public; Owner: devppeao; Tablespace: 
--

CREATE TABLE art_stat_totale (
    id integer NOT NULL,
    annee integer NOT NULL,
    mois integer NOT NULL,
    nbre_obs integer,
    obs_min real,
    obs_max real,
    pue_ecart_type real,
    pue real,
    fpe real,
    fm real,
    cap real,
    art_agglomeration_id integer NOT NULL,
    nbre_unite_recensee_periode integer,
    nbre_jour_activite integer
);


ALTER TABLE public.art_stat_totale OWNER TO devppeao;

--
-- Name: art_taille_gt_sp; Type: TABLE; Schema: public; Owner: devppeao; Tablespace: 
--

CREATE TABLE art_taille_gt_sp (
    id integer NOT NULL,
    li character varying(10),
    xi real,
    art_stat_gt_sp_id integer NOT NULL
);


ALTER TABLE public.art_taille_gt_sp OWNER TO devppeao;

--
-- Name: art_taille_sp; Type: TABLE; Schema: public; Owner: devppeao; Tablespace: 
--

CREATE TABLE art_taille_sp (
    id integer NOT NULL,
    li character varying(10),
    xi integer,
    art_stat_sp_id integer NOT NULL
);


ALTER TABLE public.art_taille_sp OWNER TO devppeao;

--
-- Name: art_type_activite; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_type_activite (
    raison character varying(50),
    libelle character varying(255),
    id character varying(10) NOT NULL
);


ALTER TABLE public.art_type_activite OWNER TO postgres;

--
-- Name: art_type_activite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_type_activite_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_type_activite_id_seq OWNER TO postgres;

--
-- Name: art_type_activite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_type_activite_id_seq', 1, false);


--
-- Name: art_type_agglomeration; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_type_agglomeration (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.art_type_agglomeration OWNER TO postgres;

--
-- Name: art_type_agglomeration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_type_agglomeration_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_type_agglomeration_id_seq OWNER TO postgres;

--
-- Name: art_type_agglomeration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_type_agglomeration_id_seq', 1, false);


--
-- Name: art_type_engin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_type_engin (
    id character varying(10) NOT NULL,
    art_grand_type_engin_id character varying(10),
    libelle character varying(50)
);


ALTER TABLE public.art_type_engin OWNER TO postgres;

--
-- Name: art_type_engin_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_type_engin_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_type_engin_id_seq OWNER TO postgres;

--
-- Name: art_type_engin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_type_engin_id_seq', 1, false);


--
-- Name: art_type_sortie; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_type_sortie (
    id integer NOT NULL,
    libelle character varying(100)
);


ALTER TABLE public.art_type_sortie OWNER TO postgres;

--
-- Name: art_type_sortie_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_type_sortie_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_type_sortie_id_seq OWNER TO postgres;

--
-- Name: art_type_sortie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_type_sortie_id_seq', 1, false);


--
-- Name: art_unite_peche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_unite_peche (
    id integer DEFAULT nextval(('"public"."art_unite_peche_id_seq"'::text)::regclass) NOT NULL,
    art_categorie_socio_professionnelle_id integer,
    libelle character varying(50),
    libelle_menage character varying(50),
    code integer,
    art_agglomeration_id integer,
    base_pays character varying(50)
);


ALTER TABLE public.art_unite_peche OWNER TO postgres;

--
-- Name: art_unite_peche_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_unite_peche_id_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_unite_peche_id_seq OWNER TO postgres;

--
-- Name: art_unite_peche_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_unite_peche_id_seq', 3331, true);


--
-- Name: art_vent; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_vent (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.art_vent OWNER TO postgres;

--
-- Name: art_vent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_vent_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_vent_id_seq OWNER TO postgres;

--
-- Name: art_vent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_vent_id_seq', 1, false);


--
-- Name: art_village_attache_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_village_attache_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_village_attache_id_seq OWNER TO postgres;

--
-- Name: art_village_attache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_village_attache_id_seq', 1, false);


--
-- Name: exp_biologie; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_biologie (
    id integer NOT NULL,
    longueur integer,
    longueur_totale integer,
    poids integer,
    exp_sexe_id character varying(10),
    exp_stade_id integer,
    exp_remplissage_id character varying(10),
    exp_fraction_id integer,
    memo text,
    valeur_estimee integer,
    CONSTRAINT exp_biologie_poids_estime_check CHECK (((valeur_estimee = 0) OR (valeur_estimee = 1)))
);


ALTER TABLE public.exp_biologie OWNER TO postgres;

--
-- Name: exp_biologie_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_biologie_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_biologie_id_seq OWNER TO postgres;

--
-- Name: exp_biologie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_biologie_id_seq', 1, false);


--
-- Name: exp_campagne; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_campagne (
    id integer DEFAULT nextval(('"public"."exp_campagne_id_seq"'::text)::regclass) NOT NULL,
    ref_systeme_id integer,
    numero_campagne integer,
    date_debut date,
    date_fin date,
    libelle character varying(100)
);


ALTER TABLE public.exp_campagne OWNER TO postgres;

--
-- Name: exp_campagne_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_campagne_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_campagne_id_seq OWNER TO postgres;

--
-- Name: exp_campagne_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_campagne_id_seq', 1, false);


--
-- Name: exp_contenu; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_contenu (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_contenu OWNER TO postgres;

--
-- Name: exp_contenu_biologie_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_contenu_biologie_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_contenu_biologie_id_seq OWNER TO postgres;

--
-- Name: exp_contenu_biologie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_contenu_biologie_id_seq', 1, false);


--
-- Name: exp_contenu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_contenu_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_contenu_id_seq OWNER TO postgres;

--
-- Name: exp_contenu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_contenu_id_seq', 1, false);


--
-- Name: exp_coup_peche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_coup_peche (
    id integer DEFAULT nextval(('"public"."exp_cp_peche_id_seq"'::text)::regclass) NOT NULL,
    date_cp date,
    longitude character varying(50),
    latitude character varying(50),
    memo text,
    profondeur real,
    exp_qualite_id integer,
    exp_campagne_id integer,
    exp_station_id character varying(10),
    numero_filet integer,
    numero_coup integer,
    exp_engin_id character varying(10),
    protocole integer,
    heure_debut time without time zone,
    heure_fin time without time zone,
    exp_environnement_id integer
);


ALTER TABLE public.exp_coup_peche OWNER TO postgres;

--
-- Name: exp_cp_peche_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_cp_peche_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_cp_peche_id_seq OWNER TO postgres;

--
-- Name: exp_cp_peche_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_cp_peche_id_seq', 1, false);


--
-- Name: exp_debris; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_debris (
    id character varying(10) NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_debris OWNER TO postgres;

--
-- Name: exp_engin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_engin (
    id character varying(10) NOT NULL,
    libelle character varying(50),
    longueur real,
    chute real,
    maille integer,
    memo text
);


ALTER TABLE public.exp_engin OWNER TO postgres;

--
-- Name: exp_environnement; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_environnement (
    id integer NOT NULL,
    transparence real,
    salinite_surface real,
    salinite_fond real,
    temperature_surface real,
    temperature_fond real,
    oxygene_surface real,
    oxygene_fond real,
    chlorophylle_surface real,
    chlorophylle_fond real,
    mot_surface real,
    mop_surface real,
    mot_fond real,
    mop_fond real,
    conductivite_surface real,
    conductivite_fond real,
    memo text,
    exp_force_courant_id integer,
    exp_sens_courant_id integer
);


ALTER TABLE public.exp_environnement OWNER TO postgres;

--
-- Name: exp_environnement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_environnement_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_environnement_id_seq OWNER TO postgres;

--
-- Name: exp_environnement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_environnement_id_seq', 1, false);


--
-- Name: exp_force_courant; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_force_courant (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_force_courant OWNER TO postgres;

--
-- Name: exp_force_courant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_force_courant_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_force_courant_id_seq OWNER TO postgres;

--
-- Name: exp_force_courant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_force_courant_id_seq', 1, false);


--
-- Name: exp_fraction; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_fraction (
    id integer NOT NULL,
    nombre_total integer,
    poids_total integer,
    memo text,
    ref_espece_id character varying(10),
    exp_coup_peche_id integer,
    nombre_estime integer,
    CONSTRAINT exp_fraction_nombre_estime_check CHECK (((nombre_estime = 0) OR (nombre_estime = 1)))
);


ALTER TABLE public.exp_fraction OWNER TO postgres;

--
-- Name: exp_fraction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_fraction_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_fraction_id_seq OWNER TO postgres;

--
-- Name: exp_fraction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_fraction_id_seq', 1, false);


--
-- Name: exp_position; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_position (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_position OWNER TO postgres;

--
-- Name: exp_position_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_position_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_position_id_seq OWNER TO postgres;

--
-- Name: exp_position_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_position_id_seq', 1, false);


--
-- Name: exp_qualite; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_qualite (
    id integer NOT NULL,
    libelle character varying(100)
);


ALTER TABLE public.exp_qualite OWNER TO postgres;

--
-- Name: exp_qualite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_qualite_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_qualite_id_seq OWNER TO postgres;

--
-- Name: exp_qualite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_qualite_id_seq', 1, false);


--
-- Name: exp_remplissage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_remplissage (
    id character varying(10) NOT NULL,
    libelle character varying(100)
);


ALTER TABLE public.exp_remplissage OWNER TO postgres;

--
-- Name: exp_remplissage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_remplissage_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_remplissage_id_seq OWNER TO postgres;

--
-- Name: exp_remplissage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_remplissage_id_seq', 1, false);


--
-- Name: exp_sediment; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_sediment (
    id character varying(10) NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_sediment OWNER TO postgres;

--
-- Name: exp_sens_courant; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_sens_courant (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_sens_courant OWNER TO postgres;

--
-- Name: exp_sens_courant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_sens_courant_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_sens_courant_id_seq OWNER TO postgres;

--
-- Name: exp_sens_courant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_sens_courant_id_seq', 1, false);


--
-- Name: exp_sexe; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_sexe (
    id character varying(10) NOT NULL,
    libelle character varying(100)
);


ALTER TABLE public.exp_sexe OWNER TO postgres;

--
-- Name: exp_stade; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_stade (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_stade OWNER TO postgres;

--
-- Name: exp_stade_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_stade_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_stade_id_seq OWNER TO postgres;

--
-- Name: exp_stade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_stade_id_seq', 1, false);


--
-- Name: exp_station; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_station (
    id character varying(10) NOT NULL,
    nom character varying(50),
    site character varying(50),
    latitude character varying(50),
    longitude character varying(50),
    memo text,
    ref_secteur_id integer,
    exp_position_id integer,
    exp_vegetation_id character varying(10),
    exp_debris_id character varying(10),
    exp_sediment_id character varying(10),
    distance_embouchure real
);


ALTER TABLE public.exp_station OWNER TO postgres;

--
-- Name: exp_trophique; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_trophique (
    id integer DEFAULT nextval(('"public"."exp_contenu_biologie_id_seq"'::text)::regclass) NOT NULL,
    exp_biologie_id integer NOT NULL,
    exp_contenu_id integer NOT NULL,
    quantite real
);


ALTER TABLE public.exp_trophique OWNER TO postgres;

--
-- Name: exp_vegetation; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_vegetation (
    id character varying(10) NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_vegetation OWNER TO postgres;

--
-- Name: pg_ts_cfg; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pg_ts_cfg (
    ts_name text NOT NULL,
    prs_name text NOT NULL,
    locale text
);


ALTER TABLE public.pg_ts_cfg OWNER TO postgres;

--
-- Name: pg_ts_cfgmap; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pg_ts_cfgmap (
    ts_name text NOT NULL,
    tok_alias text NOT NULL,
    dict_name text[]
);


ALTER TABLE public.pg_ts_cfgmap OWNER TO postgres;

--
-- Name: pg_ts_dict; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pg_ts_dict (
    dict_name text NOT NULL,
    dict_init regprocedure,
    dict_initoption text,
    dict_lexize regprocedure NOT NULL,
    dict_comment text
);


ALTER TABLE public.pg_ts_dict OWNER TO postgres;

--
-- Name: pg_ts_parser; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pg_ts_parser (
    prs_name text NOT NULL,
    prs_start regprocedure NOT NULL,
    prs_nexttoken regprocedure NOT NULL,
    prs_end regprocedure NOT NULL,
    prs_headline regprocedure NOT NULL,
    prs_lextype regprocedure NOT NULL,
    prs_comment text
);


ALTER TABLE public.pg_ts_parser OWNER TO postgres;

--
-- Name: ref_categorie_ecologique; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_categorie_ecologique (
    id character varying(10) NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.ref_categorie_ecologique OWNER TO postgres;

--
-- Name: ref_categorie_trophique; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_categorie_trophique (
    id character varying(10) NOT NULL,
    libelle character varying(100)
);


ALTER TABLE public.ref_categorie_trophique OWNER TO postgres;

--
-- Name: ref_espece; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_espece (
    id character varying(10) NOT NULL,
    libelle character varying(50),
    info character varying(255),
    ref_famille_id integer,
    ref_categorie_ecologique_id character varying(10),
    ref_categorie_trophique_id character varying(10),
    coefficient_k real,
    coefficient_b real,
    ref_origine_kb_id integer,
    ref_espece_id character varying(10)
);


ALTER TABLE public.ref_espece OWNER TO postgres;

--
-- Name: ref_famille; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_famille (
    id integer NOT NULL,
    libelle character varying(50),
    ref_ordre_id integer,
    non_poisson integer,
    CONSTRAINT ref_famille_non_poisson_check CHECK (((non_poisson = 0) OR (non_poisson = 1)))
);


ALTER TABLE public.ref_famille OWNER TO postgres;

--
-- Name: ref_famille_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_famille_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ref_famille_id_seq OWNER TO postgres;

--
-- Name: ref_famille_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_famille_id_seq', 1, false);


--
-- Name: ref_ordre; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_ordre (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.ref_ordre OWNER TO postgres;

--
-- Name: ref_ordre_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_ordre_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ref_ordre_id_seq OWNER TO postgres;

--
-- Name: ref_ordre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_ordre_id_seq', 1, false);


--
-- Name: ref_origine_kb; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_origine_kb (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.ref_origine_kb OWNER TO postgres;

--
-- Name: ref_secteur_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_secteur_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ref_secteur_id_seq OWNER TO postgres;

--
-- Name: ref_secteur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_secteur_id_seq', 1, false);


--
-- Name: ref_systeme_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_systeme_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ref_systeme_id_seq OWNER TO postgres;

--
-- Name: ref_systeme_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_systeme_id_seq', 1, false);


--
-- Name: sys_activites_a_migrer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sys_activites_a_migrer (
    pays character varying(10),
    systeme integer,
    secteur integer,
    agglomeration integer,
    activite_source integer,
    activite_cible integer,
    id serial NOT NULL,
    base_pays character varying(50)
);


ALTER TABLE public.sys_activites_a_migrer OWNER TO postgres;

--
-- Name: sys_activites_a_migrer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sys_activites_a_migrer', 'id'), 203, true);


--
-- Name: sys_campagnes_a_migrer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sys_campagnes_a_migrer (
    pays character varying(10),
    systeme integer,
    campagne_source bigint,
    campagne_cible bigint,
    id serial NOT NULL
);


ALTER TABLE public.sys_campagnes_a_migrer OWNER TO postgres;

--
-- Name: sys_campagnes_a_migrer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sys_campagnes_a_migrer', 'id'), 1, false);


--
-- Name: sys_debarquements_a_migrer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sys_debarquements_a_migrer (
    pays character varying(10),
    systeme integer,
    secteur integer,
    agglomeration integer,
    debarquement_source integer,
    debarquement_cible integer,
    id serial NOT NULL,
    base_pays character varying(50)
);


ALTER TABLE public.sys_debarquements_a_migrer OWNER TO postgres;

--
-- Name: sys_debarquements_a_migrer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sys_debarquements_a_migrer', 'id'), 83, true);


--
-- Name: sys_groupe_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sys_groupe_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sys_groupe_id_seq OWNER TO postgres;

--
-- Name: sys_groupe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sys_groupe_id_seq', 1, false);


--
-- Name: sys_periodes_enquete; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sys_periodes_enquete (
    id serial NOT NULL,
    pays_id character varying(10),
    systeme_id integer,
    secteur_id integer,
    agglomeration_id integer,
    date_debut date,
    date_fin date,
    base_pays character varying(50)
);


ALTER TABLE public.sys_periodes_enquete OWNER TO postgres;

--
-- Name: sys_periodes_enquete_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sys_periodes_enquete', 'id'), 4, true);


--
-- Name: sys_utilisateur_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sys_utilisateur_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sys_utilisateur_id_seq OWNER TO postgres;

--
-- Name: sys_utilisateur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sys_utilisateur_id_seq', 1, false);


--
-- Name: test_2a; Type: VIEW; Schema: public; Owner: devpechartexp
--

CREATE VIEW test_2a AS
    SELECT art_debarquement.code, art_debarquement.id, art_debarquement.mois, art_debarquement.art_grand_type_engin_id AS grdtyp, art_debarquement.poids_total AS pt, art_debarquement_rec.poids_total AS pt1, art_fraction.ref_espece_id AS esp, art_fraction.poids AS fdbq, art_fraction.nbre_poissons AS nfdbq, art_fraction_rec.poids AS fdbq1, art_fraction_rec.nbre_poissons AS nfdbq1 FROM art_debarquement, art_debarquement_rec, art_fraction, art_fraction_rec WHERE (((((art_fraction.art_debarquement_id = art_debarquement.id) AND ((art_debarquement.id)::text = (art_debarquement_rec.art_debarquement_id)::text)) AND ((art_fraction.id)::text = (art_fraction_rec.id)::text)) AND (art_debarquement.mois = 8)) AND ((art_fraction.ref_espece_id)::text = 'AOC'::text)) ORDER BY art_debarquement.code, art_fraction.ref_espece_id;


ALTER TABLE public.test_2a OWNER TO devpechartexp;

--
-- Name: test_2a1; Type: VIEW; Schema: public; Owner: devpechartexp
--

CREATE VIEW test_2a1 AS
    SELECT art_stat_sp.obs_sp_max AS pue_sp_max, art_stat_sp.obs_sp_min AS pue_sp_min, art_stat_sp.ref_espece_id, art_stat_sp.pue_sp_ecart_type, art_stat_sp.art_stat_totale_id, art_stat_sp.id, art_stat_sp.cap_sp, art_stat_sp.pue_sp FROM art_stat_sp WHERE (art_stat_sp.art_stat_totale_id = 2) ORDER BY art_stat_sp.ref_espece_id;


ALTER TABLE public.test_2a1 OWNER TO devpechartexp;

--
-- Name: test_somme; Type: VIEW; Schema: public; Owner: devpechartexp
--

CREATE VIEW test_somme AS
    SELECT art_stat_sp.art_stat_totale_id, sum(art_stat_sp.pue_sp) AS s1, sum(art_stat_sp.cap_sp) AS s2 FROM art_stat_sp GROUP BY art_stat_sp.art_stat_totale_id;


ALTER TABLE public.test_somme OWNER TO devpechartexp;

--
-- Data for Name: art_activite; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_activite VALUES (167, 3286, 63, 0, NULL, 0, '1994-08-03', 9, 1994, 7, 46302, 2, 2, 4, '233');
INSERT INTO art_activite VALUES (168, 3024, 63, 0, NULL, 0, '1994-08-03', 9, 1994, 7, 46303, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (169, 3032, 63, 2, 'FMDOm', 4, '1994-08-03', 9, 1994, 7, 46304, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (170, 3034, 63, 0, NULL, 0, '1994-08-03', 9, 1994, 7, 46305, 1, 0, 0, '233');
INSERT INTO art_activite VALUES (171, 3287, 63, 0, NULL, 0, '1994-08-03', 9, 1994, 7, 46306, 0, 0, 0, '900');
INSERT INTO art_activite VALUES (172, 2874, 63, 0, NULL, 0, '1994-08-03', 9, 1994, 7, 46307, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (173, 2880, 63, 0, NULL, 0, '1994-08-03', 9, 1994, 7, 46308, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (174, 3158, 63, 0, NULL, 0, '1994-08-03', 9, 1994, 7, 46309, 0, 0, 0, '900');
INSERT INTO art_activite VALUES (175, 3030, 63, 0, NULL, 0, '1994-08-03', 9, 1994, 7, 46310, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (176, 3286, 63, 2, 'EPERV', 4, '1994-08-04', 9, 1994, 7, 46311, 1, 1, 0, '111');
INSERT INTO art_activite VALUES (177, 3286, 63, 2, 'NASSE', 4, '1994-08-04', 9, 1994, 7, 46312, 0, 1, 1, '114');
INSERT INTO art_activite VALUES (178, 3024, 63, 0, NULL, 0, '1994-08-04', 9, 1994, 7, 46313, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (179, 3032, 63, 2, 'FMDOm', 4, '1994-08-04', 9, 1994, 7, 46314, 1, 0, 1, '111');
INSERT INTO art_activite VALUES (180, 3034, 63, 2, 'FMDOg', 4, '1994-08-04', 9, 1994, 7, 46315, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (181, 3287, 63, 2, 'FMDOm', 4, '1994-08-04', 9, 1994, 7, 46316, 1, 0, 1, '111');
INSERT INTO art_activite VALUES (182, 2874, 63, 2, 'FMDOg', 4, '1994-08-04', 9, 1994, 7, 46317, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (183, 2880, 63, 2, 'PALAN', 4, '1994-08-04', 9, 1994, 7, 46318, 1, 0, 1, '111');
INSERT INTO art_activite VALUES (184, 3158, 63, 2, 'PALAN', 4, '1994-08-04', 9, 1994, 7, 46319, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (185, 3030, 63, 2, 'PALAN', 4, '1994-08-04', 9, 1994, 7, 46320, 1, 0, 1, '111');
INSERT INTO art_activite VALUES (186, 3286, 63, 2, 'NASSE', 4, '1994-08-05', 9, 1994, 7, 46321, 0, 2, 0, '111');
INSERT INTO art_activite VALUES (187, 3024, 63, 0, NULL, 0, '1994-08-05', 9, 1994, 7, 46322, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (188, 3032, 63, 2, 'FMDOm', 4, '1994-08-05', 9, 1994, 7, 46323, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (189, 3034, 63, 2, 'FMDOg', 4, '1994-08-05', 9, 1994, 7, 46324, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (190, 3287, 63, 2, 'FMDOm', 4, '1994-08-05', 9, 1994, 7, 46325, 1, 0, 1, '111');
INSERT INTO art_activite VALUES (191, 2874, 63, 2, 'FMDOg', 4, '1994-08-05', 9, 1994, 7, 46326, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (192, 2880, 63, 0, NULL, 0, '1994-08-05', 9, 1994, 7, 46327, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (193, 3158, 63, 2, 'PALAN', 4, '1994-08-05', 9, 1994, 7, 46328, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (194, 3030, 63, 2, 'PALAN', 4, '1994-08-05', 9, 1994, 7, 46329, 1, 0, 1, '111');
INSERT INTO art_activite VALUES (195, 3286, 63, 0, NULL, 0, '1994-08-06', 9, 1994, 7, 46330, 1, 0, 3, '233');
INSERT INTO art_activite VALUES (196, 3024, 63, 0, NULL, 0, '1994-08-06', 9, 1994, 7, 46331, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (197, 3032, 63, 2, 'FMDOm', 4, '1994-08-06', 9, 1994, 7, 46332, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (198, 3034, 63, 0, NULL, 0, '1994-08-06', 9, 1994, 7, 46333, 1, 0, 0, '233');
INSERT INTO art_activite VALUES (199, 3287, 63, 2, 'FMDOm', 4, '1994-08-06', 9, 1994, 7, 46334, 1, 0, 1, '111');
INSERT INTO art_activite VALUES (200, 2874, 63, 2, 'FMDOg', 4, '1994-08-06', 9, 1994, 7, 46335, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (201, 2880, 63, 2, 'PALAN', 4, '1994-08-06', 9, 1994, 7, 46336, 1, 0, 1, '111');
INSERT INTO art_activite VALUES (202, 3158, 63, 0, NULL, 0, '1994-08-06', 9, 1994, 7, 46337, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (203, 3030, 63, 0, NULL, 0, '1994-08-06', 9, 1994, 7, 46338, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (110, 3286, 63, 2, 'NASSE', 4, '1994-08-29', 9, 1994, 8, 46339, 0, 2, 0, '111');
INSERT INTO art_activite VALUES (111, 3024, 63, 2, 'SE_PL', 4, '1994-08-29', 9, 1994, 8, 46340, 7, 3, 0, '111');
INSERT INTO art_activite VALUES (112, 3032, 63, 2, 'FMDO', 4, '1994-08-29', 9, 1994, 8, 46341, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (113, 3034, 63, 2, 'SE_PL', 4, '1994-08-29', 9, 1994, 8, 46342, 6, 4, 0, '111');
INSERT INTO art_activite VALUES (114, 3287, 63, 2, 'FMDOm', 4, '1994-08-29', 9, 1994, 8, 46343, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (115, 2874, 63, 0, NULL, 0, '1994-08-29', 9, 1994, 8, 46344, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (116, 2880, 63, 0, NULL, 0, '1994-08-29', 9, 1994, 8, 46345, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (117, 3158, 63, 2, 'PALAN', 4, '1994-08-29', 9, 1994, 8, 46346, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (118, 3030, 63, 2, 'PALAN', 4, '1994-08-29', 9, 1994, 8, 46347, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (119, 3286, 63, 2, 'NASSE', 4, '1994-08-30', 9, 1994, 8, 46348, 0, 2, 0, '111');
INSERT INTO art_activite VALUES (120, 3024, 63, 2, 'SE_PL', 4, '1994-08-30', 9, 1994, 8, 46349, 7, 3, 0, '111');
INSERT INTO art_activite VALUES (121, 3032, 63, 2, 'FMDO', 4, '1994-08-30', 9, 1994, 8, 46350, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (122, 3034, 63, 2, 'SE_PL', 4, '1994-08-30', 9, 1994, 8, 46351, 6, 4, 0, '111');
INSERT INTO art_activite VALUES (123, 3287, 63, 2, 'FMDOm', 4, '1994-08-30', 9, 1994, 8, 46352, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (124, 2874, 63, 0, NULL, 0, '1994-08-30', 9, 1994, 8, 46353, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (125, 2880, 63, 2, 'PALAN', 4, '1994-08-30', 9, 1994, 8, 46354, 3, 0, 0, '111');
INSERT INTO art_activite VALUES (126, 3158, 63, 2, 'PALAN', 4, '1994-08-30', 9, 1994, 8, 46355, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (127, 3030, 63, 0, NULL, 0, '1994-08-30', 9, 1994, 8, 46356, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (128, 3286, 63, 2, 'NASSE', 4, '1994-08-31', 9, 1994, 8, 46357, 0, 2, 0, '111');
INSERT INTO art_activite VALUES (129, 3024, 63, 2, 'SE_PL', 4, '1994-08-31', 9, 1994, 8, 46358, 7, 3, 0, '111');
INSERT INTO art_activite VALUES (130, 3032, 63, 2, 'FMDO', 4, '1994-08-31', 9, 1994, 8, 46359, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (131, 3034, 63, 2, 'SE_PL', 4, '1994-08-31', 9, 1994, 8, 46360, 6, 4, 0, '111');
INSERT INTO art_activite VALUES (132, 3287, 63, 2, 'FMDOm', 4, '1994-08-31', 9, 1994, 8, 46361, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (133, 2874, 63, 0, NULL, 0, '1994-08-31', 9, 1994, 8, 46362, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (134, 2880, 63, 2, 'PALAN', 4, '1994-08-31', 9, 1994, 8, 46363, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (135, 2880, 63, 2, 'PALAN', 4, '1994-08-31', 9, 1994, 8, 46364, 1, 0, 0, '114');
INSERT INTO art_activite VALUES (136, 3158, 63, 2, 'PALAN', 4, '1994-08-31', 9, 1994, 8, 46365, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (137, 3158, 63, 2, 'PALAN', 4, '1994-08-31', 9, 1994, 8, 46366, 2, 0, 0, '114');
INSERT INTO art_activite VALUES (138, 3030, 63, 2, 'PALAN', 4, '1994-08-31', 9, 1994, 8, 46367, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (139, 3286, 63, 2, 'NASSE', 4, '1994-09-01', 9, 1994, 8, 46368, 0, 1, 0, '111');
INSERT INTO art_activite VALUES (140, 3024, 63, 2, 'SE_PL', 4, '1994-09-01', 9, 1994, 8, 46369, 6, 4, 0, '111');
INSERT INTO art_activite VALUES (141, 3032, 63, 2, 'SE_PL', 4, '1994-09-01', 9, 1994, 8, 46370, 4, 2, 0, '111');
INSERT INTO art_activite VALUES (142, 3034, 63, 2, 'SE_PL', 4, '1994-09-01', 9, 1994, 8, 46371, 7, 5, 0, '111');
INSERT INTO art_activite VALUES (143, 3287, 63, 2, 'FMDOm', 4, '1994-09-01', 9, 1994, 8, 46372, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (144, 2874, 63, 0, NULL, 0, '1994-09-01', 9, 1994, 8, 46373, 0, 8, 1, '320');
INSERT INTO art_activite VALUES (145, 2880, 63, 0, NULL, 0, '1994-09-01', 9, 1994, 8, 46374, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (146, 3158, 63, 2, 'PALAN', 4, '1994-09-01', 9, 1994, 8, 46375, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (147, 3158, 63, 2, 'PALAN', 4, '1994-09-01', 9, 1994, 8, 46376, 2, 0, 0, '114');
INSERT INTO art_activite VALUES (148, 3030, 63, 2, 'PALAN', 4, '1994-09-01', 9, 1994, 8, 46377, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (149, 3286, 63, 2, 'NASSE', 4, '1994-09-02', 9, 1994, 8, 46378, 0, 1, 0, '111');
INSERT INTO art_activite VALUES (150, 3024, 63, 2, 'SE_PL', 4, '1994-09-02', 9, 1994, 8, 46379, 6, 4, 0, '111');
INSERT INTO art_activite VALUES (151, 3032, 63, 2, 'SE_PL', 4, '1994-09-02', 9, 1994, 8, 46380, 6, 3, 0, '111');
INSERT INTO art_activite VALUES (152, 3034, 63, 2, 'SE_PL', 4, '1994-09-02', 9, 1994, 8, 46381, 8, 4, 0, '111');
INSERT INTO art_activite VALUES (153, 3287, 63, 2, 'FMDOm', 4, '1994-09-02', 9, 1994, 8, 46382, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (154, 2874, 63, 0, NULL, 0, '1994-09-02', 9, 1994, 8, 46383, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (155, 2880, 63, 2, 'PALAN', 4, '1994-09-02', 9, 1994, 8, 46384, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (156, 3158, 63, 2, 'PALAN', 4, '1994-09-02', 9, 1994, 8, 46385, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (157, 3030, 63, 2, 'PALAN', 4, '1994-09-02', 9, 1994, 8, 46386, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (158, 3286, 63, 2, 'NASSE', 4, '1994-09-03', 9, 1994, 8, 46387, 0, 1, 0, '111');
INSERT INTO art_activite VALUES (159, 3024, 63, 2, 'SE_PL', 4, '1994-09-03', 9, 1994, 8, 46388, 6, 4, 0, '111');
INSERT INTO art_activite VALUES (160, 3032, 63, 2, 'SE_PL', 4, '1994-09-03', 9, 1994, 8, 46389, 6, 3, 0, '111');
INSERT INTO art_activite VALUES (161, 3034, 63, 2, 'SE_PL', 4, '1994-09-03', 9, 1994, 8, 46390, 8, 4, 0, '111');
INSERT INTO art_activite VALUES (162, 3287, 63, 2, 'FMDOm', 4, '1994-09-03', 9, 1994, 8, 46391, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (163, 2874, 63, 0, NULL, 0, '1994-09-03', 9, 1994, 8, 46392, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (164, 2880, 63, 0, NULL, 0, '1994-09-03', 9, 1994, 8, 46393, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (165, 3158, 63, 2, 'PALAN', 4, '1994-09-03', 9, 1994, 8, 46394, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (166, 3030, 63, 0, NULL, 0, '1994-09-03', 9, 1994, 8, 46395, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (55, 3286, 63, 0, NULL, 0, '1994-09-26', 9, 1994, 9, 46396, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (56, 3024, 63, 2, 'SE_PL', 4, '1994-09-26', 9, 1994, 9, 46397, 6, 5, 0, '111');
INSERT INTO art_activite VALUES (57, 3032, 63, 2, 'SE_PL', 4, '1994-09-26', 9, 1994, 9, 46398, 6, 3, 0, '111');
INSERT INTO art_activite VALUES (58, 3034, 63, 2, 'SE_PL', 4, '1994-09-26', 9, 1994, 9, 46399, 9, 6, 0, '111');
INSERT INTO art_activite VALUES (59, 3287, 63, 2, 'FMCL', 4, '1994-09-26', 9, 1994, 9, 46400, 2, 0, 1, '111');
INSERT INTO art_activite VALUES (60, 2874, 63, 0, NULL, 0, '1994-09-26', 9, 1994, 9, 46401, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (61, 2880, 63, 0, NULL, 0, '1994-09-26', 9, 1994, 9, 46402, 9, 9, 9, '231');
INSERT INTO art_activite VALUES (62, 3158, 63, 2, 'PALAN', 4, '1994-09-26', 9, 1994, 9, 46403, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (63, 3030, 63, 2, 'PALAN', 4, '1994-09-26', 9, 1994, 9, 46404, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (64, 3286, 63, 0, NULL, 0, '1994-09-27', 9, 1994, 9, 46405, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (65, 3024, 63, 2, 'SE_PL', 4, '1994-09-27', 9, 1994, 9, 46406, 6, 5, 0, '111');
INSERT INTO art_activite VALUES (66, 3032, 63, 2, 'SE_PL', 4, '1994-09-27', 9, 1994, 9, 46407, 6, 3, 0, '111');
INSERT INTO art_activite VALUES (67, 3034, 63, 2, 'SE_PL', 4, '1994-09-27', 9, 1994, 9, 46408, 9, 6, 0, '111');
INSERT INTO art_activite VALUES (68, 3287, 63, 2, 'FMCL', 4, '1994-09-27', 9, 1994, 9, 46409, 2, 0, 1, '111');
INSERT INTO art_activite VALUES (69, 2874, 63, 0, NULL, 0, '1994-09-27', 9, 1994, 9, 46410, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (70, 2880, 63, 2, 'PALAN', 4, '1994-09-27', 9, 1994, 9, 46411, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (71, 3158, 63, 2, 'PALAN', 4, '1994-09-27', 9, 1994, 9, 46412, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (72, 3030, 63, 2, 'PALAN', 4, '1994-09-27', 9, 1994, 9, 46413, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (73, 3286, 63, 0, NULL, 0, '1994-09-28', 9, 1994, 9, 46414, 0, 9, 2, '320');
INSERT INTO art_activite VALUES (74, 3024, 63, 2, 'SE_PL', 4, '1994-09-28', 9, 1994, 9, 46415, 6, 5, 0, '111');
INSERT INTO art_activite VALUES (75, 3032, 63, 2, 'SE_PL', 4, '1994-09-28', 9, 1994, 9, 46416, 6, 3, 0, '111');
INSERT INTO art_activite VALUES (76, 3034, 63, 2, 'SE_PL', 4, '1994-09-28', 9, 1994, 9, 46417, 9, 6, 0, '111');
INSERT INTO art_activite VALUES (77, 3287, 63, 2, 'FMDOm', 4, '1994-09-28', 9, 1994, 9, 46418, 1, 0, 1, '111');
INSERT INTO art_activite VALUES (78, 2874, 63, 0, NULL, 0, '1994-09-28', 9, 1994, 9, 46419, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (79, 2880, 63, 0, NULL, 0, '1994-09-28', 9, 1994, 9, 46420, 9, 9, 9, '231');
INSERT INTO art_activite VALUES (80, 3158, 63, 2, 'PALAN', 4, '1994-09-28', 9, 1994, 9, 46421, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (81, 3030, 63, 2, 'PALAN', 4, '1994-09-28', 9, 1994, 9, 46422, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (82, 3286, 63, 2, 'NASSE', 4, '1994-09-29', 9, 1994, 9, 46423, 0, 1, 0, '111');
INSERT INTO art_activite VALUES (83, 3024, 63, 2, 'SE_PL', 4, '1994-09-29', 9, 1994, 9, 46424, 6, 5, 0, '111');
INSERT INTO art_activite VALUES (84, 3032, 63, 2, 'SE_PL', 4, '1994-09-29', 9, 1994, 9, 46425, 6, 3, 0, '111');
INSERT INTO art_activite VALUES (85, 3034, 63, 2, 'SE_PL', 4, '1994-09-29', 9, 1994, 9, 46426, 9, 6, 0, '111');
INSERT INTO art_activite VALUES (86, 3287, 63, 2, 'FMCL', 4, '1994-09-29', 9, 1994, 9, 46427, 2, 0, 1, '111');
INSERT INTO art_activite VALUES (87, 2874, 63, 0, NULL, 0, '1994-09-29', 9, 1994, 9, 46428, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (88, 2880, 63, 2, 'PALAN', 4, '1994-09-29', 9, 1994, 9, 46429, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (89, 3158, 63, 2, 'PALAN', 4, '1994-09-29', 9, 1994, 9, 46430, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (90, 3030, 63, 2, 'PALAN', 4, '1994-09-29', 9, 1994, 9, 46431, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (91, 3286, 63, 0, NULL, 0, '1994-09-30', 9, 1994, 9, 46432, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (92, 3024, 63, 2, 'SE_PL', 4, '1994-09-30', 9, 1994, 9, 46433, 6, 5, 0, '111');
INSERT INTO art_activite VALUES (93, 3032, 63, 2, 'SE_PL', 4, '1994-09-30', 9, 1994, 9, 46434, 6, 3, 0, '111');
INSERT INTO art_activite VALUES (94, 3034, 63, 2, 'SE_PL', 4, '1994-09-30', 9, 1994, 9, 46435, 8, 6, 0, '111');
INSERT INTO art_activite VALUES (95, 3287, 63, 2, 'FMCL', 4, '1994-09-30', 9, 1994, 9, 46436, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (96, 2874, 63, 0, NULL, 0, '1994-09-30', 9, 1994, 9, 46437, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (97, 2880, 63, 2, 'PALAN', 4, '1994-09-30', 9, 1994, 9, 46438, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (98, 3158, 63, 2, 'PALAN', 4, '1994-09-30', 9, 1994, 9, 46439, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (99, 3030, 63, 2, 'PALAN', 4, '1994-09-30', 9, 1994, 9, 46440, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (100, 3286, 63, 2, 'NASSE', 4, '1994-10-01', 9, 1994, 9, 46441, 0, 1, 0, '111');
INSERT INTO art_activite VALUES (101, 3024, 63, 2, 'SE_PL', 4, '1994-10-01', 9, 1994, 9, 46442, 6, 5, 0, '111');
INSERT INTO art_activite VALUES (102, 3032, 63, 2, 'SE_PL', 4, '1994-10-01', 9, 1994, 9, 46443, 6, 3, 0, '111');
INSERT INTO art_activite VALUES (103, 3034, 63, 2, 'SE_PL', 4, '1994-10-01', 9, 1994, 9, 46444, 8, 6, 0, '111');
INSERT INTO art_activite VALUES (104, 3287, 63, 2, 'FMDOm', 4, '1994-10-01', 9, 1994, 9, 46445, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (105, 2874, 63, 0, NULL, 0, '1994-10-01', 9, 1994, 9, 46446, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (106, 2880, 63, 2, 'PALAN', 4, '1994-10-01', 9, 1994, 9, 46447, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (107, 2880, 63, 2, 'PALAN', 4, '1994-10-01', 9, 1994, 9, 46448, 1, 0, 0, '114');
INSERT INTO art_activite VALUES (108, 3158, 63, 2, 'PALAN', 4, '1994-10-01', 9, 1994, 9, 46449, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (109, 3030, 63, 2, 'PALAN', 4, '1994-10-01', 9, 1994, 9, 46450, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (1, 3286, 63, 0, NULL, 0, '1994-10-17', 9, 1994, 10, 46451, 9, 9, 9, '233');
INSERT INTO art_activite VALUES (2, 3024, 63, 2, 'SE_PL', 4, '1994-10-17', 9, 1994, 10, 46452, 5, 4, 0, '111');
INSERT INTO art_activite VALUES (3, 3032, 63, 2, 'SE_PL', 4, '1994-10-17', 9, 1994, 10, 46453, 6, 4, 0, '111');
INSERT INTO art_activite VALUES (4, 3034, 63, 2, 'SE_PL', 4, '1994-10-17', 9, 1994, 10, 46454, 7, 6, 0, '111');
INSERT INTO art_activite VALUES (5, 3287, 63, 2, 'FMDOm', 4, '1994-10-17', 9, 1994, 10, 46455, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (6, 2874, 63, 0, NULL, 0, '1994-10-17', 9, 1994, 10, 46456, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (7, 2880, 63, 2, 'PALAN', 4, '1994-10-17', 9, 1994, 10, 46457, 1, 0, 0, '111');
INSERT INTO art_activite VALUES (8, 3158, 63, 2, 'PALAN', 4, '1994-10-17', 9, 1994, 10, 46458, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (9, 3030, 63, 2, 'PALAN', 4, '1994-10-17', 9, 1994, 10, 46459, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (10, 3286, 63, 0, NULL, 0, '1994-10-18', 9, 1994, 10, 46460, 9, 9, 9, '233');
INSERT INTO art_activite VALUES (11, 3024, 63, 2, 'SE_PL', 4, '1994-10-18', 9, 1994, 10, 46461, 5, 4, 0, '111');
INSERT INTO art_activite VALUES (12, 3032, 63, 2, 'SE_PL', 4, '1994-10-18', 9, 1994, 10, 46462, 6, 4, 0, '111');
INSERT INTO art_activite VALUES (13, 3034, 63, 2, 'SE_PL', 4, '1994-10-18', 9, 1994, 10, 46463, 7, 6, 0, '111');
INSERT INTO art_activite VALUES (14, 3287, 63, 2, 'FMDOm', 4, '1994-10-18', 9, 1994, 10, 46464, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (15, 2874, 63, 0, NULL, 0, '1994-10-18', 9, 1994, 10, 46465, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (16, 2880, 63, 2, 'PALAN', 4, '1994-10-18', 9, 1994, 10, 46466, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (17, 3158, 63, 2, 'PALAN', 4, '1994-10-18', 9, 1994, 10, 46467, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (18, 3030, 63, 0, NULL, 0, '1994-10-18', 9, 1994, 10, 46468, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (19, 3286, 63, 0, NULL, 0, '1994-10-19', 9, 1994, 10, 46469, 9, 9, 9, '233');
INSERT INTO art_activite VALUES (20, 3024, 63, 2, 'SE_PL', 4, '1994-10-19', 9, 1994, 10, 46470, 5, 4, 0, '111');
INSERT INTO art_activite VALUES (21, 3032, 63, 2, 'SE_PL', 4, '1994-10-19', 9, 1994, 10, 46471, 6, 4, 0, '111');
INSERT INTO art_activite VALUES (22, 3034, 63, 2, 'SE_PL', 4, '1994-10-19', 9, 1994, 10, 46472, 7, 6, 0, '111');
INSERT INTO art_activite VALUES (23, 3287, 63, 2, 'FMDOm', 4, '1994-10-19', 9, 1994, 10, 46473, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (24, 2874, 63, 0, NULL, 0, '1994-10-19', 9, 1994, 10, 46474, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (25, 2880, 63, 0, NULL, 0, '1994-10-19', 9, 1994, 10, 46475, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (26, 3158, 63, 2, 'PALAN', 4, '1994-10-19', 9, 1994, 10, 46476, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (27, 3030, 63, 2, 'PALAN', 4, '1994-10-19', 9, 1994, 10, 46477, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (28, 3286, 63, 0, NULL, 0, '1994-10-20', 9, 1994, 10, 46478, 9, 9, 9, '233');
INSERT INTO art_activite VALUES (29, 3024, 63, 2, 'SE_PL', 4, '1994-10-20', 9, 1994, 10, 46479, 5, 4, 0, '111');
INSERT INTO art_activite VALUES (30, 3032, 63, 2, 'SE_PL', 4, '1994-10-20', 9, 1994, 10, 46480, 6, 4, 0, '111');
INSERT INTO art_activite VALUES (31, 3034, 63, 2, 'SE_PL', 4, '1994-10-20', 9, 1994, 10, 46481, 7, 6, 0, '111');
INSERT INTO art_activite VALUES (32, 3287, 63, 2, 'FMDOm', 4, '1994-10-20', 9, 1994, 10, 46482, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (33, 2874, 63, 0, NULL, 0, '1994-10-20', 9, 1994, 10, 46483, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (34, 2880, 63, 0, NULL, 0, '1994-10-20', 9, 1994, 10, 46484, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (35, 3158, 63, 0, NULL, 0, '1994-10-20', 9, 1994, 10, 46485, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (36, 3030, 63, 2, 'PALAN', 4, '1994-10-20', 9, 1994, 10, 46486, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (37, 3286, 63, 0, NULL, 0, '1994-10-21', 9, 1994, 10, 46487, 9, 9, 9, '233');
INSERT INTO art_activite VALUES (38, 3024, 63, 2, 'SE_PL', 4, '1994-10-21', 9, 1994, 10, 46488, 5, 3, 0, '111');
INSERT INTO art_activite VALUES (39, 3032, 63, 2, 'SE_PL', 4, '1994-10-21', 9, 1994, 10, 46489, 6, 4, 0, '111');
INSERT INTO art_activite VALUES (40, 3034, 63, 2, 'SE_PL', 4, '1994-10-21', 9, 1994, 10, 46490, 7, 6, 0, '111');
INSERT INTO art_activite VALUES (41, 3287, 63, 2, 'FMDOm', 4, '1994-10-21', 9, 1994, 10, 46491, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (42, 2874, 63, 0, NULL, 0, '1994-10-21', 9, 1994, 10, 46492, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (43, 2880, 63, 0, NULL, 0, '1994-10-21', 9, 1994, 10, 46493, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (44, 3158, 63, 2, 'PALAN', 4, '1994-10-21', 9, 1994, 10, 46494, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (45, 3030, 63, 2, 'PALAN', 4, '1994-10-21', 9, 1994, 10, 46495, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (46, 3286, 63, 0, NULL, 0, '1994-10-22', 9, 1994, 10, 46496, 9, 9, 9, '233');
INSERT INTO art_activite VALUES (47, 3024, 63, 2, 'SE_PL', 4, '1994-10-22', 9, 1994, 10, 46497, 5, 3, 0, '111');
INSERT INTO art_activite VALUES (48, 3032, 63, 0, NULL, 0, '1994-10-22', 9, 1994, 10, 46498, 9, 9, 9, '220');
INSERT INTO art_activite VALUES (49, 3034, 63, 0, NULL, 0, '1994-10-22', 9, 1994, 10, 46499, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (50, 3287, 63, 2, 'FMDOm', 4, '1994-10-22', 9, 1994, 10, 46500, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (51, 2874, 63, 0, NULL, 0, '1994-10-22', 9, 1994, 10, 46501, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (52, 2880, 63, 0, NULL, 0, '1994-10-22', 9, 1994, 10, 46502, 9, 9, 9, '320');
INSERT INTO art_activite VALUES (53, 3158, 63, 2, 'PALAN', 4, '1994-10-22', 9, 1994, 10, 46503, 2, 0, 0, '111');
INSERT INTO art_activite VALUES (54, 3030, 63, 2, 'NASSE', 4, '1994-10-22', 9, 1994, 10, 46504, 0, 1, 0, '111');


--
-- Data for Name: art_agglomeration; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_agglomeration VALUES (1, 0, 1, 'Inconnu', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (2, 2, 14, 'Salengou', '13:10:46', '010:18:59', NULL);
INSERT INTO art_agglomeration VALUES (3, 2, 14, 'Kerwane daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (4, 2, 14, 'Nigui', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (5, 2, 15, 'Kita daga', '13:02:76', '010:17:76', 'Visite mission 10 2001');
INSERT INTO art_agglomeration VALUES (6, 2, 15, 'Ladji', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (7, 2, 15, 'Tentible', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (8, 2, 16, 'Drame', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (9, 2, 16, 'Ngougny daga', '12:56:39', '010:15:96', NULL);
INSERT INTO art_agglomeration VALUES (10, 2, 16, 'Sebekoro daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (14, 1, 8, 'Barikondaga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (15, 3, 8, 'Batamani daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (16, 2, 8, 'Boumana daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (17, 1, 8, 'Camara daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (18, 0, 8, 'Galacine daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (19, 3, 8, 'Kemien daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (20, 1, 8, 'Kotaka', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (21, 2, 8, 'Koubi daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (22, 1, 8, 'Kumara daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (23, 0, 8, 'Mamadou daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (24, 3, 8, 'Mierou daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (25, 0, 8, 'Mopti hinde', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (26, 0, 8, 'Nambara daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (27, 1, 8, 'Nimitogo', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (28, 0, 8, 'Nouh-bozo', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (29, 0, 8, 'Ouromodi daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (30, 0, 8, 'Sahona', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (31, 0, 8, 'Tebena', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (32, 2, 8, 'Toala daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (33, 1, 8, 'Touala', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (34, 0, 8, 'Welibana', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (35, 2, 9, 'Chouery daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (36, 2, 9, 'Diokore daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (37, 1, 9, 'Komba diamla', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (38, 1, 9, 'Kuara', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (39, 0, 9, 'Mountou daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (40, 1, 9, 'Tomina', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (41, 2, 9, 'Wu daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (42, 3, 10, 'Idourou boly', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (43, 1, 10, 'Kakagnan', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (44, 2, 10, 'Kinieye daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (45, 2, 10, 'M bouba n diam', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (46, 3, 10, 'Pinguina daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (47, 2, 10, 'Sinde daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (48, 1, 11, 'Ankoye', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (49, 1, 11, 'Dissore', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (50, 3, 11, 'Dounde wendou', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (51, 1, 11, 'Gourao bozo', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (52, 3, 11, 'Mayo saore', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (53, 2, 11, 'Sagoye', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (54, 3, 12, 'Bougouberi daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (55, 2, 12, 'Daga toga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (56, 1, 12, 'Gunanbougou', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (57, 2, 13, 'Arabebe daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (58, 3, 13, 'Dyoma', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (59, 2, 13, 'Gamou daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (60, 1, 13, 'Gindigata nare', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (61, 3, 13, 'Mekore daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (62, 1, 13, 'Sebi', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (63, 2, 18, 'Bourlaye', '11:32:47', '008:11:24', NULL);
INSERT INTO art_agglomeration VALUES (64, 2, 18, 'Bozola', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (65, 1, 18, 'Carriere', '11:37:05', '008:11:53', NULL);
INSERT INTO art_agglomeration VALUES (66, 2, 19, 'Banando', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (67, 2, 19, 'Bugoudale', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (68, 2, 19, 'Faraba', '11:22:85', '008:18:58', NULL);
INSERT INTO art_agglomeration VALUES (69, 2, 19, 'Kabaya', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (70, 2, 19, 'Komana', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (71, 2, 19, 'Kona', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (72, 2, 20, 'Dossola', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (73, 2, 20, 'Goualafara', '11:18:19', '008:10:00', NULL);
INSERT INTO art_agglomeration VALUES (74, 2, 20, 'Kangare', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (75, 2, 20, 'Sodala', '11:23:09', '008:09:69', NULL);
INSERT INTO art_agglomeration VALUES (76, 2, 20, 'Soumaila', '11:30:71', '008:10:49', NULL);
INSERT INTO art_agglomeration VALUES (77, 1, 6, 'Nigui assoko', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (78, 1, 6, 'Nigui assa', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (79, 1, 6, 'Boubo', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (80, 2, 7, 'Tefredji', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (81, 2, 6, 'Tiebiessou', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (82, 2, 6, 'Ahikakro', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (83, 1, 7, 'Azan', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (84, 1, 7, 'Tiagba', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (86, 1, 6, 'Abraco', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (87, 2, 6, 'Atoutou a', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (88, 2, 7, 'N`goume', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (89, 2, 6, 'Atoutou b', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (90, 2, 4, 'Vridi', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (91, 1, 21, 'Amedehoueve', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (94, 1, 6, 'N`goyem', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (96, 1, 21, 'Sevatonou', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (97, 1, 22, 'Agbodrafo', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (98, 1, 22, 'Bagoudbe', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (99, 1, 21, 'Afidenyigban', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (100, 1, 22, 'Aneho', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (102, 1, 21, 'Sevatono', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (103, 2, 19, 'Tiemba', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (104, 2, 19, 'Tagankoro', '11:28:43', '008:17:55', NULL);
INSERT INTO art_agglomeration VALUES (106, 2, 20, 'Kolinda', '11:30:62', '008:05:64', NULL);
INSERT INTO art_agglomeration VALUES (107, 2, 20, 'Babougou', '11:27:45', '008:07:59', NULL);
INSERT INTO art_agglomeration VALUES (108, 1, 23, 'Barra', '13:29:11', '016:32:88', NULL);
INSERT INTO art_agglomeration VALUES (109, 1, 25, 'Ballingo', '13:29:30', '015:35:92', NULL);
INSERT INTO art_agglomeration VALUES (110, 1, 25, 'Jappeni', '13:27:33', '015:26:64', NULL);
INSERT INTO art_agglomeration VALUES (111, 1, 25, 'Kanikunda', '13:32:90', '015:22:47', NULL);
INSERT INTO art_agglomeration VALUES (112, 1, 24, 'Tendaba', '13:26:40', '015:48:47', NULL);
INSERT INTO art_agglomeration VALUES (113, 1, 24, 'Tankular', '13:25:12', '016:02:08', NULL);
INSERT INTO art_agglomeration VALUES (114, 1, 24, 'Kerewan', '13:29:86', '016:06:06', NULL);
INSERT INTO art_agglomeration VALUES (115, 1, 24, 'Bintang', '13:15:04', '016:12:66', NULL);
INSERT INTO art_agglomeration VALUES (116, 1, 23, 'Albreda', '13:19:97', '016:23:10', NULL);
INSERT INTO art_agglomeration VALUES (117, 1, 23, 'Pirang', '13:16:69', '016:31:05', NULL);
INSERT INTO art_agglomeration VALUES (118, 1, 23, 'Toubakolong', '13:20:01', '016:23:10', NULL);
INSERT INTO art_agglomeration VALUES (119, 2, 15, 'Adou', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (120, 2, 15, 'Burkina daga', '13:00:01', '010:23:37', 'Campement � 500m du point GPS');
INSERT INTO art_agglomeration VALUES (121, 2, 15, 'Mama', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (122, 1, 14, 'Manantali', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (123, 2, 14, 'Fryakoro', '13:12:45', '010:15:04', NULL);
INSERT INTO art_agglomeration VALUES (124, 2, 16, 'Lassina daga', '12:57:48', '010:16:41', NULL);
INSERT INTO art_agglomeration VALUES (125, 2, 16, 'Bokadary daga', '12:57:96', '010:16:50', NULL);
INSERT INTO art_agglomeration VALUES (126, 2, 15, 'Soumana daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (127, 2, 15, 'Dukankono ', '13:05:69', '010:17:97', NULL);
INSERT INTO art_agglomeration VALUES (128, 2, 14, 'Woclogoun', '13:14:41', '010:24:41', NULL);
INSERT INTO art_agglomeration VALUES (129, 3, 16, 'Kemba daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (130, 3, 16, 'Samai Ladji daga', '12:58:81', '010:19:19', NULL);
INSERT INTO art_agglomeration VALUES (132, 2, 20, 'Aoure daga', '11:26:49', '008:09:46', NULL);
INSERT INTO art_agglomeration VALUES (133, 2, 20, 'Sourakata daga', '11:29:91', '008:07:77', NULL);
INSERT INTO art_agglomeration VALUES (134, 2, 20, 'Dolen daga', '11:25:70', '008:10:34', NULL);
INSERT INTO art_agglomeration VALUES (135, 2, 20, 'Sodala koro', '11:21:15', '008:10:14', NULL);
INSERT INTO art_agglomeration VALUES (136, 2, 20, 'Dadie daga', '11:22:09', '008:09:87', NULL);
INSERT INTO art_agglomeration VALUES (137, 2, 19, 'Sagnoumale I', '11:22:28', '008:21:77', NULL);
INSERT INTO art_agglomeration VALUES (138, 2, 19, 'Sagnoumale II', '11:22:12', '008:25:51', NULL);
INSERT INTO art_agglomeration VALUES (139, 2, 19, 'Sagnoumale III', '11:20:89', '008:23:89', NULL);
INSERT INTO art_agglomeration VALUES (140, 2, 19, 'Sagnoumale IV', '11:19:82', '008:22:81', NULL);
INSERT INTO art_agglomeration VALUES (141, 2, 19, 'Faraba Koro daga', '11:23:17', '008:17:43', NULL);
INSERT INTO art_agglomeration VALUES (142, 2, 19, 'Kakaye daga', '11:26:01', '008:15:49', NULL);
INSERT INTO art_agglomeration VALUES (143, 2, 19, 'Nagui daga', '11:28:57', '008:15:28', NULL);
INSERT INTO art_agglomeration VALUES (144, 2, 18, 'Kouroubleni daga', '11:32:32', '008:13:48', NULL);
INSERT INTO art_agglomeration VALUES (145, 2, 18, 'Daforo daga', '11:33:26', '008:14:21', NULL);
INSERT INTO art_agglomeration VALUES (146, 1, 18, 'Carriere 2', '11:37:05', '008:11:53', 'Village de Carriere enquete 2 fois par mois au cours de la periode 11-2002 a 05-200"');
INSERT INTO art_agglomeration VALUES (147, 1, 26, 'Djinack', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (148, 1, 26, 'Missirah', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (149, 1, 26, 'Kathior', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (150, 1, 27, 'Ndangane fali', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (151, 1, 27, 'Nemaba', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (152, 1, 27, 'Toubacouta', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (153, 1, 27, 'Soukouta', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (154, 1, 28, 'Sokone', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (155, 1, 28, 'Ndjoundiou', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (156, 1, 29, 'Babandiane', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (157, 1, 30, 'Djifere', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (158, 1, 30, 'Ndangane sambou', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (159, 1, 31, 'Djirnda', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (160, 1, 32, 'Baout', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (161, 1, 32, 'Foundiougne', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (162, 1, 33, 'Kaolack', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (163, 1, 33, 'Lindiane', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (164, 1, 30, 'Sangomar', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (165, 1, 30, 'Dionewar', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (166, 1, 31, 'Fambine', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (167, 1, 32, 'Felir', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (168, 1, 26, 'Bandiala', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (169, 1, 27, 'Sipo', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (170, 1, 27, 'Dassilame', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (171, 1, 27, 'Medina sangako', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (172, 1, 28, 'Bangalere', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (173, 1, 28, 'Bambougar malick', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (174, 1, 29, 'Bossingkang', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (175, 1, 29, 'Betanti', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (176, 1, 29, 'Diofandor', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (177, 1, 29, 'Diogane', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (178, 1, 29, 'Bakhalou', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (179, 1, 29, 'Fandiongue', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (180, 1, 29, 'Gouk', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (181, 1, 29, 'Koulouk', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (182, 1, 30, 'Dinde', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (183, 1, 30, 'Falia', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (184, 1, 30, 'Fimela', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (186, 1, 30, 'Niodior', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (187, 1, 31, 'Bassar', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (188, 1, 31, 'Bassoul', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (189, 1, 31, 'Maya', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (190, 1, 31, 'Mounde', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (191, 1, 31, 'Ngadior', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (192, 1, 31, 'Siwo', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (193, 1, 31, 'Thialane', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (194, 1, 32, 'Dakhonga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (195, 1, 32, 'Diameniadio', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (196, 1, 32, 'Ndolette', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (197, 1, 32, 'Rofangue', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (198, 1, 32, 'Velingara', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (199, 1, 33, 'Fayaco', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (200, 1, 33, 'Djilor', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (201, 1, 33, 'Fatick', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (202, 1, 33, 'Guague cherif', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (203, 1, 33, 'Sibassor', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (204, 1, 33, 'Tournal nonane', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (205, 1, 33, 'Velor keur emba', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (206, 1, 33, 'Yoga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (207, 1, 33, 'Thiangane', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (208, 1, 33, 'Ndiafatte toucouleur', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (209, 1, 33, 'Latmingue', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (210, 1, 38, 'Palmarin diakhanor', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (211, 1, 38, 'Palmarin facao', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (212, 1, 38, 'Palmarin ngallou', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (213, 1, 38, 'Palmarin nguethie', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (214, 1, 27, 'Bani', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (215, 1, 28, 'Sandikoli', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (216, 1, 28, 'Bambougar massemba', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (217, 1, 29, 'Diogaye', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (218, 1, 32, 'Wandje', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (219, 0, 30, 'Mar lothie', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (220, 1, 39, 'Elinkine', '12:30:38', '016:39:93', 'D�barcadaire de pirogues de mer principalement; quelques unit�s de fleuve.');
INSERT INTO art_agglomeration VALUES (221, 1, 39, 'Tendouk', '12:13:49', '016:27:78', NULL);
INSERT INTO art_agglomeration VALUES (222, 4, 39, 'Ziguinchor', '12:36:31', '016:16:40', NULL);
INSERT INTO art_agglomeration VALUES (223, 2, 39, 'Pointe St Georges', '12:37:93', '016:33:47', NULL);
INSERT INTO art_agglomeration VALUES (224, 1, 39, 'Kamobeul', '12:29:79', '016:26:15', NULL);
INSERT INTO art_agglomeration VALUES (225, 1, 39, 'Etime', '12:28:82', '016:21:55', NULL);
INSERT INTO art_agglomeration VALUES (226, 1, 39, 'Brin', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (227, 1, 40, 'Adeane', '12:38:13', '016:00:90', NULL);
INSERT INTO art_agglomeration VALUES (228, 1, 40, 'Djibanar', '12:33:12', '015:48:59', NULL);
INSERT INTO art_agglomeration VALUES (229, 1, 40, 'Simbendi Balent', '12:33:55', '015:46:36', NULL);
INSERT INTO art_agglomeration VALUES (230, 1, 40, 'Diattakunda', '12:34:32', '015:40:54', NULL);
INSERT INTO art_agglomeration VALUES (231, 2, 40, 'Samine Escale', '12:31:85', '015:37:47', NULL);
INSERT INTO art_agglomeration VALUES (232, 4, 41, 'Sedhiou', '12:42:47', '015:33:04', NULL);
INSERT INTO art_agglomeration VALUES (233, 4, 41, 'Sefa', '12:47:01', '015:32:55', NULL);
INSERT INTO art_agglomeration VALUES (234, 1, 41, 'Simbandi Brassou', '12:37:60', '015:31:31', NULL);
INSERT INTO art_agglomeration VALUES (235, 1, 41, 'Saker', '12:50:15', '015:26:40', NULL);
INSERT INTO art_agglomeration VALUES (236, 1, 41, 'Diana Malari', '12:50:96', '015:15:10', NULL);
INSERT INTO art_agglomeration VALUES (237, 1, 41, 'Toubacouta', '12:48:48', '015:08:81', NULL);
INSERT INTO art_agglomeration VALUES (238, 4, 41, 'Kolda', '12:53:50', '014:56:50', NULL);
INSERT INTO art_agglomeration VALUES (239, 1, 40, 'Goudomp', '13:34:78', '015:52:55', NULL);
INSERT INTO art_agglomeration VALUES (240, 2, 14, 'Aruma daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (241, 2, 14, 'Bakina daga', '13:08:01', '010:23:37', NULL);
INSERT INTO art_agglomeration VALUES (242, 2, 14, 'Bocar daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (243, 2, 14, 'Madinadi daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (244, 2, 14, 'Mamatuo suobo', NULL, NULL, 'Maison isol�e proche de Mama daga');
INSERT INTO art_agglomeration VALUES (245, 2, 14, 'Soumaina daga', '13:11:75', '010:17:27', 'point pris � 500m au sud');
INSERT INTO art_agglomeration VALUES (246, 2, 15, 'Balamine daga', '13:01:06', '010:18:20', NULL);
INSERT INTO art_agglomeration VALUES (247, 2, 15, 'Demenika', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (248, 2, 15, 'Sory daga', '13:05:72', '010:16:36', NULL);
INSERT INTO art_agglomeration VALUES (249, 2, 15, 'Tondidji daga', '13:03:04', '010:17:37', NULL);
INSERT INTO art_agglomeration VALUES (250, 2, 14, 'Mama daga', '13:10:25', '010:16:51', NULL);
INSERT INTO art_agglomeration VALUES (251, 2, 15, 'Kerouane daga', NULL, NULL, NULL);
INSERT INTO art_agglomeration VALUES (252, 2, 15, 'Noumoke daga', '13:03:36', '010:18:75', NULL);


--
-- Data for Name: art_categorie_socio_professionnelle; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_categorie_socio_professionnelle VALUES (0, 'Inconnu');
INSERT INTO art_categorie_socio_professionnelle VALUES (1, 'Professionnels');
INSERT INTO art_categorie_socio_professionnelle VALUES (2, 'Saisonniers');
INSERT INTO art_categorie_socio_professionnelle VALUES (3, 'Occasionnels');


--
-- Data for Name: art_debarquement; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_debarquement VALUES (69, 3, 2, 3, 63, 175, 2872, 'FMDOm', 2, '1994-08-03', '14:00:00', '07:00:00', '14:15:00', 1, 3, 1, NULL, 1994, 7, NULL, 17058, 1, 0, 2, '1994-08-04');
INSERT INTO art_debarquement VALUES (70, 3, 2, 4, 63, 175, 2873, 'PALAN', 2, '1994-08-03', '14:00:00', '08:00:00', '15:00:00', 1, 1.5, 1, NULL, 1994, 7, NULL, 17059, 2, 0, 0, '1994-08-04');
INSERT INTO art_debarquement VALUES (71, 3, 2, 4, 63, 175, 2874, 'FMDOg', 2, '1994-08-03', '12:00:00', '05:00:00', '12:15:00', 1, 7.1900001, 1, NULL, 1994, 7, NULL, 17060, 2, 0, 0, '1994-08-04');
INSERT INTO art_debarquement VALUES (72, 3, 2, 3, 63, 176, 2875, 'FMDOm', 2, '1994-08-03', '14:00:00', '09:00:00', '15:00:00', 1, 20.629999, 1, NULL, 1994, 7, NULL, 17061, 1, 0, 0, '1994-08-04');
INSERT INTO art_debarquement VALUES (73, 3, 2, 3, 63, 175, 2876, 'FMDOm', 2, '1994-08-03', '14:00:00', '06:00:00', '14:30:00', 1, 8.4799995, 1, NULL, 1994, 7, NULL, 17062, 1, 0, 1, '1994-08-04');
INSERT INTO art_debarquement VALUES (74, 3, 3, 4, 63, 177, 2877, 'PALAN', 2, '1994-08-04', '16:00:00', '06:00:00', '17:00:00', 1, 17.450001, 1, NULL, 1994, 7, NULL, 17063, 2, 0, 0, '1994-08-05');
INSERT INTO art_debarquement VALUES (75, 3, 3, 4, 63, 175, 2878, 'FMDOm', 2, '1994-08-04', '14:00:00', '10:00:00', '14:30:00', 1, 17.684999, 1, NULL, 1994, 7, NULL, 17064, 1, 0, 1, '1994-08-05');
INSERT INTO art_debarquement VALUES (76, 3, 3, 3, 63, 175, 2874, 'FMDOg', 2, '1994-08-04', '12:00:00', '05:00:00', '12:00:00', 1, 8, 1, NULL, 1994, 7, NULL, 17065, 2, 0, 0, '1994-08-05');
INSERT INTO art_debarquement VALUES (77, 3, 3, 3, 63, 175, 2879, 'FMDOm', 2, '1994-08-04', '14:00:00', '07:00:00', '14:10:00', 1, 11.85, 1, NULL, 1994, 7, NULL, 17066, 1, 0, 1, '1994-08-05');
INSERT INTO art_debarquement VALUES (78, 3, 3, 4, 63, 175, 2875, 'FMDOg', 2, '1994-08-05', '01:00:00', '09:00:00', '15:00:00', 1, 6.4200001, 1, NULL, 1994, 7, NULL, 17067, 1, 0, 0, '1994-08-05');
INSERT INTO art_debarquement VALUES (79, 3, 3, 4, 63, 175, 2874, 'FMDOg', 2, '1994-08-05', '12:00:00', '05:00:00', '12:00:00', 1, 9.7799997, 1, NULL, 1994, 7, NULL, 17068, 2, 0, 0, '1994-08-06');
INSERT INTO art_debarquement VALUES (22, 3, 1, 1, 63, 223, 3024, 'SE_PL', 2, NULL, NULL, '11:45:00', NULL, 3, 40.400002, 1, NULL, 1994, 9, NULL, 17581, 6, 5, 0, '1994-09-27');
INSERT INTO art_debarquement VALUES (80, 3, 3, 4, 63, 177, 2880, 'PALAN', 2, '1994-08-05', '14:00:00', '08:00:00', '15:00:00', 1, 36.259998, 1, NULL, 1994, 7, NULL, 17069, 2, 0, 0, '1994-08-06');
INSERT INTO art_debarquement VALUES (81, 3, 3, 4, 63, 175, 2876, 'FMDOm', 2, '1994-08-05', '14:00:00', '10:00:00', '14:30:00', 1, 14.8, 1, NULL, 1994, 7, NULL, 17070, 1, 0, 1, '1994-08-06');
INSERT INTO art_debarquement VALUES (82, 3, 3, 4, 63, 175, 2879, 'FMDOm', 2, '1994-08-05', '14:00:00', '07:00:00', '14:10:00', 1, 5.3200002, 1, NULL, 1994, 7, NULL, 17071, 1, 0, 0, '1994-08-06');
INSERT INTO art_debarquement VALUES (83, 3, 3, 4, 63, 175, 2875, 'FMDOg', 2, '1994-08-05', '14:00:00', '09:00:00', '15:00:00', 1, 14.25, 1, NULL, 1994, 7, NULL, 17072, 1, 0, 0, '1994-08-06');
INSERT INTO art_debarquement VALUES (40, 3, 2, 4, 63, 182, 3021, 'NASSE', 2, '1994-08-28', '16:00:00', '08:00:00', '16:30:00', 1, 3.2, 1, NULL, 1994, 8, NULL, 17282, 0, 2, 0, '1994-08-29');
INSERT INTO art_debarquement VALUES (41, 3, 2, 4, 63, 182, 3022, 'SE_PL', 2, '1994-08-29', '06:00:00', '12:00:00', '07:00:00', 3, 16.25, 1, NULL, 1994, 8, NULL, 17283, 5, 3, 0, '1994-08-29');
INSERT INTO art_debarquement VALUES (42, 3, 2, 3, 63, 176, 3023, 'FMDOg', 2, '1994-08-29', '14:00:00', '06:00:00', '15:00:00', 1, 7.9499998, 1, NULL, 1994, 8, NULL, 17284, 1, 0, 0, '1994-08-30');
INSERT INTO art_debarquement VALUES (43, 3, 2, 3, 63, 182, 2880, 'PALAN', 2, '1994-08-29', '15:00:00', '06:00:00', '16:00:00', 1, 8.3000002, 1, NULL, 1994, 8, NULL, 17285, 2, 0, 0, '1994-08-30');
INSERT INTO art_debarquement VALUES (44, 3, 2, 3, 63, 182, 3024, 'SE_PL', 2, '1994-08-30', '06:00:00', '10:00:00', '06:20:00', 3, 20.200001, 1, NULL, 1994, 8, NULL, 17286, 6, 4, 0, '1994-08-30');
INSERT INTO art_debarquement VALUES (45, 3, 2, 4, 63, 180, 2880, 'PALAN', 2, '1994-08-30', '08:00:00', '05:00:00', '09:00:00', 1, 13.05, 1, NULL, 1994, 8, NULL, 17287, 2, 0, 0, '1994-08-31');
INSERT INTO art_debarquement VALUES (46, 3, 2, 4, 63, 182, 3025, 'PALAN', 2, '1994-08-30', '10:00:00', '05:00:00', '10:30:00', 1, 18.049999, 1, NULL, 1994, 8, NULL, 17288, 1, 0, 0, '1994-08-31');
INSERT INTO art_debarquement VALUES (47, 3, 2, 4, 63, 176, 2973, 'PALAN', 2, '1994-08-30', '14:00:00', '05:00:00', '15:00:00', 1, 7.3699999, 1, NULL, 1994, 8, NULL, 17289, 2, 0, 0, '1994-08-31');
INSERT INTO art_debarquement VALUES (48, 3, 2, 4, 63, 182, 3026, 'PALAN', 2, '1994-08-30', '10:00:00', '05:00:00', '11:00:00', 1, 6.0999999, 1, NULL, 1994, 8, NULL, 17290, 1, 0, 0, '1994-08-31');
INSERT INTO art_debarquement VALUES (49, 3, 2, 4, 63, 176, 3023, 'FMDO', 2, '1994-08-30', '14:00:00', '05:00:00', '15:00:00', 1, 5.1300001, 1, NULL, 1994, 8, NULL, 17291, 1, 0, 0, '1994-08-31');
INSERT INTO art_debarquement VALUES (50, 3, 2, 4, 63, 182, 2879, 'FMDOm', 2, '1994-08-30', '15:00:00', '07:00:00', '15:10:00', 1, 7.7199998, 1, NULL, 1994, 8, NULL, 17292, 2, 0, 0, '1994-08-31');
INSERT INTO art_debarquement VALUES (51, 3, 2, 4, 63, 223, 3027, 'FMDO', 2, '1994-08-30', '14:00:00', '07:00:00', '15:00:00', 1, 6.2199998, 1, NULL, 1994, 8, NULL, 17293, 2, 0, 0, '1994-08-31');
INSERT INTO art_debarquement VALUES (52, 3, 2, 3, 63, 182, 3028, 'FMDOm', 2, '1994-08-31', '16:00:00', '06:00:00', '16:20:00', 1, 6.9000001, 1, NULL, 1994, 8, NULL, 17294, 2, 0, 0, '1994-09-01');
INSERT INTO art_debarquement VALUES (53, 3, 2, 3, 63, 176, 3023, 'FMDOg', 2, '1994-08-31', '14:00:00', '06:00:00', '15:00:00', 1, 7.7199998, 1, NULL, 1994, 8, NULL, 17295, 1, 0, 0, '1994-09-01');
INSERT INTO art_debarquement VALUES (54, 3, 2, 2, 63, 182, 3024, 'SE_PL', 2, '1994-09-01', '06:00:00', '10:00:00', '06:20:00', 2, 5.3499999, 1, NULL, 1994, 8, NULL, 17296, 6, 4, 0, '1994-09-01');
INSERT INTO art_debarquement VALUES (55, 3, 2, 2, 63, 180, 3029, 'PALAN', 2, '1994-08-31', '16:00:00', '06:00:00', '16:30:00', 1, 17.299999, 1, NULL, 1994, 8, NULL, 17297, 1, 0, 0, '1994-09-01');
INSERT INTO art_debarquement VALUES (56, 3, 2, 2, 63, 180, 3030, 'PALAN', 2, '1994-09-01', '16:00:00', '06:00:00', '16:30:00', 1, 20.6, 1, NULL, 1994, 8, NULL, 17298, 1, 0, 0, '1994-09-02');
INSERT INTO art_debarquement VALUES (57, 3, 2, 2, 63, 182, 3031, 'PALAN', 2, '1994-09-01', '16:00:00', '06:00:00', '16:30:00', 1, 11, 1, NULL, 1994, 8, NULL, 17299, 1, 0, 0, '1994-09-02');
INSERT INTO art_debarquement VALUES (58, 3, 2, 2, 63, 180, 3032, 'SE_PL', 2, '1994-09-02', '05:00:00', '11:00:00', '05:20:00', 2, 57, 1, NULL, 1994, 8, NULL, 17300, 6, 3, 0, '1994-09-02');
INSERT INTO art_debarquement VALUES (59, 3, 2, 2, 63, 182, 3024, 'SE_PL', 2, '1994-09-02', '05:00:00', '10:00:00', '05:10:00', 1, 9.5, 1, NULL, 1994, 8, NULL, 17301, 6, 4, 0, '1994-09-02');
INSERT INTO art_debarquement VALUES (60, 3, 2, 2, 63, NULL, 3033, 'NASSE', 2, '1994-09-02', '08:00:00', '10:00:00', '08:10:00', 1, 4.6999998, 1, NULL, 1994, 8, NULL, 17302, 0, 1, 0, '1994-09-02');
INSERT INTO art_debarquement VALUES (61, 3, 2, 2, 63, 181, 2973, 'PALAN', 2, '1994-09-01', '16:00:00', '06:00:00', '16:40:00', 1, 9.3000002, 1, NULL, 1994, 8, NULL, 17303, 2, 0, 0, '1994-09-02');
INSERT INTO art_debarquement VALUES (62, 3, 2, 2, 63, 181, 2877, 'PALAN', 2, '1994-09-01', '16:00:00', '05:00:00', '16:30:00', 1, 8.8000002, 1, NULL, 1994, 8, NULL, 17304, 2, 0, 0, '1994-09-02');
INSERT INTO art_debarquement VALUES (63, 3, 2, 2, 63, 182, 3034, 'SE_PL', 2, '1994-09-02', '05:00:00', '09:00:00', '05:10:00', 2, 53, 1, NULL, 1994, 8, NULL, 17305, 7, 5, 0, '1994-09-02');
INSERT INTO art_debarquement VALUES (64, 3, 2, 2, 63, 182, 2879, 'FMDOm', 2, '1994-09-01', '16:00:00', '06:00:00', '16:20:00', 1, 6.5, 1, NULL, 1994, 8, NULL, 17306, 2, 0, 0, '1994-09-02');
INSERT INTO art_debarquement VALUES (65, 3, 2, 2, 63, 181, 3023, 'FMDOg', 2, '1994-09-01', '11:00:00', '07:00:00', '11:30:00', 1, 3.0699999, 1, NULL, 1994, 8, NULL, 17307, 1, 0, 0, '1994-09-02');
INSERT INTO art_debarquement VALUES (66, 3, 3, 2, 63, 182, 3024, 'SE_PL', 2, '1994-09-03', '05:00:00', '08:00:00', '05:10:00', 2, 13.2, 1, NULL, 1994, 8, NULL, 17308, 7, 3, 0, '1994-09-03');
INSERT INTO art_debarquement VALUES (67, 3, 3, 2, 63, 223, 3032, 'SE_PL', 2, '1994-09-03', '05:00:00', '08:00:00', '05:10:00', 2, 50.48, 1, NULL, 1994, 8, NULL, 17309, 6, 3, 0, '1994-09-03');
INSERT INTO art_debarquement VALUES (68, 3, 3, 2, 63, 181, 2973, 'PALAN', 2, '1994-09-02', '16:00:00', '10:00:00', '16:30:00', 1, 6.4499998, 1, NULL, 1994, 8, NULL, 17310, 2, 0, 0, '1994-09-03');
INSERT INTO art_debarquement VALUES (19, 3, 1, 1, 63, 223, 3032, 'SE_PL', 2, '1994-09-26', '06:00:00', '10:40:00', '06:10:00', 2, 48.200001, 1, NULL, 1994, 9, NULL, 17578, 6, 3, 0, '1994-09-26');
INSERT INTO art_debarquement VALUES (20, 3, 1, 1, 63, 223, 3024, 'SE_PL', 2, '1994-09-26', '06:00:00', '11:10:00', '06:15:00', 3, 48.799999, 1, NULL, 1994, 9, NULL, 17579, 6, 5, 0, '1994-09-26');
INSERT INTO art_debarquement VALUES (21, 3, 1, 1, 63, 176, 3158, 'PALAN', 2, '1994-09-25', '16:00:00', '11:45:00', '16:30:00', 1, 13.2, 1, NULL, 1994, 9, NULL, 17580, 2, 0, 0, '1994-09-26');
INSERT INTO art_debarquement VALUES (23, 3, 1, 1, 63, 223, 3031, 'PALAN', 2, '1994-09-27', '07:00:00', '11:00:00', '10:00:00', 1, 7.8000002, 1, NULL, 1994, 9, NULL, 17582, 1, 0, 1, '1994-09-27');
INSERT INTO art_debarquement VALUES (24, 3, 1, 1, 63, 223, 3030, 'PALAN', 2, '1994-09-27', '07:00:00', '11:00:00', '10:00:00', 1, 19.360001, 1, NULL, 1994, 9, NULL, 17583, 1, 0, 0, '1994-09-27');
INSERT INTO art_debarquement VALUES (25, 3, 1, 1, 63, 223, 3159, 'FMDOm', 2, '1994-09-28', '07:00:00', '09:00:00', '16:00:00', 1, 5.4000001, 1, NULL, 1994, 9, NULL, 17584, 1, 0, 2, '1994-09-28');
INSERT INTO art_debarquement VALUES (26, 3, 2, 1, 63, 223, 3032, 'SE_PL', 2, '1994-09-28', '06:00:00', '11:30:00', '06:05:00', 2, 53.400002, 1, NULL, 1994, 9, NULL, 17585, 6, 3, 0, '1994-09-28');
INSERT INTO art_debarquement VALUES (27, 3, 1, 1, 63, 223, 3034, 'SE_PL', 2, '1994-09-28', '06:00:00', '11:00:00', '06:10:00', 3, 60.099998, 1, NULL, 1994, 9, NULL, 17586, 9, 6, 0, '1994-09-28');
INSERT INTO art_debarquement VALUES (28, 3, 1, 1, 63, 223, 3160, 'NASSE', 2, '1994-09-29', '10:00:00', '11:30:00', '17:00:00', 1, 2.3, 1, NULL, 1994, 9, NULL, 17587, 0, 1, 0, '1994-09-29');
INSERT INTO art_debarquement VALUES (29, 3, 1, 1, 63, 223, 3034, 'SE_PL', 2, '1994-09-29', '05:00:00', '11:00:00', '06:00:00', 3, 36.150002, 1, NULL, 1994, 9, NULL, 17588, 8, 7, 0, '1994-09-29');
INSERT INTO art_debarquement VALUES (30, 3, 1, 1, 63, 223, 3161, 'PALAN', 2, '1994-09-28', '16:00:00', '09:30:00', '16:30:00', 1, 15.7, 1, NULL, 1994, 9, NULL, 17589, 1, 0, 0, '1994-09-29');
INSERT INTO art_debarquement VALUES (31, 3, 1, 1, 63, 223, 3030, 'PALAN', 2, '1994-09-28', '15:00:00', '10:00:00', '16:00:00', 1, 34.700001, 1, NULL, 1994, 9, NULL, 17590, 1, 0, 0, '1994-09-29');
INSERT INTO art_debarquement VALUES (32, 3, 1, 2, 63, 223, 3032, 'SE_PL', 2, '1994-09-30', '06:00:00', '11:00:00', '06:05:00', 2, 24.200001, 1, NULL, 1994, 9, NULL, 17591, 6, 5, 0, '1994-09-30');
INSERT INTO art_debarquement VALUES (33, 3, 1, 2, 63, 223, 3030, 'PALAN', 2, '1994-09-29', '16:00:00', '10:00:00', '16:30:00', 1, 16.200001, 1, NULL, 1994, 9, NULL, 17592, 1, 0, 0, '1994-09-30');
INSERT INTO art_debarquement VALUES (34, 3, 1, 2, 63, 223, 3159, 'FMDOm', 2, '1994-09-29', '14:00:00', '09:30:00', '14:20:00', 1, 8.3000002, 1, NULL, 1994, 9, NULL, 17593, 1, 0, 1, '1994-09-30');
INSERT INTO art_debarquement VALUES (35, 3, 1, 2, 63, 223, 3031, 'PALAN', 2, '1994-09-29', '15:30:00', '10:30:00', '16:00:00', 1, 4.77, 1, NULL, 1994, 9, NULL, 17594, 1, 0, 0, '1994-09-30');
INSERT INTO art_debarquement VALUES (36, 3, 1, 2, 63, 223, 3162, 'PALAN', 2, NULL, NULL, '10:30:00', NULL, 1, 15.95, 1, NULL, 1994, 9, NULL, 17595, 2, 0, 0, '1994-10-01');
INSERT INTO art_debarquement VALUES (37, 3, 1, 2, 63, 223, 3032, 'SE_PL', 2, '1994-10-01', '06:00:00', '11:00:00', '06:05:00', 2, 30.700001, 1, NULL, 1994, 9, NULL, 17596, 6, 3, 0, '1994-10-01');
INSERT INTO art_debarquement VALUES (38, 3, 1, 2, 63, 223, 3163, 'PALAN', 2, '1994-09-30', '16:00:00', '09:30:00', '16:30:00', 1, 12.6, 1, NULL, 1994, 9, NULL, 17597, 1, 0, 0, '1994-10-01');
INSERT INTO art_debarquement VALUES (39, 3, 1, 2, 63, 223, 3028, 'FMDOm', 2, '1994-09-30', '16:00:00', '08:30:00', '16:30:00', 1, 10.4, 1, NULL, 1994, 9, NULL, 17598, 2, 0, 0, '1994-10-01');
INSERT INTO art_debarquement VALUES (1, 3, 2, 3, 63, 223, 3024, 'SE_PL', 2, '1994-10-17', '05:00:00', '11:00:00', '05:05:00', 3, 14.4, 1, NULL, 1994, 10, NULL, 17933, 7, 3, 0, '1994-10-17');
INSERT INTO art_debarquement VALUES (2, 3, 2, 3, 63, 237, 3030, 'PALAN', 2, '1994-10-16', '10:00:00', '09:00:00', '10:30:00', 1, 7.1999998, 1, NULL, 1994, 10, NULL, 17934, 2, 0, 0, '1994-10-17');
INSERT INTO art_debarquement VALUES (3, 3, 2, 3, 63, 223, 3158, 'PALAN', 2, '1994-10-16', '16:00:00', '10:30:00', '16:30:00', 1, 8.8999996, 1, NULL, 1994, 10, NULL, 17935, 2, 0, 0, '1994-10-17');
INSERT INTO art_debarquement VALUES (4, 3, 3, 4, 63, 223, 3034, 'SE_PL', 2, '1994-10-18', '05:00:00', '11:00:00', '05:05:00', 3, 52.5, 1, NULL, 1994, 10, NULL, 17936, 7, 6, 0, '1994-10-18');
INSERT INTO art_debarquement VALUES (5, 3, 3, 4, 63, 223, 2880, 'PALAN', 2, '1994-10-17', '10:00:00', '09:30:00', '11:00:00', 1, 12.9, 1, NULL, 1994, 10, NULL, 17937, 2, 0, 0, '1994-10-18');
INSERT INTO art_debarquement VALUES (6, 3, 3, 4, 63, 223, 3024, 'SE_PL', 2, '1994-10-18', '06:00:00', '10:30:00', '06:05:00', 2, 17.4, 1, NULL, 1994, 10, NULL, 17938, 6, 4, 0, '1994-10-18');
INSERT INTO art_debarquement VALUES (7, 3, 2, 4, 63, 223, 3028, 'FMDOm', 2, '1994-10-18', '16:00:00', '09:30:00', '16:30:00', 1, 7.9000001, 1, NULL, 1994, 10, NULL, 17939, 2, 0, 0, '1994-10-19');
INSERT INTO art_debarquement VALUES (8, 3, 2, 4, 63, 223, 3034, 'SE_PL', 2, '1994-10-19', '05:00:00', '11:30:00', '05:05:00', 3, 31.5, 1, NULL, 1994, 10, NULL, 17940, 6, 4, 0, '1994-10-19');
INSERT INTO art_debarquement VALUES (9, 3, 2, 4, 63, 237, 3158, 'PALAN', 2, '1994-10-18', '16:00:00', '11:00:00', '16:30:00', 1, 8.6000004, 1, NULL, 1994, 10, NULL, 17941, 2, 0, 0, '1994-10-19');
INSERT INTO art_debarquement VALUES (10, 3, 1, 3, 63, 176, 3028, 'FMDOm', 2, '1994-10-19', '16:00:00', '09:30:00', '16:20:00', 1, 6.4000001, 1, NULL, 1994, 10, NULL, 17942, 2, 0, 0, '1994-10-20');
INSERT INTO art_debarquement VALUES (11, 3, 1, 3, 63, 223, 3030, 'PALAN', 2, '1994-10-20', '07:00:00', '11:30:00', '07:30:00', 1, 6.5999999, 1, NULL, 1994, 10, NULL, 17943, 2, 0, 0, '1994-10-20');
INSERT INTO art_debarquement VALUES (12, 3, 1, 3, 63, 223, 3034, 'SE_PL', 2, '1994-10-20', '05:00:00', '10:30:00', '05:05:00', 2, 60.900002, 1, NULL, 1994, 10, NULL, 17944, 9, 5, 0, '1994-10-20');
INSERT INTO art_debarquement VALUES (13, 3, 1, 2, 63, 257, 3028, 'FMDOm', 2, '1994-10-20', '16:00:00', '09:00:00', '16:30:00', 1, 3.4000001, 1, NULL, 1994, 10, NULL, 17945, 2, 0, 0, '1994-10-21');
INSERT INTO art_debarquement VALUES (14, 3, 1, 2, 63, 237, 3158, 'PALAN', 2, '1994-10-20', '16:00:00', '11:40:00', '16:30:00', 1, 12, 1, NULL, 1994, 10, NULL, 17946, 2, 0, 0, '1994-10-21');
INSERT INTO art_debarquement VALUES (15, 3, 1, 2, 63, 223, 3032, 'SE_PL', 2, '1994-10-21', '05:00:00', '11:00:00', '05:05:00', 2, 31, 1, NULL, 1994, 10, NULL, 17947, 6, 4, 0, '1994-10-21');
INSERT INTO art_debarquement VALUES (16, 3, 3, 4, 63, 223, 3159, 'FMDOm', 2, '1994-10-21', '16:00:00', '10:00:00', '16:20:00', 1, 7.5, 1, NULL, 1994, 10, NULL, 17948, 2, 0, 0, '1994-10-22');
INSERT INTO art_debarquement VALUES (17, 3, 3, 4, 63, 223, 3024, 'SE_PL', 2, '1994-10-22', '05:00:00', '11:00:00', '05:15:00', 3, 41.299999, 1, NULL, 1994, 10, NULL, 17949, 5, 3, 0, '1994-10-22');
INSERT INTO art_debarquement VALUES (18, 3, 3, 4, 63, 223, 3281, 'NASSE', 2, '1994-10-22', '09:00:00', '10:00:00', '09:10:00', 1, 3, 1, NULL, 1994, 10, NULL, 17950, 0, 1, 0, '1994-10-22');


--
-- Data for Name: art_debarquement_rec; Type: TABLE DATA; Schema: public; Owner: devppeao
--

INSERT INTO art_debarquement_rec VALUES ('rec_1', 14.4, '1');
INSERT INTO art_debarquement_rec VALUES ('rec_2', 7.1999998, '2');
INSERT INTO art_debarquement_rec VALUES ('rec_3', 8.8999996, '3');
INSERT INTO art_debarquement_rec VALUES ('rec_4', 52.5, '4');
INSERT INTO art_debarquement_rec VALUES ('rec_5', 12.9, '5');
INSERT INTO art_debarquement_rec VALUES ('rec_6', 17.4, '6');
INSERT INTO art_debarquement_rec VALUES ('rec_7', 7.9000001, '7');
INSERT INTO art_debarquement_rec VALUES ('rec_8', 31.5, '8');
INSERT INTO art_debarquement_rec VALUES ('rec_9', 8.6000004, '9');
INSERT INTO art_debarquement_rec VALUES ('rec_10', 6.4000001, '10');
INSERT INTO art_debarquement_rec VALUES ('rec_11', 6.5999999, '11');
INSERT INTO art_debarquement_rec VALUES ('rec_12', 60.900002, '12');
INSERT INTO art_debarquement_rec VALUES ('rec_13', 3.4300001, '13');
INSERT INTO art_debarquement_rec VALUES ('rec_14', 12, '14');
INSERT INTO art_debarquement_rec VALUES ('rec_15', 31.01, '15');
INSERT INTO art_debarquement_rec VALUES ('rec_16', 7.3200002, '16');
INSERT INTO art_debarquement_rec VALUES ('rec_17', 41.299999, '17');
INSERT INTO art_debarquement_rec VALUES ('rec_18', 3, '18');
INSERT INTO art_debarquement_rec VALUES ('rec_19', 48.200001, '19');
INSERT INTO art_debarquement_rec VALUES ('rec_20', 48.799999, '20');
INSERT INTO art_debarquement_rec VALUES ('rec_21', 13.2, '21');
INSERT INTO art_debarquement_rec VALUES ('rec_22', 40.400002, '22');
INSERT INTO art_debarquement_rec VALUES ('rec_23', 7.8000002, '23');
INSERT INTO art_debarquement_rec VALUES ('rec_24', 19.360001, '24');
INSERT INTO art_debarquement_rec VALUES ('rec_25', 5.3800001, '25');
INSERT INTO art_debarquement_rec VALUES ('rec_26', 53.400002, '26');
INSERT INTO art_debarquement_rec VALUES ('rec_27', 60.099998, '27');
INSERT INTO art_debarquement_rec VALUES ('rec_28', 2.24, '28');
INSERT INTO art_debarquement_rec VALUES ('rec_29', 36.150002, '29');
INSERT INTO art_debarquement_rec VALUES ('rec_30', 15.7, '30');
INSERT INTO art_debarquement_rec VALUES ('rec_31', 34.700001, '31');
INSERT INTO art_debarquement_rec VALUES ('rec_32', 24.200001, '32');
INSERT INTO art_debarquement_rec VALUES ('rec_33', 16.200001, '33');
INSERT INTO art_debarquement_rec VALUES ('rec_34', 8.3999996, '34');
INSERT INTO art_debarquement_rec VALUES ('rec_35', 4.77, '35');
INSERT INTO art_debarquement_rec VALUES ('rec_36', 15.97, '36');
INSERT INTO art_debarquement_rec VALUES ('rec_37', 30.700001, '37');
INSERT INTO art_debarquement_rec VALUES ('rec_38', 12.63, '38');
INSERT INTO art_debarquement_rec VALUES ('rec_39', 10.39, '39');
INSERT INTO art_debarquement_rec VALUES ('rec_40', 3.2, '40');
INSERT INTO art_debarquement_rec VALUES ('rec_41', 16.25, '41');
INSERT INTO art_debarquement_rec VALUES ('rec_42', 7.9499998, '42');
INSERT INTO art_debarquement_rec VALUES ('rec_43', 8.3000002, '43');
INSERT INTO art_debarquement_rec VALUES ('rec_44', 20.200001, '44');
INSERT INTO art_debarquement_rec VALUES ('rec_45', 13.05, '45');
INSERT INTO art_debarquement_rec VALUES ('rec_46', 18.049999, '46');
INSERT INTO art_debarquement_rec VALUES ('rec_47', 7.3699999, '47');
INSERT INTO art_debarquement_rec VALUES ('rec_48', 6.0999999, '48');
INSERT INTO art_debarquement_rec VALUES ('rec_49', 5.1300001, '49');
INSERT INTO art_debarquement_rec VALUES ('rec_50', 7.9000001, '50');
INSERT INTO art_debarquement_rec VALUES ('rec_51', 6.3200002, '51');
INSERT INTO art_debarquement_rec VALUES ('rec_52', 6.9000001, '52');
INSERT INTO art_debarquement_rec VALUES ('rec_53', 7.7199998, '53');
INSERT INTO art_debarquement_rec VALUES ('rec_54', 5.3499999, '54');
INSERT INTO art_debarquement_rec VALUES ('rec_55', 17.450001, '55');
INSERT INTO art_debarquement_rec VALUES ('rec_56', 20.6, '56');
INSERT INTO art_debarquement_rec VALUES ('rec_57', 11, '57');
INSERT INTO art_debarquement_rec VALUES ('rec_58', 57.130001, '58');
INSERT INTO art_debarquement_rec VALUES ('rec_59', 9.5, '59');
INSERT INTO art_debarquement_rec VALUES ('rec_60', 4.6999998, '60');
INSERT INTO art_debarquement_rec VALUES ('rec_61', 9.3000002, '61');
INSERT INTO art_debarquement_rec VALUES ('rec_62', 8.8000002, '62');
INSERT INTO art_debarquement_rec VALUES ('rec_63', 53, '63');
INSERT INTO art_debarquement_rec VALUES ('rec_64', 6.4000001, '64');
INSERT INTO art_debarquement_rec VALUES ('rec_65', 3.0699999, '65');
INSERT INTO art_debarquement_rec VALUES ('rec_66', 13.2, '66');
INSERT INTO art_debarquement_rec VALUES ('rec_67', 50.48, '67');
INSERT INTO art_debarquement_rec VALUES ('rec_68', 6.4499998, '68');
INSERT INTO art_debarquement_rec VALUES ('rec_69', 3, '69');
INSERT INTO art_debarquement_rec VALUES ('rec_70', 1.5, '70');
INSERT INTO art_debarquement_rec VALUES ('rec_71', 7.1900001, '71');
INSERT INTO art_debarquement_rec VALUES ('rec_72', 20, '72');
INSERT INTO art_debarquement_rec VALUES ('rec_73', 8.4799995, '73');
INSERT INTO art_debarquement_rec VALUES ('rec_74', 17.450001, '74');
INSERT INTO art_debarquement_rec VALUES ('rec_75', 17.684999, '75');
INSERT INTO art_debarquement_rec VALUES ('rec_76', 8, '76');
INSERT INTO art_debarquement_rec VALUES ('rec_77', 11.85, '77');
INSERT INTO art_debarquement_rec VALUES ('rec_78', 6.4200001, '78');
INSERT INTO art_debarquement_rec VALUES ('rec_79', 9.7799997, '79');
INSERT INTO art_debarquement_rec VALUES ('rec_80', 36.259998, '80');
INSERT INTO art_debarquement_rec VALUES ('rec_81', 14.8, '81');
INSERT INTO art_debarquement_rec VALUES ('rec_82', 5.3200002, '82');
INSERT INTO art_debarquement_rec VALUES ('rec_83', 13.9, '83');


--
-- Data for Name: art_effort_gt; Type: TABLE DATA; Schema: public; Owner: devppeao
--



--
-- Data for Name: art_effort_gt_sp; Type: TABLE DATA; Schema: public; Owner: devppeao
--



--
-- Data for Name: art_effort_sp; Type: TABLE DATA; Schema: public; Owner: devppeao
--



--
-- Data for Name: art_effort_taille; Type: TABLE DATA; Schema: public; Owner: devppeao
--



--
-- Data for Name: art_engin_activite; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_engin_activite VALUES (1, 71876, 3, 169, 'FMDO45');
INSERT INTO art_engin_activite VALUES (2, 71877, 1, 176, 'EP');
INSERT INTO art_engin_activite VALUES (3, 71878, 17, 177, 'DURANKO');
INSERT INTO art_engin_activite VALUES (4, 71880, 2, 179, 'FMDO35');
INSERT INTO art_engin_activite VALUES (5, 71879, 1, 179, 'FMDO45');
INSERT INTO art_engin_activite VALUES (6, 71883, 1, 180, 'FMDO55');
INSERT INTO art_engin_activite VALUES (7, 71882, 1, 180, 'FMDO65');
INSERT INTO art_engin_activite VALUES (8, 71881, 1, 180, 'FMDO75');
INSERT INTO art_engin_activite VALUES (9, 71884, 2, 181, 'FMDO35');
INSERT INTO art_engin_activite VALUES (10, 71885, 3, 182, 'FMDO55');
INSERT INTO art_engin_activite VALUES (11, 71886, 1, 183, 'PLNA');
INSERT INTO art_engin_activite VALUES (12, 71887, 2, 184, 'PLNA');
INSERT INTO art_engin_activite VALUES (13, 71888, 1, 185, 'PLNA');
INSERT INTO art_engin_activite VALUES (14, 71889, 17, 186, 'DURANKO');
INSERT INTO art_engin_activite VALUES (15, 71891, 1, 188, 'FMDO45');
INSERT INTO art_engin_activite VALUES (16, 71890, 2, 188, 'FMDO35');
INSERT INTO art_engin_activite VALUES (17, 71894, 1, 189, 'FMDO55');
INSERT INTO art_engin_activite VALUES (18, 71892, 1, 189, 'FMDO75');
INSERT INTO art_engin_activite VALUES (19, 71893, 1, 189, 'FMDO65');
INSERT INTO art_engin_activite VALUES (20, 71895, 2, 190, 'FMDO35');
INSERT INTO art_engin_activite VALUES (21, 71896, 3, 191, 'FMDO55');
INSERT INTO art_engin_activite VALUES (22, 71897, 2, 193, 'PLNA');
INSERT INTO art_engin_activite VALUES (23, 71898, 1, 194, 'PLNA');
INSERT INTO art_engin_activite VALUES (24, 71899, 3, 197, 'FMDO45');
INSERT INTO art_engin_activite VALUES (25, 71900, 2, 199, 'FMDO35');
INSERT INTO art_engin_activite VALUES (26, 71901, 3, 200, 'FMDO55');
INSERT INTO art_engin_activite VALUES (27, 71902, 3, 201, 'PLNA');
INSERT INTO art_engin_activite VALUES (28, 71903, 20, 110, 'DURANKO');
INSERT INTO art_engin_activite VALUES (29, 71904, 1, 111, 'SENNE45');
INSERT INTO art_engin_activite VALUES (30, 71905, 1, 112, 'FMDO45');
INSERT INTO art_engin_activite VALUES (31, 71907, 1, 112, 'FMDO30');
INSERT INTO art_engin_activite VALUES (32, 71906, 1, 112, 'FMDO35');
INSERT INTO art_engin_activite VALUES (33, 71908, 1, 113, 'SENNE45');
INSERT INTO art_engin_activite VALUES (34, 71910, 1, 114, 'FMDO40');
INSERT INTO art_engin_activite VALUES (35, 71909, 1, 114, 'FMDO35');
INSERT INTO art_engin_activite VALUES (36, 71911, 3, 117, 'PLNA');
INSERT INTO art_engin_activite VALUES (37, 71912, 20, 118, 'PLNA');
INSERT INTO art_engin_activite VALUES (38, 71913, 20, 119, 'DURANKO');
INSERT INTO art_engin_activite VALUES (39, 71914, 1, 120, 'SENNE45');
INSERT INTO art_engin_activite VALUES (40, 71915, 1, 121, 'FMDO45');
INSERT INTO art_engin_activite VALUES (41, 71917, 1, 121, 'FMDO30');
INSERT INTO art_engin_activite VALUES (42, 71916, 1, 121, 'FMDO35');
INSERT INTO art_engin_activite VALUES (43, 71918, 1, 122, 'SENNE45');
INSERT INTO art_engin_activite VALUES (44, 71920, 1, 123, 'FMDO40');
INSERT INTO art_engin_activite VALUES (45, 71919, 1, 123, 'FMDO35');
INSERT INTO art_engin_activite VALUES (46, 71921, 5, 125, 'PLNA');
INSERT INTO art_engin_activite VALUES (47, 71922, 3, 126, 'PLNA');
INSERT INTO art_engin_activite VALUES (48, 71923, 30, 128, 'DURANKO');
INSERT INTO art_engin_activite VALUES (49, 71924, 1, 129, 'SENNE45');
INSERT INTO art_engin_activite VALUES (50, 71926, 1, 130, 'FMDO35');
INSERT INTO art_engin_activite VALUES (51, 71925, 1, 130, 'FMDO45');
INSERT INTO art_engin_activite VALUES (52, 71927, 1, 130, 'FMDO30');
INSERT INTO art_engin_activite VALUES (53, 71928, 1, 131, 'SENNE45');
INSERT INTO art_engin_activite VALUES (54, 71930, 1, 132, 'FMDO40');
INSERT INTO art_engin_activite VALUES (55, 71929, 1, 132, 'FMDO35');
INSERT INTO art_engin_activite VALUES (56, 71931, 13, 134, 'PLNA');
INSERT INTO art_engin_activite VALUES (57, 71932, 10, 135, 'PLNA');
INSERT INTO art_engin_activite VALUES (58, 71933, 3, 136, 'PLNA');
INSERT INTO art_engin_activite VALUES (59, 71934, 3, 137, 'PLNA');
INSERT INTO art_engin_activite VALUES (60, 71935, 10, 138, 'PLNA');
INSERT INTO art_engin_activite VALUES (61, 71936, 20, 139, 'DURANKO');
INSERT INTO art_engin_activite VALUES (62, 71937, 1, 140, 'SENNE35');
INSERT INTO art_engin_activite VALUES (63, 71938, 1, 141, 'SENNE20');
INSERT INTO art_engin_activite VALUES (64, 71939, 1, 142, 'SENNE45');
INSERT INTO art_engin_activite VALUES (65, 71941, 1, 143, 'FMDO40');
INSERT INTO art_engin_activite VALUES (66, 71940, 1, 143, 'FMDO35');
INSERT INTO art_engin_activite VALUES (67, 71942, 3, 146, 'PLNA');
INSERT INTO art_engin_activite VALUES (68, 71943, 3, 147, 'PLNA');
INSERT INTO art_engin_activite VALUES (69, 71944, 4, 148, 'PLNA');
INSERT INTO art_engin_activite VALUES (70, 71945, 2, 149, 'DURANKO');
INSERT INTO art_engin_activite VALUES (71, 71946, 1, 150, 'SENNE35');
INSERT INTO art_engin_activite VALUES (72, 71947, 1, 151, 'SENNE20');
INSERT INTO art_engin_activite VALUES (73, 71948, 1, 152, 'SENNE35');
INSERT INTO art_engin_activite VALUES (74, 71949, 1, 153, 'FMDO35');
INSERT INTO art_engin_activite VALUES (75, 71950, 1, 153, 'FMDO40');
INSERT INTO art_engin_activite VALUES (76, 71951, 13, 155, 'PLNA');
INSERT INTO art_engin_activite VALUES (77, 71952, 3, 156, 'PLNA');
INSERT INTO art_engin_activite VALUES (78, 71953, 5, 157, 'PLNA');
INSERT INTO art_engin_activite VALUES (79, 71954, 10, 158, 'DURANKO');
INSERT INTO art_engin_activite VALUES (80, 71955, 1, 159, 'SENNE35');
INSERT INTO art_engin_activite VALUES (81, 71956, 1, 160, 'SENNE20');
INSERT INTO art_engin_activite VALUES (82, 71957, 1, 161, 'SENNE35');
INSERT INTO art_engin_activite VALUES (83, 71959, 1, 162, 'FMDO40');
INSERT INTO art_engin_activite VALUES (84, 71958, 1, 162, 'FMDO35');
INSERT INTO art_engin_activite VALUES (85, 71960, 6, 165, 'PLNA');
INSERT INTO art_engin_activite VALUES (86, 71961, 1, 56, 'SENNE35');
INSERT INTO art_engin_activite VALUES (87, 71962, 1, 57, 'SENNE20');
INSERT INTO art_engin_activite VALUES (88, 71963, 1, 58, 'SENNE35');
INSERT INTO art_engin_activite VALUES (89, 71964, 1, 59, 'FMCL');
INSERT INTO art_engin_activite VALUES (90, 71965, 3, 62, 'PLNA');
INSERT INTO art_engin_activite VALUES (91, 71966, 10, 63, 'PLNA');
INSERT INTO art_engin_activite VALUES (92, 71967, 1, 65, 'SENNE35');
INSERT INTO art_engin_activite VALUES (93, 71968, 1, 66, 'SENNE20');
INSERT INTO art_engin_activite VALUES (94, 71969, 1, 67, 'SENNE35');
INSERT INTO art_engin_activite VALUES (95, 71970, 1, 68, 'FMCL');
INSERT INTO art_engin_activite VALUES (96, 71971, 4, 70, 'PLNA');
INSERT INTO art_engin_activite VALUES (97, 71972, 5, 71, 'PLNA');
INSERT INTO art_engin_activite VALUES (98, 71973, 3, 72, 'PLNA');
INSERT INTO art_engin_activite VALUES (99, 71974, 1, 74, 'SENNE35');
INSERT INTO art_engin_activite VALUES (100, 71975, 1, 75, 'SENNE20');
INSERT INTO art_engin_activite VALUES (101, 71976, 2, 76, 'SENNE35');
INSERT INTO art_engin_activite VALUES (102, 71977, 1, 77, 'FMDO45');
INSERT INTO art_engin_activite VALUES (103, 71978, 4, 80, 'PLNA');
INSERT INTO art_engin_activite VALUES (104, 71979, 4, 81, 'PLNA');
INSERT INTO art_engin_activite VALUES (105, 71980, 9, 82, 'DURANKO');
INSERT INTO art_engin_activite VALUES (106, 71981, 1, 83, 'SENNE35');
INSERT INTO art_engin_activite VALUES (107, 71982, 1, 84, 'SENNE20');
INSERT INTO art_engin_activite VALUES (108, 71983, 1, 85, 'SENNE35');
INSERT INTO art_engin_activite VALUES (109, 71984, 1, 86, 'FMCL');
INSERT INTO art_engin_activite VALUES (110, 71985, 7, 88, 'PLNA');
INSERT INTO art_engin_activite VALUES (111, 71986, 3, 89, 'PLNA');
INSERT INTO art_engin_activite VALUES (112, 71987, 8, 90, 'PLNA');
INSERT INTO art_engin_activite VALUES (113, 71988, 1, 92, 'SENNE35');
INSERT INTO art_engin_activite VALUES (114, 71989, 1, 93, 'SENNE20');
INSERT INTO art_engin_activite VALUES (115, 71990, 1, 94, 'SENNE35');
INSERT INTO art_engin_activite VALUES (116, 71991, 1, 95, 'FMCL');
INSERT INTO art_engin_activite VALUES (117, 71992, 4, 97, 'PLNA');
INSERT INTO art_engin_activite VALUES (118, 71993, 4, 98, 'PLNA');
INSERT INTO art_engin_activite VALUES (119, 71994, 3, 99, 'PLNA');
INSERT INTO art_engin_activite VALUES (120, 71995, 9, 100, 'DURANKO');
INSERT INTO art_engin_activite VALUES (121, 71996, 1, 101, 'SENNE35');
INSERT INTO art_engin_activite VALUES (122, 71997, 1, 102, 'SENNE20');
INSERT INTO art_engin_activite VALUES (123, 71998, 1, 103, 'SENNE35');
INSERT INTO art_engin_activite VALUES (124, 71999, 1, 104, 'FMDO35');
INSERT INTO art_engin_activite VALUES (125, 72000, 6, 106, 'PLNA');
INSERT INTO art_engin_activite VALUES (126, 72001, 5, 107, 'PLNA');
INSERT INTO art_engin_activite VALUES (127, 72002, 1, 108, 'PLNA');
INSERT INTO art_engin_activite VALUES (128, 72003, 3, 109, 'PLNA');
INSERT INTO art_engin_activite VALUES (129, 72004, 1, 2, 'SENNE20');
INSERT INTO art_engin_activite VALUES (130, 72005, 1, 3, 'SENNE35');
INSERT INTO art_engin_activite VALUES (131, 72006, 1, 4, 'SENNE35');
INSERT INTO art_engin_activite VALUES (132, 72007, 1, 5, 'FMDO35');
INSERT INTO art_engin_activite VALUES (133, 72008, 3, 7, 'PLNA');
INSERT INTO art_engin_activite VALUES (134, 72009, 10, 8, 'PLNA');
INSERT INTO art_engin_activite VALUES (135, 72010, 3, 9, 'PLNA');
INSERT INTO art_engin_activite VALUES (136, 72011, 1, 11, 'SENNE20');
INSERT INTO art_engin_activite VALUES (137, 72012, 1, 12, 'SENNE35');
INSERT INTO art_engin_activite VALUES (138, 72013, 1, 13, 'SENNE35');
INSERT INTO art_engin_activite VALUES (139, 72014, 1, 14, 'FMDO35');
INSERT INTO art_engin_activite VALUES (140, 72015, 6, 16, 'PLNA');
INSERT INTO art_engin_activite VALUES (141, 72016, 10, 17, 'PLNA');
INSERT INTO art_engin_activite VALUES (142, 72017, 1, 20, 'SENNE20');
INSERT INTO art_engin_activite VALUES (143, 72018, 1, 21, 'SENNE35');
INSERT INTO art_engin_activite VALUES (144, 72019, 1, 22, 'SENNE35');
INSERT INTO art_engin_activite VALUES (145, 72020, 1, 23, 'FMDO35');
INSERT INTO art_engin_activite VALUES (146, 72021, 10, 26, 'PLNA');
INSERT INTO art_engin_activite VALUES (147, 72022, 4, 27, 'PLNA');
INSERT INTO art_engin_activite VALUES (148, 72023, 1, 29, 'SENNE20');
INSERT INTO art_engin_activite VALUES (149, 72024, 1, 30, 'SENNE35');
INSERT INTO art_engin_activite VALUES (150, 72025, 1, 31, 'SENNE35');
INSERT INTO art_engin_activite VALUES (151, 72026, 1, 32, 'FMDO35');
INSERT INTO art_engin_activite VALUES (152, 72027, 24, 36, 'PLNA');
INSERT INTO art_engin_activite VALUES (153, 72028, 1, 38, 'SENNE20');
INSERT INTO art_engin_activite VALUES (154, 72029, 1, 39, 'SENNE35');
INSERT INTO art_engin_activite VALUES (155, 72030, 1, 40, 'SENNE35');
INSERT INTO art_engin_activite VALUES (156, 72031, 1, 41, 'FMDO35');
INSERT INTO art_engin_activite VALUES (157, 72032, 10, 44, 'PLNA');
INSERT INTO art_engin_activite VALUES (158, 72033, 20, 45, 'PLNA');
INSERT INTO art_engin_activite VALUES (159, 72034, 1, 47, 'SENNE20');
INSERT INTO art_engin_activite VALUES (160, 72035, 1, 50, 'FMDO35');
INSERT INTO art_engin_activite VALUES (161, 72036, 12, 53, 'PLNA');
INSERT INTO art_engin_activite VALUES (162, 72037, 10, 54, 'DURANKO');


--
-- Data for Name: art_engin_peche; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_engin_peche VALUES (1, 34512, 150, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO35', 69);
INSERT INTO art_engin_peche VALUES (2, 34513, 1000, 0, 2, 1, 0, NULL, NULL, 2, 'PLNA', 70);
INSERT INTO art_engin_peche VALUES (3, 34514, 100, 40, 6, 3, 0, NULL, NULL, 2, 'FMDO55', 71);
INSERT INTO art_engin_peche VALUES (4, 34515, 100, 50, 5, 2, 0, NULL, NULL, 1, 'FMDO45', 72);
INSERT INTO art_engin_peche VALUES (5, 34517, 100, 40, 4.5, 1, 0, NULL, NULL, 2, 'FMDO35', 73);
INSERT INTO art_engin_peche VALUES (6, 34516, 100, 40, 4.5, 1, 0, NULL, NULL, 2, 'FMDO45', 73);
INSERT INTO art_engin_peche VALUES (7, 34518, 1000, 0, 2, 2, 0, NULL, NULL, 2, 'PLNA', 74);
INSERT INTO art_engin_peche VALUES (8, 34519, 100, 40, 9, 1, 0, NULL, NULL, 2, 'FMDO45', 75);
INSERT INTO art_engin_peche VALUES (9, 34520, 100, 40, 9, 1, 0, NULL, NULL, 2, 'FMDO35', 75);
INSERT INTO art_engin_peche VALUES (10, 34521, 100, 40, 24, 3, 0, NULL, NULL, 2, 'FMDO55', 76);
INSERT INTO art_engin_peche VALUES (11, 34522, 100, 50, 1.5, 1, 0, NULL, NULL, 2, 'FMDO35', 77);
INSERT INTO art_engin_peche VALUES (12, 34523, 100, 40, 15, 1, 0, NULL, NULL, 1, 'FMDO75', 78);
INSERT INTO art_engin_peche VALUES (13, 34524, 100, 50, 15, 1, 0, NULL, NULL, 1, 'FMDO55', 78);
INSERT INTO art_engin_peche VALUES (14, 34525, 100, 40, 6, 3, 0, NULL, NULL, 2, 'FMDO55', 79);
INSERT INTO art_engin_peche VALUES (15, 34526, 1000, 0, 2, 1, 0, NULL, NULL, 1, 'PLNA', 80);
INSERT INTO art_engin_peche VALUES (16, 34528, 100, 40, 9, 2, 0, NULL, NULL, 2, 'FMDO35', 81);
INSERT INTO art_engin_peche VALUES (17, 34527, 100, 40, 9, 1, 0, NULL, NULL, 2, 'FMDO45', 81);
INSERT INTO art_engin_peche VALUES (18, 34529, 100, 50, 1.5, 1, 0, NULL, NULL, 2, 'FMDO35', 82);
INSERT INTO art_engin_peche VALUES (19, 34530, 100, 50, 15, 1, 0, NULL, NULL, 1, 'FMDO75', 83);
INSERT INTO art_engin_peche VALUES (20, 34531, 100, 50, 15, 1, 0, NULL, NULL, 1, 'FMDO55', 83);
INSERT INTO art_engin_peche VALUES (21, 34826, 0, 0, 5, 5, 0, NULL, NULL, 1, 'DURANKO', 40);
INSERT INTO art_engin_peche VALUES (22, 34827, 100, 65, 2, 1, 0, NULL, NULL, 2, 'SENNE35', 41);
INSERT INTO art_engin_peche VALUES (23, 34828, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO55', 42);
INSERT INTO art_engin_peche VALUES (24, 34829, 100, 50, 2, 2, 0, NULL, NULL, 2, 'FMDO75', 42);
INSERT INTO art_engin_peche VALUES (25, 34830, 1000, 0, 20, 10, 0, NULL, NULL, 2, 'PLNA', 43);
INSERT INTO art_engin_peche VALUES (26, 34831, 100, 100, 2, 1, 0, NULL, NULL, 2, 'SENNE35', 44);
INSERT INTO art_engin_peche VALUES (27, 34832, 1000, 0, 25, 13, 0, NULL, NULL, 2, 'PLNA', 45);
INSERT INTO art_engin_peche VALUES (28, 34833, 1000, 0, 10, 5, 0, NULL, NULL, 2, 'PLNA', 46);
INSERT INTO art_engin_peche VALUES (29, 34834, 1000, 0, 20, 10, 0, NULL, NULL, 1, 'PLNA', 47);
INSERT INTO art_engin_peche VALUES (30, 34835, 1000, 0, 20, 10, 0, NULL, NULL, 1, 'PLNA', 48);
INSERT INTO art_engin_peche VALUES (31, 34838, 100, 50, 2, 1, 0, NULL, NULL, 2, 'FMDO75', 49);
INSERT INTO art_engin_peche VALUES (32, 34837, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO55', 49);
INSERT INTO art_engin_peche VALUES (33, 34836, 100, 50, 2, 1, 0, NULL, NULL, 2, 'FMDO65', 49);
INSERT INTO art_engin_peche VALUES (34, 34839, 100, 50, 1, 2, 0, NULL, NULL, 2, 'FMDO35', 49);
INSERT INTO art_engin_peche VALUES (35, 34840, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO40', 50);
INSERT INTO art_engin_peche VALUES (36, 34843, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO30', 51);
INSERT INTO art_engin_peche VALUES (37, 34842, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO35', 51);
INSERT INTO art_engin_peche VALUES (38, 34841, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO45', 51);
INSERT INTO art_engin_peche VALUES (39, 34844, 100, 45, 0.5, 1, 0, NULL, NULL, 2, 'FMDO35', 52);
INSERT INTO art_engin_peche VALUES (40, 34845, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO45', 52);
INSERT INTO art_engin_peche VALUES (41, 34847, 100, 50, 2, 1, 0, NULL, NULL, 2, 'FMDO75', 53);
INSERT INTO art_engin_peche VALUES (42, 34846, 100, 50, 1, 2, 0, NULL, NULL, 2, 'FMDO55', 53);
INSERT INTO art_engin_peche VALUES (43, 34848, 100, 100, 2, 1, 0, NULL, NULL, 2, 'SENNE35', 54);
INSERT INTO art_engin_peche VALUES (44, 34849, 1000, 0, 25, 13, 0, NULL, NULL, 2, 'PLNA', 55);
INSERT INTO art_engin_peche VALUES (45, 34850, 1000, 0, 10, 5, 0, NULL, NULL, 2, 'PLNA', 56);
INSERT INTO art_engin_peche VALUES (46, 34851, 1000, 0, 20, 5, 0, NULL, NULL, 2, 'PLNA', 57);
INSERT INTO art_engin_peche VALUES (47, 34852, 100, 400, 2, 1, 0, NULL, NULL, 2, 'SENNE35', 58);
INSERT INTO art_engin_peche VALUES (48, 34853, 100, 100, 2, 1, 0, NULL, NULL, 2, 'SENNE35', 59);
INSERT INTO art_engin_peche VALUES (49, 34854, 0, 0, 2, 2, 0, NULL, NULL, 1, 'DURANKO', 60);
INSERT INTO art_engin_peche VALUES (50, 34855, 1000, 0, 6, 3, 0, NULL, NULL, 1, 'PLNA', 61);
INSERT INTO art_engin_peche VALUES (51, 34856, 1000, 0, 6, 3, 0, NULL, NULL, 2, 'PLNA', 62);
INSERT INTO art_engin_peche VALUES (52, 34857, 100, 400, 2, 1, 0, NULL, NULL, 2, 'SENNE35', 63);
INSERT INTO art_engin_peche VALUES (53, 34858, 100, 45, 0.5, 1, 0, NULL, NULL, 2, 'FMDO35', 64);
INSERT INTO art_engin_peche VALUES (54, 34859, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO45', 64);
INSERT INTO art_engin_peche VALUES (55, 34860, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO55', 65);
INSERT INTO art_engin_peche VALUES (56, 34861, 100, 50, 2, 2, 0, NULL, NULL, 2, 'FMDO75', 65);
INSERT INTO art_engin_peche VALUES (57, 34862, 100, 50, 2, 2, 0, NULL, NULL, 2, 'FMDO65', 65);
INSERT INTO art_engin_peche VALUES (58, 34863, 100, 100, 2, 1, 0, NULL, NULL, 2, 'SENNE35', 66);
INSERT INTO art_engin_peche VALUES (59, 34864, 100, 400, 2, 1, 0, NULL, NULL, 2, 'SENNE35', 67);
INSERT INTO art_engin_peche VALUES (60, 34865, 1000, 0, 12, 6, 0, NULL, NULL, 1, 'PLNA', 68);
INSERT INTO art_engin_peche VALUES (61, 35365, 100, 100, 4, 1, 0, NULL, NULL, 2, 'SENNE20', 19);
INSERT INTO art_engin_peche VALUES (62, 35367, 100, 300, 6, 6, 0, NULL, NULL, 2, 'SENNE45', 20);
INSERT INTO art_engin_peche VALUES (63, 35366, 100, 400, 4, 4, 0, NULL, NULL, 2, 'SENNE35', 20);
INSERT INTO art_engin_peche VALUES (64, 35368, 1000, 0, 4, 4, 0, NULL, NULL, 2, 'PLNA', 21);
INSERT INTO art_engin_peche VALUES (65, 35370, 100, 300, 6, 1, 0, NULL, NULL, 2, 'SENNE45', 22);
INSERT INTO art_engin_peche VALUES (66, 35369, 100, 400, 4, 1, 0, NULL, NULL, 2, 'SENNE35', 22);
INSERT INTO art_engin_peche VALUES (67, 35371, 1000, 0, 2, 2, 0, NULL, NULL, 2, 'PLNA', 23);
INSERT INTO art_engin_peche VALUES (68, 35372, 1000, 0, 4, 2, 0, NULL, NULL, 2, 'PLNA', 24);
INSERT INTO art_engin_peche VALUES (69, 35373, 100, 50, 0.5, 1, 0, NULL, NULL, 2, 'FMDO45', 25);
INSERT INTO art_engin_peche VALUES (70, 35374, 100, 100, 4, 1, 0, NULL, NULL, 2, 'SENNE35', 26);
INSERT INTO art_engin_peche VALUES (71, 35375, 100, 300, 8, 1, 0, NULL, NULL, 2, 'SENNE35', 27);
INSERT INTO art_engin_peche VALUES (72, 35376, 0, 0, 2, 9, 0, NULL, NULL, 1, 'DURANKO', 28);
INSERT INTO art_engin_peche VALUES (73, 35377, 100, 300, 8, 1, 0, NULL, NULL, 2, 'SENNE35', 29);
INSERT INTO art_engin_peche VALUES (74, 35378, 1000, 0, 14, 7, 0, NULL, NULL, 2, 'PLNA', 30);
INSERT INTO art_engin_peche VALUES (75, 35379, 1000, 0, 16, 8, 0, NULL, NULL, 2, 'PLNA', 31);
INSERT INTO art_engin_peche VALUES (76, 35380, 100, 100, 4, 1, 0, NULL, NULL, 2, 'SENNE20', 32);
INSERT INTO art_engin_peche VALUES (77, 35381, 1000, 0, 6, 3, 0, NULL, NULL, 2, 'PLNA', 33);
INSERT INTO art_engin_peche VALUES (78, 35382, 100, 40, 0.5, 1, 0, NULL, NULL, 2, 'FMDO35', 34);
INSERT INTO art_engin_peche VALUES (79, 35383, 1000, 0, 6, 1, 0, NULL, NULL, 2, 'PLNA', 35);
INSERT INTO art_engin_peche VALUES (80, 35384, 1000, 0, 5, 5, 0, NULL, NULL, 2, 'PLNA', 36);
INSERT INTO art_engin_peche VALUES (81, 35385, 100, 100, 4, 1, 0, NULL, NULL, 2, 'SENNE20', 37);
INSERT INTO art_engin_peche VALUES (82, 35386, 1000, 0, 6, 6, 0, NULL, NULL, 2, 'PLNA', 38);
INSERT INTO art_engin_peche VALUES (83, 35387, 100, 40, 0.5, 1, 0, NULL, NULL, 2, 'FMDO35', 39);
INSERT INTO art_engin_peche VALUES (84, 36033, 100, 400, 10, 1, 0, NULL, NULL, 2, 'SENNE45', 1);
INSERT INTO art_engin_peche VALUES (85, 36034, 1000, 0, 2, 3, 0, NULL, NULL, 2, 'PLNA', 2);
INSERT INTO art_engin_peche VALUES (86, 36035, 1000, 0, 2, 3, 0, NULL, NULL, 2, 'PLNA', 3);
INSERT INTO art_engin_peche VALUES (87, 36036, 100, 100, 12, 1, 0, NULL, NULL, 2, 'SENNE35', 4);
INSERT INTO art_engin_peche VALUES (88, 36037, 1000, 0, 1, 10, 0, NULL, NULL, 2, 'PLNA', 5);
INSERT INTO art_engin_peche VALUES (89, 36038, 100, 400, 10, 1, 0, NULL, NULL, 2, 'SENNE45', 6);
INSERT INTO art_engin_peche VALUES (90, 36039, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO35', 7);
INSERT INTO art_engin_peche VALUES (91, 36040, 100, 400, 12, 1, 0, NULL, NULL, 2, 'SENNE35', 8);
INSERT INTO art_engin_peche VALUES (92, 36041, 1000, 0, 10, 1, 0, NULL, NULL, 2, 'PLNA', 9);
INSERT INTO art_engin_peche VALUES (93, 36042, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO35', 10);
INSERT INTO art_engin_peche VALUES (94, 36043, 1000, 0, 1, 24, 0, NULL, NULL, 2, 'PLNA', 11);
INSERT INTO art_engin_peche VALUES (95, 36044, 100, 400, 12, 1, 0, NULL, NULL, 2, 'SENNE35', 12);
INSERT INTO art_engin_peche VALUES (96, 36045, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO35', 13);
INSERT INTO art_engin_peche VALUES (97, 36046, 1000, 0, 1, 10, 0, NULL, NULL, 2, 'PLNA', 14);
INSERT INTO art_engin_peche VALUES (98, 36047, 100, 400, 10, 1, 0, NULL, NULL, 2, 'SENNE35', 15);
INSERT INTO art_engin_peche VALUES (99, 36048, 100, 50, 1, 1, 0, NULL, NULL, 2, 'FMDO35', 16);
INSERT INTO art_engin_peche VALUES (100, 36049, 100, 400, 10, 1, 0, NULL, NULL, 2, 'SENNE20', 17);
INSERT INTO art_engin_peche VALUES (101, 36050, 0, 0, 2, 10, 0, NULL, NULL, 1, 'DURANKO', 18);


--
-- Data for Name: art_etat_ciel; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_etat_ciel VALUES (0, 'Inconnu');
INSERT INTO art_etat_ciel VALUES (1, 'Ciel bleu ou degage');
INSERT INTO art_etat_ciel VALUES (2, 'Ciel legerement nuageux, quelques nuages');
INSERT INTO art_etat_ciel VALUES (3, 'Ciel nuageux');
INSERT INTO art_etat_ciel VALUES (4, 'Pluie');


--
-- Data for Name: art_fraction; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_fraction VALUES ('ML2_126502', 126502, 3, 25, 1, 'SGA', 69, NULL);
INSERT INTO art_fraction VALUES ('ML2_126504', 126504, 0.89999998, 5, 1, 'CNI', 70, NULL);
INSERT INTO art_fraction VALUES ('ML2_126503', 126503, 0.60000002, 1, 1, 'HBO', 70, NULL);
INSERT INTO art_fraction VALUES ('ML2_126507', 126507, 3.7, 0, 1, 'OAU', 71, NULL);
INSERT INTO art_fraction VALUES ('ML2_126510', 126510, 0.079999998, 2, 1, 'TZI', 71, NULL);
INSERT INTO art_fraction VALUES ('ML2_126509', 126509, 0.46000001, 3, 1, 'TNI', 71, NULL);
INSERT INTO art_fraction VALUES ('ML2_126508', 126508, 0.34999999, 2, 1, 'SGA', 71, NULL);
INSERT INTO art_fraction VALUES ('ML2_126505', 126505, 1, 2, 1, 'BDM', 71, NULL);
INSERT INTO art_fraction VALUES ('ML2_126506', 126506, 1.6, 7, 1, 'AOC', 71, NULL);
INSERT INTO art_fraction VALUES ('ML2_126518', 126518, 0.07, 1, 1, 'CLA', 72, NULL);
INSERT INTO art_fraction VALUES ('ML2_126517', 126517, 5.3000002, 4, 1, 'CCI', 72, NULL);
INSERT INTO art_fraction VALUES ('ML2_126516', 126516, 0.079999998, 1, 1, 'HFA', 72, NULL);
INSERT INTO art_fraction VALUES ('ML2_126519', 126519, 2, 4, 1, 'MRU', 72, NULL);
INSERT INTO art_fraction VALUES ('ML2_126515', 126515, 0.5, 3, 1, 'AOC', 72, NULL);
INSERT INTO art_fraction VALUES ('ML2_126513', 126513, 2, 9, 1, 'SGA', 72, NULL);
INSERT INTO art_fraction VALUES ('ML2_126511', 126511, 1.8, 9, 1, 'OAU', 72, NULL);
INSERT INTO art_fraction VALUES ('ML2_126520', 126520, 1.25, 1, 1, 'HNI', 72, NULL);
INSERT INTO art_fraction VALUES ('ML2_126521', 126521, 4.8000002, 11, 1, 'HME', 72, NULL);
INSERT INTO art_fraction VALUES ('ML2_126512', 126512, 1.3, 6, 1, 'TNI', 72, NULL);
INSERT INTO art_fraction VALUES ('ML2_126522', 126522, 0.40000001, 1, 1, 'BDM', 72, NULL);
INSERT INTO art_fraction VALUES ('ML2_126514', 126514, 0.5, 5, 1, 'LSE', 72, NULL);
INSERT INTO art_fraction VALUES ('ML2_126528', 126528, 0.059999999, 1, 1, 'HFA', 73, NULL);
INSERT INTO art_fraction VALUES ('ML2_126527', 126527, 0.5, 7, 1, 'TZI', 73, NULL);
INSERT INTO art_fraction VALUES ('ML2_126526', 126526, 0.60000002, 2, 1, 'HFO', 73, NULL);
INSERT INTO art_fraction VALUES ('ML2_126523', 126523, 1, 32, 1, 'CNI', 73, NULL);
INSERT INTO art_fraction VALUES ('ML2_126525', 126525, 6, 75, 1, 'LSE', 73, NULL);
INSERT INTO art_fraction VALUES ('ML2_126524', 126524, 0.31999999, 3, 1, 'CFI', 73, NULL);
INSERT INTO art_fraction VALUES ('ML2_126530', 126530, 16.25, 180, 1, 'CNI', 74, NULL);
INSERT INTO art_fraction VALUES ('ML2_126529', 126529, 1.2, 1, 1, 'BDM', 74, NULL);
INSERT INTO art_fraction VALUES ('ML2_126531', 126531, 2.5, 30, 1, 'SGA', 75, NULL);
INSERT INTO art_fraction VALUES ('ML2_126532', 126532, 1.3, 11, 1, 'OAU', 75, NULL);
INSERT INTO art_fraction VALUES ('ML2_126537', 126537, 0.40000001, 2, 1, 'BDM', 75, NULL);
INSERT INTO art_fraction VALUES ('ML2_126533', 126533, 9.3000002, 68, 1, 'LSE', 75, NULL);
INSERT INTO art_fraction VALUES ('ML2_126536', 126536, 2.3499999, 22, 1, 'CNI', 75, NULL);
INSERT INTO art_fraction VALUES ('ML2_126534', 126534, 0.40000001, 6, 1, 'TZI', 75, NULL);
INSERT INTO art_fraction VALUES ('ML2_126535', 126535, 0.75, 10, 1, 'HFA', 75, NULL);
INSERT INTO art_fraction VALUES ('ML2_126539', 126539, 0.60000002, 1, 1, 'AOC', 75, NULL);
INSERT INTO art_fraction VALUES ('ML2_126538', 126538, 0.085000001, 1, 1, 'MDE', 75, NULL);
INSERT INTO art_fraction VALUES ('ML2_126545', 126545, 0.34999999, 1, 1, 'BDM', 76, NULL);
INSERT INTO art_fraction VALUES ('ML2_126543', 126543, 2.23, 9, 1, 'AOC', 76, NULL);
INSERT INTO art_fraction VALUES ('ML2_126544', 126544, 0.13500001, 2, 1, 'HFA', 76, NULL);
INSERT INTO art_fraction VALUES ('ML2_126542', 126542, 1, 3, 1, 'CNI', 76, NULL);
INSERT INTO art_fraction VALUES ('ML2_126541', 126541, 0.73000002, 2, 1, 'DRO', 76, NULL);
INSERT INTO art_fraction VALUES ('ML2_126546', 126546, 0.74000001, 3, 1, 'LSE', 76, NULL);
INSERT INTO art_fraction VALUES ('ML2_126540', 126540, 2.5999999, 33, 1, 'OAU', 76, NULL);
INSERT INTO art_fraction VALUES ('ML2_126547', 126547, 0.115, 1, 1, 'TNI', 76, NULL);
INSERT INTO art_fraction VALUES ('ML2_126548', 126548, 0.1, 1, 1, 'SGA', 76, NULL);
INSERT INTO art_fraction VALUES ('ML2_126553', 126553, 3.5999999, 101, 1, 'OAU', 77, NULL);
INSERT INTO art_fraction VALUES ('ML2_126552', 126552, 1.6, 8, 1, 'HFA', 77, NULL);
INSERT INTO art_fraction VALUES ('ML2_126551', 126551, 0.60000002, 10, 1, 'TNI', 77, NULL);
INSERT INTO art_fraction VALUES ('ML2_126554', 126554, 0.050000001, 3, 1, 'SMY', 77, NULL);
INSERT INTO art_fraction VALUES ('ML2_126550', 126550, 1.8, 25, 1, 'SGA', 77, NULL);
INSERT INTO art_fraction VALUES ('ML2_126549', 126549, 4.1999998, 33, 1, 'LSE', 77, NULL);
INSERT INTO art_fraction VALUES ('ML2_126555', 126555, 3.4000001, 2, 1, 'HNI', 78, NULL);
INSERT INTO art_fraction VALUES ('ML2_126556', 126556, 0.38999999, 1, 1, 'SGA', 78, NULL);
INSERT INTO art_fraction VALUES ('ML2_126557', 126557, 0.89999998, 3, 1, 'AOC', 78, NULL);
INSERT INTO art_fraction VALUES ('ML2_126558', 126558, 0.17, 1, 1, 'CNI', 78, NULL);
INSERT INTO art_fraction VALUES ('ML2_126561', 126561, 0.38999999, 1, 1, 'CCI', 78, NULL);
INSERT INTO art_fraction VALUES ('ML2_126560', 126560, 0.40000001, 1, 1, 'BDM', 78, NULL);
INSERT INTO art_fraction VALUES ('ML2_126559', 126559, 0.17, 1, 1, 'HME', 78, NULL);
INSERT INTO art_fraction VALUES ('ML2_126562', 126562, 0.44999999, 3, 1, 'OAU', 78, NULL);
INSERT INTO art_fraction VALUES ('ML2_126563', 126563, 0.15000001, 1, 1, 'CLA', 78, NULL);
INSERT INTO art_fraction VALUES ('ML2_126570', 126570, 0.12, 1, 1, 'TNI', 79, NULL);
INSERT INTO art_fraction VALUES ('ML2_126571', 126571, 0.18000001, 1, 1, 'SGA', 79, NULL);
INSERT INTO art_fraction VALUES ('ML2_126569', 126569, 0.15000001, 1, 1, 'TZI', 79, NULL);
INSERT INTO art_fraction VALUES ('ML2_126568', 126568, 0.23, 1, 1, 'DRO', 79, NULL);
INSERT INTO art_fraction VALUES ('ML2_126567', 126567, 1, 5, 1, 'LSE', 79, NULL);
INSERT INTO art_fraction VALUES ('ML2_126564', 126564, 3.7, 13, 1, 'AOC', 79, NULL);
INSERT INTO art_fraction VALUES ('ML2_126566', 126566, 0.69999999, 2, 1, 'BDM', 79, NULL);
INSERT INTO art_fraction VALUES ('ML2_126565', 126565, 3.7, 31, 1, 'OAU', 79, NULL);
INSERT INTO art_fraction VALUES ('ML2_126575', 126575, 3.2, 5, 1, 'BDM', 80, NULL);
INSERT INTO art_fraction VALUES ('ML2_126574', 126574, 17.9, 29, 1, 'CLS', 80, NULL);
INSERT INTO art_fraction VALUES ('ML2_126573', 126573, 7.4000001, 21, 1, 'AOC', 80, NULL);
INSERT INTO art_fraction VALUES ('ML2_126576', 126576, 0.34999999, 4, 1, 'OAU', 80, NULL);
INSERT INTO art_fraction VALUES ('ML2_126578', 126578, 0.15000001, 1, 1, 'MRU', 80, NULL);
INSERT INTO art_fraction VALUES ('ML2_126577', 126577, 0.25, 3, 1, 'LSE', 80, NULL);
INSERT INTO art_fraction VALUES ('ML2_126579', 126579, 0.11, 3, 1, 'TZI', 80, NULL);
INSERT INTO art_fraction VALUES ('ML2_126572', 126572, 6.9000001, 33, 1, 'CNI', 80, NULL);
INSERT INTO art_fraction VALUES ('ML2_126581', 126581, 3, 30, 1, 'CNI', 81, NULL);
INSERT INTO art_fraction VALUES ('ML2_126580', 126580, 11, 75, 1, 'LSE', 81, NULL);
INSERT INTO art_fraction VALUES ('ML2_126582', 126582, 0.80000001, 5, 1, 'OAU', 81, NULL);
INSERT INTO art_fraction VALUES ('ML2_126586', 126586, 2.5, 19, 1, 'LSE', 82, NULL);
INSERT INTO art_fraction VALUES ('ML2_126587', 126587, 0.12, 3, 1, 'CFI', 82, NULL);
INSERT INTO art_fraction VALUES ('ML2_126588', 126588, 0.25, 5, 1, 'SMY', 82, NULL);
INSERT INTO art_fraction VALUES ('ML2_126584', 126584, 0.25, 4, 1, 'HFA', 82, NULL);
INSERT INTO art_fraction VALUES ('ML2_126589', 126589, 0.1, 1, 1, 'TNI', 82, NULL);
INSERT INTO art_fraction VALUES ('ML2_126583', 126583, 0.80000001, 13, 1, 'OAU', 82, NULL);
INSERT INTO art_fraction VALUES ('ML2_126590', 126590, 0.1, 1, 1, 'DRO', 82, NULL);
INSERT INTO art_fraction VALUES ('ML2_126585', 126585, 1.2, 25, 1, 'SGA', 82, NULL);
INSERT INTO art_fraction VALUES ('ML2_126598', 126598, 0.80000001, 2, 1, 'SGA', 83, NULL);
INSERT INTO art_fraction VALUES ('ML2_126597', 126597, 0.34999999, 1, 1, 'SSC', 83, NULL);
INSERT INTO art_fraction VALUES ('ML2_126593', 126593, 1.8, 6, 1, 'OAU', 83, NULL);
INSERT INTO art_fraction VALUES ('ML2_126596', 126596, 0.34999999, 1, 1, 'AOC', 83, NULL);
INSERT INTO art_fraction VALUES ('ML2_126591', 126591, 5.6999998, 9, 1, 'CCI', 83, NULL);
INSERT INTO art_fraction VALUES ('ML2_126595', 126595, 1, 1, 1, 'MEL', 83, NULL);
INSERT INTO art_fraction VALUES ('ML2_126594', 126594, 0.40000001, 2, 1, 'TNI', 83, NULL);
INSERT INTO art_fraction VALUES ('ML2_126592', 126592, 3.5, 4, 1, 'BDM', 83, NULL);
INSERT INTO art_fraction VALUES ('ML2_127401', 127401, 1, 20, 1, 'CFI', 40, NULL);
INSERT INTO art_fraction VALUES ('ML2_127400', 127400, 2.2, 35, 1, 'CNI', 40, NULL);
INSERT INTO art_fraction VALUES ('ML2_127403', 127403, 7.3000002, 70, 1, 'OAU', 41, NULL);
INSERT INTO art_fraction VALUES ('ML2_127402', 127402, 3.5, 1, 1, 'HNI', 41, NULL);
INSERT INTO art_fraction VALUES ('ML2_127405', 127405, 0.15000001, 1, 1, 'LSE', 41, NULL);
INSERT INTO art_fraction VALUES ('ML2_127404', 127404, 5, 65, 1, 'SGA', 41, NULL);
INSERT INTO art_fraction VALUES ('ML2_127406', 127406, 0.30000001, 2, 1, 'TNI', 41, NULL);
INSERT INTO art_fraction VALUES ('ML2_127407', 127407, 3, 10, 1, 'AOC', 42, NULL);
INSERT INTO art_fraction VALUES ('ML2_127411', 127411, 0.44999999, 2, 1, 'TNI', 42, NULL);
INSERT INTO art_fraction VALUES ('ML2_127412', 127412, 1.2, 6, 1, 'CNI', 42, NULL);
INSERT INTO art_fraction VALUES ('ML2_127408', 127408, 1.5, 3, 1, 'CCI', 42, NULL);
INSERT INTO art_fraction VALUES ('ML2_127410', 127410, 0.60000002, 5, 1, 'SGA', 42, NULL);
INSERT INTO art_fraction VALUES ('ML2_127409', 127409, 1.2, 2, 1, 'BDM', 42, NULL);
INSERT INTO art_fraction VALUES ('ML2_127416', 127416, 2.5, 4, 1, 'BDM', 43, NULL);
INSERT INTO art_fraction VALUES ('ML2_127415', 127415, 0.80000001, 10, 1, 'SMY', 43, NULL);
INSERT INTO art_fraction VALUES ('ML2_127414', 127414, 1.5, 22, 1, 'CNI', 43, NULL);
INSERT INTO art_fraction VALUES ('ML2_127413', 127413, 3.5, 19, 1, 'AOC', 43, NULL);
INSERT INTO art_fraction VALUES ('ML2_127421', 127421, 3, 6, 1, 'AOC', 44, NULL);
INSERT INTO art_fraction VALUES ('ML2_127417', 127417, 5.5, 35, 1, 'SGA', 44, NULL);
INSERT INTO art_fraction VALUES ('ML2_127420', 127420, 1.5, 3, 1, 'HFO', 44, NULL);
INSERT INTO art_fraction VALUES ('ML2_127419', 127419, 3, 24, 1, 'LSE', 44, NULL);
INSERT INTO art_fraction VALUES ('ML2_127418', 127418, 7.1999998, 68, 1, 'OAU', 44, NULL);
INSERT INTO art_fraction VALUES ('ML2_127426', 127426, 0.25, 1, 1, 'HME', 45, NULL);
INSERT INTO art_fraction VALUES ('ML2_127424', 127424, 2.0999999, 20, 1, 'CNI', 45, NULL);
INSERT INTO art_fraction VALUES ('ML2_127425', 127425, 0.80000001, 3, 1, 'LSE', 45, NULL);
INSERT INTO art_fraction VALUES ('ML2_127423', 127423, 1.3, 2, 1, 'TLI', 45, NULL);
INSERT INTO art_fraction VALUES ('ML2_127422', 127422, 8.6000004, 90, 1, 'AOC', 45, NULL);
INSERT INTO art_fraction VALUES ('ML2_127427', 127427, 14, 28, 1, 'AOC', 46, NULL);
INSERT INTO art_fraction VALUES ('ML2_127428', 127428, 1, 1, 1, 'BDM', 46, NULL);
INSERT INTO art_fraction VALUES ('ML2_127429', 127429, 2.0999999, 5, 1, 'CNI', 46, NULL);
INSERT INTO art_fraction VALUES ('ML2_127430', 127430, 0.94999999, 2, 1, 'TLI', 46, NULL);
INSERT INTO art_fraction VALUES ('ML2_127435', 127435, 1.2, 1, 1, 'AOC', 47, NULL);
INSERT INTO art_fraction VALUES ('ML2_127432', 127432, 0.85000002, 1, 1, 'TLI', 47, NULL);
INSERT INTO art_fraction VALUES ('ML2_127431', 127431, 2.2, 1, 1, 'MRU', 47, NULL);
INSERT INTO art_fraction VALUES ('ML2_127433', 127433, 0.12, 1, 1, 'LSE', 47, NULL);
INSERT INTO art_fraction VALUES ('ML2_127434', 127434, 3, 78, 1, 'CNI', 47, NULL);
INSERT INTO art_fraction VALUES ('ML2_127438', 127438, 2.0999999, 3, 1, 'AOC', 48, NULL);
INSERT INTO art_fraction VALUES ('ML2_127437', 127437, 2.3, 3, 1, 'BDM', 48, NULL);
INSERT INTO art_fraction VALUES ('ML2_127436', 127436, 1.7, 7, 1, 'CNI', 48, NULL);
INSERT INTO art_fraction VALUES ('ML2_127441', 127441, 0.34999999, 1, 1, 'CNI', 49, NULL);
INSERT INTO art_fraction VALUES ('ML2_127443', 127443, 0.44999999, 1, 1, 'MDE', 49, NULL);
INSERT INTO art_fraction VALUES ('ML2_127444', 127444, 0.33000001, 1, 1, 'SGA', 49, NULL);
INSERT INTO art_fraction VALUES ('ML2_127440', 127440, 0.5, 2, 1, 'AOC', 49, NULL);
INSERT INTO art_fraction VALUES ('ML2_127439', 127439, 0.80000001, 2, 1, 'MRU', 49, NULL);
INSERT INTO art_fraction VALUES ('ML2_127445', 127445, 2.3, 1, 1, 'BDM', 49, NULL);
INSERT INTO art_fraction VALUES ('ML2_127442', 127442, 0.40000001, 1, 1, 'HME', 49, NULL);
INSERT INTO art_fraction VALUES ('ML2_127451', 127451, 0.34999999, 3, 1, 'AOC', 50, NULL);
INSERT INTO art_fraction VALUES ('ML2_127454', 127454, 0.30000001, 5, 1, 'TZI', 50, NULL);
INSERT INTO art_fraction VALUES ('ML2_127449', 127449, 0.30000001, 5, 1, 'HFA', 50, NULL);
INSERT INTO art_fraction VALUES ('ML2_127453', 127453, 0.2, 3, 1, 'ANU', 50, NULL);
INSERT INTO art_fraction VALUES ('ML2_127447', 127447, 2, 45, 1, 'OAU', 50, NULL);
INSERT INTO art_fraction VALUES ('ML2_127446', 127446, 3.5999999, 30, 1, 'LSE', 50, NULL);
INSERT INTO art_fraction VALUES ('ML2_127452', 127452, 0.2, 1, 1, 'SEU', 50, NULL);
INSERT INTO art_fraction VALUES ('ML2_127450', 127450, 0.40000001, 4, 1, 'DRO', 50, NULL);
INSERT INTO art_fraction VALUES ('ML2_127448', 127448, 0.40000001, 7, 1, 'SMY', 50, NULL);
INSERT INTO art_fraction VALUES ('ML2_127455', 127455, 0.15000001, 1, 1, 'CNI', 50, NULL);
INSERT INTO art_fraction VALUES ('ML2_127456', 127456, 1, 3, 1, 'AOC', 51, NULL);
INSERT INTO art_fraction VALUES ('ML2_127457', 127457, 0.47999999, 1, 1, 'TLI', 51, NULL);
INSERT INTO art_fraction VALUES ('ML2_127461', 127461, 3.1500001, 46, 1, 'CNI', 51, NULL);
INSERT INTO art_fraction VALUES ('ML2_127460', 127460, 0.17, 1, 1, 'MDE', 51, NULL);
INSERT INTO art_fraction VALUES ('ML2_127463', 127463, 0.25, 3, 1, 'SMY', 51, NULL);
INSERT INTO art_fraction VALUES ('ML2_127465', 127465, 0.15000001, 1, 1, 'MEL', 51, NULL);
INSERT INTO art_fraction VALUES ('ML2_127458', 127458, 0.30000001, 3, 1, 'OAU', 51, NULL);
INSERT INTO art_fraction VALUES ('ML2_127464', 127464, 0.17, 1, 1, 'LSE', 51, NULL);
INSERT INTO art_fraction VALUES ('ML2_127459', 127459, 0.30000001, 2, 1, 'BDM', 51, NULL);
INSERT INTO art_fraction VALUES ('ML2_127466', 127466, 0.2, 1, 1, 'TZI', 51, NULL);
INSERT INTO art_fraction VALUES ('ML2_127462', 127462, 0.15000001, 1, 1, 'LCO', 51, NULL);
INSERT INTO art_fraction VALUES ('ML2_127471', 127471, 0.5, 4, 1, 'HFA', 52, NULL);
INSERT INTO art_fraction VALUES ('ML2_127467', 127467, 2.3, 28, 1, 'OAU', 52, NULL);
INSERT INTO art_fraction VALUES ('ML2_127468', 127468, 2.0999999, 25, 1, 'SGA', 52, NULL);
INSERT INTO art_fraction VALUES ('ML2_127469', 127469, 1.3, 6, 1, 'LSE', 52, NULL);
INSERT INTO art_fraction VALUES ('ML2_127470', 127470, 0.69999999, 9, 1, 'TZI', 52, NULL);
INSERT INTO art_fraction VALUES ('ML2_127475', 127475, 0.34999999, 1, 1, 'BDM', 53, NULL);
INSERT INTO art_fraction VALUES ('ML2_127473', 127473, 0.51999998, 1, 1, 'CCI', 53, NULL);
INSERT INTO art_fraction VALUES ('ML2_127474', 127474, 0.44, 1, 1, 'HFO', 53, NULL);
INSERT INTO art_fraction VALUES ('ML2_127472', 127472, 2.8, 9, 1, 'AOC', 53, NULL);
INSERT INTO art_fraction VALUES ('ML2_127476', 127476, 0.46000001, 1, 1, 'LSE', 53, NULL);
INSERT INTO art_fraction VALUES ('ML2_127477', 127477, 0.15000001, 1, 1, 'OAU', 53, NULL);
INSERT INTO art_fraction VALUES ('ML2_127481', 127481, 0.1, 1, 1, 'LSE', 54, NULL);
INSERT INTO art_fraction VALUES ('ML2_127484', 127484, 0.029999999, 1, 1, 'SMY', 54, NULL);
INSERT INTO art_fraction VALUES ('ML2_127478', 127478, 2.5999999, 18, 1, 'SGA', 54, NULL);
INSERT INTO art_fraction VALUES ('ML2_127483', 127483, 0.12, 1, 1, 'TZI', 54, NULL);
INSERT INTO art_fraction VALUES ('ML2_127479', 127479, 2, 9, 1, 'OAU', 54, NULL);
INSERT INTO art_fraction VALUES ('ML2_127480', 127480, 0.1, 1, 1, 'CNI', 54, NULL);
INSERT INTO art_fraction VALUES ('ML2_127482', 127482, 0.40000001, 1, 1, 'TNI', 54, NULL);
INSERT INTO art_fraction VALUES ('ML2_127489', 127489, 1, 2, 1, 'BDM', 55, NULL);
INSERT INTO art_fraction VALUES ('ML2_127488', 127488, 2.2, 7, 1, 'HME', 55, NULL);
INSERT INTO art_fraction VALUES ('ML2_127486', 127486, 3.5, 18, 1, 'CNI', 55, NULL);
INSERT INTO art_fraction VALUES ('ML2_127490', 127490, 0.25, 1, 1, 'TLI', 55, NULL);
INSERT INTO art_fraction VALUES ('ML2_127487', 127487, 0.5, 1, 1, 'HFO', 55, NULL);
INSERT INTO art_fraction VALUES ('ML2_127485', 127485, 10, 25, 1, 'AOC', 55, NULL);
INSERT INTO art_fraction VALUES ('ML2_127493', 127493, 0.60000002, 2, 1, 'MEL', 56, NULL);
INSERT INTO art_fraction VALUES ('ML2_127494', 127494, 10, 185, 1, 'CNI', 56, NULL);
INSERT INTO art_fraction VALUES ('ML2_127491', 127491, 8, 26, 1, 'AOC', 56, NULL);
INSERT INTO art_fraction VALUES ('ML2_127492', 127492, 1, 1, 1, 'BDM', 56, NULL);
INSERT INTO art_fraction VALUES ('ML2_127495', 127495, 1, 2, 1, 'CLS', 56, NULL);
INSERT INTO art_fraction VALUES ('ML2_127496', 127496, 6.5, 13, 1, 'AOC', 57, NULL);
INSERT INTO art_fraction VALUES ('ML2_127498', 127498, 2.5, 16, 1, 'CNI', 57, NULL);
INSERT INTO art_fraction VALUES ('ML2_127497', 127497, 2, 2, 1, 'BDM', 57, NULL);
INSERT INTO art_fraction VALUES ('ML2_127505', 127505, 10.38, 305, 1, 'OAU', 58, NULL);
INSERT INTO art_fraction VALUES ('ML2_127502', 127502, 1.5, 5, 1, 'AOC', 58, NULL);
INSERT INTO art_fraction VALUES ('ML2_127499', 127499, 3, 5, 1, 'BDM', 58, NULL);
INSERT INTO art_fraction VALUES ('ML2_127507', 127507, 6, 215, 1, 'SMY', 58, NULL);
INSERT INTO art_fraction VALUES ('ML2_127503', 127503, 0.30000001, 1, 1, 'LNI', 58, NULL);
INSERT INTO art_fraction VALUES ('ML2_127504', 127504, 0.44999999, 1, 1, 'MRU', 58, NULL);
INSERT INTO art_fraction VALUES ('ML2_127501', 127501, 2.5, 5, 1, 'HFO', 58, NULL);
INSERT INTO art_fraction VALUES ('ML2_127500', 127500, 3, 3, 1, 'TLI', 58, NULL);
INSERT INTO art_fraction VALUES ('ML2_127506', 127506, 30, 0, 1, 'CNI', 58, NULL);
INSERT INTO art_fraction VALUES ('ML2_127508', 127508, 4, 25, 1, 'OAU', 59, NULL);
INSERT INTO art_fraction VALUES ('ML2_127509', 127509, 3, 1, 1, 'HNI', 59, NULL);
INSERT INTO art_fraction VALUES ('ML2_127510', 127510, 2.5, 20, 1, 'SGA', 59, NULL);
INSERT INTO art_fraction VALUES ('ML2_127512', 127512, 1.5, 15, 1, 'CFI', 60, NULL);
INSERT INTO art_fraction VALUES ('ML2_127513', 127513, 2, 20, 1, 'CNI', 60, NULL);
INSERT INTO art_fraction VALUES ('ML2_127511', 127511, 1.2, 4, 1, 'LSE', 60, NULL);
INSERT INTO art_fraction VALUES ('ML2_127514', 127514, 2.3, 1, 1, 'BDM', 61, NULL);
INSERT INTO art_fraction VALUES ('ML2_127515', 127515, 7, 110, 1, 'CNI', 61, NULL);
INSERT INTO art_fraction VALUES ('ML2_127516', 127516, 7.8000002, 37, 1, 'CNI', 62, NULL);
INSERT INTO art_fraction VALUES ('ML2_127517', 127517, 1, 4, 1, 'HME', 62, NULL);
INSERT INTO art_fraction VALUES ('ML2_127523', 127523, 3.5, 25, 1, 'LSE', 63, NULL);
INSERT INTO art_fraction VALUES ('ML2_127522', 127522, 2.5, 20, 1, 'ABA', 63, NULL);
INSERT INTO art_fraction VALUES ('ML2_127519', 127519, 15, 210, 1, 'CFI', 63, NULL);
INSERT INTO art_fraction VALUES ('ML2_127520', 127520, 5, 12, 1, 'AOC', 63, NULL);
INSERT INTO art_fraction VALUES ('ML2_127518', 127518, 25, 450, 1, 'CNI', 63, NULL);
INSERT INTO art_fraction VALUES ('ML2_127521', 127521, 2, 3, 1, 'HFO', 63, NULL);
INSERT INTO art_fraction VALUES ('ML2_127529', 127529, 0.60000002, 19, 1, 'SMY', 64, NULL);
INSERT INTO art_fraction VALUES ('ML2_127525', 127525, 0.47999999, 2, 1, 'MDE', 64, NULL);
INSERT INTO art_fraction VALUES ('ML2_127530', 127530, 0.12, 1, 1, 'GSE', 64, NULL);
INSERT INTO art_fraction VALUES ('ML2_127526', 127526, 2.8, 90, 1, 'LSE', 64, NULL);
INSERT INTO art_fraction VALUES ('ML2_127531', 127531, 0.1, 1, 1, 'LNI', 64, NULL);
INSERT INTO art_fraction VALUES ('ML2_127534', 127534, 0.17, 1, 1, 'ABA', 64, NULL);
INSERT INTO art_fraction VALUES ('ML2_127527', 127527, 0.80000001, 40, 1, 'OAU', 64, NULL);
INSERT INTO art_fraction VALUES ('ML2_127535', 127535, 0.15000001, 1, 1, 'LCO', 64, NULL);
INSERT INTO art_fraction VALUES ('ML2_127528', 127528, 0.40000001, 20, 1, 'SGA', 64, NULL);
INSERT INTO art_fraction VALUES ('ML2_127533', 127533, 0.18000001, 1, 1, 'CNI', 64, NULL);
INSERT INTO art_fraction VALUES ('ML2_127532', 127532, 0.15000001, 1, 1, 'CFI', 64, NULL);
INSERT INTO art_fraction VALUES ('ML2_127524', 127524, 0.44999999, 6, 1, 'HFA', 64, NULL);
INSERT INTO art_fraction VALUES ('ML2_127539', 127539, 1.2, 1, 1, 'HFO', 65, NULL);
INSERT INTO art_fraction VALUES ('ML2_127538', 127538, 0.69999999, 1, 1, 'MRU', 65, NULL);
INSERT INTO art_fraction VALUES ('ML2_127536', 127536, 0.85000002, 2, 1, 'AOC', 65, NULL);
INSERT INTO art_fraction VALUES ('ML2_127537', 127537, 0.31999999, 1, 1, 'OAU', 65, NULL);
INSERT INTO art_fraction VALUES ('ML2_127545', 127545, 1.5, 12, 1, 'LSE', 66, NULL);
INSERT INTO art_fraction VALUES ('ML2_127543', 127543, 3.2, 38, 1, 'CNI', 66, NULL);
INSERT INTO art_fraction VALUES ('ML2_127540', 127540, 0.5, 1, 1, 'CCI', 66, NULL);
INSERT INTO art_fraction VALUES ('ML2_127541', 127541, 2.0999999, 18, 1, 'OAU', 66, NULL);
INSERT INTO art_fraction VALUES ('ML2_127547', 127547, 2.3, 28, 1, 'CFI', 66, NULL);
INSERT INTO art_fraction VALUES ('ML2_127546', 127546, 1.1, 8, 1, 'SGA', 66, NULL);
INSERT INTO art_fraction VALUES ('ML2_127542', 127542, 1.8, 20, 1, 'TZI', 66, NULL);
INSERT INTO art_fraction VALUES ('ML2_127544', 127544, 0.69999999, 3, 1, 'AMA', 66, NULL);
INSERT INTO art_fraction VALUES ('ML2_127553', 127553, 18, 230, 1, 'CNI', 67, NULL);
INSERT INTO art_fraction VALUES ('ML2_127548', 127548, 0.30000001, 1, 1, 'HFO', 67, NULL);
INSERT INTO art_fraction VALUES ('ML2_127557', 127557, 1.8, 20, 1, 'TZI', 67, NULL);
INSERT INTO art_fraction VALUES ('ML2_127550', 127550, 3.5, 80, 1, 'OAU', 67, NULL);
INSERT INTO art_fraction VALUES ('ML2_127552', 127552, 15, 125, 1, 'CFI', 67, NULL);
INSERT INTO art_fraction VALUES ('ML2_127554', 127554, 0.18000001, 1, 1, 'AMA', 67, NULL);
INSERT INTO art_fraction VALUES ('ML2_127551', 127551, 1.2, 2, 1, 'AOC', 67, NULL);
INSERT INTO art_fraction VALUES ('ML2_127555', 127555, 2.5, 38, 1, 'SMY', 67, NULL);
INSERT INTO art_fraction VALUES ('ML2_127556', 127556, 2, 30, 1, 'LSE', 67, NULL);
INSERT INTO art_fraction VALUES ('ML2_127549', 127549, 5, 155, 1, 'SGA', 67, NULL);
INSERT INTO art_fraction VALUES ('ML2_127558', 127558, 1, 0, 1, 'TLI', 67, NULL);
INSERT INTO art_fraction VALUES ('ML2_127560', 127560, 0.34999999, 1, 1, 'AOC', 68, NULL);
INSERT INTO art_fraction VALUES ('ML2_127559', 127559, 2.3, 1, 1, 'BDM', 68, NULL);
INSERT INTO art_fraction VALUES ('ML2_127561', 127561, 3.8, 18, 1, 'CNI', 68, NULL);
INSERT INTO art_fraction VALUES ('ML2_128625', 128625, 3.3, 45, 1, 'OAU', 19, NULL);
INSERT INTO art_fraction VALUES ('ML2_128626', 128626, 2.0999999, 50, 1, 'TZI', 19, NULL);
INSERT INTO art_fraction VALUES ('ML2_128624', 128624, 1.9, 30, 1, 'CFI', 19, NULL);
INSERT INTO art_fraction VALUES ('ML2_128623', 128623, 2.0999999, 33, 1, 'SMY', 19, NULL);
INSERT INTO art_fraction VALUES ('ML2_128620', 128620, 30, 95, 1, 'HME', 19, NULL);
INSERT INTO art_fraction VALUES ('ML2_128621', 128621, 0.5, 1, 1, 'BOC', 19, NULL);
INSERT INTO art_fraction VALUES ('ML2_128622', 128622, 8.3000002, 110, 1, 'CNI', 19, NULL);
INSERT INTO art_fraction VALUES ('ML2_128631', 128631, 1.9, 25, 1, 'OAU', 20, NULL);
INSERT INTO art_fraction VALUES ('ML2_128630', 128630, 1.8, 4, 1, 'HFO', 20, NULL);
INSERT INTO art_fraction VALUES ('ML2_128629', 128629, 5.3000002, 8, 1, 'CCI', 20, NULL);
INSERT INTO art_fraction VALUES ('ML2_128632', 128632, 2.3, 43, 1, 'TZI', 20, NULL);
INSERT INTO art_fraction VALUES ('ML2_128627', 128627, 17, 45, 1, 'HME', 20, NULL);
INSERT INTO art_fraction VALUES ('ML2_128628', 128628, 20.5, 185, 1, 'CNI', 20, NULL);
INSERT INTO art_fraction VALUES ('ML2_128633', 128633, 5.6999998, 18, 1, 'HME', 21, NULL);
INSERT INTO art_fraction VALUES ('ML2_128634', 128634, 3.8, 27, 1, 'CNI', 21, NULL);
INSERT INTO art_fraction VALUES ('ML2_128635', 128635, 1.3, 2, 1, 'MRU', 21, NULL);
INSERT INTO art_fraction VALUES ('ML2_128636', 128636, 2.4000001, 3, 1, 'BDM', 21, NULL);
INSERT INTO art_fraction VALUES ('ML2_128638', 128638, 6.8000002, 11, 1, 'HME', 22, NULL);
INSERT INTO art_fraction VALUES ('ML2_128643', 128643, 3.2, 37, 1, 'SMY', 22, NULL);
INSERT INTO art_fraction VALUES ('ML2_128639', 128639, 2.3, 3, 1, 'HFO', 22, NULL);
INSERT INTO art_fraction VALUES ('ML2_128640', 128640, 11.8, 82, 1, 'CNI', 22, NULL);
INSERT INTO art_fraction VALUES ('ML2_128644', 128644, 1.7, 3, 1, 'AOC', 22, NULL);
INSERT INTO art_fraction VALUES ('ML2_128641', 128641, 8.3000002, 63, 1, 'CFI', 22, NULL);
INSERT INTO art_fraction VALUES ('ML2_128642', 128642, 1.2, 8, 1, 'OAU', 22, NULL);
INSERT INTO art_fraction VALUES ('ML2_128637', 128637, 5.0999999, 4, 1, 'CCI', 22, NULL);
INSERT INTO art_fraction VALUES ('ML2_128646', 128646, 5.5, 36, 1, 'CNI', 23, NULL);
INSERT INTO art_fraction VALUES ('ML2_128645', 128645, 2.3, 6, 1, 'HME', 23, NULL);
INSERT INTO art_fraction VALUES ('ML2_128649', 128649, 0.15000001, 1, 1, 'DRO', 24, NULL);
INSERT INTO art_fraction VALUES ('ML2_128652', 128652, 0.25, 1, 1, 'LNI', 24, NULL);
INSERT INTO art_fraction VALUES ('ML2_128653', 128653, 0.12, 1, 1, 'LSE', 24, NULL);
INSERT INTO art_fraction VALUES ('ML2_128650', 128650, 3.2, 21, 1, 'CNI', 24, NULL);
INSERT INTO art_fraction VALUES ('ML2_128651', 128651, 3.3, 5, 1, 'AOC', 24, NULL);
INSERT INTO art_fraction VALUES ('ML2_128648', 128648, 1.1, 1, 1, 'BDM', 24, NULL);
INSERT INTO art_fraction VALUES ('ML2_128657', 128657, 0.14, 1, 1, 'LCO', 24, NULL);
INSERT INTO art_fraction VALUES ('ML2_128656', 128656, 0.40000001, 1, 1, 'MDE', 24, NULL);
INSERT INTO art_fraction VALUES ('ML2_128655', 128655, 0.80000001, 2, 1, 'MEL', 24, NULL);
INSERT INTO art_fraction VALUES ('ML2_128647', 128647, 9.8000002, 11, 1, 'HME', 24, NULL);
INSERT INTO art_fraction VALUES ('ML2_128654', 128654, 0.1, 1, 1, 'SSC', 24, NULL);
INSERT INTO art_fraction VALUES ('ML2_128658', 128658, 0.80000001, 12, 1, 'HFA', 25, NULL);
INSERT INTO art_fraction VALUES ('ML2_128660', 128660, 0.30000001, 1, 1, 'SYF', 25, NULL);
INSERT INTO art_fraction VALUES ('ML2_128664', 128664, 0.40000001, 4, 1, 'CNI', 25, NULL);
INSERT INTO art_fraction VALUES ('ML2_128669', 128669, 0.80000001, 9, 1, 'TZI', 25, NULL);
INSERT INTO art_fraction VALUES ('ML2_128661', 128661, 0.30000001, 3, 1, 'MDE', 25, NULL);
INSERT INTO art_fraction VALUES ('ML2_128662', 128662, 0.1, 1, 1, 'AOC', 25, NULL);
INSERT INTO art_fraction VALUES ('ML2_128665', 128665, 0.75, 8, 1, 'SMY', 25, NULL);
INSERT INTO art_fraction VALUES ('ML2_128668', 128668, 0.30000001, 2, 1, 'BDM', 25, NULL);
INSERT INTO art_fraction VALUES ('ML2_128667', 128667, 0.69999999, 1, 1, 'HFO', 25, NULL);
INSERT INTO art_fraction VALUES ('ML2_128659', 128659, 0.60000002, 1, 1, 'HME', 25, NULL);
INSERT INTO art_fraction VALUES ('ML2_128663', 128663, 0.30000001, 1, 1, 'LSE', 25, NULL);
INSERT INTO art_fraction VALUES ('ML2_128666', 128666, 0.029999999, 1, 1, 'CFI', 25, NULL);
INSERT INTO art_fraction VALUES ('ML2_128670', 128670, 13.8, 31, 1, 'HME', 26, NULL);
INSERT INTO art_fraction VALUES ('ML2_128675', 128675, 6.6999998, 53, 1, 'OAU', 26, NULL);
INSERT INTO art_fraction VALUES ('ML2_128674', 128674, 3.2, 8, 1, 'AOC', 26, NULL);
INSERT INTO art_fraction VALUES ('ML2_128671', 128671, 15.7, 112, 1, 'CNI', 26, NULL);
INSERT INTO art_fraction VALUES ('ML2_128673', 128673, 5.8000002, 63, 1, 'SMY', 26, NULL);
INSERT INTO art_fraction VALUES ('ML2_128672', 128672, 8.1999998, 130, 1, 'CFI', 26, NULL);
INSERT INTO art_fraction VALUES ('ML2_128678', 128678, 0.89999998, 9, 1, 'SGA', 27, NULL);
INSERT INTO art_fraction VALUES ('ML2_128676', 128676, 5.1999998, 2, 1, 'CCI', 27, NULL);
INSERT INTO art_fraction VALUES ('ML2_128679', 128679, 6.5, 11, 1, 'HME', 27, NULL);
INSERT INTO art_fraction VALUES ('ML2_128681', 128681, 2.5999999, 6, 1, 'AOC', 27, NULL);
INSERT INTO art_fraction VALUES ('ML2_128680', 128680, 1.2, 1, 1, 'BDM', 27, NULL);
INSERT INTO art_fraction VALUES ('ML2_128682', 128682, 3.0999999, 5, 1, 'HFO', 27, NULL);
INSERT INTO art_fraction VALUES ('ML2_128677', 128677, 40.599998, 157, 1, 'CNI', 27, NULL);
INSERT INTO art_fraction VALUES ('ML2_128686', 128686, 0.059999999, 1, 1, 'GSE', 28, NULL);
INSERT INTO art_fraction VALUES ('ML2_128683', 128683, 1.2, 5, 1, 'CNI', 28, NULL);
INSERT INTO art_fraction VALUES ('ML2_128688', 128688, 0.1, 1, 1, 'MDE', 28, NULL);
INSERT INTO art_fraction VALUES ('ML2_128687', 128687, 0.079999998, 2, 1, 'SMY', 28, NULL);
INSERT INTO art_fraction VALUES ('ML2_128684', 128684, 0.5, 2, 1, 'LSE', 28, NULL);
INSERT INTO art_fraction VALUES ('ML2_128685', 128685, 0.30000001, 6, 1, 'CFI', 28, NULL);
INSERT INTO art_fraction VALUES ('ML2_128693', 128693, 16.299999, 170, 1, 'CNI', 29, NULL);
INSERT INTO art_fraction VALUES ('ML2_128690', 128690, 2.9000001, 5, 1, 'HME', 29, NULL);
INSERT INTO art_fraction VALUES ('ML2_128692', 128692, 2.5999999, 1, 1, 'HNI', 29, NULL);
INSERT INTO art_fraction VALUES ('ML2_128696', 128696, 0.69999999, 3, 1, 'LSE', 29, NULL);
INSERT INTO art_fraction VALUES ('ML2_128698', 128698, 0.25, 1, 1, 'MDE', 29, NULL);
INSERT INTO art_fraction VALUES ('ML2_128697', 128697, 0.2, 1, 1, 'AOC', 29, NULL);
INSERT INTO art_fraction VALUES ('ML2_128695', 128695, 3.2, 8, 1, 'OAU', 29, NULL);
INSERT INTO art_fraction VALUES ('ML2_128689', 128689, 4.8000002, 11, 1, 'HFO', 29, NULL);
INSERT INTO art_fraction VALUES ('ML2_128694', 128694, 1.1, 2, 1, 'MRU', 29, NULL);
INSERT INTO art_fraction VALUES ('ML2_128699', 128699, 1.8, 1, 1, 'BDM', 29, NULL);
INSERT INTO art_fraction VALUES ('ML2_128691', 128691, 2.3, 3, 1, 'CCI', 29, NULL);
INSERT INTO art_fraction VALUES ('ML2_128700', 128700, 8, 38, 1, 'CNI', 30, NULL);
INSERT INTO art_fraction VALUES ('ML2_128701', 128701, 7.3000002, 14, 1, 'HME', 30, NULL);
INSERT INTO art_fraction VALUES ('ML2_128702', 128702, 0.1, 1, 1, 'GSE', 30, NULL);
INSERT INTO art_fraction VALUES ('ML2_128703', 128703, 0.30000001, 1, 1, 'LSE', 30, NULL);
INSERT INTO art_fraction VALUES ('ML2_128704', 128704, 22.5, 1, 1, 'MEL', 31, NULL);
INSERT INTO art_fraction VALUES ('ML2_128706', 128706, 7, 46, 1, 'CNI', 31, NULL);
INSERT INTO art_fraction VALUES ('ML2_128705', 128705, 5.1999998, 8, 1, 'HME', 31, NULL);
INSERT INTO art_fraction VALUES ('ML2_128712', 128712, 3.2, 47, 1, 'TZI', 32, NULL);
INSERT INTO art_fraction VALUES ('ML2_128711', 128711, 7.5, 77, 1, 'OAU', 32, NULL);
INSERT INTO art_fraction VALUES ('ML2_128708', 128708, 3.5, 18, 1, 'CNI', 32, NULL);
INSERT INTO art_fraction VALUES ('ML2_128710', 128710, 3.7, 35, 1, 'SMY', 32, NULL);
INSERT INTO art_fraction VALUES ('ML2_128709', 128709, 1.8, 3, 1, 'HFO', 32, NULL);
INSERT INTO art_fraction VALUES ('ML2_128707', 128707, 4.5, 10, 1, 'HME', 32, NULL);
INSERT INTO art_fraction VALUES ('ML2_128721', 128721, 1.4, 1, 1, 'BDM', 33, NULL);
INSERT INTO art_fraction VALUES ('ML2_128719', 128719, 0.15000001, 1, 1, 'SSC', 33, NULL);
INSERT INTO art_fraction VALUES ('ML2_128720', 128720, 1.3, 2, 1, 'MDE', 33, NULL);
INSERT INTO art_fraction VALUES ('ML2_128714', 128714, 0.44999999, 2, 1, 'LCO', 33, NULL);
INSERT INTO art_fraction VALUES ('ML2_128717', 128717, 0.89999998, 2, 1, 'MRU', 33, NULL);
INSERT INTO art_fraction VALUES ('ML2_128715', 128715, 2.8, 5, 1, 'AOC', 33, NULL);
INSERT INTO art_fraction VALUES ('ML2_128713', 128713, 3.3, 13, 1, 'CNI', 33, NULL);
INSERT INTO art_fraction VALUES ('ML2_128716', 128716, 5.8000002, 18, 1, 'HME', 33, NULL);
INSERT INTO art_fraction VALUES ('ML2_128718', 128718, 0.1, 1, 1, 'CFI', 33, NULL);
INSERT INTO art_fraction VALUES ('ML2_128732', 128732, 0.12, 1, 1, 'DRO', 34, NULL);
INSERT INTO art_fraction VALUES ('ML2_128723', 128723, 1.8, 28, 1, 'OAU', 34, NULL);
INSERT INTO art_fraction VALUES ('ML2_128725', 128725, 2.9000001, 45, 1, 'TZI', 34, NULL);
INSERT INTO art_fraction VALUES ('ML2_128726', 128726, 0.80000001, 5, 1, 'LSE', 34, NULL);
INSERT INTO art_fraction VALUES ('ML2_128727', 128727, 0.13, 1, 1, 'LNI', 34, NULL);
INSERT INTO art_fraction VALUES ('ML2_128728', 128728, 0.30000001, 5, 1, 'SGA', 34, NULL);
INSERT INTO art_fraction VALUES ('ML2_128730', 128730, 0.17, 1, 1, 'ABA', 34, NULL);
INSERT INTO art_fraction VALUES ('ML2_128729', 128729, 0.34999999, 4, 1, 'SMY', 34, NULL);
INSERT INTO art_fraction VALUES ('ML2_128731', 128731, 0.13, 1, 1, 'ANU', 34, NULL);
INSERT INTO art_fraction VALUES ('ML2_128724', 128724, 0.2, 2, 1, 'BDM', 34, NULL);
INSERT INTO art_fraction VALUES ('ML2_128722', 128722, 1.5, 28, 1, 'HFA', 34, NULL);
INSERT INTO art_fraction VALUES ('ML2_128734', 128734, 0.34999999, 1, 1, 'MEL', 35, NULL);
INSERT INTO art_fraction VALUES ('ML2_128738', 128738, 0.25999999, 1, 1, 'LCO', 35, NULL);
INSERT INTO art_fraction VALUES ('ML2_128735', 128735, 1.5, 8, 1, 'CNI', 35, NULL);
INSERT INTO art_fraction VALUES ('ML2_128737', 128737, 0.56, 1, 1, 'AOC', 35, NULL);
INSERT INTO art_fraction VALUES ('ML2_128733', 128733, 0.30000001, 1, 1, 'HFO', 35, NULL);
INSERT INTO art_fraction VALUES ('ML2_128736', 128736, 1.8, 3, 1, 'HME', 35, NULL);
INSERT INTO art_fraction VALUES ('ML2_128740', 128740, 7.6999998, 43, 1, 'CNI', 36, NULL);
INSERT INTO art_fraction VALUES ('ML2_128739', 128739, 7.8000002, 15, 1, 'HME', 36, NULL);
INSERT INTO art_fraction VALUES ('ML2_128741', 128741, 0.47, 1, 1, 'MRU', 36, NULL);
INSERT INTO art_fraction VALUES ('ML2_128745', 128745, 7.5, 158, 1, 'CNI', 37, NULL);
INSERT INTO art_fraction VALUES ('ML2_128743', 128743, 6.8000002, 7, 1, 'CCI', 37, NULL);
INSERT INTO art_fraction VALUES ('ML2_128746', 128746, 6.1999998, 175, 1, 'SMY', 37, NULL);
INSERT INTO art_fraction VALUES ('ML2_128742', 128742, 1.3, 2, 1, 'HFO', 37, NULL);
INSERT INTO art_fraction VALUES ('ML2_128747', 128747, 5.1999998, 110, 1, 'TZI', 37, NULL);
INSERT INTO art_fraction VALUES ('ML2_128744', 128744, 3.7, 8, 1, 'HME', 37, NULL);
INSERT INTO art_fraction VALUES ('ML2_128750', 128750, 5.3000002, 27, 1, 'CNI', 38, NULL);
INSERT INTO art_fraction VALUES ('ML2_128752', 128752, 0.079999998, 1, 1, 'SMY', 38, NULL);
INSERT INTO art_fraction VALUES ('ML2_128749', 128749, 0.85000002, 2, 1, 'AOC', 38, NULL);
INSERT INTO art_fraction VALUES ('ML2_128751', 128751, 0.69999999, 1, 1, 'BDO', 38, NULL);
INSERT INTO art_fraction VALUES ('ML2_128748', 128748, 5.6999998, 10, 1, 'HME', 38, NULL);
INSERT INTO art_fraction VALUES ('ML2_128757', 128757, 0.15000001, 2, 1, 'SSC', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_128756', 128756, 1.75, 3, 1, 'BDM', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_128762', 128762, 1.2, 5, 1, 'CNI', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_128763', 128763, 1.8, 12, 1, 'HFA', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_128759', 128759, 2.5, 35, 1, 'TZI', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_128758', 128758, 0.80000001, 8, 1, 'SMY', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_128761', 128761, 0.5, 1, 1, 'AOC', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_128753', 128753, 0.15000001, 2, 1, 'ANU', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_128765', 128765, 0.25, 1, 1, 'LSE', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_128760', 128760, 0.15000001, 1, 1, 'SGA', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_128764', 128764, 0.34, 1, 1, 'DRO', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_128754', 128754, 0.30000001, 1, 1, 'TLI', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_128755', 128755, 0.5, 1, 1, 'LCO', 39, NULL);
INSERT INTO art_fraction VALUES ('ML2_129886', 129886, 3.5, 5, 1, 'AOC', 1, NULL);
INSERT INTO art_fraction VALUES ('ML2_129885', 129885, 6.3000002, 43, 1, 'CNI', 1, NULL);
INSERT INTO art_fraction VALUES ('ML2_129884', 129884, 2.5, 28, 1, 'OAU', 1, NULL);
INSERT INTO art_fraction VALUES ('ML2_129887', 129887, 2.0999999, 3, 1, 'HME', 1, NULL);
INSERT INTO art_fraction VALUES ('ML2_129889', 129889, 2.7, 12, 1, 'HME', 2, NULL);
INSERT INTO art_fraction VALUES ('ML2_129888', 129888, 3.3, 18, 1, 'CNI', 2, NULL);
INSERT INTO art_fraction VALUES ('ML2_129890', 129890, 1.2, 2, 1, 'BDM', 2, NULL);
INSERT INTO art_fraction VALUES ('ML2_129891', 129891, 3.5, 19, 1, 'AOC', 3, NULL);
INSERT INTO art_fraction VALUES ('ML2_129894', 129894, 0.40000001, 1, 1, 'MDE', 3, NULL);
INSERT INTO art_fraction VALUES ('ML2_129892', 129892, 4.6999998, 23, 1, 'CNI', 3, NULL);
INSERT INTO art_fraction VALUES ('ML2_129893', 129893, 0.30000001, 1, 1, 'LSE', 3, NULL);
INSERT INTO art_fraction VALUES ('ML2_129895', 129895, 28.5, 156, 1, 'CNI', 4, NULL);
INSERT INTO art_fraction VALUES ('ML2_129896', 129896, 3.8, 6, 1, 'HFO', 4, NULL);
INSERT INTO art_fraction VALUES ('ML2_129898', 129898, 5.8000002, 17, 1, 'HME', 4, NULL);
INSERT INTO art_fraction VALUES ('ML2_129899', 129899, 8.1999998, 72, 1, 'OAU', 4, NULL);
INSERT INTO art_fraction VALUES ('ML2_129897', 129897, 6.1999998, 4, 1, 'CCI', 4, NULL);
INSERT INTO art_fraction VALUES ('ML2_129901', 129901, 4.1999998, 13, 1, 'CNI', 5, NULL);
INSERT INTO art_fraction VALUES ('ML2_129900', 129900, 2.0999999, 4, 1, 'AOC', 5, NULL);
INSERT INTO art_fraction VALUES ('ML2_129902', 129902, 4.8000002, 6, 1, 'HME', 5, NULL);
INSERT INTO art_fraction VALUES ('ML2_129903', 129903, 1.8, 3, 1, 'BDM', 5, NULL);
INSERT INTO art_fraction VALUES ('ML2_129906', 129906, 10.5, 67, 1, 'OAU', 6, NULL);
INSERT INTO art_fraction VALUES ('ML2_129905', 129905, 3.0999999, 43, 1, 'SMY', 6, NULL);
INSERT INTO art_fraction VALUES ('ML2_129904', 129904, 3.8, 38, 1, 'CNI', 6, NULL);
INSERT INTO art_fraction VALUES ('ML2_129908', 129908, 1.3, 8, 1, 'LSE', 7, NULL);
INSERT INTO art_fraction VALUES ('ML2_129910', 129910, 1.7, 18, 1, 'TZI', 7, NULL);
INSERT INTO art_fraction VALUES ('ML2_129907', 129907, 2.5999999, 32, 1, 'CNI', 7, NULL);
INSERT INTO art_fraction VALUES ('ML2_129909', 129909, 2.3, 25, 1, 'OAU', 7, NULL);
INSERT INTO art_fraction VALUES ('ML2_129911', 129911, 8.5, 76, 1, 'OAU', 8, NULL);
INSERT INTO art_fraction VALUES ('ML2_129913', 129913, 3.0999999, 17, 1, 'HME', 8, NULL);
INSERT INTO art_fraction VALUES ('ML2_129912', 129912, 6.3000002, 53, 1, 'TZI', 8, NULL);
INSERT INTO art_fraction VALUES ('ML2_129918', 129918, 1.5, 19, 1, 'SGA', 8, NULL);
INSERT INTO art_fraction VALUES ('ML2_129917', 129917, 1.3, 23, 1, 'CFI', 8, NULL);
INSERT INTO art_fraction VALUES ('ML2_129916', 129916, 6.6999998, 37, 1, 'CNI', 8, NULL);
INSERT INTO art_fraction VALUES ('ML2_129914', 129914, 2.3, 5, 1, 'HFO', 8, NULL);
INSERT INTO art_fraction VALUES ('ML2_129915', 129915, 1.8, 18, 1, 'SMY', 8, NULL);
INSERT INTO art_fraction VALUES ('ML2_129919', 129919, 3.5, 15, 1, 'CNI', 9, NULL);
INSERT INTO art_fraction VALUES ('ML2_129921', 129921, 2.3, 6, 1, 'HME', 9, NULL);
INSERT INTO art_fraction VALUES ('ML2_129920', 129920, 2.8, 8, 1, 'AOC', 9, NULL);
INSERT INTO art_fraction VALUES ('ML2_129923', 129923, 1.3, 22, 1, 'OAU', 10, NULL);
INSERT INTO art_fraction VALUES ('ML2_129922', 129922, 2.8, 19, 1, 'CNI', 10, NULL);
INSERT INTO art_fraction VALUES ('ML2_129924', 129924, 1.5, 25, 1, 'TZI', 10, NULL);
INSERT INTO art_fraction VALUES ('ML2_129925', 129925, 0.80000001, 12, 1, 'ANU', 10, NULL);
INSERT INTO art_fraction VALUES ('ML2_129926', 129926, 1.2, 2, 1, 'BDM', 11, NULL);
INSERT INTO art_fraction VALUES ('ML2_129927', 129927, 1.1, 2, 1, 'HME', 11, NULL);
INSERT INTO art_fraction VALUES ('ML2_129928', 129928, 4.3000002, 22, 1, 'CNI', 11, NULL);
INSERT INTO art_fraction VALUES ('ML2_129936', 129936, 1.5, 2, 1, 'HFO', 12, NULL);
INSERT INTO art_fraction VALUES ('ML2_129934', 129934, 0.40000001, 1, 1, 'MEL', 12, NULL);
INSERT INTO art_fraction VALUES ('ML2_129930', 129930, 4.5, 28, 1, 'SGA', 12, NULL);
INSERT INTO art_fraction VALUES ('ML2_129929', 129929, 3.0999999, 50, 1, 'OAU', 12, NULL);
INSERT INTO art_fraction VALUES ('ML2_129932', 129932, 6.3000002, 6, 1, 'MRU', 12, NULL);
INSERT INTO art_fraction VALUES ('ML2_129931', 129931, 8.5, 7, 1, 'CCI', 12, NULL);
INSERT INTO art_fraction VALUES ('ML2_129937', 129937, 2.3, 22, 1, 'SMY', 12, NULL);
INSERT INTO art_fraction VALUES ('ML2_129935', 129935, 15.8, 63, 1, 'CNI', 12, NULL);
INSERT INTO art_fraction VALUES ('ML2_129938', 129938, 2, 2, 1, 'AOC', 12, NULL);
INSERT INTO art_fraction VALUES ('ML2_129933', 129933, 16.5, 40, 1, 'HME', 12, NULL);
INSERT INTO art_fraction VALUES ('ML2_129944', 129944, 0.2, 1, 1, 'SCL', 13, NULL);
INSERT INTO art_fraction VALUES ('ML2_129945', 129945, 0.13, 1, 1, 'OAU', 13, NULL);
INSERT INTO art_fraction VALUES ('ML2_129941', 129941, 0.1, 2, 1, 'CFI', 13, NULL);
INSERT INTO art_fraction VALUES ('ML2_129942', 129942, 0.80000001, 6, 1, 'SMY', 13, NULL);
INSERT INTO art_fraction VALUES ('ML2_129943', 129943, 0.15000001, 2, 1, 'SSC', 13, NULL);
INSERT INTO art_fraction VALUES ('ML2_129939', 129939, 1.8, 13, 1, 'CNI', 13, NULL);
INSERT INTO art_fraction VALUES ('ML2_129940', 129940, 0.25, 2, 1, 'SGA', 13, NULL);
INSERT INTO art_fraction VALUES ('ML2_129946', 129946, 8.1999998, 33, 1, 'CNI', 14, NULL);
INSERT INTO art_fraction VALUES ('ML2_129947', 129947, 2.5, 1, 1, 'MEL', 14, NULL);
INSERT INTO art_fraction VALUES ('ML2_129948', 129948, 1.3, 3, 1, 'HME', 14, NULL);
INSERT INTO art_fraction VALUES ('ML2_129953', 129953, 0.2, 1, 1, 'LCO', 15, NULL);
INSERT INTO art_fraction VALUES ('ML2_129952', 129952, 11.3, 63, 1, 'OAU', 15, NULL);
INSERT INTO art_fraction VALUES ('ML2_129951', 129951, 0.80000001, 2, 1, 'AOC', 15, NULL);
INSERT INTO art_fraction VALUES ('ML2_129957', 129957, 0.2, 1, 1, 'LNI', 15, NULL);
INSERT INTO art_fraction VALUES ('ML2_129949', 129949, 2.0999999, 4, 1, 'HME', 15, NULL);
INSERT INTO art_fraction VALUES ('ML2_129958', 129958, 0.16, 1, 1, 'SSC', 15, NULL);
INSERT INTO art_fraction VALUES ('ML2_129955', 129955, 1.3, 25, 1, 'SMY', 15, NULL);
INSERT INTO art_fraction VALUES ('ML2_129950', 129950, 1.3, 12, 1, 'SGA', 15, NULL);
INSERT INTO art_fraction VALUES ('ML2_129954', 129954, 13.5, 78, 1, 'CNI', 15, NULL);
INSERT INTO art_fraction VALUES ('ML2_129956', 129956, 0.15000001, 1, 1, 'ADE', 15, NULL);
INSERT INTO art_fraction VALUES ('ML2_129968', 129968, 0.2, 1, 1, 'SSC', 16, NULL);
INSERT INTO art_fraction VALUES ('ML2_129962', 129962, 0.76999998, 3, 1, 'MDE', 16, NULL);
INSERT INTO art_fraction VALUES ('ML2_129959', 129959, 0.44999999, 2, 1, 'OAU', 16, NULL);
INSERT INTO art_fraction VALUES ('ML2_129961', 129961, 0.60000002, 3, 1, 'DRO', 16, NULL);
INSERT INTO art_fraction VALUES ('ML2_129963', 129963, 0.1, 1, 1, 'LSE', 16, NULL);
INSERT INTO art_fraction VALUES ('ML2_129965', 129965, 1, 11, 1, 'SMY', 16, NULL);
INSERT INTO art_fraction VALUES ('ML2_129964', 129964, 0.80000001, 3, 1, 'BDM', 16, NULL);
INSERT INTO art_fraction VALUES ('ML2_129967', 129967, 0.64999998, 2, 1, 'TNI', 16, NULL);
INSERT INTO art_fraction VALUES ('ML2_129969', 129969, 0.050000001, 1, 1, 'LCO', 16, NULL);
INSERT INTO art_fraction VALUES ('ML2_129966', 129966, 0.89999998, 4, 1, 'CNI', 16, NULL);
INSERT INTO art_fraction VALUES ('ML2_129960', 129960, 1.8, 13, 1, 'SGA', 16, NULL);
INSERT INTO art_fraction VALUES ('ML2_129972', 129972, 12.5, 105, 1, 'OAU', 17, NULL);
INSERT INTO art_fraction VALUES ('ML2_129977', 129977, 3.5, 4, 1, 'HME', 17, NULL);
INSERT INTO art_fraction VALUES ('ML2_129975', 129975, 6.3000002, 72, 1, 'CNI', 17, NULL);
INSERT INTO art_fraction VALUES ('ML2_129974', 129974, 3.2, 4, 1, 'MDE', 17, NULL);
INSERT INTO art_fraction VALUES ('ML2_129970', 129970, 2.5, 4, 1, 'MRU', 17, NULL);
INSERT INTO art_fraction VALUES ('ML2_129971', 129971, 3.0999999, 1, 1, 'HFO', 17, NULL);
INSERT INTO art_fraction VALUES ('ML2_129973', 129973, 5.5, 67, 1, 'SGA', 17, NULL);
INSERT INTO art_fraction VALUES ('ML2_129976', 129976, 4.6999998, 60, 1, 'TZI', 17, NULL);
INSERT INTO art_fraction VALUES ('ML2_129980', 129980, 0.80000001, 6, 1, 'CNI', 18, NULL);
INSERT INTO art_fraction VALUES ('ML2_129978', 129978, 1, 3, 1, 'MDE', 18, NULL);
INSERT INTO art_fraction VALUES ('ML2_129979', 129979, 1.2, 27, 1, 'CFI', 18, NULL);


--
-- Data for Name: art_fraction_rec; Type: TABLE DATA; Schema: public; Owner: devppeao
--

INSERT INTO art_fraction_rec VALUES ('ML2_129887', 2.0999999, 3, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_129884', 2.5, 28, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_129885', 6.3000002, 43, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129886', 3.5, 5, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_129890', 1.2, 2, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_129888', 3.3, 18, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129889', 2.7, 12, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_129893', 0.30000001, 1, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_129892', 4.6999998, 23, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129894', 0.40000001, 1, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_129891', 3.5, 19, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_129897', 6.1999998, 4, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_129899', 8.1999998, 72, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_129898', 5.8000002, 17, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_129896', 3.8, 6, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_129895', 28.5, 156, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129903', 1.8, 3, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_129902', 4.8000002, 6, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_129900', 2.0999999, 4, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_129901', 4.1999998, 13, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129904', 3.8, 38, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129905', 3.0999999, 43, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_129906', 10.5, 67, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_129909', 2.3, 25, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_129907', 2.5999999, 32, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129910', 1.7, 18, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_129908', 1.3, 8, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_129915', 1.8, 18, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_129914', 2.3, 5, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_129916', 6.6999998, 37, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129917', 1.3, 23, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_129918', 1.5, 19, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_129912', 6.3000002, 53, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_129913', 3.0999999, 17, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_129911', 8.5, 76, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_129920', 2.8, 8, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_129921', 2.3, 6, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_129919', 3.5, 15, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129925', 0.80000001, 12, 'ANU');
INSERT INTO art_fraction_rec VALUES ('ML2_129924', 1.5, 25, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_129922', 2.8, 19, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129923', 1.3, 22, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_129928', 4.3000002, 22, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129927', 1.1, 2, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_129926', 1.2, 2, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_129933', 16.5, 40, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_129938', 2, 2, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_129935', 15.8, 63, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129937', 2.3, 22, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_129931', 8.5, 7, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_129932', 6.3000002, 6, 'MRU');
INSERT INTO art_fraction_rec VALUES ('ML2_129929', 3.0999999, 50, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_129930', 4.5, 28, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_129934', 0.40000001, 1, 'MEL');
INSERT INTO art_fraction_rec VALUES ('ML2_129936', 1.5, 2, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_129940', 0.25, 2, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_129939', 1.8, 13, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129943', 0.15000001, 2, 'SSC');
INSERT INTO art_fraction_rec VALUES ('ML2_129942', 0.80000001, 6, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_129941', 0.1, 2, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_129945', 0.13, 1, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_129944', 0.2, 1, 'SCL');
INSERT INTO art_fraction_rec VALUES ('ML2_129948', 1.3, 3, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_129947', 2.5, 1, 'MEL');
INSERT INTO art_fraction_rec VALUES ('ML2_129946', 8.1999998, 33, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129956', 0.15000001, 1, 'ADE');
INSERT INTO art_fraction_rec VALUES ('ML2_129954', 13.5, 78, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129950', 1.3, 12, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_129955', 1.3, 25, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_129958', 0.16, 1, 'SSC');
INSERT INTO art_fraction_rec VALUES ('ML2_129949', 2.0999999, 4, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_129957', 0.2, 1, 'LNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129951', 0.80000001, 2, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_129952', 11.3, 63, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_129953', 0.2, 1, 'LCO');
INSERT INTO art_fraction_rec VALUES ('ML2_129960', 1.8, 13, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_129966', 0.89999998, 4, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129969', 0.050000001, 1, 'LCO');
INSERT INTO art_fraction_rec VALUES ('ML2_129967', 0.64999998, 2, 'TNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129964', 0.80000001, 3, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_129965', 1, 11, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_129963', 0.1, 1, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_129961', 0.60000002, 3, 'DRO');
INSERT INTO art_fraction_rec VALUES ('ML2_129959', 0.44999999, 2, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_129962', 0.76999998, 3, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_129968', 0.2, 1, 'SSC');
INSERT INTO art_fraction_rec VALUES ('ML2_129976', 4.6999998, 60, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_129973', 5.5, 67, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_129971', 3.0999999, 1, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_129970', 2.5, 4, 'MRU');
INSERT INTO art_fraction_rec VALUES ('ML2_129974', 3.2, 4, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_129975', 6.3000002, 72, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_129977', 3.5, 4, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_129972', 12.5, 105, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_129979', 1.2, 27, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_129978', 1, 3, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_129980', 0.80000001, 6, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128622', 8.3000002, 110, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128621', 0.5, 1, 'BOC');
INSERT INTO art_fraction_rec VALUES ('ML2_128620', 30, 95, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128623', 2.0999999, 33, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_128624', 1.9, 30, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_128626', 2.0999999, 50, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_128625', 3.3, 45, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_128628', 20.5, 185, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128627', 17, 45, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128632', 2.3, 43, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_128629', 5.3000002, 8, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_128630', 1.8, 4, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_128631', 1.9, 25, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_128636', 2.4000001, 3, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_128635', 1.3, 2, 'MRU');
INSERT INTO art_fraction_rec VALUES ('ML2_128634', 3.8, 27, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128633', 5.6999998, 18, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128637', 5.0999999, 4, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_128642', 1.2, 8, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_128641', 8.3000002, 63, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_128644', 1.7, 3, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_128640', 11.8, 82, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128639', 2.3, 3, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_128643', 3.2, 37, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_128638', 6.8000002, 11, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128645', 2.3, 6, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128646', 5.5, 36, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128654', 0.1, 1, 'SSC');
INSERT INTO art_fraction_rec VALUES ('ML2_128647', 9.8000002, 11, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128655', 0.80000001, 2, 'MEL');
INSERT INTO art_fraction_rec VALUES ('ML2_128656', 0.40000001, 1, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_128657', 0.14, 1, 'LCO');
INSERT INTO art_fraction_rec VALUES ('ML2_128648', 1.1, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_128651', 3.3, 5, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_128650', 3.2, 21, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128653', 0.12, 1, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_128652', 0.25, 1, 'LNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128649', 0.15000001, 1, 'DRO');
INSERT INTO art_fraction_rec VALUES ('ML2_128666', 0.029999999, 1, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_128663', 0.30000001, 1, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_128659', 0.60000002, 1, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128667', 0.69999999, 1, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_128668', 0.30000001, 2, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_128665', 0.75, 8, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_128662', 0.1, 1, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_128661', 0.30000001, 3, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_128669', 0.80000001, 9, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_128664', 0.40000001, 4, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128660', 0.30000001, 1, 'SYF');
INSERT INTO art_fraction_rec VALUES ('ML2_128658', 0.80000001, 12, 'HFA');
INSERT INTO art_fraction_rec VALUES ('ML2_128672', 8.1999998, 130, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_128673', 5.8000002, 63, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_128671', 15.7, 112, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128674', 3.2, 8, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_128675', 6.6999998, 53, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_128670', 13.8, 31, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128677', 40.599998, 157, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128682', 3.0999999, 5, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_128680', 1.2, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_128681', 2.5999999, 6, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_128679', 6.5, 11, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128676', 5.1999998, 2, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_128678', 0.89999998, 9, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_128685', 0.30000001, 6, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_128684', 0.5, 2, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_128687', 0.079999998, 2, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_128688', 0.1, 1, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_128683', 1.2, 5, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128686', 0.059999999, 1, 'GSE');
INSERT INTO art_fraction_rec VALUES ('ML2_128691', 2.3, 3, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_128699', 1.8, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_128694', 1.1, 2, 'MRU');
INSERT INTO art_fraction_rec VALUES ('ML2_128689', 4.8000002, 11, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_128695', 3.2, 8, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_128697', 0.2, 1, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_128698', 0.25, 1, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_128696', 0.69999999, 3, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_128692', 2.5999999, 1, 'HNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128690', 2.9000001, 5, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128693', 16.299999, 170, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128703', 0.30000001, 1, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_128702', 0.1, 1, 'GSE');
INSERT INTO art_fraction_rec VALUES ('ML2_128701', 7.3000002, 14, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128700', 8, 38, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128705', 5.1999998, 8, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128706', 7, 46, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128704', 22.5, 1, 'MEL');
INSERT INTO art_fraction_rec VALUES ('ML2_128707', 4.5, 10, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128709', 1.8, 3, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_128710', 3.7, 35, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_128708', 3.5, 18, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128711', 7.5, 77, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_128712', 3.2, 47, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_128718', 0.1, 1, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_128716', 5.8000002, 18, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128713', 3.3, 13, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128715', 2.8, 5, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_128717', 0.89999998, 2, 'MRU');
INSERT INTO art_fraction_rec VALUES ('ML2_128714', 0.44999999, 2, 'LCO');
INSERT INTO art_fraction_rec VALUES ('ML2_128720', 1.3, 2, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_128719', 0.15000001, 1, 'SSC');
INSERT INTO art_fraction_rec VALUES ('ML2_128721', 1.4, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_128722', 1.5, 28, 'HFA');
INSERT INTO art_fraction_rec VALUES ('ML2_128724', 0.2, 2, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_128731', 0.13, 1, 'ANU');
INSERT INTO art_fraction_rec VALUES ('ML2_128729', 0.34999999, 4, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_128730', 0.17, 1, 'ABA');
INSERT INTO art_fraction_rec VALUES ('ML2_128728', 0.30000001, 5, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_128727', 0.13, 1, 'LNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128726', 0.80000001, 5, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_128725', 2.9000001, 45, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_128723', 1.8, 28, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_128732', 0.12, 1, 'DRO');
INSERT INTO art_fraction_rec VALUES ('ML2_128736', 1.8, 3, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128733', 0.30000001, 1, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_128737', 0.56, 1, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_128735', 1.5, 8, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128738', 0.25999999, 1, 'LCO');
INSERT INTO art_fraction_rec VALUES ('ML2_128734', 0.34999999, 1, 'MEL');
INSERT INTO art_fraction_rec VALUES ('ML2_128741', 0.47, 1, 'MRU');
INSERT INTO art_fraction_rec VALUES ('ML2_128739', 7.8000002, 15, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128740', 7.6999998, 43, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128744', 3.7, 8, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128747', 5.1999998, 110, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_128742', 1.3, 2, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_128746', 6.1999998, 175, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_128743', 6.8000002, 7, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_128745', 7.5, 158, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128748', 5.6999998, 10, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_128751', 0.69999999, 1, 'BDO');
INSERT INTO art_fraction_rec VALUES ('ML2_128749', 0.85000002, 2, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_128752', 0.079999998, 1, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_128750', 5.3000002, 27, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128755', 0.5, 1, 'LCO');
INSERT INTO art_fraction_rec VALUES ('ML2_128754', 0.30000001, 1, 'TLI');
INSERT INTO art_fraction_rec VALUES ('ML2_128764', 0.34, 1, 'DRO');
INSERT INTO art_fraction_rec VALUES ('ML2_128760', 0.15000001, 1, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_128765', 0.25, 1, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_128753', 0.15000001, 2, 'ANU');
INSERT INTO art_fraction_rec VALUES ('ML2_128761', 0.5, 1, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_128758', 0.80000001, 8, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_128759', 2.5, 35, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_128763', 1.8, 12, 'HFA');
INSERT INTO art_fraction_rec VALUES ('ML2_128762', 1.2, 5, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_128756', 1.75, 3, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_128757', 0.15000001, 2, 'SSC');
INSERT INTO art_fraction_rec VALUES ('ML2_127400', 2.2, 35, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127401', 1, 20, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_127406', 0.30000001, 2, 'TNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127404', 5, 65, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_127405', 0.15000001, 1, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127402', 3.5, 1, 'HNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127403', 7.3000002, 70, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127409', 1.2, 2, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127410', 0.60000002, 5, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_127408', 1.5, 3, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_127412', 1.2, 6, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127411', 0.44999999, 2, 'TNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127407', 3, 10, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127413', 3.5, 19, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127414', 1.5, 22, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127415', 0.80000001, 10, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_127416', 2.5, 4, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127418', 7.1999998, 68, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127419', 3, 24, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127420', 1.5, 3, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_127417', 5.5, 35, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_127421', 3, 6, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127422', 8.6000004, 90, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127423', 1.3, 2, 'TLI');
INSERT INTO art_fraction_rec VALUES ('ML2_127425', 0.80000001, 3, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127424', 2.0999999, 20, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127426', 0.25, 1, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_127430', 0.94999999, 2, 'TLI');
INSERT INTO art_fraction_rec VALUES ('ML2_127429', 2.0999999, 5, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127428', 1, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127427', 14, 28, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127434', 3, 78, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127433', 0.12, 1, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127431', 2.2, 1, 'MRU');
INSERT INTO art_fraction_rec VALUES ('ML2_127432', 0.85000002, 1, 'TLI');
INSERT INTO art_fraction_rec VALUES ('ML2_127435', 1.2, 1, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127436', 1.7, 7, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127437', 2.3, 3, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127438', 2.0999999, 3, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127442', 0.40000001, 1, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_127445', 2.3, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127439', 0.80000001, 2, 'MRU');
INSERT INTO art_fraction_rec VALUES ('ML2_127440', 0.5, 2, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127444', 0.33000001, 1, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_127443', 0.44999999, 1, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_127441', 0.34999999, 1, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127455', 0.15000001, 1, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127448', 0.40000001, 7, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_127450', 0.40000001, 4, 'DRO');
INSERT INTO art_fraction_rec VALUES ('ML2_127452', 0.2, 1, 'SEU');
INSERT INTO art_fraction_rec VALUES ('ML2_127446', 3.5999999, 30, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127447', 2, 45, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127453', 0.2, 3, 'ANU');
INSERT INTO art_fraction_rec VALUES ('ML2_127449', 0.30000001, 5, 'HFA');
INSERT INTO art_fraction_rec VALUES ('ML2_127454', 0.30000001, 5, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_127451', 0.34999999, 3, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127462', 0.15000001, 1, 'LCO');
INSERT INTO art_fraction_rec VALUES ('ML2_127466', 0.2, 1, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_127459', 0.30000001, 2, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127464', 0.17, 1, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127458', 0.30000001, 3, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127465', 0.15000001, 1, 'MEL');
INSERT INTO art_fraction_rec VALUES ('ML2_127463', 0.25, 3, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_127460', 0.17, 1, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_127461', 3.1500001, 46, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127457', 0.47999999, 1, 'TLI');
INSERT INTO art_fraction_rec VALUES ('ML2_127456', 1, 3, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127470', 0.69999999, 9, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_127469', 1.3, 6, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127468', 2.0999999, 25, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_127467', 2.3, 28, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127471', 0.5, 4, 'HFA');
INSERT INTO art_fraction_rec VALUES ('ML2_127477', 0.25, 2, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127476', 0.75, 2, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127472', 4.5799999, 15, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127474', 0.72000003, 2, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_127473', 0.85000002, 2, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_127475', 0.56999999, 2, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127482', 0.40000001, 1, 'TNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127480', 0.1, 1, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127479', 2, 9, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127483', 0.12, 1, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_127478', 2.5999999, 18, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_127484', 0.029999999, 1, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_127481', 0.1, 1, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127485', 10, 25, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127487', 0.5, 1, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_127490', 0.25, 1, 'TLI');
INSERT INTO art_fraction_rec VALUES ('ML2_127486', 3.5, 18, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127488', 2.2, 7, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_127489', 1, 2, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127495', 1, 2, 'CLS');
INSERT INTO art_fraction_rec VALUES ('ML2_127492', 1, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127491', 8, 26, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127494', 10, 185, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127493', 0.60000002, 2, 'MEL');
INSERT INTO art_fraction_rec VALUES ('ML2_127497', 2, 2, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127498', 2.5, 16, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127496', 6.5, 13, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127506', 30, 420, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127500', 3, 3, 'TLI');
INSERT INTO art_fraction_rec VALUES ('ML2_127501', 2.5, 5, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_127504', 0.44999999, 1, 'MRU');
INSERT INTO art_fraction_rec VALUES ('ML2_127503', 0.30000001, 1, 'LNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127507', 6, 215, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_127499', 3, 5, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127502', 1.5, 5, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127505', 10.38, 305, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127510', 2.5, 20, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_127509', 3, 1, 'HNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127508', 4, 25, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127511', 1.2, 4, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127513', 2, 20, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127512', 1.5, 15, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_127515', 7, 110, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127514', 2.3, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127517', 1, 4, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_127516', 7.8000002, 37, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127521', 2, 3, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_127518', 25, 450, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127520', 5, 12, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127519', 15, 210, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_127522', 2.5, 20, 'ABA');
INSERT INTO art_fraction_rec VALUES ('ML2_127523', 3.5, 25, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127524', 0.44999999, 6, 'HFA');
INSERT INTO art_fraction_rec VALUES ('ML2_127532', 0.15000001, 1, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_127533', 0.18000001, 1, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127528', 0.40000001, 20, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_127535', 0.15000001, 1, 'LCO');
INSERT INTO art_fraction_rec VALUES ('ML2_127527', 0.80000001, 40, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127534', 0.17, 1, 'ABA');
INSERT INTO art_fraction_rec VALUES ('ML2_127531', 0.1, 1, 'LNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127526', 2.8, 90, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127530', 0.12, 1, 'GSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127525', 0.47999999, 2, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_127529', 0.60000002, 19, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_127537', 0.31999999, 1, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127536', 0.85000002, 2, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127538', 0.69999999, 1, 'MRU');
INSERT INTO art_fraction_rec VALUES ('ML2_127539', 1.2, 1, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_127544', 0.69999999, 3, 'AMA');
INSERT INTO art_fraction_rec VALUES ('ML2_127542', 1.8, 20, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_127546', 1.1, 8, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_127547', 2.3, 28, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_127541', 2.0999999, 18, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127540', 0.5, 1, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_127543', 3.2, 38, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127545', 1.5, 12, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127558', 1, 1, 'TLI');
INSERT INTO art_fraction_rec VALUES ('ML2_127549', 5, 155, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_127556', 2, 30, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_127555', 2.5, 38, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_127551', 1.2, 2, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_127554', 0.18000001, 1, 'AMA');
INSERT INTO art_fraction_rec VALUES ('ML2_127552', 15, 125, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_127550', 3.5, 80, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_127557', 1.8, 20, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_127548', 0.30000001, 1, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_127553', 18, 230, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127561', 3.8, 18, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_127559', 2.3, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_127560', 0.34999999, 1, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_126502', 3, 25, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_126503', 0.60000002, 1, 'HBO');
INSERT INTO art_fraction_rec VALUES ('ML2_126504', 0.89999998, 5, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126506', 1.6, 7, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_126505', 1, 2, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_126508', 0.34999999, 2, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_126509', 0.46000001, 3, 'TNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126510', 0.079999998, 2, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_126507', 3.7, 21, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_126514', 0.5, 5, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_126522', 0.40000001, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_126512', 1.3, 6, 'TNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126521', 4.8000002, 11, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_126520', 1.25, 1, 'HNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126511', 1.8, 9, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_126513', 2, 9, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_126515', 0.5, 3, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_126519', 2, 4, 'MRU');
INSERT INTO art_fraction_rec VALUES ('ML2_126516', 0.079999998, 1, 'HFA');
INSERT INTO art_fraction_rec VALUES ('ML2_126517', 5.3000002, 4, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_126518', 0.07, 1, 'CLA');
INSERT INTO art_fraction_rec VALUES ('ML2_126524', 0.31999999, 3, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_126525', 6, 75, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_126523', 1, 32, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126526', 0.60000002, 2, 'HFO');
INSERT INTO art_fraction_rec VALUES ('ML2_126527', 0.5, 7, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_126528', 0.059999999, 1, 'HFA');
INSERT INTO art_fraction_rec VALUES ('ML2_126529', 1.2, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_126530', 16.25, 180, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126538', 0.085000001, 1, 'MDE');
INSERT INTO art_fraction_rec VALUES ('ML2_126539', 0.60000002, 1, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_126535', 0.75, 10, 'HFA');
INSERT INTO art_fraction_rec VALUES ('ML2_126534', 0.40000001, 6, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_126536', 2.3499999, 22, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126533', 9.3000002, 68, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_126537', 0.40000001, 2, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_126532', 1.3, 11, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_126531', 2.5, 30, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_126548', 0.1, 1, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_126547', 0.115, 1, 'TNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126540', 2.5999999, 33, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_126546', 0.74000001, 3, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_126541', 0.73000002, 2, 'DRO');
INSERT INTO art_fraction_rec VALUES ('ML2_126542', 1, 3, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126544', 0.13500001, 2, 'HFA');
INSERT INTO art_fraction_rec VALUES ('ML2_126543', 2.23, 9, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_126545', 0.34999999, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_126549', 4.1999998, 33, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_126550', 1.8, 25, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_126554', 0.050000001, 3, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_126551', 0.60000002, 10, 'TNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126552', 1.6, 8, 'HFA');
INSERT INTO art_fraction_rec VALUES ('ML2_126553', 3.5999999, 101, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_126563', 0.15000001, 1, 'CLA');
INSERT INTO art_fraction_rec VALUES ('ML2_126562', 0.44999999, 3, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_126559', 0.17, 1, 'HME');
INSERT INTO art_fraction_rec VALUES ('ML2_126560', 0.40000001, 1, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_126561', 0.38999999, 1, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_126558', 0.17, 1, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126557', 0.89999998, 3, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_126556', 0.38999999, 1, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_126555', 3.4000001, 2, 'HNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126565', 3.7, 31, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_126566', 0.69999999, 2, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_126564', 3.7, 13, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_126567', 1, 5, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_126568', 0.23, 1, 'DRO');
INSERT INTO art_fraction_rec VALUES ('ML2_126569', 0.15000001, 1, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_126571', 0.18000001, 1, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_126570', 0.12, 1, 'TNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126572', 6.9000001, 33, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126579', 0.11, 3, 'TZI');
INSERT INTO art_fraction_rec VALUES ('ML2_126577', 0.25, 3, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_126578', 0.15000001, 1, 'MRU');
INSERT INTO art_fraction_rec VALUES ('ML2_126576', 0.34999999, 4, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_126573', 7.4000001, 21, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_126574', 17.9, 29, 'CLS');
INSERT INTO art_fraction_rec VALUES ('ML2_126575', 3.2, 5, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_126582', 0.80000001, 5, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_126580', 11, 75, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_126581', 3, 30, 'CNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126585', 1.2, 25, 'SGA');
INSERT INTO art_fraction_rec VALUES ('ML2_126590', 0.1, 1, 'DRO');
INSERT INTO art_fraction_rec VALUES ('ML2_126583', 0.80000001, 13, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_126589', 0.1, 1, 'TNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126584', 0.25, 4, 'HFA');
INSERT INTO art_fraction_rec VALUES ('ML2_126588', 0.25, 5, 'SMY');
INSERT INTO art_fraction_rec VALUES ('ML2_126587', 0.12, 3, 'CFI');
INSERT INTO art_fraction_rec VALUES ('ML2_126586', 2.5, 19, 'LSE');
INSERT INTO art_fraction_rec VALUES ('ML2_126592', 3.5, 4, 'BDM');
INSERT INTO art_fraction_rec VALUES ('ML2_126594', 0.40000001, 2, 'TNI');
INSERT INTO art_fraction_rec VALUES ('ML2_126595', 1, 1, 'MEL');
INSERT INTO art_fraction_rec VALUES ('ML2_126591', 5.6999998, 9, 'CCI');
INSERT INTO art_fraction_rec VALUES ('ML2_126596', 0.34999999, 1, 'AOC');
INSERT INTO art_fraction_rec VALUES ('ML2_126593', 1.8, 6, 'OAU');
INSERT INTO art_fraction_rec VALUES ('ML2_126597', 0.34999999, 1, 'SSC');
INSERT INTO art_fraction_rec VALUES ('ML2_126598', 0.80000001, 2, 'SGA');


--
-- Data for Name: art_grand_type_engin; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_grand_type_engin VALUES ('BALAN', 'Balances');
INSERT INTO art_grand_type_engin VALUES ('BAMBO', 'Bambous');
INSERT INTO art_grand_type_engin VALUES ('DIVER', 'Divers');
INSERT INTO art_grand_type_engin VALUES ('EPERV', 'Epervier');
INSERT INTO art_grand_type_engin VALUES ('FCREV', 'Filet a etalage crevette');
INSERT INTO art_grand_type_engin VALUES ('FMCL', 'Filet Maillant a clochettes');
INSERT INTO art_grand_type_engin VALUES ('FMCLg', 'Filet Maillant a clochettes grandes mailles');
INSERT INTO art_grand_type_engin VALUES ('FMCLm', 'Filet Maillant a clochettes moyennes mailles');
INSERT INTO art_grand_type_engin VALUES ('FMCLp', 'Filet Maillant a clochettes petites mailles');
INSERT INTO art_grand_type_engin VALUES ('FMDE', 'Filet Maillant Derivant');
INSERT INTO art_grand_type_engin VALUES ('FMDEg', 'Filet Maillant Derivant grandes mailles');
INSERT INTO art_grand_type_engin VALUES ('FMDEm', 'Filet Maillant Derivant moyennes mailles');
INSERT INTO art_grand_type_engin VALUES ('FMDEp', 'Filet Maillant Derivant petites mailles');
INSERT INTO art_grand_type_engin VALUES ('FMDO', 'Filet Maillant Dormant');
INSERT INTO art_grand_type_engin VALUES ('FMDOg', 'Filet Maillant Dormant grandes mailles');
INSERT INTO art_grand_type_engin VALUES ('FMDOm', 'Filet Maillant Dormant moyennes mailles');
INSERT INTO art_grand_type_engin VALUES ('FMDOp', 'Filet Maillant Dormant petites mailles');
INSERT INTO art_grand_type_engin VALUES ('FMEN', 'Filet Maillant Encerclant');
INSERT INTO art_grand_type_engin VALUES ('FMENg', 'Filet Maillant Encerclant grandes mailles');
INSERT INTO art_grand_type_engin VALUES ('FMENm', 'Filet Maillant Encerclant moyennes mailles');
INSERT INTO art_grand_type_engin VALUES ('FMENp', 'Filet Maillant Encerclant petites mailles');
INSERT INTO art_grand_type_engin VALUES ('FMMEL', 'Filet Maillant Melange');
INSERT INTO art_grand_type_engin VALUES ('FMMO', 'Filet Maillant Monofilament');
INSERT INTO art_grand_type_engin VALUES ('FMMOg', 'Filet Maillant Monofilament grandes mailles');
INSERT INTO art_grand_type_engin VALUES ('FMMOm', 'Filet Maillant Monofilament moyennes mailles');
INSERT INTO art_grand_type_engin VALUES ('FMMOp', 'Filet Maillant Monofilament petites mailles');
INSERT INTO art_grand_type_engin VALUES ('GA/SW', 'Ganga/Swanya');
INSERT INTO art_grand_type_engin VALUES ('INCON', 'Inconnu');
INSERT INTO art_grand_type_engin VALUES ('LANCE', 'Harpon ou fusil de peche');
INSERT INTO art_grand_type_engin VALUES ('LIGNE', 'Ligne');
INSERT INTO art_grand_type_engin VALUES ('MELAN', 'Melange engins de peche');
INSERT INTO art_grand_type_engin VALUES ('NASSE', 'Nasse');
INSERT INTO art_grand_type_engin VALUES ('PALAN', 'Palangre');
INSERT INTO art_grand_type_engin VALUES ('PIEGE', 'Pieges, barrages');
INSERT INTO art_grand_type_engin VALUES ('SE_PL', 'Senne de plage');
INSERT INTO art_grand_type_engin VALUES ('SE_SY', 'Senne syndicat');
INSERT INTO art_grand_type_engin VALUES ('SE_TO', 'Senne tournante');


--
-- Data for Name: art_lieu_de_peche; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_lieu_de_peche VALUES (1, 14, 'SALENGOU', 1);
INSERT INTO art_lieu_de_peche VALUES (2, 14, 'DOUKANKONO', 2);
INSERT INTO art_lieu_de_peche VALUES (3, 14, 'FRIYA', 3);
INSERT INTO art_lieu_de_peche VALUES (4, 16, 'BOKADARY DAGA', 4);
INSERT INTO art_lieu_de_peche VALUES (5, 16, 'LASSINA DAGA', 5);
INSERT INTO art_lieu_de_peche VALUES (6, 15, 'DABANANI', 6);
INSERT INTO art_lieu_de_peche VALUES (7, 15, 'HARABA', 7);
INSERT INTO art_lieu_de_peche VALUES (8, 15, 'KOULOU KOBE', 8);
INSERT INTO art_lieu_de_peche VALUES (9, 15, 'OUEST MAMA', 9);
INSERT INTO art_lieu_de_peche VALUES (10, 15, 'KOULOU KOFE', 10);
INSERT INTO art_lieu_de_peche VALUES (11, 15, 'FACE MAMA', 11);
INSERT INTO art_lieu_de_peche VALUES (12, 15, 'BACO', 12);
INSERT INTO art_lieu_de_peche VALUES (13, 15, 'ACCIDENT', 13);
INSERT INTO art_lieu_de_peche VALUES (14, 15, 'SOBE DAGA', 14);
INSERT INTO art_lieu_de_peche VALUES (15, 15, 'DAGA KORO', 15);
INSERT INTO art_lieu_de_peche VALUES (16, 15, 'EST MAMA', 16);
INSERT INTO art_lieu_de_peche VALUES (17, 15, 'BANTADIOKE', 17);
INSERT INTO art_lieu_de_peche VALUES (18, 15, 'HARABA DOGODOGO', 18);
INSERT INTO art_lieu_de_peche VALUES (19, 15, 'SUD MAMA DAGA', 19);
INSERT INTO art_lieu_de_peche VALUES (20, 15, 'DOGODOGO', 20);
INSERT INTO art_lieu_de_peche VALUES (21, 15, 'NORD MAMA', 21);
INSERT INTO art_lieu_de_peche VALUES (22, 16, 'KAMOUNAKI', 22);
INSERT INTO art_lieu_de_peche VALUES (23, 16, 'KABAN', 23);
INSERT INTO art_lieu_de_peche VALUES (24, 16, 'NGOUGNY', 24);
INSERT INTO art_lieu_de_peche VALUES (25, 16, 'NORD NGOUGNI', 25);
INSERT INTO art_lieu_de_peche VALUES (26, 16, 'EST NGOUGNY', 26);
INSERT INTO art_lieu_de_peche VALUES (27, 16, 'TIMBIRIQUI', 27);
INSERT INTO art_lieu_de_peche VALUES (28, 16, 'MAKAHINDAGA', 28);
INSERT INTO art_lieu_de_peche VALUES (29, 16, 'SEBEKORO', 29);
INSERT INTO art_lieu_de_peche VALUES (30, 16, 'HABAN', 30);
INSERT INTO art_lieu_de_peche VALUES (31, 14, 'ANCIEN NIGUI', 31);
INSERT INTO art_lieu_de_peche VALUES (32, 14, 'SUD SALENGOU', 32);
INSERT INTO art_lieu_de_peche VALUES (33, 14, 'KOUROUNIDIAN', 33);
INSERT INTO art_lieu_de_peche VALUES (34, 14, 'EST SALENGOU', 34);
INSERT INTO art_lieu_de_peche VALUES (35, 14, 'OUEST SALENGOU', 35);
INSERT INTO art_lieu_de_peche VALUES (36, 14, 'VERS NIGUI', 36);
INSERT INTO art_lieu_de_peche VALUES (37, 14, 'COULOIR SEBE', 37);
INSERT INTO art_lieu_de_peche VALUES (38, 14, 'FACE SALENGOU', 38);
INSERT INTO art_lieu_de_peche VALUES (39, 14, 'KOUROUNIKO', 39);
INSERT INTO art_lieu_de_peche VALUES (40, 14, 'KEGNIKO', 40);
INSERT INTO art_lieu_de_peche VALUES (41, 14, 'FRYA KORO', 41);
INSERT INTO art_lieu_de_peche VALUES (42, 14, 'VERS MANANTALI', 42);
INSERT INTO art_lieu_de_peche VALUES (43, 14, 'NORD SALENGOU', 43);
INSERT INTO art_lieu_de_peche VALUES (44, 14, 'ANCIEN BAMAFLE', 44);
INSERT INTO art_lieu_de_peche VALUES (45, 15, 'EST-OUEST', 45);
INSERT INTO art_lieu_de_peche VALUES (46, 15, 'NORD KITA', 46);
INSERT INTO art_lieu_de_peche VALUES (47, 15, 'OUEST KITA', 47);
INSERT INTO art_lieu_de_peche VALUES (48, 15, 'SEGUELA', 48);
INSERT INTO art_lieu_de_peche VALUES (49, 15, 'DIANDIANA', 49);
INSERT INTO art_lieu_de_peche VALUES (50, 15, 'N-W KITA', 50);
INSERT INTO art_lieu_de_peche VALUES (51, 15, 'SUD KITA', 51);
INSERT INTO art_lieu_de_peche VALUES (52, 15, 'EST-NORD KITA', 52);
INSERT INTO art_lieu_de_peche VALUES (53, 14, 'MANANTALI', 53);
INSERT INTO art_lieu_de_peche VALUES (54, 15, 'KERWANE', 54);
INSERT INTO art_lieu_de_peche VALUES (55, 15, 'SANGADA', 55);
INSERT INTO art_lieu_de_peche VALUES (56, 15, 'TONDIDJI', 56);
INSERT INTO art_lieu_de_peche VALUES (57, 15, 'KENEBANI', 57);
INSERT INTO art_lieu_de_peche VALUES (58, 15, 'DUKANKONO', 58);
INSERT INTO art_lieu_de_peche VALUES (59, 15, 'TENTIBLE', 59);
INSERT INTO art_lieu_de_peche VALUES (60, 15, 'BARKABOUGOU', 60);
INSERT INTO art_lieu_de_peche VALUES (61, 15, 'MADINA NIDI', 61);
INSERT INTO art_lieu_de_peche VALUES (62, 15, 'KOULOUNINA', 62);
INSERT INTO art_lieu_de_peche VALUES (63, 15, 'BAMAFLEKORO', 63);
INSERT INTO art_lieu_de_peche VALUES (64, 15, 'FACE TENTIBLE', 64);
INSERT INTO art_lieu_de_peche VALUES (65, 15, 'TIRIYAKORO', 65);
INSERT INTO art_lieu_de_peche VALUES (66, 15, 'ANCIEN CHAMP', 66);
INSERT INTO art_lieu_de_peche VALUES (67, 15, 'MADINA KORO', 67);
INSERT INTO art_lieu_de_peche VALUES (68, 14, 'EST KERWANE', 68);
INSERT INTO art_lieu_de_peche VALUES (69, 14, 'COULOIR KERWANE', 69);
INSERT INTO art_lieu_de_peche VALUES (70, 14, 'VERS TONDIDJI', 70);
INSERT INTO art_lieu_de_peche VALUES (71, 14, 'SUD KERWANE', 71);
INSERT INTO art_lieu_de_peche VALUES (72, 14, 'VERS MADINA', 72);
INSERT INTO art_lieu_de_peche VALUES (73, 14, 'FACE KERWANE', 73);
INSERT INTO art_lieu_de_peche VALUES (74, 14, 'ANCIEN KERWANE', 74);
INSERT INTO art_lieu_de_peche VALUES (75, 14, 'OUEST KERWANE', 75);
INSERT INTO art_lieu_de_peche VALUES (76, 14, 'COULOIR MADINA', 76);
INSERT INTO art_lieu_de_peche VALUES (77, 14, 'COULOIR', 77);
INSERT INTO art_lieu_de_peche VALUES (78, 15, 'NORD BURKINA', 78);
INSERT INTO art_lieu_de_peche VALUES (79, 15, 'EST BURKINA', 79);
INSERT INTO art_lieu_de_peche VALUES (80, 15, 'DANGAN', 80);
INSERT INTO art_lieu_de_peche VALUES (81, 15, 'FACE BURKINA', 81);
INSERT INTO art_lieu_de_peche VALUES (82, 15, 'BURKINA DAGA', 82);
INSERT INTO art_lieu_de_peche VALUES (83, 15, 'NORD', 83);
INSERT INTO art_lieu_de_peche VALUES (84, 15, 'LAMAKARA', 84);
INSERT INTO art_lieu_de_peche VALUES (85, 15, 'BA KIELA', 85);
INSERT INTO art_lieu_de_peche VALUES (86, 16, 'BAMBOUTA', 86);
INSERT INTO art_lieu_de_peche VALUES (87, 16, 'SOUNKOYEKA', 87);
INSERT INTO art_lieu_de_peche VALUES (88, 16, 'DRAMEKADOGODOGO', 88);
INSERT INTO art_lieu_de_peche VALUES (89, 16, 'BAMBOUTADOKODO', 89);
INSERT INTO art_lieu_de_peche VALUES (90, 16, 'OUEST SEBEKORO', 90);
INSERT INTO art_lieu_de_peche VALUES (91, 16, 'N-E SEBEKORO', 91);
INSERT INTO art_lieu_de_peche VALUES (92, 16, 'KABAKOUROU', 92);
INSERT INTO art_lieu_de_peche VALUES (93, 16, 'EST-OUEST PORT', 93);
INSERT INTO art_lieu_de_peche VALUES (94, 16, 'OUEST DU PORT', 94);
INSERT INTO art_lieu_de_peche VALUES (95, 16, 'EST SEBEKORO', 95);
INSERT INTO art_lieu_de_peche VALUES (96, 16, 'BANDOKO', 96);
INSERT INTO art_lieu_de_peche VALUES (97, 14, 'FACE NIGUI', 97);
INSERT INTO art_lieu_de_peche VALUES (98, 14, 'OUEST NIGUI', 98);
INSERT INTO art_lieu_de_peche VALUES (99, 14, 'EST NIGUI', 99);
INSERT INTO art_lieu_de_peche VALUES (100, 14, 'COULOIR NIGUI', 100);
INSERT INTO art_lieu_de_peche VALUES (101, 16, 'HAKAN', 101);
INSERT INTO art_lieu_de_peche VALUES (102, 16, 'OUEST NGOUGNY', 102);
INSERT INTO art_lieu_de_peche VALUES (103, 15, 'ANCIEN BADIOKE', 103);
INSERT INTO art_lieu_de_peche VALUES (104, 15, 'DJENDJENA', 104);
INSERT INTO art_lieu_de_peche VALUES (105, 15, 'GAFANKORO', 105);
INSERT INTO art_lieu_de_peche VALUES (106, 15, 'ANCIEN TOAFAN', 106);
INSERT INTO art_lieu_de_peche VALUES (107, 15, 'TOANTAKORO', 107);
INSERT INTO art_lieu_de_peche VALUES (108, 15, 'FACE LADJI', 108);
INSERT INTO art_lieu_de_peche VALUES (109, 16, 'NORD DRAME', 109);
INSERT INTO art_lieu_de_peche VALUES (110, 16, 'EST DRAME', 110);
INSERT INTO art_lieu_de_peche VALUES (111, 16, 'SUD DRAME', 111);
INSERT INTO art_lieu_de_peche VALUES (112, 16, 'N-S DRAME', 112);
INSERT INTO art_lieu_de_peche VALUES (113, 16, 'KOUA DAGA', 113);
INSERT INTO art_lieu_de_peche VALUES (114, 16, 'FACE DRAME', 114);
INSERT INTO art_lieu_de_peche VALUES (115, 16, 'KOROUDJOUKORO', 115);
INSERT INTO art_lieu_de_peche VALUES (116, 16, 'VERS DJENEBA', 116);
INSERT INTO art_lieu_de_peche VALUES (117, 16, 'ADOUKA DAGA', 117);
INSERT INTO art_lieu_de_peche VALUES (118, 16, 'KOUROUDJOUKORO', 118);
INSERT INTO art_lieu_de_peche VALUES (119, 16, 'OUEST DRAME', 119);
INSERT INTO art_lieu_de_peche VALUES (120, 15, 'NORD ADOU', 120);
INSERT INTO art_lieu_de_peche VALUES (121, 15, 'SUD ADOU', 121);
INSERT INTO art_lieu_de_peche VALUES (122, 15, 'SUD DAGA', 122);
INSERT INTO art_lieu_de_peche VALUES (123, 15, 'SUD YALCOUE', 123);
INSERT INTO art_lieu_de_peche VALUES (124, 15, 'EST ADOU', 124);
INSERT INTO art_lieu_de_peche VALUES (125, 15, 'MAMA DOGODOGO', 125);
INSERT INTO art_lieu_de_peche VALUES (126, 14, 'COLLINE NOIRE', 126);
INSERT INTO art_lieu_de_peche VALUES (127, 15, 'ANCIEN KAMBOU', 127);
INSERT INTO art_lieu_de_peche VALUES (128, 15, 'DOGODOGO OUEST', 128);
INSERT INTO art_lieu_de_peche VALUES (129, 15, 'ANCIEN KOMBA', 129);
INSERT INTO art_lieu_de_peche VALUES (130, 15, 'EST KITA', 130);
INSERT INTO art_lieu_de_peche VALUES (131, 16, 'NORD GARAN', 131);
INSERT INTO art_lieu_de_peche VALUES (132, 16, 'EST-SUD NGOUGNI', 132);
INSERT INTO art_lieu_de_peche VALUES (133, 16, 'N-E NGOUGNY', 133);
INSERT INTO art_lieu_de_peche VALUES (134, 16, 'N-W NGOUGNY', 134);
INSERT INTO art_lieu_de_peche VALUES (135, 16, 'FACE NGOUGNY', 135);
INSERT INTO art_lieu_de_peche VALUES (136, 15, 'MALISOUDOGO', 136);
INSERT INTO art_lieu_de_peche VALUES (137, 15, 'DOUGOUKORO', 137);
INSERT INTO art_lieu_de_peche VALUES (138, 15, 'GOUMBAN', 138);
INSERT INTO art_lieu_de_peche VALUES (139, 15, 'SONGADA', 139);
INSERT INTO art_lieu_de_peche VALUES (140, 15, 'TAKRA', 140);
INSERT INTO art_lieu_de_peche VALUES (141, 15, 'DJILINGUE', 141);
INSERT INTO art_lieu_de_peche VALUES (142, 15, 'OUEST TENTIBLE', 142);
INSERT INTO art_lieu_de_peche VALUES (143, 15, 'ANCIEN TONDIDJI', 143);
INSERT INTO art_lieu_de_peche VALUES (144, 16, 'VERS BANBOUTA', 144);
INSERT INTO art_lieu_de_peche VALUES (145, 16, 'NORD SEBEKORO', 145);
INSERT INTO art_lieu_de_peche VALUES (146, 15, 'KITA DAGAN', 146);
INSERT INTO art_lieu_de_peche VALUES (147, 15, 'OUEST BURKINA', 147);
INSERT INTO art_lieu_de_peche VALUES (148, 15, 'OUEST LADJI', 148);
INSERT INTO art_lieu_de_peche VALUES (149, 15, 'ANCIEN GANFA', 149);
INSERT INTO art_lieu_de_peche VALUES (150, 15, 'SUD LADJI', 150);
INSERT INTO art_lieu_de_peche VALUES (151, 15, 'BATIAMATIE', 151);
INSERT INTO art_lieu_de_peche VALUES (152, 15, 'FACE ADOU', 152);
INSERT INTO art_lieu_de_peche VALUES (153, 15, 'OUEST ADOU', 153);
INSERT INTO art_lieu_de_peche VALUES (154, 16, 'CHUTE D`EAU', 154);
INSERT INTO art_lieu_de_peche VALUES (155, 16, 'LAHAN', 155);
INSERT INTO art_lieu_de_peche VALUES (156, 15, 'BORY DOGODOGO', 156);
INSERT INTO art_lieu_de_peche VALUES (157, 15, 'DEMBA KOULU', 157);
INSERT INTO art_lieu_de_peche VALUES (158, 14, 'COULOIR TONDIDJ', 158);
INSERT INTO art_lieu_de_peche VALUES (159, 15, 'KOROMOUDO', 159);
INSERT INTO art_lieu_de_peche VALUES (160, 15, 'KROMOUDOLO', 160);
INSERT INTO art_lieu_de_peche VALUES (161, 15, 'DIARA DOGODOGO', 161);
INSERT INTO art_lieu_de_peche VALUES (162, 15, 'KOULOU SEGUELA', 162);
INSERT INTO art_lieu_de_peche VALUES (163, 15, 'SUD TENTIBLE', 163);
INSERT INTO art_lieu_de_peche VALUES (164, 15, 'VERS LA COLLINE', 164);
INSERT INTO art_lieu_de_peche VALUES (165, 15, 'ANCIEN MADINA', 165);
INSERT INTO art_lieu_de_peche VALUES (166, 16, 'SEBETOU', 166);
INSERT INTO art_lieu_de_peche VALUES (167, 16, 'FACE SEBEKORO', 167);
INSERT INTO art_lieu_de_peche VALUES (168, 15, 'DOGOBA', 168);
INSERT INTO art_lieu_de_peche VALUES (169, 15, 'SUD BURKINA', 169);
INSERT INTO art_lieu_de_peche VALUES (170, 15, 'BURKINA', 170);
INSERT INTO art_lieu_de_peche VALUES (171, 15, 'SOUMANA', 171);
INSERT INTO art_lieu_de_peche VALUES (172, 15, 'OUMAR DAGA', 172);
INSERT INTO art_lieu_de_peche VALUES (173, 15, 'SOUMANA ', 173);
INSERT INTO art_lieu_de_peche VALUES (174, 19, 'SANKARANI', 174);
INSERT INTO art_lieu_de_peche VALUES (175, 18, 'FACE CAMPEMENT', 175);
INSERT INTO art_lieu_de_peche VALUES (176, 18, 'KANGARECORO', 176);
INSERT INTO art_lieu_de_peche VALUES (177, 18, 'COTE CARRIERE', 177);
INSERT INTO art_lieu_de_peche VALUES (178, 18, 'FACE BARRAGE', 178);
INSERT INTO art_lieu_de_peche VALUES (179, 18, 'COULOIR KANGARE', 179);
INSERT INTO art_lieu_de_peche VALUES (180, 18, 'MANDING VOYAGE', 180);
INSERT INTO art_lieu_de_peche VALUES (181, 18, 'CONFLUENT', 181);
INSERT INTO art_lieu_de_peche VALUES (182, 18, 'FACE BROULAYE', 182);
INSERT INTO art_lieu_de_peche VALUES (183, 18, 'ALI SEREBA DAGA', 183);
INSERT INTO art_lieu_de_peche VALUES (184, 18, 'FACE BOZOLA', 184);
INSERT INTO art_lieu_de_peche VALUES (185, 18, 'COULOIR DJELENI', 185);
INSERT INTO art_lieu_de_peche VALUES (186, 20, 'KOROMOU KONO', 186);
INSERT INTO art_lieu_de_peche VALUES (187, 20, 'COTE DE DALABA', 187);
INSERT INTO art_lieu_de_peche VALUES (188, 20, 'AUTRE RIVE', 188);
INSERT INTO art_lieu_de_peche VALUES (189, 20, 'KONA DAGA', 189);
INSERT INTO art_lieu_de_peche VALUES (190, 20, 'PRES DE DALABA', 190);
INSERT INTO art_lieu_de_peche VALUES (191, 20, 'TIEGANAN DAGA', 191);
INSERT INTO art_lieu_de_peche VALUES (192, 20, 'DANS UN COIN', 192);
INSERT INTO art_lieu_de_peche VALUES (193, 20, 'BORD DU LAC', 193);
INSERT INTO art_lieu_de_peche VALUES (194, 20, 'DOSSOLA-TIEGANA', 194);
INSERT INTO art_lieu_de_peche VALUES (195, 20, 'MAHIN DAGA', 195);
INSERT INTO art_lieu_de_peche VALUES (196, 20, 'PRES DOSSOLA', 196);
INSERT INTO art_lieu_de_peche VALUES (197, 20, 'PRES TIENGANA', 197);
INSERT INTO art_lieu_de_peche VALUES (198, 20, 'PRES RESIDENCE', 198);
INSERT INTO art_lieu_de_peche VALUES (199, 18, 'BOZOLA-CARRIERE', 199);
INSERT INTO art_lieu_de_peche VALUES (200, 18, 'VERS BARRAGE', 200);
INSERT INTO art_lieu_de_peche VALUES (201, 18, 'KONDIGUILA', 201);
INSERT INTO art_lieu_de_peche VALUES (202, 18, 'COTE BARRAGE', 202);
INSERT INTO art_lieu_de_peche VALUES (203, 19, 'KOMANA', 203);
INSERT INTO art_lieu_de_peche VALUES (204, 20, 'BALEKOROMOUKONO', 204);
INSERT INTO art_lieu_de_peche VALUES (205, 20, 'BALE', 205);
INSERT INTO art_lieu_de_peche VALUES (206, 20, 'LENA', 206);
INSERT INTO art_lieu_de_peche VALUES (207, 18, 'DALABA DAGA', 207);
INSERT INTO art_lieu_de_peche VALUES (208, 18, 'VERS KANGARE', 208);
INSERT INTO art_lieu_de_peche VALUES (209, 18, 'FACE CARRIERE', 209);
INSERT INTO art_lieu_de_peche VALUES (210, 18, 'PRES BARRAGE', 210);
INSERT INTO art_lieu_de_peche VALUES (211, 19, 'KABAYA', 211);
INSERT INTO art_lieu_de_peche VALUES (212, 20, 'FACE GOUALAFARA', 212);
INSERT INTO art_lieu_de_peche VALUES (213, 20, 'GOUALAFARA', 213);
INSERT INTO art_lieu_de_peche VALUES (214, 20, 'SODALA KORO', 214);
INSERT INTO art_lieu_de_peche VALUES (215, 20, 'PRES COLLINE', 215);
INSERT INTO art_lieu_de_peche VALUES (216, 20, 'NKOLOKOUNA', 216);
INSERT INTO art_lieu_de_peche VALUES (217, 20, 'PRES GOUALAFARA', 217);
INSERT INTO art_lieu_de_peche VALUES (218, 19, 'FARABA CORO', 218);
INSERT INTO art_lieu_de_peche VALUES (219, 19, 'SIEREKOLE DAGA', 219);
INSERT INTO art_lieu_de_peche VALUES (220, 19, 'MAGADIANA', 220);
INSERT INTO art_lieu_de_peche VALUES (221, 19, 'NIANI', 221);
INSERT INTO art_lieu_de_peche VALUES (222, 19, 'GALABA', 222);
INSERT INTO art_lieu_de_peche VALUES (223, 18, 'BROULAYE DAGA', 223);
INSERT INTO art_lieu_de_peche VALUES (224, 19, 'BANANDO', 224);
INSERT INTO art_lieu_de_peche VALUES (225, 19, 'KOUKA', 225);
INSERT INTO art_lieu_de_peche VALUES (226, 19, 'TAGAN KORO', 226);
INSERT INTO art_lieu_de_peche VALUES (227, 19, 'KAKAYE DAGA', 227);
INSERT INTO art_lieu_de_peche VALUES (228, 20, 'SOUMAILA', 228);
INSERT INTO art_lieu_de_peche VALUES (229, 20, 'BRAS DU LAC', 229);
INSERT INTO art_lieu_de_peche VALUES (230, 20, 'COIN DU LAC', 230);
INSERT INTO art_lieu_de_peche VALUES (231, 20, 'DOSSOLA', 231);
INSERT INTO art_lieu_de_peche VALUES (232, 20, 'MOUSSA DAGA', 232);
INSERT INTO art_lieu_de_peche VALUES (233, 20, 'OUSMANE', 233);
INSERT INTO art_lieu_de_peche VALUES (234, 20, 'BALA DAGA', 234);
INSERT INTO art_lieu_de_peche VALUES (235, 19, 'BOUGOUDALE', 235);
INSERT INTO art_lieu_de_peche VALUES (236, 18, 'NIELENI-KANGARE', 236);
INSERT INTO art_lieu_de_peche VALUES (237, 18, 'CARRIERE', 237);
INSERT INTO art_lieu_de_peche VALUES (238, 18, 'NIELENI', 238);
INSERT INTO art_lieu_de_peche VALUES (239, 18, 'VERS NIELENI', 239);
INSERT INTO art_lieu_de_peche VALUES (240, 20, 'BOUGOUDARI DAGA', 240);
INSERT INTO art_lieu_de_peche VALUES (241, 20, 'LADJI DAGA', 241);
INSERT INTO art_lieu_de_peche VALUES (242, 20, 'KAMARA DAGA', 242);
INSERT INTO art_lieu_de_peche VALUES (243, 20, 'GA ADAMA DAGA', 243);
INSERT INTO art_lieu_de_peche VALUES (244, 20, 'SOLINKONE DAGA', 244);
INSERT INTO art_lieu_de_peche VALUES (245, 18, 'BOZOLA', 245);
INSERT INTO art_lieu_de_peche VALUES (246, 18, 'BARRAGE', 246);
INSERT INTO art_lieu_de_peche VALUES (247, 18, 'MADING VOYAGE', 247);
INSERT INTO art_lieu_de_peche VALUES (248, 20, 'SALINKORO DAGA', 248);
INSERT INTO art_lieu_de_peche VALUES (249, 19, 'KOUTOURA DAGA', 249);
INSERT INTO art_lieu_de_peche VALUES (250, 20, 'SOLO DAGA', 250);
INSERT INTO art_lieu_de_peche VALUES (251, 20, 'RIVE GAUCHE', 251);
INSERT INTO art_lieu_de_peche VALUES (252, 20, 'DADIE DAGA', 252);
INSERT INTO art_lieu_de_peche VALUES (253, 20, 'MAHIN DAGA II', 253);
INSERT INTO art_lieu_de_peche VALUES (254, 20, 'POINT A', 254);
INSERT INTO art_lieu_de_peche VALUES (255, 20, 'SIVADE DAGA', 255);
INSERT INTO art_lieu_de_peche VALUES (256, 19, 'FARANI', 256);
INSERT INTO art_lieu_de_peche VALUES (257, 18, 'KOBITOU', 257);
INSERT INTO art_lieu_de_peche VALUES (258, 14, 'WOGLOGOUN', 258);
INSERT INTO art_lieu_de_peche VALUES (259, 15, 'DOUKANKONO', 259);
INSERT INTO art_lieu_de_peche VALUES (260, 15, 'SALEGOUN', 260);
INSERT INTO art_lieu_de_peche VALUES (261, 15, 'FRIYA', 261);
INSERT INTO art_lieu_de_peche VALUES (262, 15, 'GOLF', 262);
INSERT INTO art_lieu_de_peche VALUES (263, 15, 'SALENGOU', 263);
INSERT INTO art_lieu_de_peche VALUES (264, 15, 'FRIYAKORO', 264);
INSERT INTO art_lieu_de_peche VALUES (265, 20, 'BABOUGOU', 265);
INSERT INTO art_lieu_de_peche VALUES (266, 20, 'KOLINDA', 266);
INSERT INTO art_lieu_de_peche VALUES (267, 15, 'MANANTALI', 267);
INSERT INTO art_lieu_de_peche VALUES (268, 19, 'ZAMULE ', 268);
INSERT INTO art_lieu_de_peche VALUES (269, 19, 'WOMBO', 269);
INSERT INTO art_lieu_de_peche VALUES (270, 16, 'TANTAN', 270);
INSERT INTO art_lieu_de_peche VALUES (271, 16, 'TOANTAKORO', 271);
INSERT INTO art_lieu_de_peche VALUES (272, 16, 'TANDADAKARA', 272);
INSERT INTO art_lieu_de_peche VALUES (273, 16, 'DIAMINATY', 273);
INSERT INTO art_lieu_de_peche VALUES (274, 15, 'TONDIGUI-KONO', 274);
INSERT INTO art_lieu_de_peche VALUES (275, 16, 'DOGODOGABA', 275);
INSERT INTO art_lieu_de_peche VALUES (276, 16, 'BANDOGODOGO', 276);
INSERT INTO art_lieu_de_peche VALUES (277, 16, 'DOGODODOBA', 277);
INSERT INTO art_lieu_de_peche VALUES (278, 14, 'MADINEDY', 278);
INSERT INTO art_lieu_de_peche VALUES (279, 14, 'SALEGOUN', 279);
INSERT INTO art_lieu_de_peche VALUES (280, 18, 'LAC', 280);
INSERT INTO art_lieu_de_peche VALUES (281, 16, 'DOGODOGO', 281);
INSERT INTO art_lieu_de_peche VALUES (282, 16, 'BEIDY DAGA', 282);
INSERT INTO art_lieu_de_peche VALUES (283, 14, 'CREWANE', 283);
INSERT INTO art_lieu_de_peche VALUES (284, 14, 'SADIO DAGA', 284);
INSERT INTO art_lieu_de_peche VALUES (285, 14, 'GONOTA', 285);
INSERT INTO art_lieu_de_peche VALUES (286, 18, 'MANDE VOYAGE', 286);
INSERT INTO art_lieu_de_peche VALUES (287, 18, 'TOUBABOUKOUNI', 287);
INSERT INTO art_lieu_de_peche VALUES (288, 18, 'BARAKABOUGOU', 288);
INSERT INTO art_lieu_de_peche VALUES (289, 18, 'TIENTIENKOULOUNI', 289);
INSERT INTO art_lieu_de_peche VALUES (290, 18, 'BALENI', 290);
INSERT INTO art_lieu_de_peche VALUES (291, 18, 'LINNA', 291);
INSERT INTO art_lieu_de_peche VALUES (292, 18, 'LAGUINEE LAI', 292);
INSERT INTO art_lieu_de_peche VALUES (293, 18, 'WARAKOUROUNI', 293);
INSERT INTO art_lieu_de_peche VALUES (294, 15, 'FRYA KORO', 294);
INSERT INTO art_lieu_de_peche VALUES (295, 14, 'SORY DAGA', 295);
INSERT INTO art_lieu_de_peche VALUES (296, 14, 'NASSIRE DAGA', 296);
INSERT INTO art_lieu_de_peche VALUES (297, 14, 'MADINA NDIE', 297);
INSERT INTO art_lieu_de_peche VALUES (298, 14, 'GOLF', 298);
INSERT INTO art_lieu_de_peche VALUES (299, 16, 'TONDADAGARA', 299);
INSERT INTO art_lieu_de_peche VALUES (300, 16, 'GOUNGOUNDALA', 300);
INSERT INTO art_lieu_de_peche VALUES (301, 14, 'CRAWAN�', 301);
INSERT INTO art_lieu_de_peche VALUES (302, 15, 'DEMBA DAGA ', 302);
INSERT INTO art_lieu_de_peche VALUES (303, 15, 'BOKADARY DAGA', 303);
INSERT INTO art_lieu_de_peche VALUES (304, 15, 'LAMBACARA', 304);
INSERT INTO art_lieu_de_peche VALUES (305, 14, 'NASIRE DAGA', 305);
INSERT INTO art_lieu_de_peche VALUES (306, 15, 'BAKE�NA DAGA ', 306);
INSERT INTO art_lieu_de_peche VALUES (307, 15, 'DEMBA DAGA', 307);
INSERT INTO art_lieu_de_peche VALUES (308, 16, 'DOGODOGO OUEST', 308);
INSERT INTO art_lieu_de_peche VALUES (309, 16, 'BEIDY DOGODOGO', 309);
INSERT INTO art_lieu_de_peche VALUES (310, 16, 'GUERRY DOGODOGO', 310);
INSERT INTO art_lieu_de_peche VALUES (311, 16, 'COTE DAGA', 311);
INSERT INTO art_lieu_de_peche VALUES (312, 16, 'TIBRIKI', 312);
INSERT INTO art_lieu_de_peche VALUES (313, 15, 'TONDIC KORO', 313);
INSERT INTO art_lieu_de_peche VALUES (314, 16, 'SAMAI LADJI DAGA', 314);
INSERT INTO art_lieu_de_peche VALUES (315, 16, 'NGOUGNY DAGA', 315);
INSERT INTO art_lieu_de_peche VALUES (316, 16, 'BEIDY DOGDOGO', 316);
INSERT INTO art_lieu_de_peche VALUES (317, 16, 'DOGODODOBA OUEST', 317);
INSERT INTO art_lieu_de_peche VALUES (318, 16, 'DOGODOGOBA EST', 318);
INSERT INTO art_lieu_de_peche VALUES (319, 18, 'BALE', 319);
INSERT INTO art_lieu_de_peche VALUES (320, 18, 'SANKARANI', 320);
INSERT INTO art_lieu_de_peche VALUES (321, 15, 'KEMBA DAGA ', 321);
INSERT INTO art_lieu_de_peche VALUES (322, 20, 'BOBOSY DAGA', 322);
INSERT INTO art_lieu_de_peche VALUES (323, 18, 'DJELENINA', 323);
INSERT INTO art_lieu_de_peche VALUES (324, 18, 'COULOUBLENI', 324);
INSERT INTO art_lieu_de_peche VALUES (325, 18, 'DAFOROKA', 325);
INSERT INTO art_lieu_de_peche VALUES (326, 18, 'MAGNI DAGA', 326);
INSERT INTO art_lieu_de_peche VALUES (327, 18, 'SOUMAILA', 327);
INSERT INTO art_lieu_de_peche VALUES (328, 18, 'NTIN NTINCOULOUNI', 328);
INSERT INTO art_lieu_de_peche VALUES (329, 18, 'DJELENI', 329);
INSERT INTO art_lieu_de_peche VALUES (330, 18, 'LAGUINE DAGA ', 330);
INSERT INTO art_lieu_de_peche VALUES (331, 18, 'MASSIGRIN', 331);
INSERT INTO art_lieu_de_peche VALUES (332, 15, 'LAMBAKARA ', 332);
INSERT INTO art_lieu_de_peche VALUES (333, 15, 'SORY DAGA', 333);
INSERT INTO art_lieu_de_peche VALUES (334, 19, 'SALINKORO DAGA', 334);
INSERT INTO art_lieu_de_peche VALUES (335, 18, 'LADJINE BA', 335);
INSERT INTO art_lieu_de_peche VALUES (336, 18, 'DALABADAGAN', 336);
INSERT INTO art_lieu_de_peche VALUES (337, 18, 'MANDE VAYAGE', 337);
INSERT INTO art_lieu_de_peche VALUES (338, 18, 'DAFORO', 338);
INSERT INTO art_lieu_de_peche VALUES (339, 18, 'BARE', 339);
INSERT INTO art_lieu_de_peche VALUES (340, 18, 'KOULOUBLENI', 340);
INSERT INTO art_lieu_de_peche VALUES (341, 19, 'KONA DAGA', 341);
INSERT INTO art_lieu_de_peche VALUES (342, 15, 'WOGLOGOUN', 342);
INSERT INTO art_lieu_de_peche VALUES (343, 14, 'SADIO DAGA ', 343);
INSERT INTO art_lieu_de_peche VALUES (344, 18, 'DALABALAI', 344);
INSERT INTO art_lieu_de_peche VALUES (345, 18, 'KOULOUDJAN ', 345);
INSERT INTO art_lieu_de_peche VALUES (346, 18, 'TEINTINKOULOUNI ', 346);
INSERT INTO art_lieu_de_peche VALUES (347, 18, 'TEINTEINKOULOUNI', 347);
INSERT INTO art_lieu_de_peche VALUES (348, 18, 'DANKOUMADAGA', 348);
INSERT INTO art_lieu_de_peche VALUES (349, 18, 'LAGUINE LAI', 349);
INSERT INTO art_lieu_de_peche VALUES (350, 16, 'SOMMET COTE DAGA ', 350);
INSERT INTO art_lieu_de_peche VALUES (351, 15, 'DEMDA DAGA ', 351);
INSERT INTO art_lieu_de_peche VALUES (352, 16, 'DIARA DOGODOGO', 352);
INSERT INTO art_lieu_de_peche VALUES (353, 14, 'GIONOTA', 353);
INSERT INTO art_lieu_de_peche VALUES (354, 16, 'GOUAG GOUNDALA', 354);
INSERT INTO art_lieu_de_peche VALUES (355, 16, 'BOKADOU DAGA', 355);


--
-- Data for Name: art_millieu; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_millieu VALUES (0, 'Inconnu');
INSERT INTO art_millieu VALUES (1, 'Fleuve');
INSERT INTO art_millieu VALUES (2, 'Mare');
INSERT INTO art_millieu VALUES (3, 'Lac');
INSERT INTO art_millieu VALUES (4, 'Chenal');
INSERT INTO art_millieu VALUES (5, 'Zone inondee');
INSERT INTO art_millieu VALUES (6, 'Bolong');
INSERT INTO art_millieu VALUES (7, 'Bordure');


--
-- Data for Name: art_poisson_mesure; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_poisson_mesure VALUES (1, 741010, 235, 'ML2_126504');
INSERT INTO art_poisson_mesure VALUES (2, 741009, 235, 'ML2_126504');
INSERT INTO art_poisson_mesure VALUES (3, 741008, 235, 'ML2_126504');
INSERT INTO art_poisson_mesure VALUES (4, 741005, 480, 'ML2_126503');
INSERT INTO art_poisson_mesure VALUES (5, 741006, 190, 'ML2_126504');
INSERT INTO art_poisson_mesure VALUES (6, 741007, 190, 'ML2_126504');
INSERT INTO art_poisson_mesure VALUES (7, 741025, 170, 'ML2_126507');
INSERT INTO art_poisson_mesure VALUES (8, 741024, 222, 'ML2_126507');
INSERT INTO art_poisson_mesure VALUES (9, 741023, 175, 'ML2_126507');
INSERT INTO art_poisson_mesure VALUES (10, 741012, 340, 'ML2_126505');
INSERT INTO art_poisson_mesure VALUES (11, 741011, 350, 'ML2_126505');
INSERT INTO art_poisson_mesure VALUES (12, 741015, 245, 'ML2_126506');
INSERT INTO art_poisson_mesure VALUES (13, 741021, 200, 'ML2_126507');
INSERT INTO art_poisson_mesure VALUES (14, 741020, 190, 'ML2_126507');
INSERT INTO art_poisson_mesure VALUES (15, 741014, 225, 'ML2_126506');
INSERT INTO art_poisson_mesure VALUES (16, 741022, 175, 'ML2_126507');
INSERT INTO art_poisson_mesure VALUES (17, 741013, 240, 'ML2_126506');
INSERT INTO art_poisson_mesure VALUES (18, 741019, 235, 'ML2_126506');
INSERT INTO art_poisson_mesure VALUES (19, 741016, 235, 'ML2_126506');
INSERT INTO art_poisson_mesure VALUES (20, 741018, 225, 'ML2_126506');
INSERT INTO art_poisson_mesure VALUES (21, 741017, 225, 'ML2_126506');
INSERT INTO art_poisson_mesure VALUES (22, 741036, 175, 'ML2_126510');
INSERT INTO art_poisson_mesure VALUES (23, 741035, 150, 'ML2_126510');
INSERT INTO art_poisson_mesure VALUES (24, 741034, 220, 'ML2_126509');
INSERT INTO art_poisson_mesure VALUES (25, 741026, 225, 'ML2_126507');
INSERT INTO art_poisson_mesure VALUES (26, 741033, 240, 'ML2_126509');
INSERT INTO art_poisson_mesure VALUES (27, 741028, 200, 'ML2_126507');
INSERT INTO art_poisson_mesure VALUES (28, 741027, 250, 'ML2_126507');
INSERT INTO art_poisson_mesure VALUES (29, 741029, 221, 'ML2_126507');
INSERT INTO art_poisson_mesure VALUES (30, 741032, 180, 'ML2_126509');
INSERT INTO art_poisson_mesure VALUES (31, 741031, 210, 'ML2_126508');
INSERT INTO art_poisson_mesure VALUES (32, 741030, 230, 'ML2_126508');
INSERT INTO art_poisson_mesure VALUES (33, 741040, 200, 'ML2_126512');
INSERT INTO art_poisson_mesure VALUES (34, 741039, 215, 'ML2_126512');
INSERT INTO art_poisson_mesure VALUES (35, 741065, 245, 'ML2_126521');
INSERT INTO art_poisson_mesure VALUES (36, 741068, 250, 'ML2_126521');
INSERT INTO art_poisson_mesure VALUES (37, 741067, 285, 'ML2_126521');
INSERT INTO art_poisson_mesure VALUES (38, 741066, 240, 'ML2_126521');
INSERT INTO art_poisson_mesure VALUES (39, 741064, 240, 'ML2_126521');
INSERT INTO art_poisson_mesure VALUES (40, 741042, 195, 'ML2_126513');
INSERT INTO art_poisson_mesure VALUES (41, 741041, 270, 'ML2_126513');
INSERT INTO art_poisson_mesure VALUES (42, 741069, 350, 'ML2_126522');
INSERT INTO art_poisson_mesure VALUES (43, 741063, 270, 'ML2_126521');
INSERT INTO art_poisson_mesure VALUES (44, 741061, 280, 'ML2_126521');
INSERT INTO art_poisson_mesure VALUES (45, 741053, 150, 'ML2_126516');
INSERT INTO art_poisson_mesure VALUES (46, 741043, 185, 'ML2_126513');
INSERT INTO art_poisson_mesure VALUES (47, 741060, 270, 'ML2_126521');
INSERT INTO art_poisson_mesure VALUES (48, 741045, 180, 'ML2_126513');
INSERT INTO art_poisson_mesure VALUES (49, 741052, 290, 'ML2_126515');
INSERT INTO art_poisson_mesure VALUES (50, 741049, 190, 'ML2_126514');
INSERT INTO art_poisson_mesure VALUES (51, 741044, 250, 'ML2_126513');
INSERT INTO art_poisson_mesure VALUES (52, 741046, 210, 'ML2_126513');
INSERT INTO art_poisson_mesure VALUES (53, 741048, 210, 'ML2_126514');
INSERT INTO art_poisson_mesure VALUES (54, 741047, 200, 'ML2_126514');
INSERT INTO art_poisson_mesure VALUES (55, 741054, 300, 'ML2_126518');
INSERT INTO art_poisson_mesure VALUES (56, 741051, 300, 'ML2_126515');
INSERT INTO art_poisson_mesure VALUES (57, 741050, 290, 'ML2_126515');
INSERT INTO art_poisson_mesure VALUES (58, 741059, 245, 'ML2_126521');
INSERT INTO art_poisson_mesure VALUES (59, 741055, 385, 'ML2_126519');
INSERT INTO art_poisson_mesure VALUES (60, 741058, 390, 'ML2_126519');
INSERT INTO art_poisson_mesure VALUES (61, 741057, 390, 'ML2_126519');
INSERT INTO art_poisson_mesure VALUES (62, 741056, 390, 'ML2_126519');
INSERT INTO art_poisson_mesure VALUES (63, 741062, 245, 'ML2_126521');
INSERT INTO art_poisson_mesure VALUES (64, 741037, 225, 'ML2_126511');
INSERT INTO art_poisson_mesure VALUES (65, 741038, 225, 'ML2_126511');
INSERT INTO art_poisson_mesure VALUES (66, 741070, 190, 'ML2_126523');
INSERT INTO art_poisson_mesure VALUES (67, 741072, 160, 'ML2_126523');
INSERT INTO art_poisson_mesure VALUES (68, 741071, 185, 'ML2_126523');
INSERT INTO art_poisson_mesure VALUES (69, 741075, 150, 'ML2_126527');
INSERT INTO art_poisson_mesure VALUES (70, 741074, 290, 'ML2_126526');
INSERT INTO art_poisson_mesure VALUES (71, 741073, 280, 'ML2_126526');
INSERT INTO art_poisson_mesure VALUES (72, 741076, 140, 'ML2_126527');
INSERT INTO art_poisson_mesure VALUES (73, 741078, 140, 'ML2_126527');
INSERT INTO art_poisson_mesure VALUES (74, 741077, 120, 'ML2_126527');
INSERT INTO art_poisson_mesure VALUES (75, 741079, 150, 'ML2_126527');
INSERT INTO art_poisson_mesure VALUES (76, 741082, 150, 'ML2_126528');
INSERT INTO art_poisson_mesure VALUES (77, 741080, 140, 'ML2_126527');
INSERT INTO art_poisson_mesure VALUES (78, 741081, 150, 'ML2_126527');
INSERT INTO art_poisson_mesure VALUES (79, 741084, 270, 'ML2_126530');
INSERT INTO art_poisson_mesure VALUES (80, 741083, 480, 'ML2_126529');
INSERT INTO art_poisson_mesure VALUES (81, 741085, 280, 'ML2_126530');
INSERT INTO art_poisson_mesure VALUES (82, 741087, 260, 'ML2_126530');
INSERT INTO art_poisson_mesure VALUES (83, 741091, 270, 'ML2_126530');
INSERT INTO art_poisson_mesure VALUES (84, 741086, 270, 'ML2_126530');
INSERT INTO art_poisson_mesure VALUES (85, 741090, 280, 'ML2_126530');
INSERT INTO art_poisson_mesure VALUES (86, 741089, 260, 'ML2_126530');
INSERT INTO art_poisson_mesure VALUES (87, 741088, 280, 'ML2_126530');
INSERT INTO art_poisson_mesure VALUES (88, 741092, 270, 'ML2_126530');
INSERT INTO art_poisson_mesure VALUES (89, 741093, 280, 'ML2_126530');
INSERT INTO art_poisson_mesure VALUES (90, 741141, 270, 'ML2_126536');
INSERT INTO art_poisson_mesure VALUES (91, 741142, 190, 'ML2_126536');
INSERT INTO art_poisson_mesure VALUES (92, 741137, 185, 'ML2_126535');
INSERT INTO art_poisson_mesure VALUES (93, 741147, 235, 'ML2_126536');
INSERT INTO art_poisson_mesure VALUES (94, 741104, 165, 'ML2_126532');
INSERT INTO art_poisson_mesure VALUES (95, 741103, 180, 'ML2_126531');
INSERT INTO art_poisson_mesure VALUES (96, 741102, 110, 'ML2_126531');
INSERT INTO art_poisson_mesure VALUES (97, 741101, 165, 'ML2_126531');
INSERT INTO art_poisson_mesure VALUES (98, 741100, 145, 'ML2_126531');
INSERT INTO art_poisson_mesure VALUES (99, 741094, 140, 'ML2_126531');
INSERT INTO art_poisson_mesure VALUES (100, 741099, 150, 'ML2_126531');
INSERT INTO art_poisson_mesure VALUES (101, 741095, 145, 'ML2_126531');
INSERT INTO art_poisson_mesure VALUES (102, 741098, 150, 'ML2_126531');
INSERT INTO art_poisson_mesure VALUES (103, 741096, 215, 'ML2_126531');
INSERT INTO art_poisson_mesure VALUES (104, 741097, 175, 'ML2_126531');
INSERT INTO art_poisson_mesure VALUES (105, 741145, 260, 'ML2_126536');
INSERT INTO art_poisson_mesure VALUES (106, 741136, 140, 'ML2_126535');
INSERT INTO art_poisson_mesure VALUES (107, 741135, 145, 'ML2_126535');
INSERT INTO art_poisson_mesure VALUES (108, 741134, 155, 'ML2_126535');
INSERT INTO art_poisson_mesure VALUES (109, 741144, 255, 'ML2_126536');
INSERT INTO art_poisson_mesure VALUES (110, 741114, 210, 'ML2_126533');
INSERT INTO art_poisson_mesure VALUES (111, 741146, 180, 'ML2_126536');
INSERT INTO art_poisson_mesure VALUES (112, 741107, 155, 'ML2_126532');
INSERT INTO art_poisson_mesure VALUES (113, 741113, 220, 'ML2_126533');
INSERT INTO art_poisson_mesure VALUES (114, 741106, 160, 'ML2_126532');
INSERT INTO art_poisson_mesure VALUES (115, 741105, 170, 'ML2_126532');
INSERT INTO art_poisson_mesure VALUES (116, 741112, 250, 'ML2_126532');
INSERT INTO art_poisson_mesure VALUES (117, 741108, 150, 'ML2_126532');
INSERT INTO art_poisson_mesure VALUES (118, 741111, 185, 'ML2_126532');
INSERT INTO art_poisson_mesure VALUES (119, 741110, 210, 'ML2_126532');
INSERT INTO art_poisson_mesure VALUES (120, 741109, 160, 'ML2_126532');
INSERT INTO art_poisson_mesure VALUES (121, 741133, 150, 'ML2_126535');
INSERT INTO art_poisson_mesure VALUES (122, 741127, 140, 'ML2_126534');
INSERT INTO art_poisson_mesure VALUES (123, 741143, 220, 'ML2_126536');
INSERT INTO art_poisson_mesure VALUES (124, 741118, 205, 'ML2_126533');
INSERT INTO art_poisson_mesure VALUES (125, 741117, 210, 'ML2_126533');
INSERT INTO art_poisson_mesure VALUES (126, 741116, 195, 'ML2_126533');
INSERT INTO art_poisson_mesure VALUES (127, 741115, 205, 'ML2_126533');
INSERT INTO art_poisson_mesure VALUES (128, 741121, 210, 'ML2_126533');
INSERT INTO art_poisson_mesure VALUES (129, 741126, 180, 'ML2_126534');
INSERT INTO art_poisson_mesure VALUES (130, 741120, 220, 'ML2_126533');
INSERT INTO art_poisson_mesure VALUES (131, 741119, 210, 'ML2_126533');
INSERT INTO art_poisson_mesure VALUES (132, 741122, 205, 'ML2_126533');
INSERT INTO art_poisson_mesure VALUES (133, 741125, 170, 'ML2_126534');
INSERT INTO art_poisson_mesure VALUES (134, 741123, 140, 'ML2_126534');
INSERT INTO art_poisson_mesure VALUES (135, 741124, 170, 'ML2_126534');
INSERT INTO art_poisson_mesure VALUES (136, 741131, 150, 'ML2_126535');
INSERT INTO art_poisson_mesure VALUES (137, 741132, 170, 'ML2_126535');
INSERT INTO art_poisson_mesure VALUES (138, 741128, 160, 'ML2_126534');
INSERT INTO art_poisson_mesure VALUES (139, 741130, 140, 'ML2_126535');
INSERT INTO art_poisson_mesure VALUES (140, 741129, 150, 'ML2_126535');
INSERT INTO art_poisson_mesure VALUES (141, 741138, 150, 'ML2_126535');
INSERT INTO art_poisson_mesure VALUES (142, 741139, 170, 'ML2_126536');
INSERT INTO art_poisson_mesure VALUES (143, 741140, 150, 'ML2_126536');
INSERT INTO art_poisson_mesure VALUES (144, 741151, 330, 'ML2_126538');
INSERT INTO art_poisson_mesure VALUES (145, 741150, 265, 'ML2_126537');
INSERT INTO art_poisson_mesure VALUES (146, 741149, 270, 'ML2_126537');
INSERT INTO art_poisson_mesure VALUES (147, 741148, 140, 'ML2_126536');
INSERT INTO art_poisson_mesure VALUES (148, 741152, 380, 'ML2_126539');
INSERT INTO art_poisson_mesure VALUES (149, 741166, 340, 'ML2_126542');
INSERT INTO art_poisson_mesure VALUES (150, 741156, 165, 'ML2_126540');
INSERT INTO art_poisson_mesure VALUES (151, 741154, 160, 'ML2_126540');
INSERT INTO art_poisson_mesure VALUES (152, 741165, 250, 'ML2_126542');
INSERT INTO art_poisson_mesure VALUES (153, 741153, 160, 'ML2_126540');
INSERT INTO art_poisson_mesure VALUES (154, 741155, 200, 'ML2_126540');
INSERT INTO art_poisson_mesure VALUES (155, 741159, 195, 'ML2_126540');
INSERT INTO art_poisson_mesure VALUES (156, 741158, 165, 'ML2_126540');
INSERT INTO art_poisson_mesure VALUES (157, 741157, 210, 'ML2_126540');
INSERT INTO art_poisson_mesure VALUES (158, 741164, 300, 'ML2_126541');
INSERT INTO art_poisson_mesure VALUES (159, 741160, 195, 'ML2_126540');
INSERT INTO art_poisson_mesure VALUES (160, 741163, 225, 'ML2_126541');
INSERT INTO art_poisson_mesure VALUES (161, 741161, 215, 'ML2_126540');
INSERT INTO art_poisson_mesure VALUES (162, 741162, 220, 'ML2_126540');
INSERT INTO art_poisson_mesure VALUES (163, 741168, 265, 'ML2_126543');
INSERT INTO art_poisson_mesure VALUES (164, 741167, 320, 'ML2_126542');
INSERT INTO art_poisson_mesure VALUES (165, 741169, 270, 'ML2_126543');
INSERT INTO art_poisson_mesure VALUES (166, 741170, 285, 'ML2_126543');
INSERT INTO art_poisson_mesure VALUES (167, 741172, 265, 'ML2_126543');
INSERT INTO art_poisson_mesure VALUES (168, 741177, 200, 'ML2_126544');
INSERT INTO art_poisson_mesure VALUES (169, 741171, 300, 'ML2_126543');
INSERT INTO art_poisson_mesure VALUES (170, 741173, 280, 'ML2_126543');
INSERT INTO art_poisson_mesure VALUES (171, 741176, 250, 'ML2_126543');
INSERT INTO art_poisson_mesure VALUES (172, 741175, 295, 'ML2_126543');
INSERT INTO art_poisson_mesure VALUES (173, 741174, 260, 'ML2_126543');
INSERT INTO art_poisson_mesure VALUES (174, 741181, 215, 'ML2_126546');
INSERT INTO art_poisson_mesure VALUES (175, 741184, 185, 'ML2_126548');
INSERT INTO art_poisson_mesure VALUES (176, 741179, 345, 'ML2_126545');
INSERT INTO art_poisson_mesure VALUES (177, 741178, 160, 'ML2_126544');
INSERT INTO art_poisson_mesure VALUES (178, 741180, 255, 'ML2_126546');
INSERT INTO art_poisson_mesure VALUES (179, 741183, 195, 'ML2_126547');
INSERT INTO art_poisson_mesure VALUES (180, 741182, 230, 'ML2_126546');
INSERT INTO art_poisson_mesure VALUES (181, 741188, 190, 'ML2_126549');
INSERT INTO art_poisson_mesure VALUES (182, 741189, 185, 'ML2_126549');
INSERT INTO art_poisson_mesure VALUES (183, 741190, 195, 'ML2_126549');
INSERT INTO art_poisson_mesure VALUES (184, 741192, 190, 'ML2_126549');
INSERT INTO art_poisson_mesure VALUES (185, 741205, 185, 'ML2_126552');
INSERT INTO art_poisson_mesure VALUES (186, 741191, 195, 'ML2_126549');
INSERT INTO art_poisson_mesure VALUES (187, 741204, 130, 'ML2_126550');
INSERT INTO art_poisson_mesure VALUES (188, 741194, 185, 'ML2_126549');
INSERT INTO art_poisson_mesure VALUES (189, 741203, 150, 'ML2_126550');
INSERT INTO art_poisson_mesure VALUES (190, 741193, 185, 'ML2_126549');
INSERT INTO art_poisson_mesure VALUES (191, 741197, 130, 'ML2_126550');
INSERT INTO art_poisson_mesure VALUES (192, 741196, 145, 'ML2_126550');
INSERT INTO art_poisson_mesure VALUES (193, 741202, 150, 'ML2_126550');
INSERT INTO art_poisson_mesure VALUES (194, 741195, 145, 'ML2_126550');
INSERT INTO art_poisson_mesure VALUES (195, 741198, 135, 'ML2_126550');
INSERT INTO art_poisson_mesure VALUES (196, 741201, 160, 'ML2_126550');
INSERT INTO art_poisson_mesure VALUES (197, 741199, 150, 'ML2_126550');
INSERT INTO art_poisson_mesure VALUES (198, 741200, 150, 'ML2_126550');
INSERT INTO art_poisson_mesure VALUES (199, 741210, 11, 'ML2_126554');
INSERT INTO art_poisson_mesure VALUES (200, 741209, 11, 'ML2_126554');
INSERT INTO art_poisson_mesure VALUES (201, 741208, 10, 'ML2_126554');
INSERT INTO art_poisson_mesure VALUES (202, 741207, 170, 'ML2_126552');
INSERT INTO art_poisson_mesure VALUES (203, 741206, 155, 'ML2_126552');
INSERT INTO art_poisson_mesure VALUES (204, 741186, 190, 'ML2_126549');
INSERT INTO art_poisson_mesure VALUES (205, 741187, 190, 'ML2_126549');
INSERT INTO art_poisson_mesure VALUES (206, 741185, 190, 'ML2_126549');
INSERT INTO art_poisson_mesure VALUES (207, 741219, 275, 'ML2_126561');
INSERT INTO art_poisson_mesure VALUES (208, 741216, 240, 'ML2_126557');
INSERT INTO art_poisson_mesure VALUES (209, 741217, 220, 'ML2_126559');
INSERT INTO art_poisson_mesure VALUES (210, 741218, 320, 'ML2_126560');
INSERT INTO art_poisson_mesure VALUES (211, 741211, 550, 'ML2_126555');
INSERT INTO art_poisson_mesure VALUES (212, 741215, 290, 'ML2_126557');
INSERT INTO art_poisson_mesure VALUES (213, 741214, 280, 'ML2_126557');
INSERT INTO art_poisson_mesure VALUES (214, 741213, 280, 'ML2_126556');
INSERT INTO art_poisson_mesure VALUES (215, 741212, 500, 'ML2_126555');
INSERT INTO art_poisson_mesure VALUES (216, 741221, 190, 'ML2_126562');
INSERT INTO art_poisson_mesure VALUES (217, 741220, 210, 'ML2_126562');
INSERT INTO art_poisson_mesure VALUES (218, 741223, 320, 'ML2_126563');
INSERT INTO art_poisson_mesure VALUES (219, 741222, 200, 'ML2_126562');
INSERT INTO art_poisson_mesure VALUES (220, 741245, 320, 'ML2_126566');
INSERT INTO art_poisson_mesure VALUES (221, 741235, 145, 'ML2_126565');
INSERT INTO art_poisson_mesure VALUES (222, 741244, 325, 'ML2_126566');
INSERT INTO art_poisson_mesure VALUES (223, 741234, 150, 'ML2_126565');
INSERT INTO art_poisson_mesure VALUES (224, 741231, 300, 'ML2_126564');
INSERT INTO art_poisson_mesure VALUES (225, 741233, 270, 'ML2_126564');
INSERT INTO art_poisson_mesure VALUES (226, 741232, 270, 'ML2_126564');
INSERT INTO art_poisson_mesure VALUES (227, 741243, 190, 'ML2_126565');
INSERT INTO art_poisson_mesure VALUES (228, 741238, 170, 'ML2_126565');
INSERT INTO art_poisson_mesure VALUES (229, 741237, 165, 'ML2_126565');
INSERT INTO art_poisson_mesure VALUES (230, 741236, 155, 'ML2_126565');
INSERT INTO art_poisson_mesure VALUES (231, 741242, 210, 'ML2_126565');
INSERT INTO art_poisson_mesure VALUES (232, 741239, 185, 'ML2_126565');
INSERT INTO art_poisson_mesure VALUES (233, 741241, 170, 'ML2_126565');
INSERT INTO art_poisson_mesure VALUES (234, 741240, 225, 'ML2_126565');
INSERT INTO art_poisson_mesure VALUES (235, 741249, 210, 'ML2_126567');
INSERT INTO art_poisson_mesure VALUES (236, 741247, 240, 'ML2_126567');
INSERT INTO art_poisson_mesure VALUES (237, 741248, 230, 'ML2_126567');
INSERT INTO art_poisson_mesure VALUES (238, 741246, 250, 'ML2_126567');
INSERT INTO art_poisson_mesure VALUES (239, 741251, 260, 'ML2_126568');
INSERT INTO art_poisson_mesure VALUES (240, 741254, 175, 'ML2_126571');
INSERT INTO art_poisson_mesure VALUES (241, 741250, 265, 'ML2_126567');
INSERT INTO art_poisson_mesure VALUES (242, 741253, 185, 'ML2_126570');
INSERT INTO art_poisson_mesure VALUES (243, 741252, 215, 'ML2_126569');
INSERT INTO art_poisson_mesure VALUES (244, 741230, 260, 'ML2_126564');
INSERT INTO art_poisson_mesure VALUES (245, 741229, 285, 'ML2_126564');
INSERT INTO art_poisson_mesure VALUES (246, 741228, 295, 'ML2_126564');
INSERT INTO art_poisson_mesure VALUES (247, 741227, 290, 'ML2_126564');
INSERT INTO art_poisson_mesure VALUES (248, 741226, 310, 'ML2_126564');
INSERT INTO art_poisson_mesure VALUES (249, 741225, 325, 'ML2_126564');
INSERT INTO art_poisson_mesure VALUES (250, 741224, 360, 'ML2_126564');
INSERT INTO art_poisson_mesure VALUES (251, 741255, 295, 'ML2_126572');
INSERT INTO art_poisson_mesure VALUES (252, 741259, 280, 'ML2_126572');
INSERT INTO art_poisson_mesure VALUES (253, 741258, 240, 'ML2_126572');
INSERT INTO art_poisson_mesure VALUES (254, 741257, 240, 'ML2_126572');
INSERT INTO art_poisson_mesure VALUES (255, 741256, 290, 'ML2_126572');
INSERT INTO art_poisson_mesure VALUES (256, 741260, 275, 'ML2_126572');
INSERT INTO art_poisson_mesure VALUES (257, 741262, 270, 'ML2_126572');
INSERT INTO art_poisson_mesure VALUES (258, 741263, 260, 'ML2_126572');
INSERT INTO art_poisson_mesure VALUES (259, 741264, 290, 'ML2_126572');
INSERT INTO art_poisson_mesure VALUES (260, 741261, 285, 'ML2_126572');
INSERT INTO art_poisson_mesure VALUES (261, 741268, 280, 'ML2_126573');
INSERT INTO art_poisson_mesure VALUES (262, 741269, 300, 'ML2_126573');
INSERT INTO art_poisson_mesure VALUES (263, 741275, 450, 'ML2_126574');
INSERT INTO art_poisson_mesure VALUES (264, 741267, 275, 'ML2_126573');
INSERT INTO art_poisson_mesure VALUES (265, 741265, 295, 'ML2_126573');
INSERT INTO art_poisson_mesure VALUES (266, 741292, 150, 'ML2_126576');
INSERT INTO art_poisson_mesure VALUES (267, 741266, 390, 'ML2_126573');
INSERT INTO art_poisson_mesure VALUES (268, 741272, 350, 'ML2_126573');
INSERT INTO art_poisson_mesure VALUES (269, 741270, 300, 'ML2_126573');
INSERT INTO art_poisson_mesure VALUES (270, 741291, 155, 'ML2_126576');
INSERT INTO art_poisson_mesure VALUES (271, 741274, 295, 'ML2_126573');
INSERT INTO art_poisson_mesure VALUES (272, 741271, 380, 'ML2_126573');
INSERT INTO art_poisson_mesure VALUES (273, 741276, 280, 'ML2_126574');
INSERT INTO art_poisson_mesure VALUES (274, 741273, 420, 'ML2_126573');
INSERT INTO art_poisson_mesure VALUES (275, 741290, 165, 'ML2_126576');
INSERT INTO art_poisson_mesure VALUES (276, 741281, 550, 'ML2_126574');
INSERT INTO art_poisson_mesure VALUES (277, 741280, 350, 'ML2_126574');
INSERT INTO art_poisson_mesure VALUES (278, 741277, 270, 'ML2_126574');
INSERT INTO art_poisson_mesure VALUES (279, 741279, 395, 'ML2_126574');
INSERT INTO art_poisson_mesure VALUES (280, 741278, 205, 'ML2_126574');
INSERT INTO art_poisson_mesure VALUES (281, 741284, 380, 'ML2_126574');
INSERT INTO art_poisson_mesure VALUES (282, 741282, 620, 'ML2_126574');
INSERT INTO art_poisson_mesure VALUES (283, 741289, 380, 'ML2_126575');
INSERT INTO art_poisson_mesure VALUES (284, 741283, 610, 'ML2_126574');
INSERT INTO art_poisson_mesure VALUES (285, 741285, 390, 'ML2_126575');
INSERT INTO art_poisson_mesure VALUES (286, 741288, 535, 'ML2_126575');
INSERT INTO art_poisson_mesure VALUES (287, 741286, 480, 'ML2_126575');
INSERT INTO art_poisson_mesure VALUES (288, 741287, 470, 'ML2_126575');
INSERT INTO art_poisson_mesure VALUES (289, 741300, 170, 'ML2_126579');
INSERT INTO art_poisson_mesure VALUES (290, 741296, 155, 'ML2_126577');
INSERT INTO art_poisson_mesure VALUES (291, 741295, 175, 'ML2_126577');
INSERT INTO art_poisson_mesure VALUES (292, 741294, 160, 'ML2_126577');
INSERT INTO art_poisson_mesure VALUES (293, 741293, 175, 'ML2_126576');
INSERT INTO art_poisson_mesure VALUES (294, 741298, 160, 'ML2_126579');
INSERT INTO art_poisson_mesure VALUES (295, 741297, 290, 'ML2_126578');
INSERT INTO art_poisson_mesure VALUES (296, 741299, 155, 'ML2_126579');
INSERT INTO art_poisson_mesure VALUES (297, 741320, 215, 'ML2_126581');
INSERT INTO art_poisson_mesure VALUES (298, 741319, 265, 'ML2_126581');
INSERT INTO art_poisson_mesure VALUES (299, 741318, 220, 'ML2_126581');
INSERT INTO art_poisson_mesure VALUES (300, 741317, 115, 'ML2_126581');
INSERT INTO art_poisson_mesure VALUES (301, 741316, 220, 'ML2_126581');
INSERT INTO art_poisson_mesure VALUES (302, 741315, 200, 'ML2_126581');
INSERT INTO art_poisson_mesure VALUES (303, 741314, 190, 'ML2_126581');
INSERT INTO art_poisson_mesure VALUES (304, 741310, 235, 'ML2_126580');
INSERT INTO art_poisson_mesure VALUES (305, 741311, 240, 'ML2_126581');
INSERT INTO art_poisson_mesure VALUES (306, 741313, 180, 'ML2_126581');
INSERT INTO art_poisson_mesure VALUES (307, 741312, 175, 'ML2_126581');
INSERT INTO art_poisson_mesure VALUES (308, 741309, 215, 'ML2_126580');
INSERT INTO art_poisson_mesure VALUES (309, 741308, 220, 'ML2_126580');
INSERT INTO art_poisson_mesure VALUES (310, 741306, 210, 'ML2_126580');
INSERT INTO art_poisson_mesure VALUES (311, 741307, 240, 'ML2_126580');
INSERT INTO art_poisson_mesure VALUES (312, 741322, 190, 'ML2_126582');
INSERT INTO art_poisson_mesure VALUES (313, 741305, 215, 'ML2_126580');
INSERT INTO art_poisson_mesure VALUES (314, 741304, 220, 'ML2_126580');
INSERT INTO art_poisson_mesure VALUES (315, 741303, 215, 'ML2_126580');
INSERT INTO art_poisson_mesure VALUES (316, 741321, 185, 'ML2_126582');
INSERT INTO art_poisson_mesure VALUES (317, 741302, 245, 'ML2_126580');
INSERT INTO art_poisson_mesure VALUES (318, 741301, 215, 'ML2_126580');
INSERT INTO art_poisson_mesure VALUES (319, 741325, 110, 'ML2_126582');
INSERT INTO art_poisson_mesure VALUES (320, 741323, 115, 'ML2_126582');
INSERT INTO art_poisson_mesure VALUES (321, 741324, 210, 'ML2_126582');
INSERT INTO art_poisson_mesure VALUES (322, 741350, 240, 'ML2_126586');
INSERT INTO art_poisson_mesure VALUES (323, 741349, 140, 'ML2_126585');
INSERT INTO art_poisson_mesure VALUES (324, 741351, 240, 'ML2_126586');
INSERT INTO art_poisson_mesure VALUES (325, 741347, 120, 'ML2_126585');
INSERT INTO art_poisson_mesure VALUES (326, 741348, 120, 'ML2_126585');
INSERT INTO art_poisson_mesure VALUES (327, 741363, 210, 'ML2_126588');
INSERT INTO art_poisson_mesure VALUES (328, 741362, 100, 'ML2_126587');
INSERT INTO art_poisson_mesure VALUES (329, 741361, 90, 'ML2_126587');
INSERT INTO art_poisson_mesure VALUES (330, 741360, 100, 'ML2_126587');
INSERT INTO art_poisson_mesure VALUES (331, 741353, 215, 'ML2_126586');
INSERT INTO art_poisson_mesure VALUES (332, 741354, 220, 'ML2_126586');
INSERT INTO art_poisson_mesure VALUES (333, 741359, 210, 'ML2_126586');
INSERT INTO art_poisson_mesure VALUES (334, 741352, 205, 'ML2_126586');
INSERT INTO art_poisson_mesure VALUES (335, 741355, 230, 'ML2_126586');
INSERT INTO art_poisson_mesure VALUES (336, 741358, 240, 'ML2_126586');
INSERT INTO art_poisson_mesure VALUES (337, 741356, 240, 'ML2_126586');
INSERT INTO art_poisson_mesure VALUES (338, 741357, 235, 'ML2_126586');
INSERT INTO art_poisson_mesure VALUES (339, 741365, 210, 'ML2_126588');
INSERT INTO art_poisson_mesure VALUES (340, 741364, 200, 'ML2_126588');
INSERT INTO art_poisson_mesure VALUES (341, 741366, 220, 'ML2_126588');
INSERT INTO art_poisson_mesure VALUES (342, 741369, 150, 'ML2_126590');
INSERT INTO art_poisson_mesure VALUES (343, 741367, 200, 'ML2_126588');
INSERT INTO art_poisson_mesure VALUES (344, 741368, 150, 'ML2_126589');
INSERT INTO art_poisson_mesure VALUES (345, 741346, 130, 'ML2_126585');
INSERT INTO art_poisson_mesure VALUES (346, 741345, 140, 'ML2_126585');
INSERT INTO art_poisson_mesure VALUES (347, 741332, 160, 'ML2_126583');
INSERT INTO art_poisson_mesure VALUES (348, 741344, 135, 'ML2_126585');
INSERT INTO art_poisson_mesure VALUES (349, 741331, 155, 'ML2_126583');
INSERT INTO art_poisson_mesure VALUES (350, 741330, 150, 'ML2_126583');
INSERT INTO art_poisson_mesure VALUES (351, 741326, 140, 'ML2_126583');
INSERT INTO art_poisson_mesure VALUES (352, 741329, 160, 'ML2_126583');
INSERT INTO art_poisson_mesure VALUES (353, 741328, 155, 'ML2_126583');
INSERT INTO art_poisson_mesure VALUES (354, 741327, 150, 'ML2_126583');
INSERT INTO art_poisson_mesure VALUES (355, 741334, 150, 'ML2_126583');
INSERT INTO art_poisson_mesure VALUES (356, 741343, 120, 'ML2_126585');
INSERT INTO art_poisson_mesure VALUES (357, 741342, 130, 'ML2_126585');
INSERT INTO art_poisson_mesure VALUES (358, 741333, 135, 'ML2_126583');
INSERT INTO art_poisson_mesure VALUES (359, 741335, 155, 'ML2_126583');
INSERT INTO art_poisson_mesure VALUES (360, 741336, 150, 'ML2_126584');
INSERT INTO art_poisson_mesure VALUES (361, 741341, 110, 'ML2_126585');
INSERT INTO art_poisson_mesure VALUES (362, 741337, 140, 'ML2_126584');
INSERT INTO art_poisson_mesure VALUES (363, 741340, 120, 'ML2_126585');
INSERT INTO art_poisson_mesure VALUES (364, 741338, 135, 'ML2_126584');
INSERT INTO art_poisson_mesure VALUES (365, 741339, 130, 'ML2_126584');
INSERT INTO art_poisson_mesure VALUES (366, 741388, 240, 'ML2_126593');
INSERT INTO art_poisson_mesure VALUES (367, 741387, 245, 'ML2_126593');
INSERT INTO art_poisson_mesure VALUES (368, 741389, 195, 'ML2_126594');
INSERT INTO art_poisson_mesure VALUES (369, 741386, 280, 'ML2_126593');
INSERT INTO art_poisson_mesure VALUES (370, 741385, 210, 'ML2_126593');
INSERT INTO art_poisson_mesure VALUES (371, 741384, 290, 'ML2_126593');
INSERT INTO art_poisson_mesure VALUES (372, 741393, 210, 'ML2_126597');
INSERT INTO art_poisson_mesure VALUES (373, 741392, 280, 'ML2_126596');
INSERT INTO art_poisson_mesure VALUES (374, 741391, 400, 'ML2_126595');
INSERT INTO art_poisson_mesure VALUES (375, 741390, 230, 'ML2_126594');
INSERT INTO art_poisson_mesure VALUES (376, 741383, 245, 'ML2_126593');
INSERT INTO art_poisson_mesure VALUES (377, 741394, 240, 'ML2_126598');
INSERT INTO art_poisson_mesure VALUES (378, 741382, 330, 'ML2_126592');
INSERT INTO art_poisson_mesure VALUES (379, 741381, 520, 'ML2_126592');
INSERT INTO art_poisson_mesure VALUES (380, 741380, 350, 'ML2_126592');
INSERT INTO art_poisson_mesure VALUES (381, 741395, 230, 'ML2_126598');
INSERT INTO art_poisson_mesure VALUES (382, 741379, 550, 'ML2_126592');
INSERT INTO art_poisson_mesure VALUES (383, 741370, 305, 'ML2_126591');
INSERT INTO art_poisson_mesure VALUES (384, 741373, 260, 'ML2_126591');
INSERT INTO art_poisson_mesure VALUES (385, 741371, 260, 'ML2_126591');
INSERT INTO art_poisson_mesure VALUES (386, 741378, 265, 'ML2_126591');
INSERT INTO art_poisson_mesure VALUES (387, 741372, 275, 'ML2_126591');
INSERT INTO art_poisson_mesure VALUES (388, 741374, 275, 'ML2_126591');
INSERT INTO art_poisson_mesure VALUES (389, 741377, 250, 'ML2_126591');
INSERT INTO art_poisson_mesure VALUES (390, 741375, 395, 'ML2_126591');
INSERT INTO art_poisson_mesure VALUES (391, 741376, 270, 'ML2_126591');
INSERT INTO art_poisson_mesure VALUES (392, 745156, 120, 'ML2_127401');
INSERT INTO art_poisson_mesure VALUES (393, 745157, 130, 'ML2_127401');
INSERT INTO art_poisson_mesure VALUES (394, 745158, 125, 'ML2_127401');
INSERT INTO art_poisson_mesure VALUES (395, 745162, 150, 'ML2_127401');
INSERT INTO art_poisson_mesure VALUES (396, 745159, 130, 'ML2_127401');
INSERT INTO art_poisson_mesure VALUES (397, 745161, 140, 'ML2_127401');
INSERT INTO art_poisson_mesure VALUES (398, 745160, 135, 'ML2_127401');
INSERT INTO art_poisson_mesure VALUES (399, 745164, 130, 'ML2_127401');
INSERT INTO art_poisson_mesure VALUES (400, 745163, 155, 'ML2_127401');
INSERT INTO art_poisson_mesure VALUES (401, 745165, 120, 'ML2_127401');
INSERT INTO art_poisson_mesure VALUES (402, 745155, 160, 'ML2_127400');
INSERT INTO art_poisson_mesure VALUES (403, 745154, 200, 'ML2_127400');
INSERT INTO art_poisson_mesure VALUES (404, 745153, 195, 'ML2_127400');
INSERT INTO art_poisson_mesure VALUES (405, 745152, 260, 'ML2_127400');
INSERT INTO art_poisson_mesure VALUES (406, 745148, 195, 'ML2_127400');
INSERT INTO art_poisson_mesure VALUES (407, 745151, 165, 'ML2_127400');
INSERT INTO art_poisson_mesure VALUES (408, 745147, 250, 'ML2_127400');
INSERT INTO art_poisson_mesure VALUES (409, 745146, 190, 'ML2_127400');
INSERT INTO art_poisson_mesure VALUES (410, 745150, 175, 'ML2_127400');
INSERT INTO art_poisson_mesure VALUES (411, 745149, 160, 'ML2_127400');
INSERT INTO art_poisson_mesure VALUES (412, 745168, 270, 'ML2_127403');
INSERT INTO art_poisson_mesure VALUES (413, 745177, 160, 'ML2_127404');
INSERT INTO art_poisson_mesure VALUES (414, 745167, 210, 'ML2_127403');
INSERT INTO art_poisson_mesure VALUES (415, 745166, 700, 'ML2_127402');
INSERT INTO art_poisson_mesure VALUES (416, 745176, 200, 'ML2_127403');
INSERT INTO art_poisson_mesure VALUES (417, 745170, 265, 'ML2_127403');
INSERT INTO art_poisson_mesure VALUES (418, 745169, 265, 'ML2_127403');
INSERT INTO art_poisson_mesure VALUES (419, 745171, 220, 'ML2_127403');
INSERT INTO art_poisson_mesure VALUES (420, 745175, 180, 'ML2_127403');
INSERT INTO art_poisson_mesure VALUES (421, 745172, 195, 'ML2_127403');
INSERT INTO art_poisson_mesure VALUES (422, 745174, 260, 'ML2_127403');
INSERT INTO art_poisson_mesure VALUES (423, 745173, 210, 'ML2_127403');
INSERT INTO art_poisson_mesure VALUES (424, 745179, 140, 'ML2_127404');
INSERT INTO art_poisson_mesure VALUES (425, 745184, 200, 'ML2_127404');
INSERT INTO art_poisson_mesure VALUES (426, 745178, 130, 'ML2_127404');
INSERT INTO art_poisson_mesure VALUES (427, 745180, 150, 'ML2_127404');
INSERT INTO art_poisson_mesure VALUES (428, 745183, 220, 'ML2_127404');
INSERT INTO art_poisson_mesure VALUES (429, 745181, 225, 'ML2_127404');
INSERT INTO art_poisson_mesure VALUES (430, 745182, 210, 'ML2_127404');
INSERT INTO art_poisson_mesure VALUES (431, 745187, 170, 'ML2_127405');
INSERT INTO art_poisson_mesure VALUES (432, 745185, 170, 'ML2_127404');
INSERT INTO art_poisson_mesure VALUES (433, 745186, 230, 'ML2_127404');
INSERT INTO art_poisson_mesure VALUES (434, 745188, 235, 'ML2_127406');
INSERT INTO art_poisson_mesure VALUES (435, 745189, 245, 'ML2_127406');
INSERT INTO art_poisson_mesure VALUES (436, 745197, 185, 'ML2_127407');
INSERT INTO art_poisson_mesure VALUES (437, 745199, 250, 'ML2_127407');
INSERT INTO art_poisson_mesure VALUES (438, 745196, 170, 'ML2_127407');
INSERT INTO art_poisson_mesure VALUES (439, 745195, 195, 'ML2_127407');
INSERT INTO art_poisson_mesure VALUES (440, 745194, 200, 'ML2_127407');
INSERT INTO art_poisson_mesure VALUES (441, 745193, 310, 'ML2_127407');
INSERT INTO art_poisson_mesure VALUES (442, 745192, 180, 'ML2_127407');
INSERT INTO art_poisson_mesure VALUES (443, 745191, 175, 'ML2_127407');
INSERT INTO art_poisson_mesure VALUES (444, 745190, 320, 'ML2_127407');
INSERT INTO art_poisson_mesure VALUES (445, 745215, 210, 'ML2_127412');
INSERT INTO art_poisson_mesure VALUES (446, 745214, 220, 'ML2_127412');
INSERT INTO art_poisson_mesure VALUES (447, 745213, 200, 'ML2_127412');
INSERT INTO art_poisson_mesure VALUES (448, 745198, 180, 'ML2_127407');
INSERT INTO art_poisson_mesure VALUES (449, 745212, 180, 'ML2_127412');
INSERT INTO art_poisson_mesure VALUES (450, 745211, 220, 'ML2_127411');
INSERT INTO art_poisson_mesure VALUES (451, 745216, 250, 'ML2_127412');
INSERT INTO art_poisson_mesure VALUES (452, 745217, 230, 'ML2_127412');
INSERT INTO art_poisson_mesure VALUES (453, 745210, 300, 'ML2_127411');
INSERT INTO art_poisson_mesure VALUES (454, 745209, 190, 'ML2_127410');
INSERT INTO art_poisson_mesure VALUES (455, 745200, 270, 'ML2_127408');
INSERT INTO art_poisson_mesure VALUES (456, 745208, 145, 'ML2_127410');
INSERT INTO art_poisson_mesure VALUES (457, 745201, 280, 'ML2_127408');
INSERT INTO art_poisson_mesure VALUES (458, 745207, 170, 'ML2_127410');
INSERT INTO art_poisson_mesure VALUES (459, 745206, 160, 'ML2_127410');
INSERT INTO art_poisson_mesure VALUES (460, 745202, 300, 'ML2_127408');
INSERT INTO art_poisson_mesure VALUES (461, 745203, 330, 'ML2_127409');
INSERT INTO art_poisson_mesure VALUES (462, 745205, 185, 'ML2_127410');
INSERT INTO art_poisson_mesure VALUES (463, 745204, 290, 'ML2_127409');
INSERT INTO art_poisson_mesure VALUES (464, 745224, 160, 'ML2_127413');
INSERT INTO art_poisson_mesure VALUES (465, 745223, 230, 'ML2_127413');
INSERT INTO art_poisson_mesure VALUES (466, 745222, 245, 'ML2_127413');
INSERT INTO art_poisson_mesure VALUES (467, 745218, 230, 'ML2_127413');
INSERT INTO art_poisson_mesure VALUES (468, 745221, 220, 'ML2_127413');
INSERT INTO art_poisson_mesure VALUES (469, 745220, 195, 'ML2_127413');
INSERT INTO art_poisson_mesure VALUES (470, 745219, 250, 'ML2_127413');
INSERT INTO art_poisson_mesure VALUES (471, 745239, 170, 'ML2_127415');
INSERT INTO art_poisson_mesure VALUES (472, 745225, 150, 'ML2_127413');
INSERT INTO art_poisson_mesure VALUES (473, 745230, 210, 'ML2_127414');
INSERT INTO art_poisson_mesure VALUES (474, 745229, 190, 'ML2_127414');
INSERT INTO art_poisson_mesure VALUES (475, 745226, 200, 'ML2_127413');
INSERT INTO art_poisson_mesure VALUES (476, 745228, 205, 'ML2_127414');
INSERT INTO art_poisson_mesure VALUES (477, 745227, 180, 'ML2_127413');
INSERT INTO art_poisson_mesure VALUES (478, 745233, 195, 'ML2_127414');
INSERT INTO art_poisson_mesure VALUES (479, 745238, 165, 'ML2_127415');
INSERT INTO art_poisson_mesure VALUES (480, 745232, 210, 'ML2_127414');
INSERT INTO art_poisson_mesure VALUES (481, 745231, 200, 'ML2_127414');
INSERT INTO art_poisson_mesure VALUES (482, 745234, 200, 'ML2_127414');
INSERT INTO art_poisson_mesure VALUES (483, 745237, 180, 'ML2_127414');
INSERT INTO art_poisson_mesure VALUES (484, 745235, 200, 'ML2_127414');
INSERT INTO art_poisson_mesure VALUES (485, 745236, 195, 'ML2_127414');
INSERT INTO art_poisson_mesure VALUES (486, 745240, 200, 'ML2_127415');
INSERT INTO art_poisson_mesure VALUES (487, 745246, 180, 'ML2_127415');
INSERT INTO art_poisson_mesure VALUES (488, 745241, 175, 'ML2_127415');
INSERT INTO art_poisson_mesure VALUES (489, 745245, 185, 'ML2_127415');
INSERT INTO art_poisson_mesure VALUES (490, 745242, 210, 'ML2_127415');
INSERT INTO art_poisson_mesure VALUES (491, 745244, 190, 'ML2_127415');
INSERT INTO art_poisson_mesure VALUES (492, 745243, 190, 'ML2_127415');
INSERT INTO art_poisson_mesure VALUES (493, 745248, 290, 'ML2_127416');
INSERT INTO art_poisson_mesure VALUES (494, 745249, 300, 'ML2_127416');
INSERT INTO art_poisson_mesure VALUES (495, 745247, 200, 'ML2_127415');
INSERT INTO art_poisson_mesure VALUES (496, 745250, 275, 'ML2_127416');
INSERT INTO art_poisson_mesure VALUES (497, 745251, 320, 'ML2_127416');
INSERT INTO art_poisson_mesure VALUES (498, 745273, 220, 'ML2_127419');
INSERT INTO art_poisson_mesure VALUES (499, 745269, 165, 'ML2_127418');
INSERT INTO art_poisson_mesure VALUES (500, 745272, 200, 'ML2_127419');
INSERT INTO art_poisson_mesure VALUES (501, 745271, 160, 'ML2_127418');
INSERT INTO art_poisson_mesure VALUES (502, 745270, 150, 'ML2_127418');
INSERT INTO art_poisson_mesure VALUES (503, 745268, 170, 'ML2_127418');
INSERT INTO art_poisson_mesure VALUES (504, 745264, 110, 'ML2_127418');
INSERT INTO art_poisson_mesure VALUES (505, 745267, 110, 'ML2_127418');
INSERT INTO art_poisson_mesure VALUES (506, 745276, 190, 'ML2_127419');
INSERT INTO art_poisson_mesure VALUES (507, 745262, 140, 'ML2_127418');
INSERT INTO art_poisson_mesure VALUES (508, 745257, 180, 'ML2_127417');
INSERT INTO art_poisson_mesure VALUES (509, 745275, 180, 'ML2_127419');
INSERT INTO art_poisson_mesure VALUES (510, 745278, 195, 'ML2_127419');
INSERT INTO art_poisson_mesure VALUES (511, 745277, 195, 'ML2_127419');
INSERT INTO art_poisson_mesure VALUES (512, 745274, 210, 'ML2_127419');
INSERT INTO art_poisson_mesure VALUES (513, 745263, 140, 'ML2_127418');
INSERT INTO art_poisson_mesure VALUES (514, 745256, 185, 'ML2_127417');
INSERT INTO art_poisson_mesure VALUES (515, 745255, 220, 'ML2_127417');
INSERT INTO art_poisson_mesure VALUES (516, 745254, 195, 'ML2_127417');
INSERT INTO art_poisson_mesure VALUES (517, 745253, 185, 'ML2_127417');
INSERT INTO art_poisson_mesure VALUES (518, 745252, 180, 'ML2_127417');
INSERT INTO art_poisson_mesure VALUES (519, 745260, 210, 'ML2_127417');
INSERT INTO art_poisson_mesure VALUES (520, 745259, 200, 'ML2_127417');
INSERT INTO art_poisson_mesure VALUES (521, 745261, 175, 'ML2_127417');
INSERT INTO art_poisson_mesure VALUES (522, 745281, 190, 'ML2_127419');
INSERT INTO art_poisson_mesure VALUES (523, 745286, 220, 'ML2_127421');
INSERT INTO art_poisson_mesure VALUES (524, 745280, 200, 'ML2_127419');
INSERT INTO art_poisson_mesure VALUES (525, 745279, 185, 'ML2_127419');
INSERT INTO art_poisson_mesure VALUES (526, 745285, 250, 'ML2_127421');
INSERT INTO art_poisson_mesure VALUES (527, 745258, 200, 'ML2_127417');
INSERT INTO art_poisson_mesure VALUES (528, 745284, 300, 'ML2_127420');
INSERT INTO art_poisson_mesure VALUES (529, 745283, 270, 'ML2_127420');
INSERT INTO art_poisson_mesure VALUES (530, 745282, 290, 'ML2_127420');
INSERT INTO art_poisson_mesure VALUES (531, 745288, 250, 'ML2_127421');
INSERT INTO art_poisson_mesure VALUES (532, 745287, 130, 'ML2_127421');
INSERT INTO art_poisson_mesure VALUES (533, 745289, 195, 'ML2_127421');
INSERT INTO art_poisson_mesure VALUES (534, 745290, 240, 'ML2_127421');
INSERT INTO art_poisson_mesure VALUES (535, 745266, 135, 'ML2_127418');
INSERT INTO art_poisson_mesure VALUES (536, 745265, 145, 'ML2_127418');
INSERT INTO art_poisson_mesure VALUES (537, 745309, 160, 'ML2_127424');
INSERT INTO art_poisson_mesure VALUES (538, 745308, 170, 'ML2_127424');
INSERT INTO art_poisson_mesure VALUES (539, 745307, 160, 'ML2_127424');
INSERT INTO art_poisson_mesure VALUES (540, 745303, 165, 'ML2_127424');
INSERT INTO art_poisson_mesure VALUES (541, 745306, 310, 'ML2_127424');
INSERT INTO art_poisson_mesure VALUES (542, 745293, 210, 'ML2_127422');
INSERT INTO art_poisson_mesure VALUES (543, 745302, 260, 'ML2_127423');
INSERT INTO art_poisson_mesure VALUES (544, 745292, 315, 'ML2_127422');
INSERT INTO art_poisson_mesure VALUES (545, 745291, 310, 'ML2_127422');
INSERT INTO art_poisson_mesure VALUES (546, 745296, 320, 'ML2_127422');
INSERT INTO art_poisson_mesure VALUES (547, 745301, 230, 'ML2_127423');
INSERT INTO art_poisson_mesure VALUES (548, 745295, 195, 'ML2_127422');
INSERT INTO art_poisson_mesure VALUES (549, 745294, 160, 'ML2_127422');
INSERT INTO art_poisson_mesure VALUES (550, 745300, 315, 'ML2_127422');
INSERT INTO art_poisson_mesure VALUES (551, 745297, 330, 'ML2_127422');
INSERT INTO art_poisson_mesure VALUES (552, 745299, 400, 'ML2_127422');
INSERT INTO art_poisson_mesure VALUES (553, 745298, 220, 'ML2_127422');
INSERT INTO art_poisson_mesure VALUES (554, 745304, 210, 'ML2_127424');
INSERT INTO art_poisson_mesure VALUES (555, 745305, 210, 'ML2_127424');
INSERT INTO art_poisson_mesure VALUES (556, 745310, 320, 'ML2_127424');
INSERT INTO art_poisson_mesure VALUES (557, 745311, 210, 'ML2_127424');
INSERT INTO art_poisson_mesure VALUES (558, 745312, 175, 'ML2_127424');
INSERT INTO art_poisson_mesure VALUES (559, 745313, 180, 'ML2_127425');
INSERT INTO art_poisson_mesure VALUES (560, 745314, 185, 'ML2_127425');
INSERT INTO art_poisson_mesure VALUES (561, 745316, 220, 'ML2_127426');
INSERT INTO art_poisson_mesure VALUES (562, 745315, 180, 'ML2_127425');
INSERT INTO art_poisson_mesure VALUES (563, 745325, 390, 'ML2_127427');
INSERT INTO art_poisson_mesure VALUES (564, 745324, 290, 'ML2_127427');
INSERT INTO art_poisson_mesure VALUES (565, 745326, 270, 'ML2_127427');
INSERT INTO art_poisson_mesure VALUES (566, 745327, 440, 'ML2_127428');
INSERT INTO art_poisson_mesure VALUES (567, 745328, 240, 'ML2_127429');
INSERT INTO art_poisson_mesure VALUES (568, 745331, 240, 'ML2_127429');
INSERT INTO art_poisson_mesure VALUES (569, 745330, 195, 'ML2_127429');
INSERT INTO art_poisson_mesure VALUES (570, 745329, 170, 'ML2_127429');
INSERT INTO art_poisson_mesure VALUES (571, 745333, 300, 'ML2_127430');
INSERT INTO art_poisson_mesure VALUES (572, 745334, 330, 'ML2_127430');
INSERT INTO art_poisson_mesure VALUES (573, 745332, 250, 'ML2_127429');
INSERT INTO art_poisson_mesure VALUES (574, 745323, 280, 'ML2_127427');
INSERT INTO art_poisson_mesure VALUES (575, 745322, 200, 'ML2_127427');
INSERT INTO art_poisson_mesure VALUES (576, 745321, 310, 'ML2_127427');
INSERT INTO art_poisson_mesure VALUES (577, 745320, 315, 'ML2_127427');
INSERT INTO art_poisson_mesure VALUES (578, 745319, 195, 'ML2_127427');
INSERT INTO art_poisson_mesure VALUES (579, 745318, 180, 'ML2_127427');
INSERT INTO art_poisson_mesure VALUES (580, 745317, 300, 'ML2_127427');
INSERT INTO art_poisson_mesure VALUES (581, 745340, 210, 'ML2_127434');
INSERT INTO art_poisson_mesure VALUES (582, 745339, 245, 'ML2_127434');
INSERT INTO art_poisson_mesure VALUES (583, 745338, 210, 'ML2_127434');
INSERT INTO art_poisson_mesure VALUES (584, 745335, 680, 'ML2_127431');
INSERT INTO art_poisson_mesure VALUES (585, 745337, 225, 'ML2_127433');
INSERT INTO art_poisson_mesure VALUES (586, 745336, 370, 'ML2_127432');
INSERT INTO art_poisson_mesure VALUES (587, 745341, 400, 'ML2_127435');
INSERT INTO art_poisson_mesure VALUES (588, 745347, 210, 'ML2_127436');
INSERT INTO art_poisson_mesure VALUES (589, 745343, 200, 'ML2_127436');
INSERT INTO art_poisson_mesure VALUES (590, 745342, 210, 'ML2_127436');
INSERT INTO art_poisson_mesure VALUES (591, 745346, 200, 'ML2_127436');
INSERT INTO art_poisson_mesure VALUES (592, 745344, 190, 'ML2_127436');
INSERT INTO art_poisson_mesure VALUES (593, 745345, 195, 'ML2_127436');
INSERT INTO art_poisson_mesure VALUES (594, 745350, 290, 'ML2_127438');
INSERT INTO art_poisson_mesure VALUES (595, 745349, 460, 'ML2_127437');
INSERT INTO art_poisson_mesure VALUES (596, 745348, 170, 'ML2_127436');
INSERT INTO art_poisson_mesure VALUES (597, 745351, 370, 'ML2_127438');
INSERT INTO art_poisson_mesure VALUES (598, 745352, 380, 'ML2_127438');
INSERT INTO art_poisson_mesure VALUES (599, 745359, 450, 'ML2_127443');
INSERT INTO art_poisson_mesure VALUES (600, 745358, 270, 'ML2_127442');
INSERT INTO art_poisson_mesure VALUES (601, 745357, 310, 'ML2_127441');
INSERT INTO art_poisson_mesure VALUES (602, 745356, 285, 'ML2_127440');
INSERT INTO art_poisson_mesure VALUES (603, 745355, 300, 'ML2_127440');
INSERT INTO art_poisson_mesure VALUES (604, 745354, 450, 'ML2_127439');
INSERT INTO art_poisson_mesure VALUES (605, 745353, 385, 'ML2_127439');
INSERT INTO art_poisson_mesure VALUES (606, 745360, 260, 'ML2_127444');
INSERT INTO art_poisson_mesure VALUES (607, 745361, 600, 'ML2_127445');
INSERT INTO art_poisson_mesure VALUES (608, 745378, 180, 'ML2_127447');
INSERT INTO art_poisson_mesure VALUES (609, 745377, 175, 'ML2_127447');
INSERT INTO art_poisson_mesure VALUES (610, 745376, 150, 'ML2_127447');
INSERT INTO art_poisson_mesure VALUES (611, 745379, 170, 'ML2_127447');
INSERT INTO art_poisson_mesure VALUES (612, 745375, 140, 'ML2_127447');
INSERT INTO art_poisson_mesure VALUES (613, 745373, 170, 'ML2_127447');
INSERT INTO art_poisson_mesure VALUES (614, 745374, 155, 'ML2_127447');
INSERT INTO art_poisson_mesure VALUES (615, 745372, 155, 'ML2_127447');
INSERT INTO art_poisson_mesure VALUES (616, 745391, 130, 'ML2_127449');
INSERT INTO art_poisson_mesure VALUES (617, 745364, 155, 'ML2_127446');
INSERT INTO art_poisson_mesure VALUES (618, 745380, 160, 'ML2_127447');
INSERT INTO art_poisson_mesure VALUES (619, 745381, 150, 'ML2_127447');
INSERT INTO art_poisson_mesure VALUES (620, 745363, 145, 'ML2_127446');
INSERT INTO art_poisson_mesure VALUES (621, 745362, 180, 'ML2_127446');
INSERT INTO art_poisson_mesure VALUES (622, 745365, 160, 'ML2_127446');
INSERT INTO art_poisson_mesure VALUES (623, 745390, 140, 'ML2_127449');
INSERT INTO art_poisson_mesure VALUES (624, 745371, 180, 'ML2_127446');
INSERT INTO art_poisson_mesure VALUES (625, 745370, 190, 'ML2_127446');
INSERT INTO art_poisson_mesure VALUES (626, 745366, 175, 'ML2_127446');
INSERT INTO art_poisson_mesure VALUES (627, 745369, 190, 'ML2_127446');
INSERT INTO art_poisson_mesure VALUES (628, 745368, 190, 'ML2_127446');
INSERT INTO art_poisson_mesure VALUES (629, 745367, 185, 'ML2_127446');
INSERT INTO art_poisson_mesure VALUES (630, 745382, 165, 'ML2_127448');
INSERT INTO art_poisson_mesure VALUES (631, 745389, 155, 'ML2_127449');
INSERT INTO art_poisson_mesure VALUES (632, 745384, 165, 'ML2_127448');
INSERT INTO art_poisson_mesure VALUES (633, 745383, 155, 'ML2_127448');
INSERT INTO art_poisson_mesure VALUES (634, 745385, 150, 'ML2_127448');
INSERT INTO art_poisson_mesure VALUES (635, 745388, 155, 'ML2_127448');
INSERT INTO art_poisson_mesure VALUES (636, 745386, 160, 'ML2_127448');
INSERT INTO art_poisson_mesure VALUES (637, 745387, 165, 'ML2_127448');
INSERT INTO art_poisson_mesure VALUES (638, 745406, 175, 'ML2_127454');
INSERT INTO art_poisson_mesure VALUES (639, 745397, 170, 'ML2_127450');
INSERT INTO art_poisson_mesure VALUES (640, 745396, 160, 'ML2_127450');
INSERT INTO art_poisson_mesure VALUES (641, 745392, 160, 'ML2_127449');
INSERT INTO art_poisson_mesure VALUES (642, 745395, 160, 'ML2_127450');
INSERT INTO art_poisson_mesure VALUES (643, 745393, 150, 'ML2_127449');
INSERT INTO art_poisson_mesure VALUES (644, 745394, 165, 'ML2_127450');
INSERT INTO art_poisson_mesure VALUES (645, 745405, 150, 'ML2_127454');
INSERT INTO art_poisson_mesure VALUES (646, 745400, 165, 'ML2_127451');
INSERT INTO art_poisson_mesure VALUES (647, 745399, 295, 'ML2_127451');
INSERT INTO art_poisson_mesure VALUES (648, 745398, 150, 'ML2_127451');
INSERT INTO art_poisson_mesure VALUES (649, 745404, 150, 'ML2_127453');
INSERT INTO art_poisson_mesure VALUES (650, 745401, 120, 'ML2_127452');
INSERT INTO art_poisson_mesure VALUES (651, 745403, 150, 'ML2_127453');
INSERT INTO art_poisson_mesure VALUES (652, 745402, 145, 'ML2_127453');
INSERT INTO art_poisson_mesure VALUES (653, 745408, 150, 'ML2_127454');
INSERT INTO art_poisson_mesure VALUES (654, 745407, 150, 'ML2_127454');
INSERT INTO art_poisson_mesure VALUES (655, 745409, 145, 'ML2_127454');
INSERT INTO art_poisson_mesure VALUES (656, 745410, 160, 'ML2_127455');
INSERT INTO art_poisson_mesure VALUES (657, 745435, 220, 'ML2_127464');
INSERT INTO art_poisson_mesure VALUES (658, 745433, 180, 'ML2_127463');
INSERT INTO art_poisson_mesure VALUES (659, 745434, 160, 'ML2_127463');
INSERT INTO art_poisson_mesure VALUES (660, 745432, 140, 'ML2_127463');
INSERT INTO art_poisson_mesure VALUES (661, 745431, 190, 'ML2_127462');
INSERT INTO art_poisson_mesure VALUES (662, 745436, 190, 'ML2_127465');
INSERT INTO art_poisson_mesure VALUES (663, 745424, 160, 'ML2_127461');
INSERT INTO art_poisson_mesure VALUES (664, 745430, 175, 'ML2_127461');
INSERT INTO art_poisson_mesure VALUES (665, 745437, 165, 'ML2_127466');
INSERT INTO art_poisson_mesure VALUES (666, 745423, 150, 'ML2_127461');
INSERT INTO art_poisson_mesure VALUES (667, 745413, 310, 'ML2_127456');
INSERT INTO art_poisson_mesure VALUES (668, 745422, 140, 'ML2_127461');
INSERT INTO art_poisson_mesure VALUES (669, 745412, 320, 'ML2_127456');
INSERT INTO art_poisson_mesure VALUES (670, 745411, 220, 'ML2_127456');
INSERT INTO art_poisson_mesure VALUES (671, 745415, 140, 'ML2_127458');
INSERT INTO art_poisson_mesure VALUES (672, 745421, 180, 'ML2_127461');
INSERT INTO art_poisson_mesure VALUES (673, 745416, 125, 'ML2_127458');
INSERT INTO art_poisson_mesure VALUES (674, 745414, 300, 'ML2_127457');
INSERT INTO art_poisson_mesure VALUES (675, 745420, 330, 'ML2_127460');
INSERT INTO art_poisson_mesure VALUES (676, 745417, 115, 'ML2_127458');
INSERT INTO art_poisson_mesure VALUES (677, 745419, 270, 'ML2_127459');
INSERT INTO art_poisson_mesure VALUES (678, 745418, 210, 'ML2_127459');
INSERT INTO art_poisson_mesure VALUES (679, 745426, 170, 'ML2_127461');
INSERT INTO art_poisson_mesure VALUES (680, 745427, 140, 'ML2_127461');
INSERT INTO art_poisson_mesure VALUES (681, 745428, 195, 'ML2_127461');
INSERT INTO art_poisson_mesure VALUES (682, 745429, 195, 'ML2_127461');
INSERT INTO art_poisson_mesure VALUES (683, 745425, 165, 'ML2_127461');
INSERT INTO art_poisson_mesure VALUES (684, 745445, 155, 'ML2_127467');
INSERT INTO art_poisson_mesure VALUES (685, 745438, 120, 'ML2_127467');
INSERT INTO art_poisson_mesure VALUES (686, 745440, 170, 'ML2_127467');
INSERT INTO art_poisson_mesure VALUES (687, 745439, 150, 'ML2_127467');
INSERT INTO art_poisson_mesure VALUES (688, 745462, 220, 'ML2_127469');
INSERT INTO art_poisson_mesure VALUES (689, 745444, 160, 'ML2_127467');
INSERT INTO art_poisson_mesure VALUES (690, 745441, 160, 'ML2_127467');
INSERT INTO art_poisson_mesure VALUES (691, 745443, 175, 'ML2_127467');
INSERT INTO art_poisson_mesure VALUES (692, 745442, 130, 'ML2_127467');
INSERT INTO art_poisson_mesure VALUES (693, 745447, 145, 'ML2_127467');
INSERT INTO art_poisson_mesure VALUES (694, 745461, 210, 'ML2_127469');
INSERT INTO art_poisson_mesure VALUES (695, 745452, 110, 'ML2_127468');
INSERT INTO art_poisson_mesure VALUES (696, 745446, 150, 'ML2_127467');
INSERT INTO art_poisson_mesure VALUES (697, 745451, 115, 'ML2_127468');
INSERT INTO art_poisson_mesure VALUES (698, 745448, 115, 'ML2_127468');
INSERT INTO art_poisson_mesure VALUES (699, 745450, 135, 'ML2_127468');
INSERT INTO art_poisson_mesure VALUES (700, 745449, 195, 'ML2_127468');
INSERT INTO art_poisson_mesure VALUES (701, 745455, 170, 'ML2_127468');
INSERT INTO art_poisson_mesure VALUES (702, 745460, 190, 'ML2_127469');
INSERT INTO art_poisson_mesure VALUES (703, 745454, 180, 'ML2_127468');
INSERT INTO art_poisson_mesure VALUES (704, 745453, 120, 'ML2_127468');
INSERT INTO art_poisson_mesure VALUES (705, 745459, 240, 'ML2_127469');
INSERT INTO art_poisson_mesure VALUES (706, 745456, 130, 'ML2_127468');
INSERT INTO art_poisson_mesure VALUES (707, 745458, 230, 'ML2_127469');
INSERT INTO art_poisson_mesure VALUES (708, 745457, 125, 'ML2_127468');
INSERT INTO art_poisson_mesure VALUES (709, 745475, 140, 'ML2_127471');
INSERT INTO art_poisson_mesure VALUES (710, 745476, 145, 'ML2_127471');
INSERT INTO art_poisson_mesure VALUES (711, 745466, 170, 'ML2_127470');
INSERT INTO art_poisson_mesure VALUES (712, 745465, 145, 'ML2_127470');
INSERT INTO art_poisson_mesure VALUES (713, 745463, 235, 'ML2_127469');
INSERT INTO art_poisson_mesure VALUES (714, 745464, 120, 'ML2_127470');
INSERT INTO art_poisson_mesure VALUES (715, 745467, 135, 'ML2_127470');
INSERT INTO art_poisson_mesure VALUES (716, 745474, 150, 'ML2_127471');
INSERT INTO art_poisson_mesure VALUES (717, 745469, 140, 'ML2_127470');
INSERT INTO art_poisson_mesure VALUES (718, 745468, 160, 'ML2_127470');
INSERT INTO art_poisson_mesure VALUES (719, 745473, 130, 'ML2_127471');
INSERT INTO art_poisson_mesure VALUES (720, 745470, 115, 'ML2_127470');
INSERT INTO art_poisson_mesure VALUES (721, 745472, 155, 'ML2_127470');
INSERT INTO art_poisson_mesure VALUES (722, 745471, 110, 'ML2_127470');
INSERT INTO art_poisson_mesure VALUES (723, 745480, 285, 'ML2_127472');
INSERT INTO art_poisson_mesure VALUES (724, 745479, 290, 'ML2_127472');
INSERT INTO art_poisson_mesure VALUES (725, 745478, 300, 'ML2_127472');
INSERT INTO art_poisson_mesure VALUES (726, 745477, 290, 'ML2_127472');
INSERT INTO art_poisson_mesure VALUES (727, 745481, 275, 'ML2_127472');
INSERT INTO art_poisson_mesure VALUES (728, 745482, 280, 'ML2_127472');
INSERT INTO art_poisson_mesure VALUES (729, 745484, 280, 'ML2_127472');
INSERT INTO art_poisson_mesure VALUES (730, 745483, 270, 'ML2_127472');
INSERT INTO art_poisson_mesure VALUES (731, 745488, 330, 'ML2_127475');
INSERT INTO art_poisson_mesure VALUES (732, 745485, 300, 'ML2_127472');
INSERT INTO art_poisson_mesure VALUES (733, 745487, 390, 'ML2_127474');
INSERT INTO art_poisson_mesure VALUES (734, 745486, 300, 'ML2_127473');
INSERT INTO art_poisson_mesure VALUES (735, 745490, 220, 'ML2_127477');
INSERT INTO art_poisson_mesure VALUES (736, 745489, 340, 'ML2_127476');
INSERT INTO art_poisson_mesure VALUES (737, 745514, 200, 'ML2_127484');
INSERT INTO art_poisson_mesure VALUES (738, 745513, 190, 'ML2_127483');
INSERT INTO art_poisson_mesure VALUES (739, 745502, 145, 'ML2_127479');
INSERT INTO art_poisson_mesure VALUES (740, 745501, 195, 'ML2_127479');
INSERT INTO art_poisson_mesure VALUES (741, 745500, 200, 'ML2_127478');
INSERT INTO art_poisson_mesure VALUES (742, 745499, 200, 'ML2_127478');
INSERT INTO art_poisson_mesure VALUES (743, 745498, 125, 'ML2_127478');
INSERT INTO art_poisson_mesure VALUES (744, 745497, 170, 'ML2_127478');
INSERT INTO art_poisson_mesure VALUES (745, 745491, 140, 'ML2_127478');
INSERT INTO art_poisson_mesure VALUES (746, 745496, 175, 'ML2_127478');
INSERT INTO art_poisson_mesure VALUES (747, 745492, 130, 'ML2_127478');
INSERT INTO art_poisson_mesure VALUES (748, 745495, 200, 'ML2_127478');
INSERT INTO art_poisson_mesure VALUES (749, 745494, 210, 'ML2_127478');
INSERT INTO art_poisson_mesure VALUES (750, 745493, 150, 'ML2_127478');
INSERT INTO art_poisson_mesure VALUES (751, 745512, 300, 'ML2_127482');
INSERT INTO art_poisson_mesure VALUES (752, 745511, 190, 'ML2_127481');
INSERT INTO art_poisson_mesure VALUES (753, 745509, 120, 'ML2_127479');
INSERT INTO art_poisson_mesure VALUES (754, 745510, 200, 'ML2_127480');
INSERT INTO art_poisson_mesure VALUES (755, 745505, 130, 'ML2_127479');
INSERT INTO art_poisson_mesure VALUES (756, 745508, 250, 'ML2_127479');
INSERT INTO art_poisson_mesure VALUES (757, 745507, 240, 'ML2_127479');
INSERT INTO art_poisson_mesure VALUES (758, 745503, 115, 'ML2_127479');
INSERT INTO art_poisson_mesure VALUES (759, 745504, 130, 'ML2_127479');
INSERT INTO art_poisson_mesure VALUES (760, 745506, 230, 'ML2_127479');
INSERT INTO art_poisson_mesure VALUES (761, 745515, 230, 'ML2_127485');
INSERT INTO art_poisson_mesure VALUES (762, 745516, 380, 'ML2_127485');
INSERT INTO art_poisson_mesure VALUES (763, 745517, 260, 'ML2_127485');
INSERT INTO art_poisson_mesure VALUES (764, 745518, 370, 'ML2_127485');
INSERT INTO art_poisson_mesure VALUES (765, 745520, 260, 'ML2_127485');
INSERT INTO art_poisson_mesure VALUES (766, 745519, 320, 'ML2_127485');
INSERT INTO art_poisson_mesure VALUES (767, 745528, 230, 'ML2_127486');
INSERT INTO art_poisson_mesure VALUES (768, 745545, 195, 'ML2_127490');
INSERT INTO art_poisson_mesure VALUES (769, 745527, 240, 'ML2_127486');
INSERT INTO art_poisson_mesure VALUES (770, 745522, 260, 'ML2_127485');
INSERT INTO art_poisson_mesure VALUES (771, 745521, 340, 'ML2_127485');
INSERT INTO art_poisson_mesure VALUES (772, 745526, 250, 'ML2_127486');
INSERT INTO art_poisson_mesure VALUES (773, 745523, 270, 'ML2_127485');
INSERT INTO art_poisson_mesure VALUES (774, 745525, 280, 'ML2_127486');
INSERT INTO art_poisson_mesure VALUES (775, 745524, 220, 'ML2_127485');
INSERT INTO art_poisson_mesure VALUES (776, 745533, 250, 'ML2_127486');
INSERT INTO art_poisson_mesure VALUES (777, 745529, 230, 'ML2_127486');
INSERT INTO art_poisson_mesure VALUES (778, 745535, 350, 'ML2_127487');
INSERT INTO art_poisson_mesure VALUES (779, 745544, 300, 'ML2_127489');
INSERT INTO art_poisson_mesure VALUES (780, 745532, 180, 'ML2_127486');
INSERT INTO art_poisson_mesure VALUES (781, 745531, 175, 'ML2_127486');
INSERT INTO art_poisson_mesure VALUES (782, 745530, 220, 'ML2_127486');
INSERT INTO art_poisson_mesure VALUES (783, 745534, 185, 'ML2_127486');
INSERT INTO art_poisson_mesure VALUES (784, 745538, 240, 'ML2_127488');
INSERT INTO art_poisson_mesure VALUES (785, 745536, 225, 'ML2_127488');
INSERT INTO art_poisson_mesure VALUES (786, 745537, 210, 'ML2_127488');
INSERT INTO art_poisson_mesure VALUES (787, 745543, 330, 'ML2_127489');
INSERT INTO art_poisson_mesure VALUES (788, 745542, 230, 'ML2_127488');
INSERT INTO art_poisson_mesure VALUES (789, 745539, 250, 'ML2_127488');
INSERT INTO art_poisson_mesure VALUES (790, 745541, 210, 'ML2_127488');
INSERT INTO art_poisson_mesure VALUES (791, 745540, 260, 'ML2_127488');
INSERT INTO art_poisson_mesure VALUES (792, 745546, 280, 'ML2_127491');
INSERT INTO art_poisson_mesure VALUES (793, 745559, 180, 'ML2_127494');
INSERT INTO art_poisson_mesure VALUES (794, 745550, 370, 'ML2_127491');
INSERT INTO art_poisson_mesure VALUES (795, 745549, 360, 'ML2_127491');
INSERT INTO art_poisson_mesure VALUES (796, 745547, 380, 'ML2_127491');
INSERT INTO art_poisson_mesure VALUES (797, 745548, 290, 'ML2_127491');
INSERT INTO art_poisson_mesure VALUES (798, 745553, 320, 'ML2_127491');
INSERT INTO art_poisson_mesure VALUES (799, 745552, 330, 'ML2_127491');
INSERT INTO art_poisson_mesure VALUES (800, 745558, 295, 'ML2_127493');
INSERT INTO art_poisson_mesure VALUES (801, 745551, 270, 'ML2_127491');
INSERT INTO art_poisson_mesure VALUES (802, 745557, 270, 'ML2_127493');
INSERT INTO art_poisson_mesure VALUES (803, 745554, 450, 'ML2_127491');
INSERT INTO art_poisson_mesure VALUES (804, 745556, 520, 'ML2_127492');
INSERT INTO art_poisson_mesure VALUES (805, 745555, 310, 'ML2_127491');
INSERT INTO art_poisson_mesure VALUES (806, 745566, 170, 'ML2_127494');
INSERT INTO art_poisson_mesure VALUES (807, 745560, 180, 'ML2_127494');
INSERT INTO art_poisson_mesure VALUES (808, 745561, 130, 'ML2_127494');
INSERT INTO art_poisson_mesure VALUES (809, 745565, 195, 'ML2_127494');
INSERT INTO art_poisson_mesure VALUES (810, 745562, 175, 'ML2_127494');
INSERT INTO art_poisson_mesure VALUES (811, 745564, 210, 'ML2_127494');
INSERT INTO art_poisson_mesure VALUES (812, 745563, 215, 'ML2_127494');
INSERT INTO art_poisson_mesure VALUES (813, 745567, 115, 'ML2_127494');
INSERT INTO art_poisson_mesure VALUES (814, 745569, 380, 'ML2_127495');
INSERT INTO art_poisson_mesure VALUES (815, 745568, 220, 'ML2_127494');
INSERT INTO art_poisson_mesure VALUES (816, 745570, 420, 'ML2_127495');
INSERT INTO art_poisson_mesure VALUES (817, 745576, 350, 'ML2_127496');
INSERT INTO art_poisson_mesure VALUES (818, 745588, 190, 'ML2_127498');
INSERT INTO art_poisson_mesure VALUES (819, 745575, 380, 'ML2_127496');
INSERT INTO art_poisson_mesure VALUES (820, 745574, 250, 'ML2_127496');
INSERT INTO art_poisson_mesure VALUES (821, 745573, 240, 'ML2_127496');
INSERT INTO art_poisson_mesure VALUES (822, 745572, 260, 'ML2_127496');
INSERT INTO art_poisson_mesure VALUES (823, 745571, 380, 'ML2_127496');
INSERT INTO art_poisson_mesure VALUES (824, 745586, 215, 'ML2_127498');
INSERT INTO art_poisson_mesure VALUES (825, 745592, 200, 'ML2_127498');
INSERT INTO art_poisson_mesure VALUES (826, 745587, 215, 'ML2_127498');
INSERT INTO art_poisson_mesure VALUES (827, 745580, 370, 'ML2_127496');
INSERT INTO art_poisson_mesure VALUES (828, 745578, 300, 'ML2_127496');
INSERT INTO art_poisson_mesure VALUES (829, 745579, 200, 'ML2_127496');
INSERT INTO art_poisson_mesure VALUES (830, 745577, 315, 'ML2_127496');
INSERT INTO art_poisson_mesure VALUES (831, 745581, 480, 'ML2_127497');
INSERT INTO art_poisson_mesure VALUES (832, 745585, 220, 'ML2_127498');
INSERT INTO art_poisson_mesure VALUES (833, 745582, 350, 'ML2_127497');
INSERT INTO art_poisson_mesure VALUES (834, 745591, 175, 'ML2_127498');
INSERT INTO art_poisson_mesure VALUES (835, 745590, 175, 'ML2_127498');
INSERT INTO art_poisson_mesure VALUES (836, 745584, 150, 'ML2_127498');
INSERT INTO art_poisson_mesure VALUES (837, 745589, 190, 'ML2_127498');
INSERT INTO art_poisson_mesure VALUES (838, 745583, 210, 'ML2_127498');
INSERT INTO art_poisson_mesure VALUES (839, 745611, 120, 'ML2_127505');
INSERT INTO art_poisson_mesure VALUES (840, 745612, 130, 'ML2_127505');
INSERT INTO art_poisson_mesure VALUES (841, 745613, 100, 'ML2_127505');
INSERT INTO art_poisson_mesure VALUES (842, 745610, 190, 'ML2_127505');
INSERT INTO art_poisson_mesure VALUES (843, 745609, 140, 'ML2_127505');
INSERT INTO art_poisson_mesure VALUES (844, 745593, 580, 'ML2_127499');
INSERT INTO art_poisson_mesure VALUES (845, 745594, 350, 'ML2_127499');
INSERT INTO art_poisson_mesure VALUES (846, 745608, 120, 'ML2_127505');
INSERT INTO art_poisson_mesure VALUES (847, 745599, 350, 'ML2_127500');
INSERT INTO art_poisson_mesure VALUES (848, 745598, 360, 'ML2_127500');
INSERT INTO art_poisson_mesure VALUES (849, 745595, 330, 'ML2_127499');
INSERT INTO art_poisson_mesure VALUES (850, 745597, 390, 'ML2_127499');
INSERT INTO art_poisson_mesure VALUES (851, 745596, 295, 'ML2_127499');
INSERT INTO art_poisson_mesure VALUES (852, 745601, 260, 'ML2_127502');
INSERT INTO art_poisson_mesure VALUES (853, 745607, 390, 'ML2_127504');
INSERT INTO art_poisson_mesure VALUES (854, 745602, 280, 'ML2_127502');
INSERT INTO art_poisson_mesure VALUES (855, 745600, 320, 'ML2_127500');
INSERT INTO art_poisson_mesure VALUES (856, 745606, 280, 'ML2_127503');
INSERT INTO art_poisson_mesure VALUES (857, 745603, 270, 'ML2_127502');
INSERT INTO art_poisson_mesure VALUES (858, 745605, 220, 'ML2_127502');
INSERT INTO art_poisson_mesure VALUES (859, 745604, 250, 'ML2_127502');
INSERT INTO art_poisson_mesure VALUES (860, 745617, 110, 'ML2_127505');
INSERT INTO art_poisson_mesure VALUES (861, 745616, 130, 'ML2_127505');
INSERT INTO art_poisson_mesure VALUES (862, 745615, 110, 'ML2_127505');
INSERT INTO art_poisson_mesure VALUES (863, 745614, 120, 'ML2_127505');
INSERT INTO art_poisson_mesure VALUES (864, 745620, 100, 'ML2_127506');
INSERT INTO art_poisson_mesure VALUES (865, 745619, 250, 'ML2_127506');
INSERT INTO art_poisson_mesure VALUES (866, 745618, 100, 'ML2_127506');
INSERT INTO art_poisson_mesure VALUES (867, 745621, 110, 'ML2_127506');
INSERT INTO art_poisson_mesure VALUES (868, 745637, 170, 'ML2_127507');
INSERT INTO art_poisson_mesure VALUES (869, 745628, 105, 'ML2_127507');
INSERT INTO art_poisson_mesure VALUES (870, 745623, 175, 'ML2_127506');
INSERT INTO art_poisson_mesure VALUES (871, 745622, 210, 'ML2_127506');
INSERT INTO art_poisson_mesure VALUES (872, 745624, 110, 'ML2_127506');
INSERT INTO art_poisson_mesure VALUES (873, 745627, 130, 'ML2_127506');
INSERT INTO art_poisson_mesure VALUES (874, 745626, 190, 'ML2_127506');
INSERT INTO art_poisson_mesure VALUES (875, 745625, 200, 'ML2_127506');
INSERT INTO art_poisson_mesure VALUES (876, 745630, 100, 'ML2_127507');
INSERT INTO art_poisson_mesure VALUES (877, 745629, 160, 'ML2_127507');
INSERT INTO art_poisson_mesure VALUES (878, 745636, 100, 'ML2_127507');
INSERT INTO art_poisson_mesure VALUES (879, 745631, 110, 'ML2_127507');
INSERT INTO art_poisson_mesure VALUES (880, 745635, 150, 'ML2_127507');
INSERT INTO art_poisson_mesure VALUES (881, 745632, 100, 'ML2_127507');
INSERT INTO art_poisson_mesure VALUES (882, 745634, 140, 'ML2_127507');
INSERT INTO art_poisson_mesure VALUES (883, 745633, 150, 'ML2_127507');
INSERT INTO art_poisson_mesure VALUES (884, 745638, 160, 'ML2_127508');
INSERT INTO art_poisson_mesure VALUES (885, 745639, 200, 'ML2_127508');
INSERT INTO art_poisson_mesure VALUES (886, 745644, 195, 'ML2_127508');
INSERT INTO art_poisson_mesure VALUES (887, 745653, 200, 'ML2_127510');
INSERT INTO art_poisson_mesure VALUES (888, 745642, 145, 'ML2_127508');
INSERT INTO art_poisson_mesure VALUES (889, 745643, 170, 'ML2_127508');
INSERT INTO art_poisson_mesure VALUES (890, 745641, 160, 'ML2_127508');
INSERT INTO art_poisson_mesure VALUES (891, 745640, 170, 'ML2_127508');
INSERT INTO art_poisson_mesure VALUES (892, 745647, 140, 'ML2_127508');
INSERT INTO art_poisson_mesure VALUES (893, 745645, 200, 'ML2_127508');
INSERT INTO art_poisson_mesure VALUES (894, 745652, 240, 'ML2_127510');
INSERT INTO art_poisson_mesure VALUES (895, 745646, 220, 'ML2_127508');
INSERT INTO art_poisson_mesure VALUES (896, 745648, 560, 'ML2_127509');
INSERT INTO art_poisson_mesure VALUES (897, 745651, 100, 'ML2_127510');
INSERT INTO art_poisson_mesure VALUES (898, 745650, 130, 'ML2_127510');
INSERT INTO art_poisson_mesure VALUES (899, 745649, 160, 'ML2_127510');
INSERT INTO art_poisson_mesure VALUES (900, 745655, 120, 'ML2_127510');
INSERT INTO art_poisson_mesure VALUES (901, 745654, 120, 'ML2_127510');
INSERT INTO art_poisson_mesure VALUES (902, 745656, 170, 'ML2_127510');
INSERT INTO art_poisson_mesure VALUES (903, 745658, 150, 'ML2_127510');
INSERT INTO art_poisson_mesure VALUES (904, 745657, 150, 'ML2_127510');
INSERT INTO art_poisson_mesure VALUES (905, 745679, 110, 'ML2_127513');
INSERT INTO art_poisson_mesure VALUES (906, 745678, 110, 'ML2_127513');
INSERT INTO art_poisson_mesure VALUES (907, 745680, 135, 'ML2_127513');
INSERT INTO art_poisson_mesure VALUES (908, 745682, 120, 'ML2_127513');
INSERT INTO art_poisson_mesure VALUES (909, 745681, 160, 'ML2_127513');
INSERT INTO art_poisson_mesure VALUES (910, 745677, 125, 'ML2_127513');
INSERT INTO art_poisson_mesure VALUES (911, 745676, 130, 'ML2_127513');
INSERT INTO art_poisson_mesure VALUES (912, 745675, 140, 'ML2_127513');
INSERT INTO art_poisson_mesure VALUES (913, 745671, 90, 'ML2_127512');
INSERT INTO art_poisson_mesure VALUES (914, 745670, 100, 'ML2_127512');
INSERT INTO art_poisson_mesure VALUES (915, 745669, 80, 'ML2_127512');
INSERT INTO art_poisson_mesure VALUES (916, 745660, 220, 'ML2_127511');
INSERT INTO art_poisson_mesure VALUES (917, 745659, 230, 'ML2_127511');
INSERT INTO art_poisson_mesure VALUES (918, 745662, 230, 'ML2_127511');
INSERT INTO art_poisson_mesure VALUES (919, 745668, 95, 'ML2_127512');
INSERT INTO art_poisson_mesure VALUES (920, 745661, 210, 'ML2_127511');
INSERT INTO art_poisson_mesure VALUES (921, 745663, 150, 'ML2_127512');
INSERT INTO art_poisson_mesure VALUES (922, 745667, 100, 'ML2_127512');
INSERT INTO art_poisson_mesure VALUES (923, 745664, 130, 'ML2_127512');
INSERT INTO art_poisson_mesure VALUES (924, 745666, 120, 'ML2_127512');
INSERT INTO art_poisson_mesure VALUES (925, 745665, 130, 'ML2_127512');
INSERT INTO art_poisson_mesure VALUES (926, 745672, 100, 'ML2_127512');
INSERT INTO art_poisson_mesure VALUES (927, 745674, 130, 'ML2_127513');
INSERT INTO art_poisson_mesure VALUES (928, 745673, 100, 'ML2_127513');
INSERT INTO art_poisson_mesure VALUES (929, 745687, 300, 'ML2_127515');
INSERT INTO art_poisson_mesure VALUES (930, 745689, 260, 'ML2_127515');
INSERT INTO art_poisson_mesure VALUES (931, 745686, 250, 'ML2_127515');
INSERT INTO art_poisson_mesure VALUES (932, 745688, 310, 'ML2_127515');
INSERT INTO art_poisson_mesure VALUES (933, 745685, 240, 'ML2_127515');
INSERT INTO art_poisson_mesure VALUES (934, 745684, 280, 'ML2_127515');
INSERT INTO art_poisson_mesure VALUES (935, 745683, 680, 'ML2_127514');
INSERT INTO art_poisson_mesure VALUES (936, 745690, 220, 'ML2_127515');
INSERT INTO art_poisson_mesure VALUES (937, 745693, 270, 'ML2_127515');
INSERT INTO art_poisson_mesure VALUES (938, 745692, 230, 'ML2_127515');
INSERT INTO art_poisson_mesure VALUES (939, 745691, 220, 'ML2_127515');
INSERT INTO art_poisson_mesure VALUES (940, 745698, 175, 'ML2_127516');
INSERT INTO art_poisson_mesure VALUES (941, 745694, 195, 'ML2_127516');
INSERT INTO art_poisson_mesure VALUES (942, 745695, 280, 'ML2_127516');
INSERT INTO art_poisson_mesure VALUES (943, 745697, 185, 'ML2_127516');
INSERT INTO art_poisson_mesure VALUES (944, 745696, 210, 'ML2_127516');
INSERT INTO art_poisson_mesure VALUES (945, 745705, 200, 'ML2_127517');
INSERT INTO art_poisson_mesure VALUES (946, 745701, 230, 'ML2_127516');
INSERT INTO art_poisson_mesure VALUES (947, 745700, 290, 'ML2_127516');
INSERT INTO art_poisson_mesure VALUES (948, 745699, 250, 'ML2_127516');
INSERT INTO art_poisson_mesure VALUES (949, 745702, 220, 'ML2_127516');
INSERT INTO art_poisson_mesure VALUES (950, 745704, 220, 'ML2_127517');
INSERT INTO art_poisson_mesure VALUES (951, 745703, 200, 'ML2_127516');
INSERT INTO art_poisson_mesure VALUES (952, 745707, 230, 'ML2_127517');
INSERT INTO art_poisson_mesure VALUES (953, 745706, 210, 'ML2_127517');
INSERT INTO art_poisson_mesure VALUES (954, 745723, 140, 'ML2_127519');
INSERT INTO art_poisson_mesure VALUES (955, 745722, 120, 'ML2_127519');
INSERT INTO art_poisson_mesure VALUES (956, 745721, 100, 'ML2_127519');
INSERT INTO art_poisson_mesure VALUES (957, 745724, 140, 'ML2_127519');
INSERT INTO art_poisson_mesure VALUES (958, 745720, 110, 'ML2_127519');
INSERT INTO art_poisson_mesure VALUES (959, 745726, 120, 'ML2_127519');
INSERT INTO art_poisson_mesure VALUES (960, 745725, 130, 'ML2_127519');
INSERT INTO art_poisson_mesure VALUES (961, 745727, 110, 'ML2_127519');
INSERT INTO art_poisson_mesure VALUES (962, 745728, 170, 'ML2_127520');
INSERT INTO art_poisson_mesure VALUES (963, 745729, 160, 'ML2_127520');
INSERT INTO art_poisson_mesure VALUES (964, 745719, 205, 'ML2_127519');
INSERT INTO art_poisson_mesure VALUES (965, 745718, 145, 'ML2_127519');
INSERT INTO art_poisson_mesure VALUES (966, 745715, 210, 'ML2_127518');
INSERT INTO art_poisson_mesure VALUES (967, 745730, 250, 'ML2_127520');
INSERT INTO art_poisson_mesure VALUES (968, 745731, 200, 'ML2_127520');
INSERT INTO art_poisson_mesure VALUES (969, 745714, 190, 'ML2_127518');
INSERT INTO art_poisson_mesure VALUES (970, 745708, 150, 'ML2_127518');
INSERT INTO art_poisson_mesure VALUES (971, 745713, 195, 'ML2_127518');
INSERT INTO art_poisson_mesure VALUES (972, 745712, 140, 'ML2_127518');
INSERT INTO art_poisson_mesure VALUES (973, 745709, 185, 'ML2_127518');
INSERT INTO art_poisson_mesure VALUES (974, 745711, 160, 'ML2_127518');
INSERT INTO art_poisson_mesure VALUES (975, 745710, 200, 'ML2_127518');
INSERT INTO art_poisson_mesure VALUES (976, 745732, 180, 'ML2_127520');
INSERT INTO art_poisson_mesure VALUES (977, 745716, 200, 'ML2_127518');
INSERT INTO art_poisson_mesure VALUES (978, 745744, 150, 'ML2_127522');
INSERT INTO art_poisson_mesure VALUES (979, 745735, 160, 'ML2_127520');
INSERT INTO art_poisson_mesure VALUES (980, 745717, 160, 'ML2_127518');
INSERT INTO art_poisson_mesure VALUES (981, 745734, 170, 'ML2_127520');
INSERT INTO art_poisson_mesure VALUES (982, 745733, 180, 'ML2_127520');
INSERT INTO art_poisson_mesure VALUES (983, 745738, 300, 'ML2_127521');
INSERT INTO art_poisson_mesure VALUES (984, 745743, 140, 'ML2_127522');
INSERT INTO art_poisson_mesure VALUES (985, 745737, 150, 'ML2_127520');
INSERT INTO art_poisson_mesure VALUES (986, 745736, 160, 'ML2_127520');
INSERT INTO art_poisson_mesure VALUES (987, 745742, 145, 'ML2_127522');
INSERT INTO art_poisson_mesure VALUES (988, 745739, 290, 'ML2_127521');
INSERT INTO art_poisson_mesure VALUES (989, 745741, 160, 'ML2_127522');
INSERT INTO art_poisson_mesure VALUES (990, 745740, 260, 'ML2_127521');
INSERT INTO art_poisson_mesure VALUES (991, 745748, 150, 'ML2_127522');
INSERT INTO art_poisson_mesure VALUES (992, 745751, 170, 'ML2_127523');
INSERT INTO art_poisson_mesure VALUES (993, 745760, 175, 'ML2_127523');
INSERT INTO art_poisson_mesure VALUES (994, 745747, 140, 'ML2_127522');
INSERT INTO art_poisson_mesure VALUES (995, 745746, 150, 'ML2_127522');
INSERT INTO art_poisson_mesure VALUES (996, 745745, 160, 'ML2_127522');
INSERT INTO art_poisson_mesure VALUES (997, 745750, 170, 'ML2_127522');
INSERT INTO art_poisson_mesure VALUES (998, 745749, 130, 'ML2_127522');
INSERT INTO art_poisson_mesure VALUES (999, 745753, 185, 'ML2_127523');
INSERT INTO art_poisson_mesure VALUES (1000, 745759, 195, 'ML2_127523');
INSERT INTO art_poisson_mesure VALUES (1001, 745754, 160, 'ML2_127523');
INSERT INTO art_poisson_mesure VALUES (1002, 745752, 190, 'ML2_127523');
INSERT INTO art_poisson_mesure VALUES (1003, 745758, 160, 'ML2_127523');
INSERT INTO art_poisson_mesure VALUES (1004, 745755, 170, 'ML2_127523');
INSERT INTO art_poisson_mesure VALUES (1005, 745757, 170, 'ML2_127523');
INSERT INTO art_poisson_mesure VALUES (1006, 745756, 200, 'ML2_127523');
INSERT INTO art_poisson_mesure VALUES (1007, 745814, 170, 'ML2_127535');
INSERT INTO art_poisson_mesure VALUES (1008, 745805, 190, 'ML2_127529');
INSERT INTO art_poisson_mesure VALUES (1009, 745804, 230, 'ML2_127529');
INSERT INTO art_poisson_mesure VALUES (1010, 745802, 200, 'ML2_127529');
INSERT INTO art_poisson_mesure VALUES (1011, 745803, 210, 'ML2_127529');
INSERT INTO art_poisson_mesure VALUES (1012, 745806, 160, 'ML2_127529');
INSERT INTO art_poisson_mesure VALUES (1013, 745813, 190, 'ML2_127534');
INSERT INTO art_poisson_mesure VALUES (1014, 745808, 195, 'ML2_127529');
INSERT INTO art_poisson_mesure VALUES (1015, 745807, 195, 'ML2_127529');
INSERT INTO art_poisson_mesure VALUES (1016, 745809, 175, 'ML2_127530');
INSERT INTO art_poisson_mesure VALUES (1017, 745812, 200, 'ML2_127533');
INSERT INTO art_poisson_mesure VALUES (1018, 745810, 160, 'ML2_127531');
INSERT INTO art_poisson_mesure VALUES (1019, 745811, 170, 'ML2_127532');
INSERT INTO art_poisson_mesure VALUES (1020, 745764, 170, 'ML2_127524');
INSERT INTO art_poisson_mesure VALUES (1021, 745801, 205, 'ML2_127529');
INSERT INTO art_poisson_mesure VALUES (1022, 745763, 160, 'ML2_127524');
INSERT INTO art_poisson_mesure VALUES (1023, 745762, 175, 'ML2_127524');
INSERT INTO art_poisson_mesure VALUES (1024, 745761, 180, 'ML2_127524');
INSERT INTO art_poisson_mesure VALUES (1025, 745800, 210, 'ML2_127529');
INSERT INTO art_poisson_mesure VALUES (1026, 745772, 200, 'ML2_127526');
INSERT INTO art_poisson_mesure VALUES (1027, 745799, 180, 'ML2_127529');
INSERT INTO art_poisson_mesure VALUES (1028, 745798, 130, 'ML2_127528');
INSERT INTO art_poisson_mesure VALUES (1029, 745771, 220, 'ML2_127526');
INSERT INTO art_poisson_mesure VALUES (1030, 745770, 160, 'ML2_127526');
INSERT INTO art_poisson_mesure VALUES (1031, 745765, 130, 'ML2_127524');
INSERT INTO art_poisson_mesure VALUES (1032, 745769, 195, 'ML2_127526');
INSERT INTO art_poisson_mesure VALUES (1033, 745766, 145, 'ML2_127524');
INSERT INTO art_poisson_mesure VALUES (1034, 745768, 250, 'ML2_127525');
INSERT INTO art_poisson_mesure VALUES (1035, 745767, 245, 'ML2_127525');
INSERT INTO art_poisson_mesure VALUES (1036, 745797, 150, 'ML2_127528');
INSERT INTO art_poisson_mesure VALUES (1037, 745777, 175, 'ML2_127526');
INSERT INTO art_poisson_mesure VALUES (1038, 745773, 200, 'ML2_127526');
INSERT INTO art_poisson_mesure VALUES (1039, 745786, 140, 'ML2_127527');
INSERT INTO art_poisson_mesure VALUES (1040, 745776, 180, 'ML2_127526');
INSERT INTO art_poisson_mesure VALUES (1041, 745775, 190, 'ML2_127526');
INSERT INTO art_poisson_mesure VALUES (1042, 745774, 190, 'ML2_127526');
INSERT INTO art_poisson_mesure VALUES (1043, 745785, 120, 'ML2_127527');
INSERT INTO art_poisson_mesure VALUES (1044, 745778, 210, 'ML2_127526');
INSERT INTO art_poisson_mesure VALUES (1045, 745780, 135, 'ML2_127527');
INSERT INTO art_poisson_mesure VALUES (1046, 745779, 120, 'ML2_127527');
INSERT INTO art_poisson_mesure VALUES (1047, 745781, 130, 'ML2_127527');
INSERT INTO art_poisson_mesure VALUES (1048, 745784, 140, 'ML2_127527');
INSERT INTO art_poisson_mesure VALUES (1049, 745783, 150, 'ML2_127527');
INSERT INTO art_poisson_mesure VALUES (1050, 745782, 145, 'ML2_127527');
INSERT INTO art_poisson_mesure VALUES (1051, 745796, 150, 'ML2_127528');
INSERT INTO art_poisson_mesure VALUES (1052, 745792, 130, 'ML2_127528');
INSERT INTO art_poisson_mesure VALUES (1053, 745787, 150, 'ML2_127527');
INSERT INTO art_poisson_mesure VALUES (1054, 745788, 130, 'ML2_127527');
INSERT INTO art_poisson_mesure VALUES (1055, 745791, 110, 'ML2_127528');
INSERT INTO art_poisson_mesure VALUES (1056, 745790, 140, 'ML2_127528');
INSERT INTO art_poisson_mesure VALUES (1057, 745789, 135, 'ML2_127528');
INSERT INTO art_poisson_mesure VALUES (1058, 745795, 140, 'ML2_127528');
INSERT INTO art_poisson_mesure VALUES (1059, 745793, 120, 'ML2_127528');
INSERT INTO art_poisson_mesure VALUES (1060, 745794, 130, 'ML2_127528');
INSERT INTO art_poisson_mesure VALUES (1061, 745815, 220, 'ML2_127536');
INSERT INTO art_poisson_mesure VALUES (1062, 745818, 330, 'ML2_127538');
INSERT INTO art_poisson_mesure VALUES (1063, 745817, 240, 'ML2_127537');
INSERT INTO art_poisson_mesure VALUES (1064, 745816, 240, 'ML2_127536');
INSERT INTO art_poisson_mesure VALUES (1065, 745819, 370, 'ML2_127539');
INSERT INTO art_poisson_mesure VALUES (1066, 745827, 170, 'ML2_127541');
INSERT INTO art_poisson_mesure VALUES (1067, 745875, 190, 'ML2_127547');
INSERT INTO art_poisson_mesure VALUES (1068, 745874, 180, 'ML2_127547');
INSERT INTO art_poisson_mesure VALUES (1069, 745826, 340, 'ML2_127541');
INSERT INTO art_poisson_mesure VALUES (1070, 745873, 175, 'ML2_127547');
INSERT INTO art_poisson_mesure VALUES (1071, 745825, 185, 'ML2_127541');
INSERT INTO art_poisson_mesure VALUES (1072, 745872, 145, 'ML2_127547');
INSERT INTO art_poisson_mesure VALUES (1073, 745828, 200, 'ML2_127541');
INSERT INTO art_poisson_mesure VALUES (1074, 745824, 170, 'ML2_127541');
INSERT INTO art_poisson_mesure VALUES (1075, 745871, 160, 'ML2_127546');
INSERT INTO art_poisson_mesure VALUES (1076, 745870, 185, 'ML2_127546');
INSERT INTO art_poisson_mesure VALUES (1077, 745869, 170, 'ML2_127546');
INSERT INTO art_poisson_mesure VALUES (1078, 745823, 160, 'ML2_127541');
INSERT INTO art_poisson_mesure VALUES (1079, 745822, 150, 'ML2_127541');
INSERT INTO art_poisson_mesure VALUES (1080, 745868, 155, 'ML2_127546');
INSERT INTO art_poisson_mesure VALUES (1081, 745821, 145, 'ML2_127541');
INSERT INTO art_poisson_mesure VALUES (1082, 745820, 300, 'ML2_127540');
INSERT INTO art_poisson_mesure VALUES (1083, 745867, 270, 'ML2_127546');
INSERT INTO art_poisson_mesure VALUES (1084, 745865, 150, 'ML2_127546');
INSERT INTO art_poisson_mesure VALUES (1085, 745836, 140, 'ML2_127542');
INSERT INTO art_poisson_mesure VALUES (1086, 745864, 160, 'ML2_127546');
INSERT INTO art_poisson_mesure VALUES (1087, 745835, 110, 'ML2_127542');
INSERT INTO art_poisson_mesure VALUES (1088, 745834, 150, 'ML2_127542');
INSERT INTO art_poisson_mesure VALUES (1089, 745833, 140, 'ML2_127542');
INSERT INTO art_poisson_mesure VALUES (1090, 745829, 250, 'ML2_127541');
INSERT INTO art_poisson_mesure VALUES (1091, 745832, 125, 'ML2_127542');
INSERT INTO art_poisson_mesure VALUES (1092, 745831, 160, 'ML2_127542');
INSERT INTO art_poisson_mesure VALUES (1093, 745830, 190, 'ML2_127541');
INSERT INTO art_poisson_mesure VALUES (1094, 745866, 160, 'ML2_127546');
INSERT INTO art_poisson_mesure VALUES (1095, 745838, 130, 'ML2_127542');
INSERT INTO art_poisson_mesure VALUES (1096, 745862, 230, 'ML2_127545');
INSERT INTO art_poisson_mesure VALUES (1097, 745863, 270, 'ML2_127545');
INSERT INTO art_poisson_mesure VALUES (1098, 745845, 170, 'ML2_127543');
INSERT INTO art_poisson_mesure VALUES (1099, 745837, 120, 'ML2_127542');
INSERT INTO art_poisson_mesure VALUES (1100, 745839, 130, 'ML2_127542');
INSERT INTO art_poisson_mesure VALUES (1101, 745844, 180, 'ML2_127543');
INSERT INTO art_poisson_mesure VALUES (1102, 745843, 150, 'ML2_127543');
INSERT INTO art_poisson_mesure VALUES (1103, 745840, 140, 'ML2_127542');
INSERT INTO art_poisson_mesure VALUES (1104, 745841, 145, 'ML2_127543');
INSERT INTO art_poisson_mesure VALUES (1105, 745842, 160, 'ML2_127543');
INSERT INTO art_poisson_mesure VALUES (1106, 745852, 320, 'ML2_127544');
INSERT INTO art_poisson_mesure VALUES (1107, 745847, 145, 'ML2_127543');
INSERT INTO art_poisson_mesure VALUES (1108, 745861, 200, 'ML2_127545');
INSERT INTO art_poisson_mesure VALUES (1109, 745846, 160, 'ML2_127543');
INSERT INTO art_poisson_mesure VALUES (1110, 745851, 320, 'ML2_127544');
INSERT INTO art_poisson_mesure VALUES (1111, 745848, 150, 'ML2_127543');
INSERT INTO art_poisson_mesure VALUES (1112, 745850, 150, 'ML2_127543');
INSERT INTO art_poisson_mesure VALUES (1113, 745849, 160, 'ML2_127543');
INSERT INTO art_poisson_mesure VALUES (1114, 745855, 220, 'ML2_127545');
INSERT INTO art_poisson_mesure VALUES (1115, 745860, 190, 'ML2_127545');
INSERT INTO art_poisson_mesure VALUES (1116, 745853, 270, 'ML2_127544');
INSERT INTO art_poisson_mesure VALUES (1117, 745854, 230, 'ML2_127545');
INSERT INTO art_poisson_mesure VALUES (1118, 745856, 215, 'ML2_127545');
INSERT INTO art_poisson_mesure VALUES (1119, 745859, 195, 'ML2_127545');
INSERT INTO art_poisson_mesure VALUES (1120, 745858, 200, 'ML2_127545');
INSERT INTO art_poisson_mesure VALUES (1121, 745857, 210, 'ML2_127545');
INSERT INTO art_poisson_mesure VALUES (1122, 745878, 130, 'ML2_127547');
INSERT INTO art_poisson_mesure VALUES (1123, 745877, 140, 'ML2_127547');
INSERT INTO art_poisson_mesure VALUES (1124, 745876, 230, 'ML2_127547');
INSERT INTO art_poisson_mesure VALUES (1125, 745881, 170, 'ML2_127547');
INSERT INTO art_poisson_mesure VALUES (1126, 745880, 160, 'ML2_127547');
INSERT INTO art_poisson_mesure VALUES (1127, 745879, 130, 'ML2_127547');
INSERT INTO art_poisson_mesure VALUES (1128, 745918, 150, 'ML2_127553');
INSERT INTO art_poisson_mesure VALUES (1129, 745895, 110, 'ML2_127550');
INSERT INTO art_poisson_mesure VALUES (1130, 745896, 130, 'ML2_127550');
INSERT INTO art_poisson_mesure VALUES (1131, 745917, 160, 'ML2_127553');
INSERT INTO art_poisson_mesure VALUES (1132, 745899, 140, 'ML2_127550');
INSERT INTO art_poisson_mesure VALUES (1133, 745916, 160, 'ML2_127553');
INSERT INTO art_poisson_mesure VALUES (1134, 745898, 120, 'ML2_127550');
INSERT INTO art_poisson_mesure VALUES (1135, 745897, 100, 'ML2_127550');
INSERT INTO art_poisson_mesure VALUES (1136, 745901, 150, 'ML2_127550');
INSERT INTO art_poisson_mesure VALUES (1137, 745915, 160, 'ML2_127553');
INSERT INTO art_poisson_mesure VALUES (1138, 745906, 140, 'ML2_127552');
INSERT INTO art_poisson_mesure VALUES (1139, 745900, 160, 'ML2_127550');
INSERT INTO art_poisson_mesure VALUES (1140, 745902, 130, 'ML2_127550');
INSERT INTO art_poisson_mesure VALUES (1141, 745905, 150, 'ML2_127552');
INSERT INTO art_poisson_mesure VALUES (1142, 745903, 320, 'ML2_127551');
INSERT INTO art_poisson_mesure VALUES (1143, 745904, 290, 'ML2_127551');
INSERT INTO art_poisson_mesure VALUES (1144, 745909, 150, 'ML2_127552');
INSERT INTO art_poisson_mesure VALUES (1145, 745914, 160, 'ML2_127552');
INSERT INTO art_poisson_mesure VALUES (1146, 745907, 170, 'ML2_127552');
INSERT INTO art_poisson_mesure VALUES (1147, 745908, 180, 'ML2_127552');
INSERT INTO art_poisson_mesure VALUES (1148, 745913, 160, 'ML2_127552');
INSERT INTO art_poisson_mesure VALUES (1149, 745910, 155, 'ML2_127552');
INSERT INTO art_poisson_mesure VALUES (1150, 745912, 160, 'ML2_127552');
INSERT INTO art_poisson_mesure VALUES (1151, 745911, 160, 'ML2_127552');
INSERT INTO art_poisson_mesure VALUES (1152, 745946, 135, 'ML2_127557');
INSERT INTO art_poisson_mesure VALUES (1153, 745923, 160, 'ML2_127553');
INSERT INTO art_poisson_mesure VALUES (1154, 745922, 155, 'ML2_127553');
INSERT INTO art_poisson_mesure VALUES (1155, 745921, 180, 'ML2_127553');
INSERT INTO art_poisson_mesure VALUES (1156, 745956, 285, 'ML2_127558');
INSERT INTO art_poisson_mesure VALUES (1157, 745919, 160, 'ML2_127553');
INSERT INTO art_poisson_mesure VALUES (1158, 745920, 170, 'ML2_127553');
INSERT INTO art_poisson_mesure VALUES (1159, 745936, 160, 'ML2_127556');
INSERT INTO art_poisson_mesure VALUES (1160, 745945, 150, 'ML2_127556');
INSERT INTO art_poisson_mesure VALUES (1161, 745933, 160, 'ML2_127555');
INSERT INTO art_poisson_mesure VALUES (1162, 745935, 170, 'ML2_127555');
INSERT INTO art_poisson_mesure VALUES (1163, 745932, 160, 'ML2_127555');
INSERT INTO art_poisson_mesure VALUES (1164, 745930, 140, 'ML2_127555');
INSERT INTO art_poisson_mesure VALUES (1165, 745931, 150, 'ML2_127555');
INSERT INTO art_poisson_mesure VALUES (1166, 745934, 150, 'ML2_127555');
INSERT INTO art_poisson_mesure VALUES (1167, 745939, 175, 'ML2_127556');
INSERT INTO art_poisson_mesure VALUES (1168, 745944, 175, 'ML2_127556');
INSERT INTO art_poisson_mesure VALUES (1169, 745938, 180, 'ML2_127556');
INSERT INTO art_poisson_mesure VALUES (1170, 745937, 150, 'ML2_127556');
INSERT INTO art_poisson_mesure VALUES (1171, 745943, 170, 'ML2_127556');
INSERT INTO art_poisson_mesure VALUES (1172, 745940, 160, 'ML2_127556');
INSERT INTO art_poisson_mesure VALUES (1173, 745942, 170, 'ML2_127556');
INSERT INTO art_poisson_mesure VALUES (1174, 745941, 175, 'ML2_127556');
INSERT INTO art_poisson_mesure VALUES (1175, 745955, 150, 'ML2_127557');
INSERT INTO art_poisson_mesure VALUES (1176, 745948, 140, 'ML2_127557');
INSERT INTO art_poisson_mesure VALUES (1177, 745954, 130, 'ML2_127557');
INSERT INTO art_poisson_mesure VALUES (1178, 745947, 140, 'ML2_127557');
INSERT INTO art_poisson_mesure VALUES (1179, 745950, 145, 'ML2_127557');
INSERT INTO art_poisson_mesure VALUES (1180, 745949, 130, 'ML2_127557');
INSERT INTO art_poisson_mesure VALUES (1181, 745953, 140, 'ML2_127557');
INSERT INTO art_poisson_mesure VALUES (1182, 745952, 155, 'ML2_127557');
INSERT INTO art_poisson_mesure VALUES (1183, 745951, 150, 'ML2_127557');
INSERT INTO art_poisson_mesure VALUES (1184, 745929, 170, 'ML2_127555');
INSERT INTO art_poisson_mesure VALUES (1185, 745894, 165, 'ML2_127550');
INSERT INTO art_poisson_mesure VALUES (1186, 745892, 160, 'ML2_127549');
INSERT INTO art_poisson_mesure VALUES (1187, 745928, 170, 'ML2_127555');
INSERT INTO art_poisson_mesure VALUES (1188, 745927, 165, 'ML2_127555');
INSERT INTO art_poisson_mesure VALUES (1189, 745893, 170, 'ML2_127550');
INSERT INTO art_poisson_mesure VALUES (1190, 745891, 285, 'ML2_127549');
INSERT INTO art_poisson_mesure VALUES (1191, 745926, 160, 'ML2_127555');
INSERT INTO art_poisson_mesure VALUES (1192, 745890, 195, 'ML2_127549');
INSERT INTO art_poisson_mesure VALUES (1193, 745887, 140, 'ML2_127549');
INSERT INTO art_poisson_mesure VALUES (1194, 745925, 280, 'ML2_127554');
INSERT INTO art_poisson_mesure VALUES (1195, 745886, 110, 'ML2_127549');
INSERT INTO art_poisson_mesure VALUES (1196, 745885, 120, 'ML2_127549');
INSERT INTO art_poisson_mesure VALUES (1197, 745882, 300, 'ML2_127548');
INSERT INTO art_poisson_mesure VALUES (1198, 745884, 165, 'ML2_127549');
INSERT INTO art_poisson_mesure VALUES (1199, 745883, 155, 'ML2_127549');
INSERT INTO art_poisson_mesure VALUES (1200, 745924, 170, 'ML2_127553');
INSERT INTO art_poisson_mesure VALUES (1201, 745888, 150, 'ML2_127549');
INSERT INTO art_poisson_mesure VALUES (1202, 745889, 160, 'ML2_127549');
INSERT INTO art_poisson_mesure VALUES (1203, 745959, 290, 'ML2_127561');
INSERT INTO art_poisson_mesure VALUES (1204, 745961, 290, 'ML2_127561');
INSERT INTO art_poisson_mesure VALUES (1205, 745960, 300, 'ML2_127561');
INSERT INTO art_poisson_mesure VALUES (1206, 745958, 320, 'ML2_127560');
INSERT INTO art_poisson_mesure VALUES (1207, 745965, 300, 'ML2_127561');
INSERT INTO art_poisson_mesure VALUES (1208, 745964, 195, 'ML2_127561');
INSERT INTO art_poisson_mesure VALUES (1209, 745963, 220, 'ML2_127561');
INSERT INTO art_poisson_mesure VALUES (1210, 745962, 230, 'ML2_127561');
INSERT INTO art_poisson_mesure VALUES (1211, 745957, 620, 'ML2_127559');
INSERT INTO art_poisson_mesure VALUES (1212, 745967, 280, 'ML2_127561');
INSERT INTO art_poisson_mesure VALUES (1213, 745966, 350, 'ML2_127561');
INSERT INTO art_poisson_mesure VALUES (1214, 745968, 320, 'ML2_127561');
INSERT INTO art_poisson_mesure VALUES (1215, 751867, 120, 'ML2_128626');
INSERT INTO art_poisson_mesure VALUES (1216, 751841, 140, 'ML2_128623');
INSERT INTO art_poisson_mesure VALUES (1217, 751842, 150, 'ML2_128623');
INSERT INTO art_poisson_mesure VALUES (1218, 751865, 125, 'ML2_128626');
INSERT INTO art_poisson_mesure VALUES (1219, 751868, 120, 'ML2_128626');
INSERT INTO art_poisson_mesure VALUES (1220, 751866, 130, 'ML2_128626');
INSERT INTO art_poisson_mesure VALUES (1221, 751843, 150, 'ML2_128623');
INSERT INTO art_poisson_mesure VALUES (1222, 751844, 140, 'ML2_128624');
INSERT INTO art_poisson_mesure VALUES (1223, 751864, 150, 'ML2_128626');
INSERT INTO art_poisson_mesure VALUES (1224, 751840, 145, 'ML2_128623');
INSERT INTO art_poisson_mesure VALUES (1225, 751832, 230, 'ML2_128622');
INSERT INTO art_poisson_mesure VALUES (1226, 751831, 220, 'ML2_128622');
INSERT INTO art_poisson_mesure VALUES (1227, 751830, 195, 'ML2_128622');
INSERT INTO art_poisson_mesure VALUES (1228, 751829, 185, 'ML2_128622');
INSERT INTO art_poisson_mesure VALUES (1229, 751838, 130, 'ML2_128623');
INSERT INTO art_poisson_mesure VALUES (1230, 751863, 150, 'ML2_128625');
INSERT INTO art_poisson_mesure VALUES (1231, 751839, 160, 'ML2_128623');
INSERT INTO art_poisson_mesure VALUES (1232, 751834, 155, 'ML2_128623');
INSERT INTO art_poisson_mesure VALUES (1233, 751833, 175, 'ML2_128622');
INSERT INTO art_poisson_mesure VALUES (1234, 751837, 140, 'ML2_128623');
INSERT INTO art_poisson_mesure VALUES (1235, 751835, 170, 'ML2_128623');
INSERT INTO art_poisson_mesure VALUES (1236, 751836, 150, 'ML2_128623');
INSERT INTO art_poisson_mesure VALUES (1237, 751862, 150, 'ML2_128625');
INSERT INTO art_poisson_mesure VALUES (1238, 751857, 75, 'ML2_128625');
INSERT INTO art_poisson_mesure VALUES (1239, 751856, 100, 'ML2_128625');
INSERT INTO art_poisson_mesure VALUES (1240, 751855, 130, 'ML2_128625');
INSERT INTO art_poisson_mesure VALUES (1241, 751861, 90, 'ML2_128625');
INSERT INTO art_poisson_mesure VALUES (1242, 751858, 80, 'ML2_128625');
INSERT INTO art_poisson_mesure VALUES (1243, 751860, 100, 'ML2_128625');
INSERT INTO art_poisson_mesure VALUES (1244, 751859, 115, 'ML2_128625');
INSERT INTO art_poisson_mesure VALUES (1245, 751854, 110, 'ML2_128625');
INSERT INTO art_poisson_mesure VALUES (1246, 751828, 150, 'ML2_128622');
INSERT INTO art_poisson_mesure VALUES (1247, 751845, 155, 'ML2_128624');
INSERT INTO art_poisson_mesure VALUES (1248, 751852, 120, 'ML2_128624');
INSERT INTO art_poisson_mesure VALUES (1249, 751827, 210, 'ML2_128622');
INSERT INTO art_poisson_mesure VALUES (1250, 751853, 130, 'ML2_128624');
INSERT INTO art_poisson_mesure VALUES (1251, 751846, 155, 'ML2_128624');
INSERT INTO art_poisson_mesure VALUES (1252, 751873, 110, 'ML2_128626');
INSERT INTO art_poisson_mesure VALUES (1253, 751851, 135, 'ML2_128624');
INSERT INTO art_poisson_mesure VALUES (1254, 751850, 125, 'ML2_128624');
INSERT INTO art_poisson_mesure VALUES (1255, 751847, 160, 'ML2_128624');
INSERT INTO art_poisson_mesure VALUES (1256, 751849, 145, 'ML2_128624');
INSERT INTO art_poisson_mesure VALUES (1257, 751848, 150, 'ML2_128624');
INSERT INTO art_poisson_mesure VALUES (1258, 751869, 160, 'ML2_128626');
INSERT INTO art_poisson_mesure VALUES (1259, 751870, 145, 'ML2_128626');
INSERT INTO art_poisson_mesure VALUES (1260, 751872, 125, 'ML2_128626');
INSERT INTO art_poisson_mesure VALUES (1261, 751871, 135, 'ML2_128626');
INSERT INTO art_poisson_mesure VALUES (1262, 751815, 215, 'ML2_128620');
INSERT INTO art_poisson_mesure VALUES (1263, 751826, 140, 'ML2_128622');
INSERT INTO art_poisson_mesure VALUES (1264, 751814, 195, 'ML2_128620');
INSERT INTO art_poisson_mesure VALUES (1265, 751813, 250, 'ML2_128620');
INSERT INTO art_poisson_mesure VALUES (1266, 751820, 250, 'ML2_128620');
INSERT INTO art_poisson_mesure VALUES (1267, 751816, 220, 'ML2_128620');
INSERT INTO art_poisson_mesure VALUES (1268, 751825, 130, 'ML2_128622');
INSERT INTO art_poisson_mesure VALUES (1269, 751819, 270, 'ML2_128620');
INSERT INTO art_poisson_mesure VALUES (1270, 751818, 230, 'ML2_128620');
INSERT INTO art_poisson_mesure VALUES (1271, 751817, 270, 'ML2_128620');
INSERT INTO art_poisson_mesure VALUES (1272, 751824, 160, 'ML2_128622');
INSERT INTO art_poisson_mesure VALUES (1273, 751822, 210, 'ML2_128620');
INSERT INTO art_poisson_mesure VALUES (1274, 751821, 220, 'ML2_128620');
INSERT INTO art_poisson_mesure VALUES (1275, 751823, 340, 'ML2_128621');
INSERT INTO art_poisson_mesure VALUES (1276, 751916, 110, 'ML2_128632');
INSERT INTO art_poisson_mesure VALUES (1277, 751922, 100, 'ML2_128632');
INSERT INTO art_poisson_mesure VALUES (1278, 751915, 120, 'ML2_128631');
INSERT INTO art_poisson_mesure VALUES (1279, 751921, 170, 'ML2_128632');
INSERT INTO art_poisson_mesure VALUES (1280, 751923, 85, 'ML2_128632');
INSERT INTO art_poisson_mesure VALUES (1281, 751889, 230, 'ML2_128628');
INSERT INTO art_poisson_mesure VALUES (1282, 751890, 340, 'ML2_128628');
INSERT INTO art_poisson_mesure VALUES (1283, 751920, 150, 'ML2_128632');
INSERT INTO art_poisson_mesure VALUES (1284, 751888, 185, 'ML2_128628');
INSERT INTO art_poisson_mesure VALUES (1285, 751914, 110, 'ML2_128631');
INSERT INTO art_poisson_mesure VALUES (1286, 751905, 410, 'ML2_128630');
INSERT INTO art_poisson_mesure VALUES (1287, 751892, 340, 'ML2_128628');
INSERT INTO art_poisson_mesure VALUES (1288, 751891, 355, 'ML2_128628');
INSERT INTO art_poisson_mesure VALUES (1289, 751904, 400, 'ML2_128630');
INSERT INTO art_poisson_mesure VALUES (1290, 751919, 180, 'ML2_128632');
INSERT INTO art_poisson_mesure VALUES (1291, 751897, 330, 'ML2_128629');
INSERT INTO art_poisson_mesure VALUES (1292, 751893, 195, 'ML2_128628');
INSERT INTO art_poisson_mesure VALUES (1293, 751894, 310, 'ML2_128629');
INSERT INTO art_poisson_mesure VALUES (1294, 751896, 360, 'ML2_128629');
INSERT INTO art_poisson_mesure VALUES (1295, 751895, 315, 'ML2_128629');
INSERT INTO art_poisson_mesure VALUES (1296, 751903, 375, 'ML2_128630');
INSERT INTO art_poisson_mesure VALUES (1297, 751899, 320, 'ML2_128629');
INSERT INTO art_poisson_mesure VALUES (1298, 751898, 330, 'ML2_128629');
INSERT INTO art_poisson_mesure VALUES (1299, 751918, 110, 'ML2_128632');
INSERT INTO art_poisson_mesure VALUES (1300, 751900, 340, 'ML2_128629');
INSERT INTO art_poisson_mesure VALUES (1301, 751902, 390, 'ML2_128630');
INSERT INTO art_poisson_mesure VALUES (1302, 751917, 120, 'ML2_128632');
INSERT INTO art_poisson_mesure VALUES (1303, 751901, 300, 'ML2_128629');
INSERT INTO art_poisson_mesure VALUES (1304, 751924, 90, 'ML2_128632');
INSERT INTO art_poisson_mesure VALUES (1305, 751925, 150, 'ML2_128632');
INSERT INTO art_poisson_mesure VALUES (1306, 751887, 195, 'ML2_128628');
INSERT INTO art_poisson_mesure VALUES (1307, 751913, 210, 'ML2_128631');
INSERT INTO art_poisson_mesure VALUES (1308, 751912, 250, 'ML2_128631');
INSERT INTO art_poisson_mesure VALUES (1309, 751874, 297, 'ML2_128627');
INSERT INTO art_poisson_mesure VALUES (1310, 751880, 340, 'ML2_128627');
INSERT INTO art_poisson_mesure VALUES (1311, 751886, 200, 'ML2_128628');
INSERT INTO art_poisson_mesure VALUES (1312, 751879, 343, 'ML2_128627');
INSERT INTO art_poisson_mesure VALUES (1313, 751878, 255, 'ML2_128627');
INSERT INTO art_poisson_mesure VALUES (1314, 751877, 220, 'ML2_128627');
INSERT INTO art_poisson_mesure VALUES (1315, 751876, 230, 'ML2_128627');
INSERT INTO art_poisson_mesure VALUES (1316, 751875, 240, 'ML2_128627');
INSERT INTO art_poisson_mesure VALUES (1317, 751911, 190, 'ML2_128631');
INSERT INTO art_poisson_mesure VALUES (1318, 751884, 220, 'ML2_128628');
INSERT INTO art_poisson_mesure VALUES (1319, 751885, 210, 'ML2_128628');
INSERT INTO art_poisson_mesure VALUES (1320, 751883, 280, 'ML2_128627');
INSERT INTO art_poisson_mesure VALUES (1321, 751882, 370, 'ML2_128627');
INSERT INTO art_poisson_mesure VALUES (1322, 751881, 335, 'ML2_128627');
INSERT INTO art_poisson_mesure VALUES (1323, 751910, 185, 'ML2_128631');
INSERT INTO art_poisson_mesure VALUES (1324, 751906, 110, 'ML2_128631');
INSERT INTO art_poisson_mesure VALUES (1325, 751908, 130, 'ML2_128631');
INSERT INTO art_poisson_mesure VALUES (1326, 751907, 115, 'ML2_128631');
INSERT INTO art_poisson_mesure VALUES (1327, 751909, 122, 'ML2_128631');
INSERT INTO art_poisson_mesure VALUES (1328, 751931, 355, 'ML2_128633');
INSERT INTO art_poisson_mesure VALUES (1329, 751926, 230, 'ML2_128633');
INSERT INTO art_poisson_mesure VALUES (1330, 751930, 250, 'ML2_128633');
INSERT INTO art_poisson_mesure VALUES (1331, 751929, 235, 'ML2_128633');
INSERT INTO art_poisson_mesure VALUES (1332, 751928, 270, 'ML2_128633');
INSERT INTO art_poisson_mesure VALUES (1333, 751927, 260, 'ML2_128633');
INSERT INTO art_poisson_mesure VALUES (1334, 751936, 220, 'ML2_128634');
INSERT INTO art_poisson_mesure VALUES (1335, 751945, 175, 'ML2_128634');
INSERT INTO art_poisson_mesure VALUES (1336, 751935, 310, 'ML2_128633');
INSERT INTO art_poisson_mesure VALUES (1337, 751932, 340, 'ML2_128633');
INSERT INTO art_poisson_mesure VALUES (1338, 751934, 330, 'ML2_128633');
INSERT INTO art_poisson_mesure VALUES (1339, 751933, 325, 'ML2_128633');
INSERT INTO art_poisson_mesure VALUES (1340, 751944, 260, 'ML2_128634');
INSERT INTO art_poisson_mesure VALUES (1341, 751939, 250, 'ML2_128634');
INSERT INTO art_poisson_mesure VALUES (1342, 751938, 160, 'ML2_128634');
INSERT INTO art_poisson_mesure VALUES (1343, 751937, 160, 'ML2_128634');
INSERT INTO art_poisson_mesure VALUES (1344, 751943, 240, 'ML2_128634');
INSERT INTO art_poisson_mesure VALUES (1345, 751940, 190, 'ML2_128634');
INSERT INTO art_poisson_mesure VALUES (1346, 751942, 250, 'ML2_128634');
INSERT INTO art_poisson_mesure VALUES (1347, 751941, 260, 'ML2_128634');
INSERT INTO art_poisson_mesure VALUES (1348, 751947, 350, 'ML2_128635');
INSERT INTO art_poisson_mesure VALUES (1349, 751946, 390, 'ML2_128635');
INSERT INTO art_poisson_mesure VALUES (1350, 751950, 400, 'ML2_128636');
INSERT INTO art_poisson_mesure VALUES (1351, 751948, 350, 'ML2_128636');
INSERT INTO art_poisson_mesure VALUES (1352, 751949, 365, 'ML2_128636');
INSERT INTO art_poisson_mesure VALUES (1353, 751965, 375, 'ML2_128639');
INSERT INTO art_poisson_mesure VALUES (1354, 751974, 185, 'ML2_128640');
INSERT INTO art_poisson_mesure VALUES (1355, 751964, 340, 'ML2_128638');
INSERT INTO art_poisson_mesure VALUES (1356, 751960, 275, 'ML2_128638');
INSERT INTO art_poisson_mesure VALUES (1357, 751962, 250, 'ML2_128638');
INSERT INTO art_poisson_mesure VALUES (1358, 751963, 230, 'ML2_128638');
INSERT INTO art_poisson_mesure VALUES (1359, 751961, 260, 'ML2_128638');
INSERT INTO art_poisson_mesure VALUES (1360, 751992, 195, 'ML2_128642');
INSERT INTO art_poisson_mesure VALUES (1361, 752002, 210, 'ML2_128643');
INSERT INTO art_poisson_mesure VALUES (1362, 751991, 230, 'ML2_128642');
INSERT INTO art_poisson_mesure VALUES (1363, 751993, 173, 'ML2_128642');
INSERT INTO art_poisson_mesure VALUES (1364, 752003, 220, 'ML2_128643');
INSERT INTO art_poisson_mesure VALUES (1365, 752001, 190, 'ML2_128643');
INSERT INTO art_poisson_mesure VALUES (1366, 751997, 130, 'ML2_128643');
INSERT INTO art_poisson_mesure VALUES (1367, 751995, 205, 'ML2_128642');
INSERT INTO art_poisson_mesure VALUES (1368, 751994, 210, 'ML2_128642');
INSERT INTO art_poisson_mesure VALUES (1369, 752000, 140, 'ML2_128643');
INSERT INTO art_poisson_mesure VALUES (1370, 751996, 195, 'ML2_128643');
INSERT INTO art_poisson_mesure VALUES (1371, 751998, 135, 'ML2_128643');
INSERT INTO art_poisson_mesure VALUES (1372, 751999, 150, 'ML2_128643');
INSERT INTO art_poisson_mesure VALUES (1373, 751973, 210, 'ML2_128640');
INSERT INTO art_poisson_mesure VALUES (1374, 751959, 300, 'ML2_128638');
INSERT INTO art_poisson_mesure VALUES (1375, 751958, 315, 'ML2_128638');
INSERT INTO art_poisson_mesure VALUES (1376, 751972, 270, 'ML2_128640');
INSERT INTO art_poisson_mesure VALUES (1377, 751971, 200, 'ML2_128640');
INSERT INTO art_poisson_mesure VALUES (1378, 751957, 315, 'ML2_128638');
INSERT INTO art_poisson_mesure VALUES (1379, 751951, 370, 'ML2_128637');
INSERT INTO art_poisson_mesure VALUES (1380, 751956, 320, 'ML2_128638');
INSERT INTO art_poisson_mesure VALUES (1381, 751970, 175, 'ML2_128640');
INSERT INTO art_poisson_mesure VALUES (1382, 751952, 420, 'ML2_128637');
INSERT INTO art_poisson_mesure VALUES (1383, 751953, 400, 'ML2_128637');
INSERT INTO art_poisson_mesure VALUES (1384, 751955, 333, 'ML2_128638');
INSERT INTO art_poisson_mesure VALUES (1385, 751969, 205, 'ML2_128640');
INSERT INTO art_poisson_mesure VALUES (1386, 751968, 235, 'ML2_128640');
INSERT INTO art_poisson_mesure VALUES (1387, 751954, 395, 'ML2_128637');
INSERT INTO art_poisson_mesure VALUES (1388, 751967, 335, 'ML2_128639');
INSERT INTO art_poisson_mesure VALUES (1389, 751966, 380, 'ML2_128639');
INSERT INTO art_poisson_mesure VALUES (1390, 751983, 175, 'ML2_128641');
INSERT INTO art_poisson_mesure VALUES (1391, 752006, 360, 'ML2_128644');
INSERT INTO art_poisson_mesure VALUES (1392, 751984, 160, 'ML2_128641');
INSERT INTO art_poisson_mesure VALUES (1393, 752005, 180, 'ML2_128643');
INSERT INTO art_poisson_mesure VALUES (1394, 751982, 185, 'ML2_128641');
INSERT INTO art_poisson_mesure VALUES (1395, 751976, 190, 'ML2_128640');
INSERT INTO art_poisson_mesure VALUES (1396, 751975, 140, 'ML2_128640');
INSERT INTO art_poisson_mesure VALUES (1397, 752004, 210, 'ML2_128643');
INSERT INTO art_poisson_mesure VALUES (1398, 751978, 170, 'ML2_128641');
INSERT INTO art_poisson_mesure VALUES (1399, 751981, 140, 'ML2_128641');
INSERT INTO art_poisson_mesure VALUES (1400, 751977, 225, 'ML2_128640');
INSERT INTO art_poisson_mesure VALUES (1401, 751980, 145, 'ML2_128641');
INSERT INTO art_poisson_mesure VALUES (1402, 751990, 175, 'ML2_128642');
INSERT INTO art_poisson_mesure VALUES (1403, 751985, 150, 'ML2_128641');
INSERT INTO art_poisson_mesure VALUES (1404, 751979, 150, 'ML2_128641');
INSERT INTO art_poisson_mesure VALUES (1405, 752008, 305, 'ML2_128644');
INSERT INTO art_poisson_mesure VALUES (1406, 752007, 332, 'ML2_128644');
INSERT INTO art_poisson_mesure VALUES (1407, 751989, 185, 'ML2_128642');
INSERT INTO art_poisson_mesure VALUES (1408, 751987, 180, 'ML2_128641');
INSERT INTO art_poisson_mesure VALUES (1409, 751988, 164, 'ML2_128642');
INSERT INTO art_poisson_mesure VALUES (1410, 751986, 140, 'ML2_128641');
INSERT INTO art_poisson_mesure VALUES (1411, 752022, 170, 'ML2_128646');
INSERT INTO art_poisson_mesure VALUES (1412, 752020, 215, 'ML2_128646');
INSERT INTO art_poisson_mesure VALUES (1413, 752011, 330, 'ML2_128645');
INSERT INTO art_poisson_mesure VALUES (1414, 752021, 220, 'ML2_128646');
INSERT INTO art_poisson_mesure VALUES (1415, 752010, 310, 'ML2_128645');
INSERT INTO art_poisson_mesure VALUES (1416, 752009, 320, 'ML2_128645');
INSERT INTO art_poisson_mesure VALUES (1417, 752019, 210, 'ML2_128646');
INSERT INTO art_poisson_mesure VALUES (1418, 752014, 315, 'ML2_128645');
INSERT INTO art_poisson_mesure VALUES (1419, 752012, 300, 'ML2_128645');
INSERT INTO art_poisson_mesure VALUES (1420, 752013, 395, 'ML2_128645');
INSERT INTO art_poisson_mesure VALUES (1421, 752018, 195, 'ML2_128646');
INSERT INTO art_poisson_mesure VALUES (1422, 752015, 230, 'ML2_128646');
INSERT INTO art_poisson_mesure VALUES (1423, 752017, 185, 'ML2_128646');
INSERT INTO art_poisson_mesure VALUES (1424, 752016, 195, 'ML2_128646');
INSERT INTO art_poisson_mesure VALUES (1425, 752023, 185, 'ML2_128646');
INSERT INTO art_poisson_mesure VALUES (1426, 752024, 200, 'ML2_128646');
INSERT INTO art_poisson_mesure VALUES (1427, 752047, 300, 'ML2_128651');
INSERT INTO art_poisson_mesure VALUES (1428, 752046, 355, 'ML2_128651');
INSERT INTO art_poisson_mesure VALUES (1429, 752045, 240, 'ML2_128650');
INSERT INTO art_poisson_mesure VALUES (1430, 752048, 295, 'ML2_128651');
INSERT INTO art_poisson_mesure VALUES (1431, 752044, 220, 'ML2_128650');
INSERT INTO art_poisson_mesure VALUES (1432, 752040, 185, 'ML2_128650');
INSERT INTO art_poisson_mesure VALUES (1433, 752043, 250, 'ML2_128650');
INSERT INTO art_poisson_mesure VALUES (1434, 752039, 200, 'ML2_128650');
INSERT INTO art_poisson_mesure VALUES (1435, 752029, 295, 'ML2_128647');
INSERT INTO art_poisson_mesure VALUES (1436, 752025, 345, 'ML2_128647');
INSERT INTO art_poisson_mesure VALUES (1437, 752038, 250, 'ML2_128650');
INSERT INTO art_poisson_mesure VALUES (1438, 752028, 300, 'ML2_128647');
INSERT INTO art_poisson_mesure VALUES (1439, 752027, 340, 'ML2_128647');
INSERT INTO art_poisson_mesure VALUES (1440, 752026, 345, 'ML2_128647');
INSERT INTO art_poisson_mesure VALUES (1441, 752030, 333, 'ML2_128647');
INSERT INTO art_poisson_mesure VALUES (1442, 752037, 260, 'ML2_128650');
INSERT INTO art_poisson_mesure VALUES (1443, 752032, 350, 'ML2_128647');
INSERT INTO art_poisson_mesure VALUES (1444, 752031, 320, 'ML2_128647');
INSERT INTO art_poisson_mesure VALUES (1445, 752033, 370, 'ML2_128647');
INSERT INTO art_poisson_mesure VALUES (1446, 752036, 175, 'ML2_128650');
INSERT INTO art_poisson_mesure VALUES (1447, 752035, 550, 'ML2_128648');
INSERT INTO art_poisson_mesure VALUES (1448, 752034, 390, 'ML2_128647');
INSERT INTO art_poisson_mesure VALUES (1449, 752041, 180, 'ML2_128650');
INSERT INTO art_poisson_mesure VALUES (1450, 752053, 175, 'ML2_128654');
INSERT INTO art_poisson_mesure VALUES (1451, 752049, 320, 'ML2_128651');
INSERT INTO art_poisson_mesure VALUES (1452, 752042, 195, 'ML2_128650');
INSERT INTO art_poisson_mesure VALUES (1453, 752052, 230, 'ML2_128653');
INSERT INTO art_poisson_mesure VALUES (1454, 752050, 350, 'ML2_128651');
INSERT INTO art_poisson_mesure VALUES (1455, 752051, 260, 'ML2_128652');
INSERT INTO art_poisson_mesure VALUES (1456, 752057, 220, 'ML2_128657');
INSERT INTO art_poisson_mesure VALUES (1457, 752056, 410, 'ML2_128656');
INSERT INTO art_poisson_mesure VALUES (1458, 752055, 275, 'ML2_128655');
INSERT INTO art_poisson_mesure VALUES (1459, 752054, 235, 'ML2_128655');
INSERT INTO art_poisson_mesure VALUES (1460, 752088, 310, 'ML2_128667');
INSERT INTO art_poisson_mesure VALUES (1461, 752099, 150, 'ML2_128669');
INSERT INTO art_poisson_mesure VALUES (1462, 752089, 330, 'ML2_128668');
INSERT INTO art_poisson_mesure VALUES (1463, 752074, 210, 'ML2_128663');
INSERT INTO art_poisson_mesure VALUES (1464, 752076, 210, 'ML2_128664');
INSERT INTO art_poisson_mesure VALUES (1465, 752079, 160, 'ML2_128665');
INSERT INTO art_poisson_mesure VALUES (1466, 752077, 190, 'ML2_128664');
INSERT INTO art_poisson_mesure VALUES (1467, 752075, 240, 'ML2_128664');
INSERT INTO art_poisson_mesure VALUES (1468, 752098, 155, 'ML2_128669');
INSERT INTO art_poisson_mesure VALUES (1469, 752087, 150, 'ML2_128666');
INSERT INTO art_poisson_mesure VALUES (1470, 752078, 180, 'ML2_128664');
INSERT INTO art_poisson_mesure VALUES (1471, 752081, 163, 'ML2_128665');
INSERT INTO art_poisson_mesure VALUES (1472, 752086, 175, 'ML2_128665');
INSERT INTO art_poisson_mesure VALUES (1473, 752080, 192, 'ML2_128665');
INSERT INTO art_poisson_mesure VALUES (1474, 752090, 300, 'ML2_128668');
INSERT INTO art_poisson_mesure VALUES (1475, 752085, 163, 'ML2_128665');
INSERT INTO art_poisson_mesure VALUES (1476, 752083, 150, 'ML2_128665');
INSERT INTO art_poisson_mesure VALUES (1477, 752082, 180, 'ML2_128665');
INSERT INTO art_poisson_mesure VALUES (1478, 752084, 215, 'ML2_128665');
INSERT INTO art_poisson_mesure VALUES (1479, 752063, 160, 'ML2_128658');
INSERT INTO art_poisson_mesure VALUES (1480, 752093, 152, 'ML2_128669');
INSERT INTO art_poisson_mesure VALUES (1481, 752097, 130, 'ML2_128669');
INSERT INTO art_poisson_mesure VALUES (1482, 752061, 140, 'ML2_128658');
INSERT INTO art_poisson_mesure VALUES (1483, 752092, 123, 'ML2_128669');
INSERT INTO art_poisson_mesure VALUES (1484, 752062, 145, 'ML2_128658');
INSERT INTO art_poisson_mesure VALUES (1485, 752091, 120, 'ML2_128669');
INSERT INTO art_poisson_mesure VALUES (1486, 752060, 150, 'ML2_128658');
INSERT INTO art_poisson_mesure VALUES (1487, 752073, 220, 'ML2_128662');
INSERT INTO art_poisson_mesure VALUES (1488, 752058, 160, 'ML2_128658');
INSERT INTO art_poisson_mesure VALUES (1489, 752059, 150, 'ML2_128658');
INSERT INTO art_poisson_mesure VALUES (1490, 752096, 200, 'ML2_128669');
INSERT INTO art_poisson_mesure VALUES (1491, 752067, 130, 'ML2_128658');
INSERT INTO art_poisson_mesure VALUES (1492, 752095, 140, 'ML2_128669');
INSERT INTO art_poisson_mesure VALUES (1493, 752066, 140, 'ML2_128658');
INSERT INTO art_poisson_mesure VALUES (1494, 752065, 130, 'ML2_128658');
INSERT INTO art_poisson_mesure VALUES (1495, 752064, 155, 'ML2_128658');
INSERT INTO art_poisson_mesure VALUES (1496, 752094, 150, 'ML2_128669');
INSERT INTO art_poisson_mesure VALUES (1497, 752069, 200, 'ML2_128660');
INSERT INTO art_poisson_mesure VALUES (1498, 752070, 300, 'ML2_128661');
INSERT INTO art_poisson_mesure VALUES (1499, 752068, 230, 'ML2_128659');
INSERT INTO art_poisson_mesure VALUES (1500, 752072, 320, 'ML2_128661');
INSERT INTO art_poisson_mesure VALUES (1501, 752071, 312, 'ML2_128661');
INSERT INTO art_poisson_mesure VALUES (1502, 752100, 240, 'ML2_128670');
INSERT INTO art_poisson_mesure VALUES (1503, 752144, 390, 'ML2_128674');
INSERT INTO art_poisson_mesure VALUES (1504, 752101, 255, 'ML2_128670');
INSERT INTO art_poisson_mesure VALUES (1505, 752152, 210, 'ML2_128675');
INSERT INTO art_poisson_mesure VALUES (1506, 752151, 135, 'ML2_128675');
INSERT INTO art_poisson_mesure VALUES (1507, 752102, 215, 'ML2_128670');
INSERT INTO art_poisson_mesure VALUES (1508, 752143, 315, 'ML2_128674');
INSERT INTO art_poisson_mesure VALUES (1509, 752116, 197, 'ML2_128671');
INSERT INTO art_poisson_mesure VALUES (1510, 752107, 210, 'ML2_128670');
INSERT INTO art_poisson_mesure VALUES (1511, 752115, 195, 'ML2_128671');
INSERT INTO art_poisson_mesure VALUES (1512, 752106, 255, 'ML2_128670');
INSERT INTO art_poisson_mesure VALUES (1513, 752114, 175, 'ML2_128671');
INSERT INTO art_poisson_mesure VALUES (1514, 752105, 185, 'ML2_128670');
INSERT INTO art_poisson_mesure VALUES (1515, 752104, 195, 'ML2_128670');
INSERT INTO art_poisson_mesure VALUES (1516, 752109, 230, 'ML2_128670');
INSERT INTO art_poisson_mesure VALUES (1517, 752108, 192, 'ML2_128670');
INSERT INTO art_poisson_mesure VALUES (1518, 752103, 200, 'ML2_128670');
INSERT INTO art_poisson_mesure VALUES (1519, 752130, 135, 'ML2_128673');
INSERT INTO art_poisson_mesure VALUES (1520, 752142, 280, 'ML2_128674');
INSERT INTO art_poisson_mesure VALUES (1521, 752150, 205, 'ML2_128675');
INSERT INTO art_poisson_mesure VALUES (1522, 752121, 180, 'ML2_128672');
INSERT INTO art_poisson_mesure VALUES (1523, 752120, 140, 'ML2_128672');
INSERT INTO art_poisson_mesure VALUES (1524, 752119, 235, 'ML2_128671');
INSERT INTO art_poisson_mesure VALUES (1525, 752118, 165, 'ML2_128671');
INSERT INTO art_poisson_mesure VALUES (1526, 752117, 155, 'ML2_128671');
INSERT INTO art_poisson_mesure VALUES (1527, 752124, 153, 'ML2_128672');
INSERT INTO art_poisson_mesure VALUES (1528, 752122, 185, 'ML2_128672');
INSERT INTO art_poisson_mesure VALUES (1529, 752129, 162, 'ML2_128672');
INSERT INTO art_poisson_mesure VALUES (1530, 752123, 190, 'ML2_128672');
INSERT INTO art_poisson_mesure VALUES (1531, 752128, 155, 'ML2_128672');
INSERT INTO art_poisson_mesure VALUES (1532, 752125, 152, 'ML2_128672');
INSERT INTO art_poisson_mesure VALUES (1533, 752127, 165, 'ML2_128672');
INSERT INTO art_poisson_mesure VALUES (1534, 752126, 170, 'ML2_128672');
INSERT INTO art_poisson_mesure VALUES (1535, 752141, 300, 'ML2_128674');
INSERT INTO art_poisson_mesure VALUES (1536, 752136, 130, 'ML2_128673');
INSERT INTO art_poisson_mesure VALUES (1537, 752131, 195, 'ML2_128673');
INSERT INTO art_poisson_mesure VALUES (1538, 752149, 145, 'ML2_128675');
INSERT INTO art_poisson_mesure VALUES (1539, 752132, 212, 'ML2_128673');
INSERT INTO art_poisson_mesure VALUES (1540, 752135, 132, 'ML2_128673');
INSERT INTO art_poisson_mesure VALUES (1541, 752134, 205, 'ML2_128673');
INSERT INTO art_poisson_mesure VALUES (1542, 752133, 210, 'ML2_128673');
INSERT INTO art_poisson_mesure VALUES (1543, 752138, 130, 'ML2_128673');
INSERT INTO art_poisson_mesure VALUES (1544, 752148, 175, 'ML2_128675');
INSERT INTO art_poisson_mesure VALUES (1545, 752140, 310, 'ML2_128674');
INSERT INTO art_poisson_mesure VALUES (1546, 752137, 140, 'ML2_128673');
INSERT INTO art_poisson_mesure VALUES (1547, 752139, 200, 'ML2_128673');
INSERT INTO art_poisson_mesure VALUES (1548, 752147, 290, 'ML2_128674');
INSERT INTO art_poisson_mesure VALUES (1549, 752146, 333, 'ML2_128674');
INSERT INTO art_poisson_mesure VALUES (1550, 752145, 292, 'ML2_128674');
INSERT INTO art_poisson_mesure VALUES (1551, 752113, 243, 'ML2_128671');
INSERT INTO art_poisson_mesure VALUES (1552, 752157, 220, 'ML2_128675');
INSERT INTO art_poisson_mesure VALUES (1553, 752156, 195, 'ML2_128675');
INSERT INTO art_poisson_mesure VALUES (1554, 752153, 175, 'ML2_128675');
INSERT INTO art_poisson_mesure VALUES (1555, 752155, 155, 'ML2_128675');
INSERT INTO art_poisson_mesure VALUES (1556, 752154, 162, 'ML2_128675');
INSERT INTO art_poisson_mesure VALUES (1557, 752112, 253, 'ML2_128671');
INSERT INTO art_poisson_mesure VALUES (1558, 752111, 220, 'ML2_128671');
INSERT INTO art_poisson_mesure VALUES (1559, 752110, 190, 'ML2_128671');
INSERT INTO art_poisson_mesure VALUES (1560, 752164, 230, 'ML2_128678');
INSERT INTO art_poisson_mesure VALUES (1561, 752162, 250, 'ML2_128678');
INSERT INTO art_poisson_mesure VALUES (1562, 752163, 210, 'ML2_128678');
INSERT INTO art_poisson_mesure VALUES (1563, 752161, 210, 'ML2_128677');
INSERT INTO art_poisson_mesure VALUES (1564, 752159, 510, 'ML2_128676');
INSERT INTO art_poisson_mesure VALUES (1565, 752160, 220, 'ML2_128677');
INSERT INTO art_poisson_mesure VALUES (1566, 752158, 520, 'ML2_128676');
INSERT INTO art_poisson_mesure VALUES (1567, 752165, 230, 'ML2_128679');
INSERT INTO art_poisson_mesure VALUES (1568, 752166, 350, 'ML2_128679');
INSERT INTO art_poisson_mesure VALUES (1569, 752167, 550, 'ML2_128680');
INSERT INTO art_poisson_mesure VALUES (1570, 752168, 290, 'ML2_128681');
INSERT INTO art_poisson_mesure VALUES (1571, 752170, 310, 'ML2_128681');
INSERT INTO art_poisson_mesure VALUES (1572, 752169, 330, 'ML2_128681');
INSERT INTO art_poisson_mesure VALUES (1573, 752171, 300, 'ML2_128681');
INSERT INTO art_poisson_mesure VALUES (1574, 752172, 300, 'ML2_128681');
INSERT INTO art_poisson_mesure VALUES (1575, 752173, 360, 'ML2_128681');
INSERT INTO art_poisson_mesure VALUES (1576, 752177, 260, 'ML2_128683');
INSERT INTO art_poisson_mesure VALUES (1577, 752176, 280, 'ML2_128683');
INSERT INTO art_poisson_mesure VALUES (1578, 752175, 270, 'ML2_128683');
INSERT INTO art_poisson_mesure VALUES (1579, 752174, 255, 'ML2_128683');
INSERT INTO art_poisson_mesure VALUES (1580, 752187, 180, 'ML2_128686');
INSERT INTO art_poisson_mesure VALUES (1581, 752181, 120, 'ML2_128685');
INSERT INTO art_poisson_mesure VALUES (1582, 752180, 220, 'ML2_128684');
INSERT INTO art_poisson_mesure VALUES (1583, 752178, 245, 'ML2_128683');
INSERT INTO art_poisson_mesure VALUES (1584, 752179, 240, 'ML2_128684');
INSERT INTO art_poisson_mesure VALUES (1585, 752186, 150, 'ML2_128685');
INSERT INTO art_poisson_mesure VALUES (1586, 752183, 125, 'ML2_128685');
INSERT INTO art_poisson_mesure VALUES (1587, 752190, 240, 'ML2_128688');
INSERT INTO art_poisson_mesure VALUES (1588, 752182, 130, 'ML2_128685');
INSERT INTO art_poisson_mesure VALUES (1589, 752185, 140, 'ML2_128685');
INSERT INTO art_poisson_mesure VALUES (1590, 752189, 170, 'ML2_128687');
INSERT INTO art_poisson_mesure VALUES (1591, 752184, 135, 'ML2_128685');
INSERT INTO art_poisson_mesure VALUES (1592, 752188, 150, 'ML2_128687');
INSERT INTO art_poisson_mesure VALUES (1593, 752193, 395, 'ML2_128689');
INSERT INTO art_poisson_mesure VALUES (1594, 752200, 390, 'ML2_128689');
INSERT INTO art_poisson_mesure VALUES (1595, 752201, 335, 'ML2_128690');
INSERT INTO art_poisson_mesure VALUES (1596, 752202, 300, 'ML2_128690');
INSERT INTO art_poisson_mesure VALUES (1597, 752192, 400, 'ML2_128689');
INSERT INTO art_poisson_mesure VALUES (1598, 752194, 390, 'ML2_128689');
INSERT INTO art_poisson_mesure VALUES (1599, 752199, 385, 'ML2_128689');
INSERT INTO art_poisson_mesure VALUES (1600, 752197, 305, 'ML2_128689');
INSERT INTO art_poisson_mesure VALUES (1601, 752196, 370, 'ML2_128689');
INSERT INTO art_poisson_mesure VALUES (1602, 752195, 380, 'ML2_128689');
INSERT INTO art_poisson_mesure VALUES (1603, 752198, 295, 'ML2_128689');
INSERT INTO art_poisson_mesure VALUES (1604, 752203, 320, 'ML2_128690');
INSERT INTO art_poisson_mesure VALUES (1605, 752204, 325, 'ML2_128690');
INSERT INTO art_poisson_mesure VALUES (1606, 752205, 320, 'ML2_128690');
INSERT INTO art_poisson_mesure VALUES (1607, 752235, 150, 'ML2_128699');
INSERT INTO art_poisson_mesure VALUES (1608, 752232, 300, 'ML2_128696');
INSERT INTO art_poisson_mesure VALUES (1609, 752234, 390, 'ML2_128698');
INSERT INTO art_poisson_mesure VALUES (1610, 752233, 340, 'ML2_128697');
INSERT INTO art_poisson_mesure VALUES (1611, 752225, 230, 'ML2_128695');
INSERT INTO art_poisson_mesure VALUES (1612, 752214, 350, 'ML2_128693');
INSERT INTO art_poisson_mesure VALUES (1613, 752224, 195, 'ML2_128695');
INSERT INTO art_poisson_mesure VALUES (1614, 752191, 430, 'ML2_128689');
INSERT INTO art_poisson_mesure VALUES (1615, 752213, 195, 'ML2_128693');
INSERT INTO art_poisson_mesure VALUES (1616, 752211, 220, 'ML2_128693');
INSERT INTO art_poisson_mesure VALUES (1617, 752223, 175, 'ML2_128695');
INSERT INTO art_poisson_mesure VALUES (1618, 752206, 310, 'ML2_128691');
INSERT INTO art_poisson_mesure VALUES (1619, 752212, 196, 'ML2_128693');
INSERT INTO art_poisson_mesure VALUES (1620, 752207, 410, 'ML2_128691');
INSERT INTO art_poisson_mesure VALUES (1621, 752210, 330, 'ML2_128693');
INSERT INTO art_poisson_mesure VALUES (1622, 752209, 600, 'ML2_128692');
INSERT INTO art_poisson_mesure VALUES (1623, 752208, 400, 'ML2_128691');
INSERT INTO art_poisson_mesure VALUES (1624, 752215, 340, 'ML2_128693');
INSERT INTO art_poisson_mesure VALUES (1625, 752217, 230, 'ML2_128693');
INSERT INTO art_poisson_mesure VALUES (1626, 752222, 140, 'ML2_128695');
INSERT INTO art_poisson_mesure VALUES (1627, 752216, 230, 'ML2_128693');
INSERT INTO art_poisson_mesure VALUES (1628, 752218, 240, 'ML2_128693');
INSERT INTO art_poisson_mesure VALUES (1629, 752221, 300, 'ML2_128694');
INSERT INTO art_poisson_mesure VALUES (1630, 752219, 210, 'ML2_128693');
INSERT INTO art_poisson_mesure VALUES (1631, 752220, 400, 'ML2_128694');
INSERT INTO art_poisson_mesure VALUES (1632, 752230, 260, 'ML2_128696');
INSERT INTO art_poisson_mesure VALUES (1633, 752229, 360, 'ML2_128695');
INSERT INTO art_poisson_mesure VALUES (1634, 752231, 270, 'ML2_128696');
INSERT INTO art_poisson_mesure VALUES (1635, 752228, 260, 'ML2_128695');
INSERT INTO art_poisson_mesure VALUES (1636, 752227, 210, 'ML2_128695');
INSERT INTO art_poisson_mesure VALUES (1637, 752226, 200, 'ML2_128695');
INSERT INTO art_poisson_mesure VALUES (1638, 752241, 160, 'ML2_128700');
INSERT INTO art_poisson_mesure VALUES (1639, 752242, 260, 'ML2_128700');
INSERT INTO art_poisson_mesure VALUES (1640, 752237, 175, 'ML2_128700');
INSERT INTO art_poisson_mesure VALUES (1641, 752239, 190, 'ML2_128700');
INSERT INTO art_poisson_mesure VALUES (1642, 752240, 230, 'ML2_128700');
INSERT INTO art_poisson_mesure VALUES (1643, 752236, 275, 'ML2_128700');
INSERT INTO art_poisson_mesure VALUES (1644, 752247, 270, 'ML2_128701');
INSERT INTO art_poisson_mesure VALUES (1645, 752248, 315, 'ML2_128701');
INSERT INTO art_poisson_mesure VALUES (1646, 752256, 180, 'ML2_128702');
INSERT INTO art_poisson_mesure VALUES (1647, 752246, 330, 'ML2_128701');
INSERT INTO art_poisson_mesure VALUES (1648, 752245, 235, 'ML2_128700');
INSERT INTO art_poisson_mesure VALUES (1649, 752244, 190, 'ML2_128700');
INSERT INTO art_poisson_mesure VALUES (1650, 752238, 180, 'ML2_128700');
INSERT INTO art_poisson_mesure VALUES (1651, 752250, 290, 'ML2_128701');
INSERT INTO art_poisson_mesure VALUES (1652, 752255, 315, 'ML2_128701');
INSERT INTO art_poisson_mesure VALUES (1653, 752249, 296, 'ML2_128701');
INSERT INTO art_poisson_mesure VALUES (1654, 752254, 310, 'ML2_128701');
INSERT INTO art_poisson_mesure VALUES (1655, 752251, 220, 'ML2_128701');
INSERT INTO art_poisson_mesure VALUES (1656, 752253, 280, 'ML2_128701');
INSERT INTO art_poisson_mesure VALUES (1657, 752252, 390, 'ML2_128701');
INSERT INTO art_poisson_mesure VALUES (1658, 752257, 230, 'ML2_128703');
INSERT INTO art_poisson_mesure VALUES (1659, 752243, 310, 'ML2_128700');
INSERT INTO art_poisson_mesure VALUES (1660, 752268, 175, 'ML2_128706');
INSERT INTO art_poisson_mesure VALUES (1661, 752267, 360, 'ML2_128706');
INSERT INTO art_poisson_mesure VALUES (1662, 752265, 375, 'ML2_128705');
INSERT INTO art_poisson_mesure VALUES (1663, 752263, 320, 'ML2_128705');
INSERT INTO art_poisson_mesure VALUES (1664, 752266, 300, 'ML2_128705');
INSERT INTO art_poisson_mesure VALUES (1665, 752262, 295, 'ML2_128705');
INSERT INTO art_poisson_mesure VALUES (1666, 752270, 215, 'ML2_128706');
INSERT INTO art_poisson_mesure VALUES (1667, 752260, 190, 'ML2_128705');
INSERT INTO art_poisson_mesure VALUES (1668, 752269, 300, 'ML2_128706');
INSERT INTO art_poisson_mesure VALUES (1669, 752272, 290, 'ML2_128706');
INSERT INTO art_poisson_mesure VALUES (1670, 752261, 195, 'ML2_128705');
INSERT INTO art_poisson_mesure VALUES (1671, 752271, 180, 'ML2_128706');
INSERT INTO art_poisson_mesure VALUES (1672, 752259, 290, 'ML2_128705');
INSERT INTO art_poisson_mesure VALUES (1673, 752273, 210, 'ML2_128706');
INSERT INTO art_poisson_mesure VALUES (1674, 752258, 1040, 'ML2_128704');
INSERT INTO art_poisson_mesure VALUES (1675, 752275, 165, 'ML2_128706');
INSERT INTO art_poisson_mesure VALUES (1676, 752274, 190, 'ML2_128706');
INSERT INTO art_poisson_mesure VALUES (1677, 752264, 315, 'ML2_128705');
INSERT INTO art_poisson_mesure VALUES (1678, 752276, 195, 'ML2_128706');
INSERT INTO art_poisson_mesure VALUES (1679, 752326, 120, 'ML2_128712');
INSERT INTO art_poisson_mesure VALUES (1680, 752325, 170, 'ML2_128712');
INSERT INTO art_poisson_mesure VALUES (1681, 752324, 125, 'ML2_128712');
INSERT INTO art_poisson_mesure VALUES (1682, 752311, 175, 'ML2_128711');
INSERT INTO art_poisson_mesure VALUES (1683, 752310, 145, 'ML2_128711');
INSERT INTO art_poisson_mesure VALUES (1684, 752309, 115, 'ML2_128710');
INSERT INTO art_poisson_mesure VALUES (1685, 752300, 210, 'ML2_128710');
INSERT INTO art_poisson_mesure VALUES (1686, 752303, 160, 'ML2_128710');
INSERT INTO art_poisson_mesure VALUES (1687, 752302, 245, 'ML2_128710');
INSERT INTO art_poisson_mesure VALUES (1688, 752308, 175, 'ML2_128710');
INSERT INTO art_poisson_mesure VALUES (1689, 752301, 200, 'ML2_128710');
INSERT INTO art_poisson_mesure VALUES (1690, 752304, 120, 'ML2_128710');
INSERT INTO art_poisson_mesure VALUES (1691, 752307, 150, 'ML2_128710');
INSERT INTO art_poisson_mesure VALUES (1692, 752305, 130, 'ML2_128710');
INSERT INTO art_poisson_mesure VALUES (1693, 752306, 140, 'ML2_128710');
INSERT INTO art_poisson_mesure VALUES (1694, 752315, 140, 'ML2_128711');
INSERT INTO art_poisson_mesure VALUES (1695, 752314, 155, 'ML2_128711');
INSERT INTO art_poisson_mesure VALUES (1696, 752323, 130, 'ML2_128712');
INSERT INTO art_poisson_mesure VALUES (1697, 752322, 145, 'ML2_128712');
INSERT INTO art_poisson_mesure VALUES (1698, 752320, 135, 'ML2_128712');
INSERT INTO art_poisson_mesure VALUES (1699, 752313, 130, 'ML2_128711');
INSERT INTO art_poisson_mesure VALUES (1700, 752312, 155, 'ML2_128711');
INSERT INTO art_poisson_mesure VALUES (1701, 752319, 170, 'ML2_128711');
INSERT INTO art_poisson_mesure VALUES (1702, 752316, 130, 'ML2_128711');
INSERT INTO art_poisson_mesure VALUES (1703, 752318, 165, 'ML2_128711');
INSERT INTO art_poisson_mesure VALUES (1704, 752317, 125, 'ML2_128711');
INSERT INTO art_poisson_mesure VALUES (1705, 752327, 130, 'ML2_128712');
INSERT INTO art_poisson_mesure VALUES (1706, 752321, 110, 'ML2_128712');
INSERT INTO art_poisson_mesure VALUES (1707, 752329, 110, 'ML2_128712');
INSERT INTO art_poisson_mesure VALUES (1708, 752328, 140, 'ML2_128712');
INSERT INTO art_poisson_mesure VALUES (1709, 752299, 345, 'ML2_128709');
INSERT INTO art_poisson_mesure VALUES (1710, 752298, 350, 'ML2_128709');
INSERT INTO art_poisson_mesure VALUES (1711, 752295, 195, 'ML2_128708');
INSERT INTO art_poisson_mesure VALUES (1712, 752278, 275, 'ML2_128707');
INSERT INTO art_poisson_mesure VALUES (1713, 752297, 360, 'ML2_128709');
INSERT INTO art_poisson_mesure VALUES (1714, 752277, 280, 'ML2_128707');
INSERT INTO art_poisson_mesure VALUES (1715, 752285, 300, 'ML2_128707');
INSERT INTO art_poisson_mesure VALUES (1716, 752280, 290, 'ML2_128707');
INSERT INTO art_poisson_mesure VALUES (1717, 752279, 300, 'ML2_128707');
INSERT INTO art_poisson_mesure VALUES (1718, 752294, 180, 'ML2_128708');
INSERT INTO art_poisson_mesure VALUES (1719, 752281, 280, 'ML2_128707');
INSERT INTO art_poisson_mesure VALUES (1720, 752284, 335, 'ML2_128707');
INSERT INTO art_poisson_mesure VALUES (1721, 752283, 300, 'ML2_128707');
INSERT INTO art_poisson_mesure VALUES (1722, 752282, 295, 'ML2_128707');
INSERT INTO art_poisson_mesure VALUES (1723, 752286, 270, 'ML2_128707');
INSERT INTO art_poisson_mesure VALUES (1724, 752288, 195, 'ML2_128708');
INSERT INTO art_poisson_mesure VALUES (1725, 752293, 215, 'ML2_128708');
INSERT INTO art_poisson_mesure VALUES (1726, 752287, 210, 'ML2_128708');
INSERT INTO art_poisson_mesure VALUES (1727, 752289, 185, 'ML2_128708');
INSERT INTO art_poisson_mesure VALUES (1728, 752292, 230, 'ML2_128708');
INSERT INTO art_poisson_mesure VALUES (1729, 752291, 175, 'ML2_128708');
INSERT INTO art_poisson_mesure VALUES (1730, 752290, 165, 'ML2_128708');
INSERT INTO art_poisson_mesure VALUES (1731, 752296, 220, 'ML2_128708');
INSERT INTO art_poisson_mesure VALUES (1732, 752344, 245, 'ML2_128715');
INSERT INTO art_poisson_mesure VALUES (1733, 752343, 215, 'ML2_128715');
INSERT INTO art_poisson_mesure VALUES (1734, 752342, 400, 'ML2_128715');
INSERT INTO art_poisson_mesure VALUES (1735, 752341, 210, 'ML2_128714');
INSERT INTO art_poisson_mesure VALUES (1736, 752340, 265, 'ML2_128714');
INSERT INTO art_poisson_mesure VALUES (1737, 752331, 200, 'ML2_128713');
INSERT INTO art_poisson_mesure VALUES (1738, 752339, 165, 'ML2_128713');
INSERT INTO art_poisson_mesure VALUES (1739, 752330, 220, 'ML2_128713');
INSERT INTO art_poisson_mesure VALUES (1740, 752338, 260, 'ML2_128713');
INSERT INTO art_poisson_mesure VALUES (1741, 752333, 197, 'ML2_128713');
INSERT INTO art_poisson_mesure VALUES (1742, 752332, 195, 'ML2_128713');
INSERT INTO art_poisson_mesure VALUES (1743, 752337, 195, 'ML2_128713');
INSERT INTO art_poisson_mesure VALUES (1744, 752334, 230, 'ML2_128713');
INSERT INTO art_poisson_mesure VALUES (1745, 752336, 210, 'ML2_128713');
INSERT INTO art_poisson_mesure VALUES (1746, 752335, 185, 'ML2_128713');
INSERT INTO art_poisson_mesure VALUES (1747, 752347, 220, 'ML2_128716');
INSERT INTO art_poisson_mesure VALUES (1748, 752346, 255, 'ML2_128715');
INSERT INTO art_poisson_mesure VALUES (1749, 752345, 260, 'ML2_128715');
INSERT INTO art_poisson_mesure VALUES (1750, 752350, 200, 'ML2_128716');
INSERT INTO art_poisson_mesure VALUES (1751, 752349, 216, 'ML2_128716');
INSERT INTO art_poisson_mesure VALUES (1752, 752348, 195, 'ML2_128716');
INSERT INTO art_poisson_mesure VALUES (1753, 752352, 215, 'ML2_128716');
INSERT INTO art_poisson_mesure VALUES (1754, 752351, 230, 'ML2_128716');
INSERT INTO art_poisson_mesure VALUES (1755, 752356, 210, 'ML2_128716');
INSERT INTO art_poisson_mesure VALUES (1756, 752353, 270, 'ML2_128716');
INSERT INTO art_poisson_mesure VALUES (1757, 752354, 280, 'ML2_128716');
INSERT INTO art_poisson_mesure VALUES (1758, 752355, 340, 'ML2_128716');
INSERT INTO art_poisson_mesure VALUES (1759, 752359, 100, 'ML2_128718');
INSERT INTO art_poisson_mesure VALUES (1760, 752358, 285, 'ML2_128717');
INSERT INTO art_poisson_mesure VALUES (1761, 752357, 460, 'ML2_128717');
INSERT INTO art_poisson_mesure VALUES (1762, 752360, 210, 'ML2_128719');
INSERT INTO art_poisson_mesure VALUES (1763, 752361, 390, 'ML2_128720');
INSERT INTO art_poisson_mesure VALUES (1764, 752363, 630, 'ML2_128721');
INSERT INTO art_poisson_mesure VALUES (1765, 752362, 350, 'ML2_128720');
INSERT INTO art_poisson_mesure VALUES (1766, 752413, 195, 'ML2_128732');
INSERT INTO art_poisson_mesure VALUES (1767, 752375, 155, 'ML2_128723');
INSERT INTO art_poisson_mesure VALUES (1768, 752374, 150, 'ML2_128723');
INSERT INTO art_poisson_mesure VALUES (1769, 752373, 135, 'ML2_128722');
INSERT INTO art_poisson_mesure VALUES (1770, 752380, 135, 'ML2_128723');
INSERT INTO art_poisson_mesure VALUES (1771, 752412, 205, 'ML2_128731');
INSERT INTO art_poisson_mesure VALUES (1772, 752399, 210, 'ML2_128726');
INSERT INTO art_poisson_mesure VALUES (1773, 752377, 160, 'ML2_128723');
INSERT INTO art_poisson_mesure VALUES (1774, 752376, 140, 'ML2_128723');
INSERT INTO art_poisson_mesure VALUES (1775, 752378, 155, 'ML2_128723');
INSERT INTO art_poisson_mesure VALUES (1776, 752379, 130, 'ML2_128723');
INSERT INTO art_poisson_mesure VALUES (1777, 752382, 165, 'ML2_128723');
INSERT INTO art_poisson_mesure VALUES (1778, 752398, 200, 'ML2_128726');
INSERT INTO art_poisson_mesure VALUES (1779, 752381, 120, 'ML2_128723');
INSERT INTO art_poisson_mesure VALUES (1780, 752393, 145, 'ML2_128725');
INSERT INTO art_poisson_mesure VALUES (1781, 752397, 195, 'ML2_128726');
INSERT INTO art_poisson_mesure VALUES (1782, 752394, 135, 'ML2_128725');
INSERT INTO art_poisson_mesure VALUES (1783, 752396, 215, 'ML2_128726');
INSERT INTO art_poisson_mesure VALUES (1784, 752395, 137, 'ML2_128725');
INSERT INTO art_poisson_mesure VALUES (1785, 752400, 185, 'ML2_128726');
INSERT INTO art_poisson_mesure VALUES (1786, 752411, 200, 'ML2_128730');
INSERT INTO art_poisson_mesure VALUES (1787, 752405, 135, 'ML2_128728');
INSERT INTO art_poisson_mesure VALUES (1788, 752404, 130, 'ML2_128728');
INSERT INTO art_poisson_mesure VALUES (1789, 752401, 220, 'ML2_128727');
INSERT INTO art_poisson_mesure VALUES (1790, 752403, 145, 'ML2_128728');
INSERT INTO art_poisson_mesure VALUES (1791, 752402, 160, 'ML2_128728');
INSERT INTO art_poisson_mesure VALUES (1792, 752410, 180, 'ML2_128729');
INSERT INTO art_poisson_mesure VALUES (1793, 752407, 195, 'ML2_128729');
INSERT INTO art_poisson_mesure VALUES (1794, 752406, 150, 'ML2_128728');
INSERT INTO art_poisson_mesure VALUES (1795, 752409, 190, 'ML2_128729');
INSERT INTO art_poisson_mesure VALUES (1796, 752408, 180, 'ML2_128729');
INSERT INTO art_poisson_mesure VALUES (1797, 752372, 163, 'ML2_128722');
INSERT INTO art_poisson_mesure VALUES (1798, 752392, 125, 'ML2_128725');
INSERT INTO art_poisson_mesure VALUES (1799, 752371, 155, 'ML2_128722');
INSERT INTO art_poisson_mesure VALUES (1800, 752391, 140, 'ML2_128725');
INSERT INTO art_poisson_mesure VALUES (1801, 752370, 150, 'ML2_128722');
INSERT INTO art_poisson_mesure VALUES (1802, 752390, 123, 'ML2_128725');
INSERT INTO art_poisson_mesure VALUES (1803, 752389, 150, 'ML2_128725');
INSERT INTO art_poisson_mesure VALUES (1804, 752369, 160, 'ML2_128722');
INSERT INTO art_poisson_mesure VALUES (1805, 752365, 130, 'ML2_128722');
INSERT INTO art_poisson_mesure VALUES (1806, 752364, 140, 'ML2_128722');
INSERT INTO art_poisson_mesure VALUES (1807, 752388, 110, 'ML2_128725');
INSERT INTO art_poisson_mesure VALUES (1808, 752368, 140, 'ML2_128722');
INSERT INTO art_poisson_mesure VALUES (1809, 752385, 190, 'ML2_128724');
INSERT INTO art_poisson_mesure VALUES (1810, 752367, 150, 'ML2_128722');
INSERT INTO art_poisson_mesure VALUES (1811, 752384, 210, 'ML2_128724');
INSERT INTO art_poisson_mesure VALUES (1812, 752366, 142, 'ML2_128722');
INSERT INTO art_poisson_mesure VALUES (1813, 752383, 145, 'ML2_128723');
INSERT INTO art_poisson_mesure VALUES (1814, 752386, 130, 'ML2_128725');
INSERT INTO art_poisson_mesure VALUES (1815, 752387, 142, 'ML2_128725');
INSERT INTO art_poisson_mesure VALUES (1816, 752415, 345, 'ML2_128734');
INSERT INTO art_poisson_mesure VALUES (1817, 752416, 270, 'ML2_128735');
INSERT INTO art_poisson_mesure VALUES (1818, 752424, 295, 'ML2_128736');
INSERT INTO art_poisson_mesure VALUES (1819, 752414, 360, 'ML2_128733');
INSERT INTO art_poisson_mesure VALUES (1820, 752423, 250, 'ML2_128735');
INSERT INTO art_poisson_mesure VALUES (1821, 752422, 290, 'ML2_128735');
INSERT INTO art_poisson_mesure VALUES (1822, 752421, 285, 'ML2_128735');
INSERT INTO art_poisson_mesure VALUES (1823, 752420, 270, 'ML2_128735');
INSERT INTO art_poisson_mesure VALUES (1824, 752419, 265, 'ML2_128735');
INSERT INTO art_poisson_mesure VALUES (1825, 752418, 230, 'ML2_128735');
INSERT INTO art_poisson_mesure VALUES (1826, 752417, 260, 'ML2_128735');
INSERT INTO art_poisson_mesure VALUES (1827, 752426, 325, 'ML2_128736');
INSERT INTO art_poisson_mesure VALUES (1828, 752425, 330, 'ML2_128736');
INSERT INTO art_poisson_mesure VALUES (1829, 752428, 245, 'ML2_128738');
INSERT INTO art_poisson_mesure VALUES (1830, 752427, 330, 'ML2_128737');
INSERT INTO art_poisson_mesure VALUES (1831, 752429, 275, 'ML2_128739');
INSERT INTO art_poisson_mesure VALUES (1832, 752447, 270, 'ML2_128740');
INSERT INTO art_poisson_mesure VALUES (1833, 752446, 280, 'ML2_128740');
INSERT INTO art_poisson_mesure VALUES (1834, 752445, 290, 'ML2_128740');
INSERT INTO art_poisson_mesure VALUES (1835, 752430, 340, 'ML2_128739');
INSERT INTO art_poisson_mesure VALUES (1836, 752433, 303, 'ML2_128739');
INSERT INTO art_poisson_mesure VALUES (1837, 752432, 307, 'ML2_128739');
INSERT INTO art_poisson_mesure VALUES (1838, 752431, 325, 'ML2_128739');
INSERT INTO art_poisson_mesure VALUES (1839, 752449, 385, 'ML2_128741');
INSERT INTO art_poisson_mesure VALUES (1840, 752448, 275, 'ML2_128740');
INSERT INTO art_poisson_mesure VALUES (1841, 752444, 263, 'ML2_128740');
INSERT INTO art_poisson_mesure VALUES (1842, 752443, 276, 'ML2_128740');
INSERT INTO art_poisson_mesure VALUES (1843, 752442, 240, 'ML2_128740');
INSERT INTO art_poisson_mesure VALUES (1844, 752434, 310, 'ML2_128739');
INSERT INTO art_poisson_mesure VALUES (1845, 752435, 375, 'ML2_128739');
INSERT INTO art_poisson_mesure VALUES (1846, 752437, 335, 'ML2_128739');
INSERT INTO art_poisson_mesure VALUES (1847, 752436, 265, 'ML2_128739');
INSERT INTO art_poisson_mesure VALUES (1848, 752439, 265, 'ML2_128740');
INSERT INTO art_poisson_mesure VALUES (1849, 752438, 330, 'ML2_128739');
INSERT INTO art_poisson_mesure VALUES (1850, 752441, 260, 'ML2_128740');
INSERT INTO art_poisson_mesure VALUES (1851, 752440, 255, 'ML2_128740');
INSERT INTO art_poisson_mesure VALUES (1852, 752484, 155, 'ML2_128746');
INSERT INTO art_poisson_mesure VALUES (1853, 752482, 140, 'ML2_128746');
INSERT INTO art_poisson_mesure VALUES (1854, 752483, 155, 'ML2_128746');
INSERT INTO art_poisson_mesure VALUES (1855, 752485, 130, 'ML2_128746');
INSERT INTO art_poisson_mesure VALUES (1856, 752480, 150, 'ML2_128746');
INSERT INTO art_poisson_mesure VALUES (1857, 752481, 135, 'ML2_128746');
INSERT INTO art_poisson_mesure VALUES (1858, 752479, 145, 'ML2_128746');
INSERT INTO art_poisson_mesure VALUES (1859, 752478, 150, 'ML2_128746');
INSERT INTO art_poisson_mesure VALUES (1860, 752489, 125, 'ML2_128747');
INSERT INTO art_poisson_mesure VALUES (1861, 752490, 105, 'ML2_128747');
INSERT INTO art_poisson_mesure VALUES (1862, 752475, 150, 'ML2_128745');
INSERT INTO art_poisson_mesure VALUES (1863, 752488, 150, 'ML2_128747');
INSERT INTO art_poisson_mesure VALUES (1864, 752476, 210, 'ML2_128745');
INSERT INTO art_poisson_mesure VALUES (1865, 752496, 110, 'ML2_128747');
INSERT INTO art_poisson_mesure VALUES (1866, 752487, 90, 'ML2_128747');
INSERT INTO art_poisson_mesure VALUES (1867, 752477, 120, 'ML2_128746');
INSERT INTO art_poisson_mesure VALUES (1868, 752486, 160, 'ML2_128746');
INSERT INTO art_poisson_mesure VALUES (1869, 752452, 315, 'ML2_128743');
INSERT INTO art_poisson_mesure VALUES (1870, 752461, 260, 'ML2_128744');
INSERT INTO art_poisson_mesure VALUES (1871, 752495, 100, 'ML2_128747');
INSERT INTO art_poisson_mesure VALUES (1872, 752450, 340, 'ML2_128742');
INSERT INTO art_poisson_mesure VALUES (1873, 752474, 160, 'ML2_128745');
INSERT INTO art_poisson_mesure VALUES (1874, 752451, 365, 'ML2_128742');
INSERT INTO art_poisson_mesure VALUES (1875, 752455, 365, 'ML2_128743');
INSERT INTO art_poisson_mesure VALUES (1876, 752454, 330, 'ML2_128743');
INSERT INTO art_poisson_mesure VALUES (1877, 752453, 340, 'ML2_128743');
INSERT INTO art_poisson_mesure VALUES (1878, 752460, 275, 'ML2_128744');
INSERT INTO art_poisson_mesure VALUES (1879, 752459, 290, 'ML2_128744');
INSERT INTO art_poisson_mesure VALUES (1880, 752456, 370, 'ML2_128743');
INSERT INTO art_poisson_mesure VALUES (1881, 752457, 295, 'ML2_128743');
INSERT INTO art_poisson_mesure VALUES (1882, 752458, 335, 'ML2_128743');
INSERT INTO art_poisson_mesure VALUES (1883, 752473, 175, 'ML2_128745');
INSERT INTO art_poisson_mesure VALUES (1884, 752467, 175, 'ML2_128745');
INSERT INTO art_poisson_mesure VALUES (1885, 752462, 300, 'ML2_128744');
INSERT INTO art_poisson_mesure VALUES (1886, 752494, 110, 'ML2_128747');
INSERT INTO art_poisson_mesure VALUES (1887, 752466, 230, 'ML2_128744');
INSERT INTO art_poisson_mesure VALUES (1888, 752463, 280, 'ML2_128744');
INSERT INTO art_poisson_mesure VALUES (1889, 752465, 225, 'ML2_128744');
INSERT INTO art_poisson_mesure VALUES (1890, 752464, 270, 'ML2_128744');
INSERT INTO art_poisson_mesure VALUES (1891, 752493, 105, 'ML2_128747');
INSERT INTO art_poisson_mesure VALUES (1892, 752469, 180, 'ML2_128745');
INSERT INTO art_poisson_mesure VALUES (1893, 752468, 190, 'ML2_128745');
INSERT INTO art_poisson_mesure VALUES (1894, 752472, 165, 'ML2_128745');
INSERT INTO art_poisson_mesure VALUES (1895, 752492, 105, 'ML2_128747');
INSERT INTO art_poisson_mesure VALUES (1896, 752471, 195, 'ML2_128745');
INSERT INTO art_poisson_mesure VALUES (1897, 752491, 155, 'ML2_128747');
INSERT INTO art_poisson_mesure VALUES (1898, 752470, 230, 'ML2_128745');
INSERT INTO art_poisson_mesure VALUES (1899, 752515, 310, 'ML2_128750');
INSERT INTO art_poisson_mesure VALUES (1900, 752514, 300, 'ML2_128750');
INSERT INTO art_poisson_mesure VALUES (1901, 752513, 286, 'ML2_128750');
INSERT INTO art_poisson_mesure VALUES (1902, 752512, 275, 'ML2_128750');
INSERT INTO art_poisson_mesure VALUES (1903, 752511, 320, 'ML2_128750');
INSERT INTO art_poisson_mesure VALUES (1904, 752506, 270, 'ML2_128748');
INSERT INTO art_poisson_mesure VALUES (1905, 752497, 285, 'ML2_128748');
INSERT INTO art_poisson_mesure VALUES (1906, 752500, 310, 'ML2_128748');
INSERT INTO art_poisson_mesure VALUES (1907, 752499, 330, 'ML2_128748');
INSERT INTO art_poisson_mesure VALUES (1908, 752498, 300, 'ML2_128748');
INSERT INTO art_poisson_mesure VALUES (1909, 752501, 295, 'ML2_128748');
INSERT INTO art_poisson_mesure VALUES (1910, 752505, 270, 'ML2_128748');
INSERT INTO art_poisson_mesure VALUES (1911, 752504, 300, 'ML2_128748');
INSERT INTO art_poisson_mesure VALUES (1912, 752503, 315, 'ML2_128748');
INSERT INTO art_poisson_mesure VALUES (1913, 752502, 320, 'ML2_128748');
INSERT INTO art_poisson_mesure VALUES (1914, 752510, 270, 'ML2_128750');
INSERT INTO art_poisson_mesure VALUES (1915, 752509, 280, 'ML2_128750');
INSERT INTO art_poisson_mesure VALUES (1916, 752520, 200, 'ML2_128752');
INSERT INTO art_poisson_mesure VALUES (1917, 752519, 395, 'ML2_128751');
INSERT INTO art_poisson_mesure VALUES (1918, 752508, 385, 'ML2_128749');
INSERT INTO art_poisson_mesure VALUES (1919, 752518, 265, 'ML2_128750');
INSERT INTO art_poisson_mesure VALUES (1920, 752507, 350, 'ML2_128749');
INSERT INTO art_poisson_mesure VALUES (1921, 752517, 265, 'ML2_128750');
INSERT INTO art_poisson_mesure VALUES (1922, 752516, 290, 'ML2_128750');
INSERT INTO art_poisson_mesure VALUES (1923, 752536, 175, 'ML2_128758');
INSERT INTO art_poisson_mesure VALUES (1924, 752544, 170, 'ML2_128759');
INSERT INTO art_poisson_mesure VALUES (1925, 752534, 190, 'ML2_128758');
INSERT INTO art_poisson_mesure VALUES (1926, 752533, 175, 'ML2_128758');
INSERT INTO art_poisson_mesure VALUES (1927, 752530, 180, 'ML2_128758');
INSERT INTO art_poisson_mesure VALUES (1928, 752529, 165, 'ML2_128757');
INSERT INTO art_poisson_mesure VALUES (1929, 752528, 195, 'ML2_128757');
INSERT INTO art_poisson_mesure VALUES (1930, 752523, 250, 'ML2_128754');
INSERT INTO art_poisson_mesure VALUES (1931, 752522, 190, 'ML2_128753');
INSERT INTO art_poisson_mesure VALUES (1932, 752521, 165, 'ML2_128753');
INSERT INTO art_poisson_mesure VALUES (1933, 752527, 240, 'ML2_128756');
INSERT INTO art_poisson_mesure VALUES (1934, 752524, 255, 'ML2_128755');
INSERT INTO art_poisson_mesure VALUES (1935, 752526, 195, 'ML2_128756');
INSERT INTO art_poisson_mesure VALUES (1936, 752525, 520, 'ML2_128756');
INSERT INTO art_poisson_mesure VALUES (1937, 752545, 115, 'ML2_128759');
INSERT INTO art_poisson_mesure VALUES (1938, 752562, 145, 'ML2_128763');
INSERT INTO art_poisson_mesure VALUES (1939, 752531, 150, 'ML2_128758');
INSERT INTO art_poisson_mesure VALUES (1940, 752549, 310, 'ML2_128761');
INSERT INTO art_poisson_mesure VALUES (1941, 752535, 190, 'ML2_128758');
INSERT INTO art_poisson_mesure VALUES (1942, 752532, 195, 'ML2_128758');
INSERT INTO art_poisson_mesure VALUES (1943, 752548, 205, 'ML2_128760');
INSERT INTO art_poisson_mesure VALUES (1944, 752547, 153, 'ML2_128759');
INSERT INTO art_poisson_mesure VALUES (1945, 752546, 162, 'ML2_128759');
INSERT INTO art_poisson_mesure VALUES (1946, 752554, 195, 'ML2_128762');
INSERT INTO art_poisson_mesure VALUES (1947, 752553, 220, 'ML2_128762');
INSERT INTO art_poisson_mesure VALUES (1948, 752550, 197, 'ML2_128762');
INSERT INTO art_poisson_mesure VALUES (1949, 752552, 210, 'ML2_128762');
INSERT INTO art_poisson_mesure VALUES (1950, 752551, 240, 'ML2_128762');
INSERT INTO art_poisson_mesure VALUES (1951, 752564, 168, 'ML2_128763');
INSERT INTO art_poisson_mesure VALUES (1952, 752563, 140, 'ML2_128763');
INSERT INTO art_poisson_mesure VALUES (1953, 752565, 255, 'ML2_128764');
INSERT INTO art_poisson_mesure VALUES (1954, 752566, 230, 'ML2_128765');
INSERT INTO art_poisson_mesure VALUES (1955, 752543, 160, 'ML2_128759');
INSERT INTO art_poisson_mesure VALUES (1956, 752561, 130, 'ML2_128763');
INSERT INTO art_poisson_mesure VALUES (1957, 752560, 135, 'ML2_128763');
INSERT INTO art_poisson_mesure VALUES (1958, 752542, 130, 'ML2_128759');
INSERT INTO art_poisson_mesure VALUES (1959, 752559, 140, 'ML2_128763');
INSERT INTO art_poisson_mesure VALUES (1960, 752541, 147, 'ML2_128759');
INSERT INTO art_poisson_mesure VALUES (1961, 752540, 127, 'ML2_128759');
INSERT INTO art_poisson_mesure VALUES (1962, 752558, 150, 'ML2_128763');
INSERT INTO art_poisson_mesure VALUES (1963, 752557, 150, 'ML2_128763');
INSERT INTO art_poisson_mesure VALUES (1964, 752539, 125, 'ML2_128759');
INSERT INTO art_poisson_mesure VALUES (1965, 752556, 155, 'ML2_128763');
INSERT INTO art_poisson_mesure VALUES (1966, 752538, 130, 'ML2_128759');
INSERT INTO art_poisson_mesure VALUES (1967, 752555, 155, 'ML2_128763');
INSERT INTO art_poisson_mesure VALUES (1968, 752537, 165, 'ML2_128758');
INSERT INTO art_poisson_mesure VALUES (1969, 759310, 120, 'ML2_129884');
INSERT INTO art_poisson_mesure VALUES (1970, 759308, 125, 'ML2_129884');
INSERT INTO art_poisson_mesure VALUES (1971, 759309, 110, 'ML2_129884');
INSERT INTO art_poisson_mesure VALUES (1972, 759312, 160, 'ML2_129884');
INSERT INTO art_poisson_mesure VALUES (1973, 759311, 150, 'ML2_129884');
INSERT INTO art_poisson_mesure VALUES (1974, 759306, 140, 'ML2_129884');
INSERT INTO art_poisson_mesure VALUES (1975, 759307, 135, 'ML2_129884');
INSERT INTO art_poisson_mesure VALUES (1976, 759313, 190, 'ML2_129885');
INSERT INTO art_poisson_mesure VALUES (1977, 759314, 175, 'ML2_129885');
INSERT INTO art_poisson_mesure VALUES (1978, 759316, 210, 'ML2_129885');
INSERT INTO art_poisson_mesure VALUES (1979, 759305, 150, 'ML2_129884');
INSERT INTO art_poisson_mesure VALUES (1980, 759304, 155, 'ML2_129884');
INSERT INTO art_poisson_mesure VALUES (1981, 759315, 215, 'ML2_129885');
INSERT INTO art_poisson_mesure VALUES (1982, 759324, 360, 'ML2_129886');
INSERT INTO art_poisson_mesure VALUES (1983, 759317, 200, 'ML2_129885');
INSERT INTO art_poisson_mesure VALUES (1984, 759303, 130, 'ML2_129884');
INSERT INTO art_poisson_mesure VALUES (1985, 759323, 295, 'ML2_129886');
INSERT INTO art_poisson_mesure VALUES (1986, 759318, 180, 'ML2_129885');
INSERT INTO art_poisson_mesure VALUES (1987, 759322, 195, 'ML2_129885');
INSERT INTO art_poisson_mesure VALUES (1988, 759319, 185, 'ML2_129885');
INSERT INTO art_poisson_mesure VALUES (1989, 759321, 155, 'ML2_129885');
INSERT INTO art_poisson_mesure VALUES (1990, 759320, 160, 'ML2_129885');
INSERT INTO art_poisson_mesure VALUES (1991, 759326, 380, 'ML2_129886');
INSERT INTO art_poisson_mesure VALUES (1992, 759325, 230, 'ML2_129886');
INSERT INTO art_poisson_mesure VALUES (1993, 759330, 335, 'ML2_129887');
INSERT INTO art_poisson_mesure VALUES (1994, 759327, 350, 'ML2_129886');
INSERT INTO art_poisson_mesure VALUES (1995, 759329, 345, 'ML2_129887');
INSERT INTO art_poisson_mesure VALUES (1996, 759328, 295, 'ML2_129887');
INSERT INTO art_poisson_mesure VALUES (1997, 759352, 320, 'ML2_129890');
INSERT INTO art_poisson_mesure VALUES (1998, 759342, 215, 'ML2_129889');
INSERT INTO art_poisson_mesure VALUES (1999, 759351, 350, 'ML2_129890');
INSERT INTO art_poisson_mesure VALUES (2000, 759341, 205, 'ML2_129889');
INSERT INTO art_poisson_mesure VALUES (2001, 759331, 235, 'ML2_129888');
INSERT INTO art_poisson_mesure VALUES (2002, 759340, 245, 'ML2_129888');
INSERT INTO art_poisson_mesure VALUES (2003, 759333, 195, 'ML2_129888');
INSERT INTO art_poisson_mesure VALUES (2004, 759339, 240, 'ML2_129888');
INSERT INTO art_poisson_mesure VALUES (2005, 759332, 240, 'ML2_129888');
INSERT INTO art_poisson_mesure VALUES (2006, 759334, 215, 'ML2_129888');
INSERT INTO art_poisson_mesure VALUES (2007, 759338, 235, 'ML2_129888');
INSERT INTO art_poisson_mesure VALUES (2008, 759335, 200, 'ML2_129888');
INSERT INTO art_poisson_mesure VALUES (2009, 759337, 250, 'ML2_129888');
INSERT INTO art_poisson_mesure VALUES (2010, 759336, 260, 'ML2_129888');
INSERT INTO art_poisson_mesure VALUES (2011, 759348, 190, 'ML2_129889');
INSERT INTO art_poisson_mesure VALUES (2012, 759343, 175, 'ML2_129889');
INSERT INTO art_poisson_mesure VALUES (2013, 759349, 185, 'ML2_129889');
INSERT INTO art_poisson_mesure VALUES (2014, 759350, 270, 'ML2_129889');
INSERT INTO art_poisson_mesure VALUES (2015, 759347, 195, 'ML2_129889');
INSERT INTO art_poisson_mesure VALUES (2016, 759344, 230, 'ML2_129889');
INSERT INTO art_poisson_mesure VALUES (2017, 759346, 200, 'ML2_129889');
INSERT INTO art_poisson_mesure VALUES (2018, 759345, 220, 'ML2_129889');
INSERT INTO art_poisson_mesure VALUES (2019, 759353, 300, 'ML2_129891');
INSERT INTO art_poisson_mesure VALUES (2020, 759365, 250, 'ML2_129892');
INSERT INTO art_poisson_mesure VALUES (2021, 759366, 240, 'ML2_129892');
INSERT INTO art_poisson_mesure VALUES (2022, 759367, 185, 'ML2_129892');
INSERT INTO art_poisson_mesure VALUES (2023, 759368, 260, 'ML2_129892');
INSERT INTO art_poisson_mesure VALUES (2024, 759370, 300, 'ML2_129892');
INSERT INTO art_poisson_mesure VALUES (2025, 759369, 285, 'ML2_129892');
INSERT INTO art_poisson_mesure VALUES (2026, 759371, 235, 'ML2_129892');
INSERT INTO art_poisson_mesure VALUES (2027, 759374, 380, 'ML2_129894');
INSERT INTO art_poisson_mesure VALUES (2028, 759373, 290, 'ML2_129893');
INSERT INTO art_poisson_mesure VALUES (2029, 759372, 200, 'ML2_129892');
INSERT INTO art_poisson_mesure VALUES (2030, 759364, 270, 'ML2_129892');
INSERT INTO art_poisson_mesure VALUES (2031, 759363, 220, 'ML2_129892');
INSERT INTO art_poisson_mesure VALUES (2032, 759362, 275, 'ML2_129891');
INSERT INTO art_poisson_mesure VALUES (2033, 759361, 270, 'ML2_129891');
INSERT INTO art_poisson_mesure VALUES (2034, 759360, 285, 'ML2_129891');
INSERT INTO art_poisson_mesure VALUES (2035, 759354, 220, 'ML2_129891');
INSERT INTO art_poisson_mesure VALUES (2036, 759359, 245, 'ML2_129891');
INSERT INTO art_poisson_mesure VALUES (2037, 759358, 195, 'ML2_129891');
INSERT INTO art_poisson_mesure VALUES (2038, 759355, 250, 'ML2_129891');
INSERT INTO art_poisson_mesure VALUES (2039, 759357, 215, 'ML2_129891');
INSERT INTO art_poisson_mesure VALUES (2040, 759356, 265, 'ML2_129891');
INSERT INTO art_poisson_mesure VALUES (2041, 759391, 330, 'ML2_129897');
INSERT INTO art_poisson_mesure VALUES (2042, 759395, 235, 'ML2_129898');
INSERT INTO art_poisson_mesure VALUES (2043, 759390, 375, 'ML2_129896');
INSERT INTO art_poisson_mesure VALUES (2044, 759389, 295, 'ML2_129896');
INSERT INTO art_poisson_mesure VALUES (2045, 759397, 200, 'ML2_129898');
INSERT INTO art_poisson_mesure VALUES (2046, 759396, 195, 'ML2_129898');
INSERT INTO art_poisson_mesure VALUES (2047, 759398, 210, 'ML2_129898');
INSERT INTO art_poisson_mesure VALUES (2048, 759388, 320, 'ML2_129896');
INSERT INTO art_poisson_mesure VALUES (2049, 759399, 230, 'ML2_129898');
INSERT INTO art_poisson_mesure VALUES (2050, 759385, 350, 'ML2_129896');
INSERT INTO art_poisson_mesure VALUES (2051, 759384, 165, 'ML2_129895');
INSERT INTO art_poisson_mesure VALUES (2052, 759375, 175, 'ML2_129895');
INSERT INTO art_poisson_mesure VALUES (2053, 759378, 185, 'ML2_129895');
INSERT INTO art_poisson_mesure VALUES (2054, 759383, 255, 'ML2_129895');
INSERT INTO art_poisson_mesure VALUES (2055, 759377, 150, 'ML2_129895');
INSERT INTO art_poisson_mesure VALUES (2056, 759376, 145, 'ML2_129895');
INSERT INTO art_poisson_mesure VALUES (2057, 759379, 260, 'ML2_129895');
INSERT INTO art_poisson_mesure VALUES (2058, 759382, 190, 'ML2_129895');
INSERT INTO art_poisson_mesure VALUES (2059, 759381, 225, 'ML2_129895');
INSERT INTO art_poisson_mesure VALUES (2060, 759380, 235, 'ML2_129895');
INSERT INTO art_poisson_mesure VALUES (2061, 759386, 335, 'ML2_129896');
INSERT INTO art_poisson_mesure VALUES (2062, 759412, 150, 'ML2_129899');
INSERT INTO art_poisson_mesure VALUES (2063, 759387, 340, 'ML2_129896');
INSERT INTO art_poisson_mesure VALUES (2064, 759400, 260, 'ML2_129898');
INSERT INTO art_poisson_mesure VALUES (2065, 759403, 300, 'ML2_129898');
INSERT INTO art_poisson_mesure VALUES (2066, 759402, 285, 'ML2_129898');
INSERT INTO art_poisson_mesure VALUES (2067, 759401, 225, 'ML2_129898');
INSERT INTO art_poisson_mesure VALUES (2068, 759405, 165, 'ML2_129899');
INSERT INTO art_poisson_mesure VALUES (2069, 759406, 150, 'ML2_129899');
INSERT INTO art_poisson_mesure VALUES (2070, 759404, 290, 'ML2_129898');
INSERT INTO art_poisson_mesure VALUES (2071, 759411, 165, 'ML2_129899');
INSERT INTO art_poisson_mesure VALUES (2072, 759410, 185, 'ML2_129899');
INSERT INTO art_poisson_mesure VALUES (2073, 759407, 165, 'ML2_129899');
INSERT INTO art_poisson_mesure VALUES (2074, 759409, 220, 'ML2_129899');
INSERT INTO art_poisson_mesure VALUES (2075, 759408, 175, 'ML2_129899');
INSERT INTO art_poisson_mesure VALUES (2076, 759414, 190, 'ML2_129899');
INSERT INTO art_poisson_mesure VALUES (2077, 759413, 145, 'ML2_129899');
INSERT INTO art_poisson_mesure VALUES (2078, 759394, 320, 'ML2_129897');
INSERT INTO art_poisson_mesure VALUES (2079, 759393, 320, 'ML2_129897');
INSERT INTO art_poisson_mesure VALUES (2080, 759392, 335, 'ML2_129897');
INSERT INTO art_poisson_mesure VALUES (2081, 759432, 234, 'ML2_129902');
INSERT INTO art_poisson_mesure VALUES (2082, 759431, 340, 'ML2_129902');
INSERT INTO art_poisson_mesure VALUES (2083, 759430, 220, 'ML2_129902');
INSERT INTO art_poisson_mesure VALUES (2084, 759429, 295, 'ML2_129902');
INSERT INTO art_poisson_mesure VALUES (2085, 759428, 215, 'ML2_129901');
INSERT INTO art_poisson_mesure VALUES (2086, 759419, 230, 'ML2_129901');
INSERT INTO art_poisson_mesure VALUES (2087, 759415, 350, 'ML2_129900');
INSERT INTO art_poisson_mesure VALUES (2088, 759418, 360, 'ML2_129900');
INSERT INTO art_poisson_mesure VALUES (2089, 759417, 295, 'ML2_129900');
INSERT INTO art_poisson_mesure VALUES (2090, 759416, 335, 'ML2_129900');
INSERT INTO art_poisson_mesure VALUES (2091, 759420, 180, 'ML2_129901');
INSERT INTO art_poisson_mesure VALUES (2092, 759422, 225, 'ML2_129901');
INSERT INTO art_poisson_mesure VALUES (2093, 759427, 240, 'ML2_129901');
INSERT INTO art_poisson_mesure VALUES (2094, 759421, 210, 'ML2_129901');
INSERT INTO art_poisson_mesure VALUES (2095, 759423, 230, 'ML2_129901');
INSERT INTO art_poisson_mesure VALUES (2096, 759426, 200, 'ML2_129901');
INSERT INTO art_poisson_mesure VALUES (2097, 759425, 195, 'ML2_129901');
INSERT INTO art_poisson_mesure VALUES (2098, 759424, 240, 'ML2_129901');
INSERT INTO art_poisson_mesure VALUES (2099, 759434, 200, 'ML2_129902');
INSERT INTO art_poisson_mesure VALUES (2100, 759435, 310, 'ML2_129903');
INSERT INTO art_poisson_mesure VALUES (2101, 759433, 225, 'ML2_129902');
INSERT INTO art_poisson_mesure VALUES (2102, 759437, 350, 'ML2_129903');
INSERT INTO art_poisson_mesure VALUES (2103, 759436, 320, 'ML2_129903');
INSERT INTO art_poisson_mesure VALUES (2104, 759460, 160, 'ML2_129906');
INSERT INTO art_poisson_mesure VALUES (2105, 759459, 170, 'ML2_129906');
INSERT INTO art_poisson_mesure VALUES (2106, 759461, 135, 'ML2_129906');
INSERT INTO art_poisson_mesure VALUES (2107, 759447, 210, 'ML2_129904');
INSERT INTO art_poisson_mesure VALUES (2108, 759464, 160, 'ML2_129906');
INSERT INTO art_poisson_mesure VALUES (2109, 759458, 140, 'ML2_129906');
INSERT INTO art_poisson_mesure VALUES (2110, 759463, 175, 'ML2_129906');
INSERT INTO art_poisson_mesure VALUES (2111, 759456, 150, 'ML2_129905');
INSERT INTO art_poisson_mesure VALUES (2112, 759457, 185, 'ML2_129905');
INSERT INTO art_poisson_mesure VALUES (2113, 759462, 120, 'ML2_129906');
INSERT INTO art_poisson_mesure VALUES (2114, 759446, 165, 'ML2_129904');
INSERT INTO art_poisson_mesure VALUES (2115, 759438, 220, 'ML2_129904');
INSERT INTO art_poisson_mesure VALUES (2116, 759445, 190, 'ML2_129904');
INSERT INTO art_poisson_mesure VALUES (2117, 759440, 155, 'ML2_129904');
INSERT INTO art_poisson_mesure VALUES (2118, 759439, 185, 'ML2_129904');
INSERT INTO art_poisson_mesure VALUES (2119, 759444, 175, 'ML2_129904');
INSERT INTO art_poisson_mesure VALUES (2120, 759441, 160, 'ML2_129904');
INSERT INTO art_poisson_mesure VALUES (2121, 759443, 200, 'ML2_129904');
INSERT INTO art_poisson_mesure VALUES (2122, 759442, 230, 'ML2_129904');
INSERT INTO art_poisson_mesure VALUES (2123, 759465, 150, 'ML2_129906');
INSERT INTO art_poisson_mesure VALUES (2124, 759448, 165, 'ML2_129905');
INSERT INTO art_poisson_mesure VALUES (2125, 759455, 140, 'ML2_129905');
INSERT INTO art_poisson_mesure VALUES (2126, 759454, 170, 'ML2_129905');
INSERT INTO art_poisson_mesure VALUES (2127, 759450, 150, 'ML2_129905');
INSERT INTO art_poisson_mesure VALUES (2128, 759449, 150, 'ML2_129905');
INSERT INTO art_poisson_mesure VALUES (2129, 759452, 155, 'ML2_129905');
INSERT INTO art_poisson_mesure VALUES (2130, 759453, 160, 'ML2_129905');
INSERT INTO art_poisson_mesure VALUES (2131, 759451, 180, 'ML2_129905');
INSERT INTO art_poisson_mesure VALUES (2132, 759466, 220, 'ML2_129906');
INSERT INTO art_poisson_mesure VALUES (2133, 759467, 200, 'ML2_129906');
INSERT INTO art_poisson_mesure VALUES (2134, 759489, 165, 'ML2_129909');
INSERT INTO art_poisson_mesure VALUES (2135, 759488, 175, 'ML2_129909');
INSERT INTO art_poisson_mesure VALUES (2136, 759471, 175, 'ML2_129907');
INSERT INTO art_poisson_mesure VALUES (2137, 759470, 185, 'ML2_129907');
INSERT INTO art_poisson_mesure VALUES (2138, 759469, 185, 'ML2_129907');
INSERT INTO art_poisson_mesure VALUES (2139, 759468, 135, 'ML2_129907');
INSERT INTO art_poisson_mesure VALUES (2140, 759472, 200, 'ML2_129907');
INSERT INTO art_poisson_mesure VALUES (2141, 759487, 180, 'ML2_129909');
INSERT INTO art_poisson_mesure VALUES (2142, 759478, 200, 'ML2_129908');
INSERT INTO art_poisson_mesure VALUES (2143, 759473, 145, 'ML2_129907');
INSERT INTO art_poisson_mesure VALUES (2144, 759474, 150, 'ML2_129907');
INSERT INTO art_poisson_mesure VALUES (2145, 759477, 150, 'ML2_129907');
INSERT INTO art_poisson_mesure VALUES (2146, 759476, 220, 'ML2_129907');
INSERT INTO art_poisson_mesure VALUES (2147, 759475, 230, 'ML2_129907');
INSERT INTO art_poisson_mesure VALUES (2148, 759481, 160, 'ML2_129908');
INSERT INTO art_poisson_mesure VALUES (2149, 759486, 170, 'ML2_129909');
INSERT INTO art_poisson_mesure VALUES (2150, 759480, 190, 'ML2_129908');
INSERT INTO art_poisson_mesure VALUES (2151, 759479, 195, 'ML2_129908');
INSERT INTO art_poisson_mesure VALUES (2152, 759482, 175, 'ML2_129908');
INSERT INTO art_poisson_mesure VALUES (2153, 759485, 185, 'ML2_129908');
INSERT INTO art_poisson_mesure VALUES (2154, 759484, 190, 'ML2_129908');
INSERT INTO art_poisson_mesure VALUES (2155, 759483, 180, 'ML2_129908');
INSERT INTO art_poisson_mesure VALUES (2156, 759493, 110, 'ML2_129909');
INSERT INTO art_poisson_mesure VALUES (2157, 759492, 110, 'ML2_129909');
INSERT INTO art_poisson_mesure VALUES (2158, 759502, 130, 'ML2_129910');
INSERT INTO art_poisson_mesure VALUES (2159, 759491, 130, 'ML2_129909');
INSERT INTO art_poisson_mesure VALUES (2160, 759490, 150, 'ML2_129909');
INSERT INTO art_poisson_mesure VALUES (2161, 759495, 120, 'ML2_129909');
INSERT INTO art_poisson_mesure VALUES (2162, 759496, 140, 'ML2_129910');
INSERT INTO art_poisson_mesure VALUES (2163, 759494, 155, 'ML2_129909');
INSERT INTO art_poisson_mesure VALUES (2164, 759501, 150, 'ML2_129910');
INSERT INTO art_poisson_mesure VALUES (2165, 759497, 120, 'ML2_129910');
INSERT INTO art_poisson_mesure VALUES (2166, 759500, 130, 'ML2_129910');
INSERT INTO art_poisson_mesure VALUES (2167, 759499, 160, 'ML2_129910');
INSERT INTO art_poisson_mesure VALUES (2168, 759498, 150, 'ML2_129910');
INSERT INTO art_poisson_mesure VALUES (2169, 759504, 110, 'ML2_129910');
INSERT INTO art_poisson_mesure VALUES (2170, 759503, 120, 'ML2_129910');
INSERT INTO art_poisson_mesure VALUES (2171, 759505, 145, 'ML2_129910');
INSERT INTO art_poisson_mesure VALUES (2172, 759553, 160, 'ML2_129916');
INSERT INTO art_poisson_mesure VALUES (2173, 759554, 170, 'ML2_129916');
INSERT INTO art_poisson_mesure VALUES (2174, 759555, 160, 'ML2_129916');
INSERT INTO art_poisson_mesure VALUES (2175, 759552, 150, 'ML2_129916');
INSERT INTO art_poisson_mesure VALUES (2176, 759551, 175, 'ML2_129916');
INSERT INTO art_poisson_mesure VALUES (2177, 759559, 180, 'ML2_129916');
INSERT INTO art_poisson_mesure VALUES (2178, 759558, 160, 'ML2_129916');
INSERT INTO art_poisson_mesure VALUES (2179, 759519, 175, 'ML2_129912');
INSERT INTO art_poisson_mesure VALUES (2180, 759550, 175, 'ML2_129915');
INSERT INTO art_poisson_mesure VALUES (2181, 759509, 120, 'ML2_129911');
INSERT INTO art_poisson_mesure VALUES (2182, 759518, 180, 'ML2_129912');
INSERT INTO art_poisson_mesure VALUES (2183, 759508, 110, 'ML2_129911');
INSERT INTO art_poisson_mesure VALUES (2184, 759507, 150, 'ML2_129911');
INSERT INTO art_poisson_mesure VALUES (2185, 759506, 150, 'ML2_129911');
INSERT INTO art_poisson_mesure VALUES (2186, 759512, 130, 'ML2_129911');
INSERT INTO art_poisson_mesure VALUES (2187, 759517, 135, 'ML2_129912');
INSERT INTO art_poisson_mesure VALUES (2188, 759511, 150, 'ML2_129911');
INSERT INTO art_poisson_mesure VALUES (2189, 759510, 160, 'ML2_129911');
INSERT INTO art_poisson_mesure VALUES (2190, 759516, 130, 'ML2_129912');
INSERT INTO art_poisson_mesure VALUES (2191, 759513, 155, 'ML2_129911');
INSERT INTO art_poisson_mesure VALUES (2192, 759515, 140, 'ML2_129911');
INSERT INTO art_poisson_mesure VALUES (2193, 759514, 200, 'ML2_129911');
INSERT INTO art_poisson_mesure VALUES (2194, 759557, 150, 'ML2_129916');
INSERT INTO art_poisson_mesure VALUES (2195, 759549, 150, 'ML2_129915');
INSERT INTO art_poisson_mesure VALUES (2196, 759523, 110, 'ML2_129912');
INSERT INTO art_poisson_mesure VALUES (2197, 759533, 160, 'ML2_129913');
INSERT INTO art_poisson_mesure VALUES (2198, 759521, 120, 'ML2_129912');
INSERT INTO art_poisson_mesure VALUES (2199, 759522, 145, 'ML2_129912');
INSERT INTO art_poisson_mesure VALUES (2200, 759520, 160, 'ML2_129912');
INSERT INTO art_poisson_mesure VALUES (2201, 759524, 135, 'ML2_129912');
INSERT INTO art_poisson_mesure VALUES (2202, 759525, 100, 'ML2_129912');
INSERT INTO art_poisson_mesure VALUES (2203, 759532, 150, 'ML2_129913');
INSERT INTO art_poisson_mesure VALUES (2204, 759527, 210, 'ML2_129913');
INSERT INTO art_poisson_mesure VALUES (2205, 759526, 150, 'ML2_129913');
INSERT INTO art_poisson_mesure VALUES (2206, 759531, 185, 'ML2_129913');
INSERT INTO art_poisson_mesure VALUES (2207, 759528, 200, 'ML2_129913');
INSERT INTO art_poisson_mesure VALUES (2208, 759530, 170, 'ML2_129913');
INSERT INTO art_poisson_mesure VALUES (2209, 759529, 195, 'ML2_129913');
INSERT INTO art_poisson_mesure VALUES (2210, 759539, 295, 'ML2_129914');
INSERT INTO art_poisson_mesure VALUES (2211, 759548, 155, 'ML2_129915');
INSERT INTO art_poisson_mesure VALUES (2212, 759556, 155, 'ML2_129916');
INSERT INTO art_poisson_mesure VALUES (2213, 759534, 175, 'ML2_129913');
INSERT INTO art_poisson_mesure VALUES (2214, 759538, 235, 'ML2_129914');
INSERT INTO art_poisson_mesure VALUES (2215, 759535, 185, 'ML2_129913');
INSERT INTO art_poisson_mesure VALUES (2216, 759537, 360, 'ML2_129914');
INSERT INTO art_poisson_mesure VALUES (2217, 759536, 350, 'ML2_129914');
INSERT INTO art_poisson_mesure VALUES (2218, 759547, 160, 'ML2_129915');
INSERT INTO art_poisson_mesure VALUES (2219, 759542, 180, 'ML2_129915');
INSERT INTO art_poisson_mesure VALUES (2220, 759541, 185, 'ML2_129915');
INSERT INTO art_poisson_mesure VALUES (2221, 759540, 345, 'ML2_129914');
INSERT INTO art_poisson_mesure VALUES (2222, 759546, 170, 'ML2_129915');
INSERT INTO art_poisson_mesure VALUES (2223, 759543, 175, 'ML2_129915');
INSERT INTO art_poisson_mesure VALUES (2224, 759544, 165, 'ML2_129915');
INSERT INTO art_poisson_mesure VALUES (2225, 759545, 160, 'ML2_129915');
INSERT INTO art_poisson_mesure VALUES (2226, 759561, 110, 'ML2_129917');
INSERT INTO art_poisson_mesure VALUES (2227, 759560, 175, 'ML2_129916');
INSERT INTO art_poisson_mesure VALUES (2228, 759562, 160, 'ML2_129917');
INSERT INTO art_poisson_mesure VALUES (2229, 759563, 120, 'ML2_129917');
INSERT INTO art_poisson_mesure VALUES (2230, 759568, 150, 'ML2_129917');
INSERT INTO art_poisson_mesure VALUES (2231, 759567, 155, 'ML2_129917');
INSERT INTO art_poisson_mesure VALUES (2232, 759566, 130, 'ML2_129917');
INSERT INTO art_poisson_mesure VALUES (2233, 759565, 135, 'ML2_129917');
INSERT INTO art_poisson_mesure VALUES (2234, 759564, 145, 'ML2_129917');
INSERT INTO art_poisson_mesure VALUES (2235, 759570, 170, 'ML2_129917');
INSERT INTO art_poisson_mesure VALUES (2236, 759575, 185, 'ML2_129918');
INSERT INTO art_poisson_mesure VALUES (2237, 759569, 140, 'ML2_129917');
INSERT INTO art_poisson_mesure VALUES (2238, 759574, 170, 'ML2_129918');
INSERT INTO art_poisson_mesure VALUES (2239, 759571, 200, 'ML2_129918');
INSERT INTO art_poisson_mesure VALUES (2240, 759572, 165, 'ML2_129918');
INSERT INTO art_poisson_mesure VALUES (2241, 759573, 175, 'ML2_129918');
INSERT INTO art_poisson_mesure VALUES (2242, 759578, 210, 'ML2_129918');
INSERT INTO art_poisson_mesure VALUES (2243, 759576, 180, 'ML2_129918');
INSERT INTO art_poisson_mesure VALUES (2244, 759577, 195, 'ML2_129918');
INSERT INTO art_poisson_mesure VALUES (2245, 759579, 220, 'ML2_129918');
INSERT INTO art_poisson_mesure VALUES (2246, 759580, 215, 'ML2_129918');
INSERT INTO art_poisson_mesure VALUES (2247, 759585, 210, 'ML2_129919');
INSERT INTO art_poisson_mesure VALUES (2248, 759584, 190, 'ML2_129919');
INSERT INTO art_poisson_mesure VALUES (2249, 759583, 200, 'ML2_129919');
INSERT INTO art_poisson_mesure VALUES (2250, 759582, 180, 'ML2_129919');
INSERT INTO art_poisson_mesure VALUES (2251, 759581, 220, 'ML2_129919');
INSERT INTO art_poisson_mesure VALUES (2252, 759591, 295, 'ML2_129920');
INSERT INTO art_poisson_mesure VALUES (2253, 759588, 195, 'ML2_129919');
INSERT INTO art_poisson_mesure VALUES (2254, 759587, 200, 'ML2_129919');
INSERT INTO art_poisson_mesure VALUES (2255, 759586, 210, 'ML2_129919');
INSERT INTO art_poisson_mesure VALUES (2256, 759600, 340, 'ML2_129921');
INSERT INTO art_poisson_mesure VALUES (2257, 759590, 215, 'ML2_129919');
INSERT INTO art_poisson_mesure VALUES (2258, 759589, 195, 'ML2_129919');
INSERT INTO art_poisson_mesure VALUES (2259, 759594, 320, 'ML2_129920');
INSERT INTO art_poisson_mesure VALUES (2260, 759599, 330, 'ML2_129921');
INSERT INTO art_poisson_mesure VALUES (2261, 759593, 340, 'ML2_129920');
INSERT INTO art_poisson_mesure VALUES (2262, 759592, 330, 'ML2_129920');
INSERT INTO art_poisson_mesure VALUES (2263, 759595, 350, 'ML2_129920');
INSERT INTO art_poisson_mesure VALUES (2264, 759598, 350, 'ML2_129920');
INSERT INTO art_poisson_mesure VALUES (2265, 759597, 300, 'ML2_129920');
INSERT INTO art_poisson_mesure VALUES (2266, 759596, 275, 'ML2_129920');
INSERT INTO art_poisson_mesure VALUES (2267, 759602, 250, 'ML2_129921');
INSERT INTO art_poisson_mesure VALUES (2268, 759601, 285, 'ML2_129921');
INSERT INTO art_poisson_mesure VALUES (2269, 759603, 265, 'ML2_129921');
INSERT INTO art_poisson_mesure VALUES (2270, 759604, 305, 'ML2_129921');
INSERT INTO art_poisson_mesure VALUES (2271, 759618, 130, 'ML2_129923');
INSERT INTO art_poisson_mesure VALUES (2272, 759617, 165, 'ML2_129923');
INSERT INTO art_poisson_mesure VALUES (2273, 759607, 185, 'ML2_129922');
INSERT INTO art_poisson_mesure VALUES (2274, 759616, 140, 'ML2_129923');
INSERT INTO art_poisson_mesure VALUES (2275, 759606, 190, 'ML2_129922');
INSERT INTO art_poisson_mesure VALUES (2276, 759605, 210, 'ML2_129922');
INSERT INTO art_poisson_mesure VALUES (2277, 759609, 220, 'ML2_129922');
INSERT INTO art_poisson_mesure VALUES (2278, 759610, 200, 'ML2_129922');
INSERT INTO art_poisson_mesure VALUES (2279, 759608, 210, 'ML2_129922');
INSERT INTO art_poisson_mesure VALUES (2280, 759615, 160, 'ML2_129923');
INSERT INTO art_poisson_mesure VALUES (2281, 759614, 230, 'ML2_129922');
INSERT INTO art_poisson_mesure VALUES (2282, 759611, 195, 'ML2_129922');
INSERT INTO art_poisson_mesure VALUES (2283, 759612, 165, 'ML2_129922');
INSERT INTO art_poisson_mesure VALUES (2284, 759613, 175, 'ML2_129922');
INSERT INTO art_poisson_mesure VALUES (2285, 759628, 130, 'ML2_129924');
INSERT INTO art_poisson_mesure VALUES (2286, 759623, 160, 'ML2_129923');
INSERT INTO art_poisson_mesure VALUES (2287, 759619, 155, 'ML2_129923');
INSERT INTO art_poisson_mesure VALUES (2288, 759621, 160, 'ML2_129923');
INSERT INTO art_poisson_mesure VALUES (2289, 759622, 150, 'ML2_129923');
INSERT INTO art_poisson_mesure VALUES (2290, 759620, 170, 'ML2_129923');
INSERT INTO art_poisson_mesure VALUES (2291, 759627, 120, 'ML2_129924');
INSERT INTO art_poisson_mesure VALUES (2292, 759626, 110, 'ML2_129924');
INSERT INTO art_poisson_mesure VALUES (2293, 759625, 135, 'ML2_129924');
INSERT INTO art_poisson_mesure VALUES (2294, 759624, 165, 'ML2_129923');
INSERT INTO art_poisson_mesure VALUES (2295, 759635, 140, 'ML2_129925');
INSERT INTO art_poisson_mesure VALUES (2296, 759629, 175, 'ML2_129924');
INSERT INTO art_poisson_mesure VALUES (2297, 759630, 170, 'ML2_129924');
INSERT INTO art_poisson_mesure VALUES (2298, 759644, 175, 'ML2_129925');
INSERT INTO art_poisson_mesure VALUES (2299, 759634, 140, 'ML2_129924');
INSERT INTO art_poisson_mesure VALUES (2300, 759631, 135, 'ML2_129924');
INSERT INTO art_poisson_mesure VALUES (2301, 759633, 140, 'ML2_129924');
INSERT INTO art_poisson_mesure VALUES (2302, 759632, 145, 'ML2_129924');
INSERT INTO art_poisson_mesure VALUES (2303, 759638, 155, 'ML2_129925');
INSERT INTO art_poisson_mesure VALUES (2304, 759636, 165, 'ML2_129925');
INSERT INTO art_poisson_mesure VALUES (2305, 759643, 145, 'ML2_129925');
INSERT INTO art_poisson_mesure VALUES (2306, 759637, 160, 'ML2_129925');
INSERT INTO art_poisson_mesure VALUES (2307, 759642, 150, 'ML2_129925');
INSERT INTO art_poisson_mesure VALUES (2308, 759639, 145, 'ML2_129925');
INSERT INTO art_poisson_mesure VALUES (2309, 759641, 160, 'ML2_129925');
INSERT INTO art_poisson_mesure VALUES (2310, 759640, 170, 'ML2_129925');
INSERT INTO art_poisson_mesure VALUES (2311, 759645, 320, 'ML2_129926');
INSERT INTO art_poisson_mesure VALUES (2312, 759647, 280, 'ML2_129927');
INSERT INTO art_poisson_mesure VALUES (2313, 759656, 275, 'ML2_129928');
INSERT INTO art_poisson_mesure VALUES (2314, 759646, 600, 'ML2_129926');
INSERT INTO art_poisson_mesure VALUES (2315, 759655, 280, 'ML2_129928');
INSERT INTO art_poisson_mesure VALUES (2316, 759650, 195, 'ML2_129928');
INSERT INTO art_poisson_mesure VALUES (2317, 759648, 300, 'ML2_129927');
INSERT INTO art_poisson_mesure VALUES (2318, 759649, 320, 'ML2_129928');
INSERT INTO art_poisson_mesure VALUES (2319, 759651, 310, 'ML2_129928');
INSERT INTO art_poisson_mesure VALUES (2320, 759654, 295, 'ML2_129928');
INSERT INTO art_poisson_mesure VALUES (2321, 759652, 290, 'ML2_129928');
INSERT INTO art_poisson_mesure VALUES (2322, 759653, 285, 'ML2_129928');
INSERT INTO art_poisson_mesure VALUES (2323, 759657, 225, 'ML2_129928');
INSERT INTO art_poisson_mesure VALUES (2324, 759658, 280, 'ML2_129928');
INSERT INTO art_poisson_mesure VALUES (2325, 759697, 290, 'ML2_129933');
INSERT INTO art_poisson_mesure VALUES (2326, 759708, 210, 'ML2_129935');
INSERT INTO art_poisson_mesure VALUES (2327, 759709, 200, 'ML2_129935');
INSERT INTO art_poisson_mesure VALUES (2328, 759668, 110, 'ML2_129929');
INSERT INTO art_poisson_mesure VALUES (2329, 759707, 230, 'ML2_129935');
INSERT INTO art_poisson_mesure VALUES (2330, 759706, 225, 'ML2_129935');
INSERT INTO art_poisson_mesure VALUES (2331, 759669, 150, 'ML2_129930');
INSERT INTO art_poisson_mesure VALUES (2332, 759671, 200, 'ML2_129930');
INSERT INTO art_poisson_mesure VALUES (2333, 759670, 280, 'ML2_129930');
INSERT INTO art_poisson_mesure VALUES (2334, 759696, 240, 'ML2_129933');
INSERT INTO art_poisson_mesure VALUES (2335, 759674, 145, 'ML2_129930');
INSERT INTO art_poisson_mesure VALUES (2336, 759673, 165, 'ML2_129930');
INSERT INTO art_poisson_mesure VALUES (2337, 759672, 175, 'ML2_129930');
INSERT INTO art_poisson_mesure VALUES (2338, 759667, 145, 'ML2_129929');
INSERT INTO art_poisson_mesure VALUES (2339, 759677, 125, 'ML2_129930');
INSERT INTO art_poisson_mesure VALUES (2340, 759666, 130, 'ML2_129929');
INSERT INTO art_poisson_mesure VALUES (2341, 759675, 130, 'ML2_129930');
INSERT INTO art_poisson_mesure VALUES (2342, 759676, 120, 'ML2_129930');
INSERT INTO art_poisson_mesure VALUES (2343, 759695, 300, 'ML2_129933');
INSERT INTO art_poisson_mesure VALUES (2344, 759680, 455, 'ML2_129931');
INSERT INTO art_poisson_mesure VALUES (2345, 759665, 120, 'ML2_129929');
INSERT INTO art_poisson_mesure VALUES (2346, 759679, 310, 'ML2_129931');
INSERT INTO art_poisson_mesure VALUES (2347, 759678, 130, 'ML2_129930');
INSERT INTO art_poisson_mesure VALUES (2348, 759694, 310, 'ML2_129933');
INSERT INTO art_poisson_mesure VALUES (2349, 759664, 155, 'ML2_129929');
INSERT INTO art_poisson_mesure VALUES (2350, 759681, 435, 'ML2_129931');
INSERT INTO art_poisson_mesure VALUES (2351, 759682, 305, 'ML2_129931');
INSERT INTO art_poisson_mesure VALUES (2352, 759693, 240, 'ML2_129933');
INSERT INTO art_poisson_mesure VALUES (2353, 759683, 315, 'ML2_129931');
INSERT INTO art_poisson_mesure VALUES (2354, 759663, 150, 'ML2_129929');
INSERT INTO art_poisson_mesure VALUES (2355, 759661, 115, 'ML2_129929');
INSERT INTO art_poisson_mesure VALUES (2356, 759692, 320, 'ML2_129933');
INSERT INTO art_poisson_mesure VALUES (2357, 759684, 300, 'ML2_129931');
INSERT INTO art_poisson_mesure VALUES (2358, 759660, 135, 'ML2_129929');
INSERT INTO art_poisson_mesure VALUES (2359, 759659, 120, 'ML2_129929');
INSERT INTO art_poisson_mesure VALUES (2360, 759662, 140, 'ML2_129929');
INSERT INTO art_poisson_mesure VALUES (2361, 759685, 320, 'ML2_129931');
INSERT INTO art_poisson_mesure VALUES (2362, 759686, 330, 'ML2_129932');
INSERT INTO art_poisson_mesure VALUES (2363, 759691, 350, 'ML2_129932');
INSERT INTO art_poisson_mesure VALUES (2364, 759687, 310, 'ML2_129932');
INSERT INTO art_poisson_mesure VALUES (2365, 759690, 750, 'ML2_129932');
INSERT INTO art_poisson_mesure VALUES (2366, 759689, 390, 'ML2_129932');
INSERT INTO art_poisson_mesure VALUES (2367, 759688, 320, 'ML2_129932');
INSERT INTO art_poisson_mesure VALUES (2368, 759699, 210, 'ML2_129933');
INSERT INTO art_poisson_mesure VALUES (2369, 759702, 380, 'ML2_129934');
INSERT INTO art_poisson_mesure VALUES (2370, 759715, 230, 'ML2_129937');
INSERT INTO art_poisson_mesure VALUES (2371, 759716, 145, 'ML2_129937');
INSERT INTO art_poisson_mesure VALUES (2372, 759711, 190, 'ML2_129935');
INSERT INTO art_poisson_mesure VALUES (2373, 759703, 225, 'ML2_129935');
INSERT INTO art_poisson_mesure VALUES (2374, 759710, 230, 'ML2_129935');
INSERT INTO art_poisson_mesure VALUES (2375, 759704, 245, 'ML2_129935');
INSERT INTO art_poisson_mesure VALUES (2376, 759705, 215, 'ML2_129935');
INSERT INTO art_poisson_mesure VALUES (2377, 759714, 365, 'ML2_129936');
INSERT INTO art_poisson_mesure VALUES (2378, 759712, 185, 'ML2_129935');
INSERT INTO art_poisson_mesure VALUES (2379, 759713, 350, 'ML2_129936');
INSERT INTO art_poisson_mesure VALUES (2380, 759698, 230, 'ML2_129933');
INSERT INTO art_poisson_mesure VALUES (2381, 759720, 185, 'ML2_129937');
INSERT INTO art_poisson_mesure VALUES (2382, 759717, 160, 'ML2_129937');
INSERT INTO art_poisson_mesure VALUES (2383, 759701, 195, 'ML2_129933');
INSERT INTO art_poisson_mesure VALUES (2384, 759700, 320, 'ML2_129933');
INSERT INTO art_poisson_mesure VALUES (2385, 759719, 200, 'ML2_129937');
INSERT INTO art_poisson_mesure VALUES (2386, 759718, 140, 'ML2_129937');
INSERT INTO art_poisson_mesure VALUES (2387, 759723, 220, 'ML2_129937');
INSERT INTO art_poisson_mesure VALUES (2388, 759722, 150, 'ML2_129937');
INSERT INTO art_poisson_mesure VALUES (2389, 759721, 155, 'ML2_129937');
INSERT INTO art_poisson_mesure VALUES (2390, 759724, 165, 'ML2_129937');
INSERT INTO art_poisson_mesure VALUES (2391, 759726, 320, 'ML2_129938');
INSERT INTO art_poisson_mesure VALUES (2392, 759725, 360, 'ML2_129938');
INSERT INTO art_poisson_mesure VALUES (2393, 759747, 150, 'ML2_129943');
INSERT INTO art_poisson_mesure VALUES (2394, 759729, 205, 'ML2_129939');
INSERT INTO art_poisson_mesure VALUES (2395, 759746, 195, 'ML2_129942');
INSERT INTO art_poisson_mesure VALUES (2396, 759728, 210, 'ML2_129939');
INSERT INTO art_poisson_mesure VALUES (2397, 759727, 205, 'ML2_129939');
INSERT INTO art_poisson_mesure VALUES (2398, 759732, 205, 'ML2_129939');
INSERT INTO art_poisson_mesure VALUES (2399, 759734, 210, 'ML2_129939');
INSERT INTO art_poisson_mesure VALUES (2400, 759736, 210, 'ML2_129939');
INSERT INTO art_poisson_mesure VALUES (2401, 759731, 240, 'ML2_129939');
INSERT INTO art_poisson_mesure VALUES (2402, 759730, 250, 'ML2_129939');
INSERT INTO art_poisson_mesure VALUES (2403, 759745, 190, 'ML2_129942');
INSERT INTO art_poisson_mesure VALUES (2404, 759733, 200, 'ML2_129939');
INSERT INTO art_poisson_mesure VALUES (2405, 759735, 220, 'ML2_129939');
INSERT INTO art_poisson_mesure VALUES (2406, 759739, 175, 'ML2_129941');
INSERT INTO art_poisson_mesure VALUES (2407, 759738, 205, 'ML2_129940');
INSERT INTO art_poisson_mesure VALUES (2408, 759744, 210, 'ML2_129942');
INSERT INTO art_poisson_mesure VALUES (2409, 759737, 100, 'ML2_129940');
INSERT INTO art_poisson_mesure VALUES (2410, 759743, 210, 'ML2_129942');
INSERT INTO art_poisson_mesure VALUES (2411, 759740, 160, 'ML2_129941');
INSERT INTO art_poisson_mesure VALUES (2412, 759741, 215, 'ML2_129942');
INSERT INTO art_poisson_mesure VALUES (2413, 759742, 200, 'ML2_129942');
INSERT INTO art_poisson_mesure VALUES (2414, 759750, 175, 'ML2_129945');
INSERT INTO art_poisson_mesure VALUES (2415, 759749, 215, 'ML2_129944');
INSERT INTO art_poisson_mesure VALUES (2416, 759748, 190, 'ML2_129943');
INSERT INTO art_poisson_mesure VALUES (2417, 759759, 200, 'ML2_129946');
INSERT INTO art_poisson_mesure VALUES (2418, 759752, 225, 'ML2_129946');
INSERT INTO art_poisson_mesure VALUES (2419, 759751, 270, 'ML2_129946');
INSERT INTO art_poisson_mesure VALUES (2420, 759758, 230, 'ML2_129946');
INSERT INTO art_poisson_mesure VALUES (2421, 759753, 250, 'ML2_129946');
INSERT INTO art_poisson_mesure VALUES (2422, 759757, 250, 'ML2_129946');
INSERT INTO art_poisson_mesure VALUES (2423, 759754, 240, 'ML2_129946');
INSERT INTO art_poisson_mesure VALUES (2424, 759756, 200, 'ML2_129946');
INSERT INTO art_poisson_mesure VALUES (2425, 759755, 230, 'ML2_129946');
INSERT INTO art_poisson_mesure VALUES (2426, 759760, 600, 'ML2_129946');
INSERT INTO art_poisson_mesure VALUES (2427, 759761, 580, 'ML2_129947');
INSERT INTO art_poisson_mesure VALUES (2428, 759762, 295, 'ML2_129948');
INSERT INTO art_poisson_mesure VALUES (2429, 759764, 300, 'ML2_129948');
INSERT INTO art_poisson_mesure VALUES (2430, 759763, 300, 'ML2_129948');
INSERT INTO art_poisson_mesure VALUES (2431, 759791, 190, 'ML2_129953');
INSERT INTO art_poisson_mesure VALUES (2432, 759795, 225, 'ML2_129954');
INSERT INTO art_poisson_mesure VALUES (2433, 759792, 210, 'ML2_129954');
INSERT INTO art_poisson_mesure VALUES (2434, 759794, 235, 'ML2_129954');
INSERT INTO art_poisson_mesure VALUES (2435, 759793, 250, 'ML2_129954');
INSERT INTO art_poisson_mesure VALUES (2436, 759790, 140, 'ML2_129952');
INSERT INTO art_poisson_mesure VALUES (2437, 759788, 175, 'ML2_129952');
INSERT INTO art_poisson_mesure VALUES (2438, 759789, 180, 'ML2_129952');
INSERT INTO art_poisson_mesure VALUES (2439, 759776, 165, 'ML2_129950');
INSERT INTO art_poisson_mesure VALUES (2440, 759796, 240, 'ML2_129954');
INSERT INTO art_poisson_mesure VALUES (2441, 759787, 170, 'ML2_129952');
INSERT INTO art_poisson_mesure VALUES (2442, 759775, 160, 'ML2_129950');
INSERT INTO art_poisson_mesure VALUES (2443, 759766, 295, 'ML2_129949');
INSERT INTO art_poisson_mesure VALUES (2444, 759765, 350, 'ML2_129949');
INSERT INTO art_poisson_mesure VALUES (2445, 759767, 330, 'ML2_129949');
INSERT INTO art_poisson_mesure VALUES (2446, 759774, 170, 'ML2_129950');
INSERT INTO art_poisson_mesure VALUES (2447, 759769, 150, 'ML2_129950');
INSERT INTO art_poisson_mesure VALUES (2448, 759768, 320, 'ML2_129949');
INSERT INTO art_poisson_mesure VALUES (2449, 759773, 120, 'ML2_129950');
INSERT INTO art_poisson_mesure VALUES (2450, 759770, 150, 'ML2_129950');
INSERT INTO art_poisson_mesure VALUES (2451, 759772, 130, 'ML2_129950');
INSERT INTO art_poisson_mesure VALUES (2452, 759771, 155, 'ML2_129950');
INSERT INTO art_poisson_mesure VALUES (2453, 759785, 160, 'ML2_129952');
INSERT INTO art_poisson_mesure VALUES (2454, 759779, 340, 'ML2_129951');
INSERT INTO art_poisson_mesure VALUES (2455, 759801, 225, 'ML2_129954');
INSERT INTO art_poisson_mesure VALUES (2456, 759797, 215, 'ML2_129954');
INSERT INTO art_poisson_mesure VALUES (2457, 759786, 150, 'ML2_129952');
INSERT INTO art_poisson_mesure VALUES (2458, 759778, 130, 'ML2_129950');
INSERT INTO art_poisson_mesure VALUES (2459, 759777, 145, 'ML2_129950');
INSERT INTO art_poisson_mesure VALUES (2460, 759781, 165, 'ML2_129952');
INSERT INTO art_poisson_mesure VALUES (2461, 759784, 175, 'ML2_129952');
INSERT INTO art_poisson_mesure VALUES (2462, 759800, 180, 'ML2_129954');
INSERT INTO art_poisson_mesure VALUES (2463, 759780, 320, 'ML2_129951');
INSERT INTO art_poisson_mesure VALUES (2464, 759783, 150, 'ML2_129952');
INSERT INTO art_poisson_mesure VALUES (2465, 759799, 185, 'ML2_129954');
INSERT INTO art_poisson_mesure VALUES (2466, 759798, 195, 'ML2_129954');
INSERT INTO art_poisson_mesure VALUES (2467, 759782, 145, 'ML2_129952');
INSERT INTO art_poisson_mesure VALUES (2468, 759802, 175, 'ML2_129955');
INSERT INTO art_poisson_mesure VALUES (2469, 759808, 160, 'ML2_129955');
INSERT INTO art_poisson_mesure VALUES (2470, 759803, 130, 'ML2_129955');
INSERT INTO art_poisson_mesure VALUES (2471, 759807, 190, 'ML2_129955');
INSERT INTO art_poisson_mesure VALUES (2472, 759804, 180, 'ML2_129955');
INSERT INTO art_poisson_mesure VALUES (2473, 759806, 200, 'ML2_129955');
INSERT INTO art_poisson_mesure VALUES (2474, 759805, 185, 'ML2_129955');
INSERT INTO art_poisson_mesure VALUES (2475, 759810, 150, 'ML2_129955');
INSERT INTO art_poisson_mesure VALUES (2476, 759811, 175, 'ML2_129955');
INSERT INTO art_poisson_mesure VALUES (2477, 759809, 145, 'ML2_129955');
INSERT INTO art_poisson_mesure VALUES (2478, 759812, 195, 'ML2_129956');
INSERT INTO art_poisson_mesure VALUES (2479, 759814, 170, 'ML2_129958');
INSERT INTO art_poisson_mesure VALUES (2480, 759813, 220, 'ML2_129957');
INSERT INTO art_poisson_mesure VALUES (2481, 759820, 175, 'ML2_129960');
INSERT INTO art_poisson_mesure VALUES (2482, 759819, 180, 'ML2_129960');
INSERT INTO art_poisson_mesure VALUES (2483, 759818, 215, 'ML2_129960');
INSERT INTO art_poisson_mesure VALUES (2484, 759817, 220, 'ML2_129960');
INSERT INTO art_poisson_mesure VALUES (2485, 759816, 170, 'ML2_129959');
INSERT INTO art_poisson_mesure VALUES (2486, 759815, 175, 'ML2_129959');
INSERT INTO art_poisson_mesure VALUES (2487, 759823, 175, 'ML2_129960');
INSERT INTO art_poisson_mesure VALUES (2488, 759826, 150, 'ML2_129960');
INSERT INTO art_poisson_mesure VALUES (2489, 759843, 200, 'ML2_129965');
INSERT INTO art_poisson_mesure VALUES (2490, 759822, 160, 'ML2_129960');
INSERT INTO art_poisson_mesure VALUES (2491, 759821, 162, 'ML2_129960');
INSERT INTO art_poisson_mesure VALUES (2492, 759825, 180, 'ML2_129960');
INSERT INTO art_poisson_mesure VALUES (2493, 759824, 175, 'ML2_129960');
INSERT INTO art_poisson_mesure VALUES (2494, 759828, 225, 'ML2_129961');
INSERT INTO art_poisson_mesure VALUES (2495, 759833, 215, 'ML2_129963');
INSERT INTO art_poisson_mesure VALUES (2496, 759827, 230, 'ML2_129961');
INSERT INTO art_poisson_mesure VALUES (2497, 759842, 225, 'ML2_129965');
INSERT INTO art_poisson_mesure VALUES (2498, 759832, 260, 'ML2_129962');
INSERT INTO art_poisson_mesure VALUES (2499, 759829, 240, 'ML2_129961');
INSERT INTO art_poisson_mesure VALUES (2500, 759831, 260, 'ML2_129962');
INSERT INTO art_poisson_mesure VALUES (2501, 759830, 280, 'ML2_129962');
INSERT INTO art_poisson_mesure VALUES (2502, 759836, 300, 'ML2_129964');
INSERT INTO art_poisson_mesure VALUES (2503, 759835, 280, 'ML2_129964');
INSERT INTO art_poisson_mesure VALUES (2504, 759834, 305, 'ML2_129964');
INSERT INTO art_poisson_mesure VALUES (2505, 759841, 200, 'ML2_129965');
INSERT INTO art_poisson_mesure VALUES (2506, 759840, 210, 'ML2_129965');
INSERT INTO art_poisson_mesure VALUES (2507, 759837, 185, 'ML2_129965');
INSERT INTO art_poisson_mesure VALUES (2508, 759839, 210, 'ML2_129965');
INSERT INTO art_poisson_mesure VALUES (2509, 759838, 205, 'ML2_129965');
INSERT INTO art_poisson_mesure VALUES (2510, 759844, 190, 'ML2_129965');
INSERT INTO art_poisson_mesure VALUES (2511, 759846, 195, 'ML2_129965');
INSERT INTO art_poisson_mesure VALUES (2512, 759854, 185, 'ML2_129969');
INSERT INTO art_poisson_mesure VALUES (2513, 759845, 180, 'ML2_129965');
INSERT INTO art_poisson_mesure VALUES (2514, 759853, 195, 'ML2_129968');
INSERT INTO art_poisson_mesure VALUES (2515, 759848, 180, 'ML2_129966');
INSERT INTO art_poisson_mesure VALUES (2516, 759847, 240, 'ML2_129966');
INSERT INTO art_poisson_mesure VALUES (2517, 759852, 170, 'ML2_129967');
INSERT INTO art_poisson_mesure VALUES (2518, 759849, 170, 'ML2_129966');
INSERT INTO art_poisson_mesure VALUES (2519, 759851, 210, 'ML2_129967');
INSERT INTO art_poisson_mesure VALUES (2520, 759850, 340, 'ML2_129966');
INSERT INTO art_poisson_mesure VALUES (2521, 759872, 160, 'ML2_129973');
INSERT INTO art_poisson_mesure VALUES (2522, 759871, 170, 'ML2_129973');
INSERT INTO art_poisson_mesure VALUES (2523, 759869, 155, 'ML2_129972');
INSERT INTO art_poisson_mesure VALUES (2524, 759876, 210, 'ML2_129973');
INSERT INTO art_poisson_mesure VALUES (2525, 759870, 155, 'ML2_129973');
INSERT INTO art_poisson_mesure VALUES (2526, 759875, 130, 'ML2_129973');
INSERT INTO art_poisson_mesure VALUES (2527, 759873, 150, 'ML2_129973');
INSERT INTO art_poisson_mesure VALUES (2528, 759874, 140, 'ML2_129973');
INSERT INTO art_poisson_mesure VALUES (2529, 759878, 165, 'ML2_129973');
INSERT INTO art_poisson_mesure VALUES (2530, 759877, 160, 'ML2_129973');
INSERT INTO art_poisson_mesure VALUES (2531, 759867, 150, 'ML2_129972');
INSERT INTO art_poisson_mesure VALUES (2532, 759868, 145, 'ML2_129972');
INSERT INTO art_poisson_mesure VALUES (2533, 759881, 400, 'ML2_129974');
INSERT INTO art_poisson_mesure VALUES (2534, 759866, 130, 'ML2_129972');
INSERT INTO art_poisson_mesure VALUES (2535, 759880, 300, 'ML2_129974');
INSERT INTO art_poisson_mesure VALUES (2536, 759865, 145, 'ML2_129972');
INSERT INTO art_poisson_mesure VALUES (2537, 759856, 380, 'ML2_129970');
INSERT INTO art_poisson_mesure VALUES (2538, 759879, 150, 'ML2_129973');
INSERT INTO art_poisson_mesure VALUES (2539, 759882, 320, 'ML2_129974');
INSERT INTO art_poisson_mesure VALUES (2540, 759895, 120, 'ML2_129976');
INSERT INTO art_poisson_mesure VALUES (2541, 759857, 365, 'ML2_129970');
INSERT INTO art_poisson_mesure VALUES (2542, 759864, 170, 'ML2_129972');
INSERT INTO art_poisson_mesure VALUES (2543, 759883, 385, 'ML2_129974');
INSERT INTO art_poisson_mesure VALUES (2544, 759894, 110, 'ML2_129976');
INSERT INTO art_poisson_mesure VALUES (2545, 759855, 350, 'ML2_129970');
INSERT INTO art_poisson_mesure VALUES (2546, 759862, 125, 'ML2_129972');
INSERT INTO art_poisson_mesure VALUES (2547, 759893, 180, 'ML2_129975');
INSERT INTO art_poisson_mesure VALUES (2548, 759884, 195, 'ML2_129975');
INSERT INTO art_poisson_mesure VALUES (2549, 759863, 120, 'ML2_129972');
INSERT INTO art_poisson_mesure VALUES (2550, 759858, 375, 'ML2_129970');
INSERT INTO art_poisson_mesure VALUES (2551, 759861, 140, 'ML2_129972');
INSERT INTO art_poisson_mesure VALUES (2552, 759860, 160, 'ML2_129972');
INSERT INTO art_poisson_mesure VALUES (2553, 759859, 495, 'ML2_129971');
INSERT INTO art_poisson_mesure VALUES (2554, 759886, 160, 'ML2_129975');
INSERT INTO art_poisson_mesure VALUES (2555, 759887, 150, 'ML2_129975');
INSERT INTO art_poisson_mesure VALUES (2556, 759885, 180, 'ML2_129975');
INSERT INTO art_poisson_mesure VALUES (2557, 759892, 170, 'ML2_129975');
INSERT INTO art_poisson_mesure VALUES (2558, 759891, 190, 'ML2_129975');
INSERT INTO art_poisson_mesure VALUES (2559, 759888, 130, 'ML2_129975');
INSERT INTO art_poisson_mesure VALUES (2560, 759890, 150, 'ML2_129975');
INSERT INTO art_poisson_mesure VALUES (2561, 759889, 140, 'ML2_129975');
INSERT INTO art_poisson_mesure VALUES (2562, 759899, 115, 'ML2_129976');
INSERT INTO art_poisson_mesure VALUES (2563, 759900, 125, 'ML2_129976');
INSERT INTO art_poisson_mesure VALUES (2564, 759898, 105, 'ML2_129976');
INSERT INTO art_poisson_mesure VALUES (2565, 759896, 95, 'ML2_129976');
INSERT INTO art_poisson_mesure VALUES (2566, 759897, 110, 'ML2_129976');
INSERT INTO art_poisson_mesure VALUES (2567, 759903, 120, 'ML2_129976');
INSERT INTO art_poisson_mesure VALUES (2568, 759902, 90, 'ML2_129976');
INSERT INTO art_poisson_mesure VALUES (2569, 759901, 100, 'ML2_129976');
INSERT INTO art_poisson_mesure VALUES (2570, 759907, 270, 'ML2_129977');
INSERT INTO art_poisson_mesure VALUES (2571, 759904, 250, 'ML2_129977');
INSERT INTO art_poisson_mesure VALUES (2572, 759906, 260, 'ML2_129977');
INSERT INTO art_poisson_mesure VALUES (2573, 759905, 225, 'ML2_129977');
INSERT INTO art_poisson_mesure VALUES (2574, 759909, 350, 'ML2_129978');
INSERT INTO art_poisson_mesure VALUES (2575, 759926, 150, 'ML2_129980');
INSERT INTO art_poisson_mesure VALUES (2576, 759908, 330, 'ML2_129978');
INSERT INTO art_poisson_mesure VALUES (2577, 759912, 140, 'ML2_129979');
INSERT INTO art_poisson_mesure VALUES (2578, 759911, 125, 'ML2_129979');
INSERT INTO art_poisson_mesure VALUES (2579, 759910, 295, 'ML2_129978');
INSERT INTO art_poisson_mesure VALUES (2580, 759916, 115, 'ML2_129979');
INSERT INTO art_poisson_mesure VALUES (2581, 759925, 165, 'ML2_129980');
INSERT INTO art_poisson_mesure VALUES (2582, 759913, 125, 'ML2_129979');
INSERT INTO art_poisson_mesure VALUES (2583, 759915, 130, 'ML2_129979');
INSERT INTO art_poisson_mesure VALUES (2584, 759914, 115, 'ML2_129979');
INSERT INTO art_poisson_mesure VALUES (2585, 759918, 105, 'ML2_129979');
INSERT INTO art_poisson_mesure VALUES (2586, 759919, 100, 'ML2_129979');
INSERT INTO art_poisson_mesure VALUES (2587, 759917, 110, 'ML2_129979');
INSERT INTO art_poisson_mesure VALUES (2588, 759924, 155, 'ML2_129980');
INSERT INTO art_poisson_mesure VALUES (2589, 759920, 100, 'ML2_129979');
INSERT INTO art_poisson_mesure VALUES (2590, 759923, 140, 'ML2_129980');
INSERT INTO art_poisson_mesure VALUES (2591, 759922, 175, 'ML2_129980');
INSERT INTO art_poisson_mesure VALUES (2592, 759921, 150, 'ML2_129980');


--
-- Data for Name: art_stat_gt; Type: TABLE DATA; Schema: public; Owner: devppeao
--



--
-- Data for Name: art_stat_gt_sp; Type: TABLE DATA; Schema: public; Owner: devppeao
--



--
-- Data for Name: art_stat_sp; Type: TABLE DATA; Schema: public; Owner: devppeao
--



--
-- Data for Name: art_stat_totale; Type: TABLE DATA; Schema: public; Owner: devppeao
--



--
-- Data for Name: art_taille_gt_sp; Type: TABLE DATA; Schema: public; Owner: devppeao
--



--
-- Data for Name: art_taille_sp; Type: TABLE DATA; Schema: public; Owner: devppeao
--



--
-- Data for Name: art_type_activite; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_type_activite VALUES ('peche avec capture', 'unite de peche de retour de peche debarquant sa capture', '111');
INSERT INTO art_type_activite VALUES ('peche sans capture', 'unite de peche de retour de peche avec prise nulle', '112');
INSERT INTO art_type_activite VALUES ('retour de peche puis depart', 'unite de peche effectuant au cours de la meme journee un retour de peche puis un depart', '113');
INSERT INTO art_type_activite VALUES ('2 sorties de peche', 'unite de peche effectuant au cours de la meme journee 2 sorties de peche _ soit deux retours', '114');
INSERT INTO art_type_activite VALUES ('depart d une sortie de peche', 'unite de peche au depart d une sortie de peche', '121');
INSERT INTO art_type_activite VALUES ('autre engin utilise', 'unite de peche sortie avec un autre engin de peche que l habituel', '130');
INSERT INTO art_type_activite VALUES ('non peche sans explication', 'unite de peche  n ayant pas effectuee de sortie dans la journee sans explication', '200');
INSERT INTO art_type_activite VALUES ('environnement climatique', 'unite de peche  n ayant pas effectuee de sortie  pour une raison d environnement climatique', '210');
INSERT INTO art_type_activite VALUES ('pluie', 'unite de peche  n ayant pas effectuee de sortie dans la journee  pour des raisons de pluie', '211');
INSERT INTO art_type_activite VALUES ('vent violent', 'unite de peche  n ayant pas effectuee de sortie dans la journee pour cause de vent violent', '212');
INSERT INTO art_type_activite VALUES ('maree defavorable', 'unite de peche  n ayant pas effectuee de sortie dans la journee en raison de maree defavorable', '213');
INSERT INTO art_type_activite VALUES ('brouillard intense', 'unite de peche  n ayant pas effectuee de sortie dans la journee en raison de brouillard intense', '214');
INSERT INTO art_type_activite VALUES ('retard par rapport a la maree', 'unite de peche  n ayant pas effectuee de sortie dans la journee en retard par rapport a la maree', '215');
INSERT INTO art_type_activite VALUES ('casse du mat�riel', 'UP non sortie du fait d une casse du mat�riel', '220');
INSERT INTO art_type_activite VALUES ('moteur en panne', 'moteur en panne', '221');
INSERT INTO art_type_activite VALUES ('pirogue en reparation', 'pirogue en reparation', '222');
INSERT INTO art_type_activite VALUES ('filet ou ligne en reparation', 'filet ou ligne en reparation', '223');
INSERT INTO art_type_activite VALUES ('pas d essence', 'pas d essence', '224');
INSERT INTO art_type_activite VALUES ('manque ou recherche d appats', 'manque ou recherche d appats', '225');
INSERT INTO art_type_activite VALUES ('glaciere en reparation', 'glaciere en reparation', '226');
INSERT INTO art_type_activite VALUES ('pas de glace', 'pas de glace', '227');
INSERT INTO art_type_activite VALUES ('probleme equipage', 'UP non sortie en raison de probleme d equipage', '230');
INSERT INTO art_type_activite VALUES ('equipage incomplet ou malade', 'equipage incomplet ou malade', '231');
INSERT INTO art_type_activite VALUES ('equipage en travaux', 'equipage effectuant des travaux autre que la peche', '232');
INSERT INTO art_type_activite VALUES ('equipage en travaux champetres', 'equipage effectuant des travaux champetres', '233');
INSERT INTO art_type_activite VALUES ('equipage au repos', 'equipage au repos', '234');
INSERT INTO art_type_activite VALUES ('peche importante la veille', 'le resultat de la veille justifie la non sortie _ peche importante', '235');
INSERT INTO art_type_activite VALUES ('peche faible la veille', 'le resultat de la veille justifie la non sortie _ peche faible', '236');
INSERT INTO art_type_activite VALUES ('pas d argent', 'pas d argent pour financer la sortie', '237');
INSERT INTO art_type_activite VALUES ('contraintes villageoises', 'UP non sortie en raison de contraintes villageoises', '240');
INSERT INTO art_type_activite VALUES ('fetes civiles', 'fetes civiles', '241');
INSERT INTO art_type_activite VALUES ('fetes religieuses', 'fetes religieuses', '242');
INSERT INTO art_type_activite VALUES ('interdits sociaux', 'interdits sociaux', '243');
INSERT INTO art_type_activite VALUES ('reunions administratives', 'organisations de reunions administratives', '244');
INSERT INTO art_type_activite VALUES ('UP neuve non operationnelle', 'UP neuve, mais non encore operationnelle', '250');
INSERT INTO art_type_activite VALUES ('pret elements UP', 'elements de l unite de peche prete a une autre unite de peche', '251');
INSERT INTO art_type_activite VALUES ('commerce', 'unite de peche non sortie pour raison commerciale', '260');
INSERT INTO art_type_activite VALUES ('vente du poisson', 'vente du poisson au cours de la journee', '261');
INSERT INTO art_type_activite VALUES ('mode commercialisation captures absent', 'non sortie car absence de mode de commercialisation des captures', '262');
INSERT INTO art_type_activite VALUES ('UP absente pour raison inconnue', 'UP absente du lieu de debarquement pour une raison inconnue', '300');
INSERT INTO art_type_activite VALUES ('UP en sortie de plusieurs jours', 'UP absente car effectuant une sortie de peche de plusieurs jours', '310');
INSERT INTO art_type_activite VALUES ('UP en deplacement', 'UP absente car en deplacement sur un autre lieu de debarquement _ migration', '320');
INSERT INTO art_type_activite VALUES ('UP vendue', 'UP absente car vendue', '330');
INSERT INTO art_type_activite VALUES ('embarcation chez un charpentier', 'UP absente car embarcation en reparation chez un charpentier', '340');
INSERT INTO art_type_activite VALUES ('barque brisee', 'UP absente car barque brisee', '350');
INSERT INTO art_type_activite VALUES ('enqueteur present mais pas d information', 'enqueteur present sur le lieu de debarquement n ayant pas d information sur l unite de peche', '900');
INSERT INTO art_type_activite VALUES ('enqueteur absent', 'enqueteur absent du lieu de debarquement', '910');


--
-- Data for Name: art_type_agglomeration; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_type_agglomeration VALUES (0, 'Inconnu');
INSERT INTO art_type_agglomeration VALUES (1, 'Village');
INSERT INTO art_type_agglomeration VALUES (2, 'Campement permanent');
INSERT INTO art_type_agglomeration VALUES (3, 'Campement temporaire');
INSERT INTO art_type_agglomeration VALUES (4, 'Ville');


--
-- Data for Name: art_type_engin; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_type_engin VALUES ('BALANCE', 'BALAN', 'Balance a crabes');
INSERT INTO art_type_engin VALUES ('BAMBOUS', 'BAMBO', 'Bambous');
INSERT INTO art_type_engin VALUES ('BARRAGE', 'PIEGE', 'Barrage de filets');
INSERT INTO art_type_engin VALUES ('CARMENT', 'NASSE', 'Durankono geant (decrue)');
INSERT INTO art_type_engin VALUES ('CASIER', 'NASSE', 'Casier � poulpes');
INSERT INTO art_type_engin VALUES ('CHA_CRE', 'FCREV', 'Chalut � crevettes');
INSERT INTO art_type_engin VALUES ('COQUILL', 'DIVER', 'Ramassage de coquillages');
INSERT INTO art_type_engin VALUES ('CORICOR', 'DIVER', 'Cori cori');
INSERT INTO art_type_engin VALUES ('DIENE', 'NASSE', 'Grande nasse Diene');
INSERT INTO art_type_engin VALUES ('DIVER', 'DIVER', 'Divers-Inconnu');
INSERT INTO art_type_engin VALUES ('DIVERS', 'DIVER', 'Divers-Inconnu');
INSERT INTO art_type_engin VALUES ('DURANKO', 'NASSE', 'Petite nasse Durankoro');
INSERT INTO art_type_engin VALUES ('EGLE', 'BALAN', 'Balance a crabes');
INSERT INTO art_type_engin VALUES ('EP', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP10', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP15', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP18', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP20', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP25', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP28', 'EPERV', 'Epervier maille 28');
INSERT INTO art_type_engin VALUES ('EP30', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP35', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP36', 'EPERV', 'Epervier maille 36');
INSERT INTO art_type_engin VALUES ('EP40', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP45', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP50', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP55', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP60', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP65', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP75', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EP95', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EPERV', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EPERV20', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('EPERV35', 'EPERV', 'Epervier');
INSERT INTO art_type_engin VALUES ('F2MAINS', 'GA/SW', 'Filet a deux mains');
INSERT INTO art_type_engin VALUES ('FCREV', 'FCREV', 'Filet a l`etalage crevette');
INSERT INTO art_type_engin VALUES ('FCREV10', 'FCREV', 'Filet a l`etalage crevette maille 10');
INSERT INTO art_type_engin VALUES ('FCREV20', 'FCREV', 'Filet a etalage crevette maille 20');
INSERT INTO art_type_engin VALUES ('FCREV30', 'FCREV', 'Filet a etalage crevette maille 30');
INSERT INTO art_type_engin VALUES ('FCREV45', 'FCREV', 'Filet a l`etalage crevette maille 45');
INSERT INTO art_type_engin VALUES ('FCREV55', 'FCREV', 'Filet a etalage crevette maille 55');
INSERT INTO art_type_engin VALUES ('FELEPOI', 'FMDEm', 'Fele Fele � poissons');
INSERT INTO art_type_engin VALUES ('FFIXCRE', 'FCREV', 'Filets fixes � crevettes');
INSERT INTO art_type_engin VALUES ('FM22.5', 'FMDOp', 'Filet Maillant Dormant maille 22.5');
INSERT INTO art_type_engin VALUES ('FMCL', 'FMCL', 'Filet Maillant a clochettes');
INSERT INTO art_type_engin VALUES ('FMCL105', 'FMCLg', 'Filet Maillant a clochettes maille 105');
INSERT INTO art_type_engin VALUES ('FMCL20', 'FMCLp', 'Filet Maillant a clochettes maille 20');
INSERT INTO art_type_engin VALUES ('FMCL35', 'FMCLm', 'Filet Maillant a clochettes maille 35');
INSERT INTO art_type_engin VALUES ('FMCL40', 'FMCLm', 'Filet Maillant a clochette maille 40');
INSERT INTO art_type_engin VALUES ('FMCL45', 'FMCLm', 'Filet Maillant a clochettes maille 45');
INSERT INTO art_type_engin VALUES ('FMCL50', 'FMCLg', 'Filet Maillant a clochettes maille 50');
INSERT INTO art_type_engin VALUES ('FMCL55', 'FMCLg', 'Filet Maillant a clochettes maille 55');
INSERT INTO art_type_engin VALUES ('FMCL60', 'FMCLg', 'Filet Maillant a clochettes maille 60');
INSERT INTO art_type_engin VALUES ('FMCL65', 'FMCLg', 'Filet Maillant a clochettes maille 65');
INSERT INTO art_type_engin VALUES ('FMCL75', 'FMCLg', 'Filet Maillant a clochettes maille 75');
INSERT INTO art_type_engin VALUES ('FMCL80', 'FMCLg', 'Filet Maillant a clochettes maille 80');
INSERT INTO art_type_engin VALUES ('FMCL85', 'FMCLg', 'Filet Maillant a clochettes maille 85');
INSERT INTO art_type_engin VALUES ('FMCL95', 'FMCLg', 'Filet Maillant a clochettes maille 95');
INSERT INTO art_type_engin VALUES ('FMDE', 'FMDE', 'Filet Maillant Derivant');
INSERT INTO art_type_engin VALUES ('FMDE10', 'FMDEp', 'Filet Maillant Derivant maille 10');
INSERT INTO art_type_engin VALUES ('FMDE100', 'FMDEg', 'Filet Maillant Derivant maille 100');
INSERT INTO art_type_engin VALUES ('FMDE115', 'FMDEg', 'Filet Maillant Derivant maille 115');
INSERT INTO art_type_engin VALUES ('FMDE120', 'FMDEg', 'Filet Maillant DErivant maille 120');
INSERT INTO art_type_engin VALUES ('FMDE20', 'FMDEp', 'Filet Maillant Derivant maille 20');
INSERT INTO art_type_engin VALUES ('FMDE25', 'FMDEp', 'Filet Maillant d�rivant 25mm');
INSERT INTO art_type_engin VALUES ('FMDE28', 'FMDEp', 'Filet Maillant DErivant maille 28');
INSERT INTO art_type_engin VALUES ('FMDE30', 'FMDEp', 'Filet Maillant Derivant maille 30');
INSERT INTO art_type_engin VALUES ('FMDE35', 'FMDEm', 'Filet Maillant Derivant maille 35');
INSERT INTO art_type_engin VALUES ('FMDE36', 'FMDEm', 'Filet Maillant d�rivant 36mm');
INSERT INTO art_type_engin VALUES ('FMDE40', 'FMDEm', 'Filet Maillant Derivant maille 40');
INSERT INTO art_type_engin VALUES ('FMDE44', 'FMDEm', 'Filet Maillant Derivant maille 44');
INSERT INTO art_type_engin VALUES ('FMDE45', 'FMDEm', 'Filet Maillant Derivant maille 45');
INSERT INTO art_type_engin VALUES ('FMDE50', 'FMDEm', 'Filet Maillant Derivant maille 50');
INSERT INTO art_type_engin VALUES ('FMDE55', 'FMDEg', 'Filet Maillant Derivant maille 55');
INSERT INTO art_type_engin VALUES ('FMDE60', 'FMDEg', 'Filet Maillant Derivant maille 60');
INSERT INTO art_type_engin VALUES ('FMDE65', 'FMDEg', 'Filet Maillant Derivant maille 65');
INSERT INTO art_type_engin VALUES ('FMDE75', 'FMDEg', 'Filet Maillant Derivant maille 75');
INSERT INTO art_type_engin VALUES ('FMDE80', 'FMDEg', 'Filet Maillant DErivant maille 80');
INSERT INTO art_type_engin VALUES ('FMDE85', 'FMDEg', 'Filet Maillant Derivant maille 85');
INSERT INTO art_type_engin VALUES ('FMDE90', 'FMDEg', 'Filet Maillant DErivant maille 90');
INSERT INTO art_type_engin VALUES ('FMDE95', 'FMDEg', 'Filet Maillant Derivant maille 95');
INSERT INTO art_type_engin VALUES ('FMDEfo', 'FMDEm', 'Filet maillant derivant de fond (Yolal)');
INSERT INTO art_type_engin VALUES ('FMDO', 'FMDO', 'Filet Maillant Dormant');
INSERT INTO art_type_engin VALUES ('FMDO10', 'FMDOp', 'Filet Maillant Dormant maille 10');
INSERT INTO art_type_engin VALUES ('FMDO100', 'FMDOg', 'Filet Maillant Dormant maille 100');
INSERT INTO art_type_engin VALUES ('FMDO105', 'FMDOg', 'Filet Maillant Dormant maille 105');
INSERT INTO art_type_engin VALUES ('FMDO115', 'FMDOg', 'Filet Maillant Dormant maille 115');
INSERT INTO art_type_engin VALUES ('FMDO125', 'FMDOg', 'Filet Maillant Dormant maille 125');
INSERT INTO art_type_engin VALUES ('FMDO135', 'FMDOg', 'Filet Maillant Dormant maille 135');
INSERT INTO art_type_engin VALUES ('FMDO15', 'FMDOp', 'Filet Maillant Dormant maille 15');
INSERT INTO art_type_engin VALUES ('FMDO15S', 'FMDOp', 'Filet Maillant Dormant maille 15');
INSERT INTO art_type_engin VALUES ('FMDO18S', 'FMDOp', 'Filet Maillant Dormant maille 18');
INSERT INTO art_type_engin VALUES ('FMDO20', 'FMDOp', 'Filet Maillant Dormant maille 20');
INSERT INTO art_type_engin VALUES ('FMDO20S', 'FMDOp', 'Filet Maillant Dormant maille 20');
INSERT INTO art_type_engin VALUES ('FMDO22', 'FMDOp', 'Filet Maillant Dormant maille 22');
INSERT INTO art_type_engin VALUES ('FMDO25', 'FMDOp', 'Filet Maillant Dormant maille 25');
INSERT INTO art_type_engin VALUES ('FMDO25S', 'FMDOp', 'Filet Maillant Dormant maille 25');
INSERT INTO art_type_engin VALUES ('FMDO30', 'FMDOp', 'Filet Maillant Dormant maille 30');
INSERT INTO art_type_engin VALUES ('FMDO30S', 'FMDOp', 'Filet Maillant Dormant maille 30');
INSERT INTO art_type_engin VALUES ('FMDO35', 'FMDOm', 'Filet Maillant Dormant maille 35');
INSERT INTO art_type_engin VALUES ('FMDO40', 'FMDOm', 'Filet Maillant Dormant maille 40');
INSERT INTO art_type_engin VALUES ('FMDO45', 'FMDOm', 'Filet Maillant Dormant maille 45');
INSERT INTO art_type_engin VALUES ('FMDO50', 'FMDOm', 'Filet Maillant Dormant maille 50');
INSERT INTO art_type_engin VALUES ('FMDO55', 'FMDOg', 'Filet Maillant Dormant maille 55');
INSERT INTO art_type_engin VALUES ('FMDO60', 'FMDOg', 'Filet Maillant Dormant maille 60');
INSERT INTO art_type_engin VALUES ('FMDO65', 'FMDOg', 'Filet Maillant Dormant maille 65');
INSERT INTO art_type_engin VALUES ('FMDO70', 'FMDOg', 'Filet Maillant Dormant maille 70');
INSERT INTO art_type_engin VALUES ('FMDO75', 'FMDOg', 'Filet Maillant Dormant maille 75');
INSERT INTO art_type_engin VALUES ('FMDO80', 'FMDOg', 'Filet Maillant Dormant maille 80');
INSERT INTO art_type_engin VALUES ('FMDO85', 'FMDOg', 'Filet Maillant Dormant maille 85');
INSERT INTO art_type_engin VALUES ('FMDO90', 'FMDOg', 'Filet Maillant Dormant maille 90');
INSERT INTO art_type_engin VALUES ('FMDO95', 'FMDOg', 'Filet Maillant Dormant maille 95');
INSERT INTO art_type_engin VALUES ('FMDOefi', 'FMDO', 'Filet maillant dormant � ethmaloses');
INSERT INTO art_type_engin VALUES ('FMDOg', 'FMDOg', 'Filet Maillant Dormant grandes mailles');
INSERT INTO art_type_engin VALUES ('FMDOlan', 'FMDO', 'Filet maillant dormant � langoustes');
INSERT INTO art_type_engin VALUES ('FMDOm', 'FMDOm', 'Filet Maillant Dormant moyennes mailles');
INSERT INTO art_type_engin VALUES ('FMDOp', 'FMDOp', 'Filet Maillant Dormant petites mailles');
INSERT INTO art_type_engin VALUES ('FMDOpoi', 'FMDOm', 'Filet maillant dormant � poissons');
INSERT INTO art_type_engin VALUES ('FMDOs', 'FMDOg', 'Filet Maillant Dormant a soles');
INSERT INTO art_type_engin VALUES ('FMDOsol', 'FMDOm', 'Filet maillant dormant � soles');
INSERT INTO art_type_engin VALUES ('FMDOsur', 'FMDOm', 'Filet maillant dormant');
INSERT INTO art_type_engin VALUES ('FMDOyee', 'FMDOg', 'Filet maillant dormant � yeet');
INSERT INTO art_type_engin VALUES ('FMEN', 'FMEN', 'Filet Maillant Encerclant');
INSERT INTO art_type_engin VALUES ('FMEN30', 'FMENp', 'Filet Maillant Encerclant maille 30');
INSERT INTO art_type_engin VALUES ('FMEN35', 'FMENm', 'Filet Maillant Encerclant maille 35');
INSERT INTO art_type_engin VALUES ('FMEN40', 'FMENm', 'Filet maillant encerclant Saima');
INSERT INTO art_type_engin VALUES ('FMEN45', 'FMENm', 'Filet Maillant Encerclant maille 45');
INSERT INTO art_type_engin VALUES ('FMEN55', 'FMENg', 'Filet Maillant Encerclant maille 55');
INSERT INTO art_type_engin VALUES ('FMEN65', 'FMENg', 'Filet Maillant Encerclant maille 65');
INSERT INTO art_type_engin VALUES ('FMEN75', 'FMENg', 'Filet Maillant Encerclant maille 75');
INSERT INTO art_type_engin VALUES ('FMMO', 'FMMO', 'Filet Maillant Monofilament');
INSERT INTO art_type_engin VALUES ('FMMO10', 'FMMOp', 'Filet Maillant Monofilament maille 10');
INSERT INTO art_type_engin VALUES ('FMMO100', 'FMMOg', 'Filet Maillant Monofilament maille 100');
INSERT INTO art_type_engin VALUES ('FMMO15', 'FMMOp', 'Filet Maillant Monofilament maille 15');
INSERT INTO art_type_engin VALUES ('FMMO20', 'FMMOp', 'Filet Maillant Monofilament maille 20');
INSERT INTO art_type_engin VALUES ('FMMO25', 'FMMOp', 'Filet Maillant Monofilamant maille 25');
INSERT INTO art_type_engin VALUES ('FMMO30', 'FMMOp', 'Filet Maillant Monofilament maille 30');
INSERT INTO art_type_engin VALUES ('FMMO35', 'FMMOm', 'Filet Maillant Monofilament maille 35');
INSERT INTO art_type_engin VALUES ('FMMO40', 'FMMOm', 'Filet Maillant Monofilament maille 40');
INSERT INTO art_type_engin VALUES ('FMMO45', 'FMMOm', 'Filet Maillant Monofilament maille 45');
INSERT INTO art_type_engin VALUES ('FMMO50', 'FMMOm', 'Filet maillant monofilament maille 50');
INSERT INTO art_type_engin VALUES ('FMMO55', 'FMMOg', 'Filet maillant monofilament maille 55');
INSERT INTO art_type_engin VALUES ('FMMO60', 'FMMOg', 'Filet maillant monofilament maille 60');
INSERT INTO art_type_engin VALUES ('FMMO65', 'FMMOg', 'Filet maillant monofilament maille 65');
INSERT INTO art_type_engin VALUES ('FMMO70', 'FMMOg', 'Filet maillant monofilament maille 70');
INSERT INTO art_type_engin VALUES ('FMMO75', 'FMMOg', 'Filet maillant monofilament maille 75');
INSERT INTO art_type_engin VALUES ('FMMO80', 'FMMOg', 'Filet maillant monofilament maille 80');
INSERT INTO art_type_engin VALUES ('FMMO85', 'FMMOg', 'Filet maillant monofilament maille 85');
INSERT INTO art_type_engin VALUES ('FMMO95', 'FMMOg', 'Filet maillant monofilament maille 95');
INSERT INTO art_type_engin VALUES ('FUSIL', 'LANCE', 'Fusil de p�che');
INSERT INTO art_type_engin VALUES ('GANGA', 'GA/SW', 'Ganga');
INSERT INTO art_type_engin VALUES ('GOLF', 'DIVER', 'Filet golf');
INSERT INTO art_type_engin VALUES ('GOLF40', 'DIVER', 'Filet golf');
INSERT INTO art_type_engin VALUES ('HA', 'DIVER', 'Engin inconnu');
INSERT INTO art_type_engin VALUES ('HARPON', 'LANCE', 'Harpons');
INSERT INTO art_type_engin VALUES ('HLHOC', 'DIVER', 'Engin inconnu');
INSERT INTO art_type_engin VALUES ('INCONNU', 'DIVER', 'Engin Inconnu');
INSERT INTO art_type_engin VALUES ('KA', 'DIVER', 'Engin Inconnu');
INSERT INTO art_type_engin VALUES ('KILLI', 'FCREV', 'Filet � crevettes Killi');
INSERT INTO art_type_engin VALUES ('LIGNE', 'LIGNE', 'Ligne a main');
INSERT INTO art_type_engin VALUES ('LIGNEC', 'LIGNE', 'Ligne avec canne');
INSERT INTO art_type_engin VALUES ('LIGNEM', 'LIGNE', 'Ligne avec main');
INSERT INTO art_type_engin VALUES ('LIGNM', 'LIGNE', 'Ligne a main');
INSERT INTO art_type_engin VALUES ('MAINS', 'DIVER', 'Peche a la main');
INSERT INTO art_type_engin VALUES ('NASSE', 'NASSE', 'Nasse a poisson');
INSERT INTO art_type_engin VALUES ('NUL', 'DIVER', 'Engin Inconnu');
INSERT INTO art_type_engin VALUES ('PANIER', 'GA/SW', 'Panier');
INSERT INTO art_type_engin VALUES ('PAPOLO', 'NASSE', 'Nasse Papolo');
INSERT INTO art_type_engin VALUES ('PIEGE', 'PIEGE', 'Piege');
INSERT INTO art_type_engin VALUES ('PLA', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA10', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA11', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA12', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA13', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA14', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA15', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA16', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA2', 'PALAN', 'Palangre appatee ');
INSERT INTO art_type_engin VALUES ('PLA3', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA4', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA5', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA6', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA7', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA8', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLA9', 'PALAN', 'Palangre appatee');
INSERT INTO art_type_engin VALUES ('PLNA', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA10', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA11', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA12', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA13', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA14', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA15', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA16', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA17', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA2', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA3', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA4', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA5', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA6', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA7', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA8', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('PLNA9', 'PALAN', 'Palangre non appatee');
INSERT INTO art_type_engin VALUES ('SE_dig', 'SE_PL', 'Senne de plage Diguel');
INSERT INTO art_type_engin VALUES ('SE_opa', 'SE_PL', 'Senne de plage opane');
INSERT INTO art_type_engin VALUES ('SE_PL', 'SE_PL', 'Senne de plage');
INSERT INTO art_type_engin VALUES ('SE_PLAG', 'SE_PL', 'Senne de plage');
INSERT INTO art_type_engin VALUES ('SE_TOUR', 'SE_TO', 'Senne tournante ghaneene');
INSERT INTO art_type_engin VALUES ('SENNE', 'SE_PL', 'Senne de plage');
INSERT INTO art_type_engin VALUES ('SENNE T', 'SE_PL', 'Senne de plage');
INSERT INTO art_type_engin VALUES ('SENNE10', 'SE_PL', 'Senne de plage maille 10');
INSERT INTO art_type_engin VALUES ('SENNE14', 'SE_PL', 'Senne de plage maille 14mm');
INSERT INTO art_type_engin VALUES ('SENNE20', 'SE_PL', 'Senne de plage maille 20');
INSERT INTO art_type_engin VALUES ('SENNE25', 'SE_PL', 'Senne de plage maille 25');
INSERT INTO art_type_engin VALUES ('SENNE30', 'SE_PL', 'Senne de plage maille 30');
INSERT INTO art_type_engin VALUES ('SENNE35', 'SE_PL', 'Senne de plage maille 35');
INSERT INTO art_type_engin VALUES ('SENNE40', 'SE_PL', 'Senne de plage maille 40');
INSERT INTO art_type_engin VALUES ('SENNE45', 'SE_PL', 'Senne de plage maille 45');
INSERT INTO art_type_engin VALUES ('SENNE50', 'SE_PL', 'Senne de plage maille 50');
INSERT INTO art_type_engin VALUES ('SENNE55', 'SE_PL', 'Senne de plage maille 55');
INSERT INTO art_type_engin VALUES ('SENNE60', 'SE_PL', 'Senne de plage multi mailles');
INSERT INTO art_type_engin VALUES ('SENNE65', 'SE_PL', 'Senne de plage maille 65');
INSERT INTO art_type_engin VALUES ('SENNE85', 'SE_PL', 'Senne de plage');
INSERT INTO art_type_engin VALUES ('SENNEte', 'SE_PL', 'Senne de terre');
INSERT INTO art_type_engin VALUES ('SEPI', 'DIVER', 'Engin inconnu');
INSERT INTO art_type_engin VALUES ('SWANYA', 'GA/SW', 'Swanya');
INSERT INTO art_type_engin VALUES ('SYNDICA', 'SE_SY', 'Senne syndicat');
INSERT INTO art_type_engin VALUES ('XUBI10', 'SE_PL', 'Xubiseu petite senne maille 10');
INSERT INTO art_type_engin VALUES ('XUBI20', 'SE_PL', 'Xubiseu petite senne maille 20');
INSERT INTO art_type_engin VALUES ('XUBI30', 'SE_PL', 'Xubiseu petite senne maille 30');
INSERT INTO art_type_engin VALUES ('XUBI35', 'SE_PL', 'Xubiseu petite senne maille 35');
INSERT INTO art_type_engin VALUES ('XUBI40', 'SE_PL', 'Xubiseu petite senne maille 40');
INSERT INTO art_type_engin VALUES ('XUBI45', 'SE_PL', 'Xubiseu petite senne maille 45');
INSERT INTO art_type_engin VALUES ('XUBISEU', 'SE_PL', 'Xubiseu petite senne');


--
-- Data for Name: art_type_sortie; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_type_sortie VALUES (0, 'Non informe');
INSERT INTO art_type_sortie VALUES (1, 'Sortie effectuee a pied');
INSERT INTO art_type_sortie VALUES (2, 'Sortie effectuee dans une embarcation non motorisee');
INSERT INTO art_type_sortie VALUES (3, 'Sortie effectuee dans une embarcation motorisee');


--
-- Data for Name: art_unite_peche; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_unite_peche VALUES (1, 1, 'ALY SANCAFE', NULL, 2, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2, 1, 'MAHAMADOU BARRY', NULL, 3, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3, 1, 'ABDOULAYE SANCAFE', NULL, 4, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (4, 1, 'LASSANE TRAORE', NULL, 5, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (5, 1, 'MOUSSA SANCAFE', NULL, 6, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (6, 1, 'BARYMA SANCAFE', NULL, 7, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (7, 1, 'BAKARY FOFANA', NULL, 8, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (8, 1, 'FAROUGOU TANEMPO', NULL, 9, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (9, 1, 'YACOUBA BARRY', NULL, 10, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (10, 1, 'SEKOU AMADOU KEITA', NULL, 12, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (11, 1, 'AMADOU WOSSONKO', NULL, 13, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (12, 1, 'SADIO WOSSONKO', NULL, 15, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (13, 1, 'SOUMANA FOFANA', NULL, 17, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (14, 1, 'NKA PAITO', NULL, 18, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (15, 1, 'LASSANA KEMPO', NULL, 19, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (16, 1, 'DJIBRIL SALAMATA', NULL, 20, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (17, 1, 'BOUBACAR NADIAN', NULL, 21, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (18, 1, 'BARYMA KONTA', NULL, 22, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (19, 1, 'HAMIDOU DIENTA', NULL, 23, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (20, 1, 'BOUBACAR KADIAN', NULL, 24, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (21, 1, 'MOHAMED FOFANA', NULL, 25, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (22, 1, 'MAHAMADOU DIENTA', NULL, 26, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (23, 1, 'ABLOULAYE SANCAFE', NULL, 27, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (24, 1, 'ASSIM DIENTA', NULL, 28, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (25, 1, 'SOUMANA DIENTA', NULL, 29, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (26, 1, 'MAHAMOUDOU SIMPANA', NULL, 30, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (27, 1, 'SEKOU AMADOU FOFANA', NULL, 31, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (28, 1, 'LASSANA TRAORE', NULL, 32, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (29, 1, 'ABDOU KADER FOFANA', NULL, 33, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (30, 1, 'SOLOMANE MINMANTA', NULL, 34, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (31, 1, 'TEBABA TANAPO', NULL, 35, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (32, 1, 'SOUMANA KONTA', NULL, 36, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (33, 1, 'BABA DICKO', NULL, 37, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (34, 1, 'OUMAR TIMBO', NULL, 38, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (35, 1, 'SIDIKI MINMANTA', NULL, 39, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (36, 1, 'MOUSSA DOUCOURE', NULL, 397, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (37, 1, 'LASSINA KOMOTAO', NULL, 398, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (38, 1, 'AMADY TAMBOURA', NULL, 399, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (39, 1, 'ZOUMANA FOFANA', NULL, 400, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (40, 1, 'ISSA KOMOU', NULL, 401, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (41, 1, 'YOUSSOUF KOMOU', NULL, 402, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (42, 1, 'MAMA KOMOTAO', NULL, 403, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (43, 1, 'ASSANA DIARRA', NULL, 404, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (44, 1, 'KONIBA COULIBALY', NULL, 405, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (45, 1, 'ALMAMY HA�DARA', NULL, 408, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (46, 1, 'SAMBA TAMBOURA', NULL, 409, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (47, 1, 'SINALY HA�DARA', NULL, 410, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (48, 1, 'MAMA KONTA', NULL, 411, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (49, 1, 'LASSANA FAROTA', NULL, 413, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (50, 1, 'TIDIANE KONTA', NULL, 414, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (51, 1, 'SAMBOU DEMBELE', NULL, 415, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (52, 1, 'ALMAMY TEMBO', NULL, 416, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (53, 1, 'INAKA KONTA', NULL, 417, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (54, 1, 'SEKOU KANAKOMO', NULL, 418, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (55, 1, 'DIARRY DIENTA', NULL, 419, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (56, 1, 'MAMADOU KALLOPO', NULL, 420, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (57, 1, 'MAHAMBE TOUNKARA', NULL, 421, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (58, 1, 'BREMA TRAORE', NULL, 422, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (59, 1, 'BREMA SACKO', NULL, 424, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (60, 1, 'BEKAYE YATTARA', NULL, 425, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (61, 1, 'MAMA KANAKOMO', NULL, 426, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (62, 1, 'DEMBA KALLOPO', NULL, 427, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (63, 1, 'NOUHOU TOMOTA', NULL, 428, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (64, 1, 'BOUBACARY CRONSO', NULL, 429, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (65, 1, 'MAMADOU TRAORE', NULL, 430, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (66, 1, 'MAMA DIENTA', NULL, 431, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (67, 1, 'OUSMANE KANAKOMO', NULL, 432, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (68, 1, 'YAYA SAMAKE', NULL, 433, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (69, 1, 'ALMAMY TEMBA', NULL, 434, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (70, 1, 'ISSA TRAORE', NULL, 435, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (71, 1, 'diadie nadjan ', NULL, 436, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (72, 1, 'soumana kallopo', NULL, 437, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (73, 1, 'MOUSSA TRAORE', NULL, 438, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (74, 1, 'SEKOU SINAYOKO', NULL, 439, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (75, 1, 'SEKOU NAPOUKOU', NULL, 440, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (76, 1, 'LASSANA NABO', NULL, 441, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (77, 1, 'BREMA MIENTA', NULL, 442, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (78, 1, 'MAMA A.MIENTA', NULL, 443, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (79, 1, 'BOUREMA BOUARE', NULL, 444, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (80, 1, 'DOUDOU KAMPO', NULL, 445, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (81, 1, 'MAMA A. MIENTA', NULL, 446, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (82, 1, 'MAMADOU KANTA', NULL, 447, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (83, 1, 'SEKOU A. SAPANA', NULL, 448, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (84, 1, 'BOURAMA BOUARE', NULL, 449, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (85, 1, 'DIADIE KOUNTA', NULL, 450, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (86, 1, 'MAMA SINAYOKO', NULL, 451, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (87, 1, 'ADAMA YOUANOU', NULL, 452, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (88, 1, 'MAMA TIENTA', NULL, 453, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (89, 1, 'AMADOU DRAME', NULL, 454, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (90, 1, 'AMDOU DRAME', NULL, 455, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (91, 1, 'SEKOU AMADOU SAPANA', NULL, 456, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (92, 1, 'MAMA AMADOU MIENTA', NULL, 457, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (93, 1, 'mamadou tienta dit maoudou', NULL, 458, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (94, 1, 'sibiry diarra', NULL, 459, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (95, 1, 'lassana kontao', NULL, 460, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (96, 1, 'MAMA MIENTA', NULL, 461, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (97, 1, 'MAMA NOPO', NULL, 462, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (98, 1, 'MODOU TIENTA', NULL, 463, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (99, 1, 'MAMA NAPO', NULL, 464, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (100, 1, 'MADOU TIENTA', NULL, 465, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (101, 1, 'BOUKADARY SEKRY', NULL, 466, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (102, 1, 'LASSANA NAPO', NULL, 467, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (103, 1, 'mamadou/maoudo tienta', NULL, 468, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (104, 1, 'lassy kantao', NULL, 469, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (105, 1, 'MAMA KAMPO', NULL, 470, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (106, 1, 'MAMA FAROTA', NULL, 471, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (107, 1, 'SEKOU NAPOKOU', NULL, 472, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (108, 1, 'BOUKADARY SEKIRY', NULL, 473, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (109, 1, 'MAMA DIT DOUDOU KAMPO', NULL, 474, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (110, 1, 'DIBIRY DIARRA', NULL, 475, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (111, 1, 'BREMA DIENTA', NULL, 476, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (112, 1, 'LASSY KONTAO', NULL, 477, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (113, 1, 'sibiry diara', NULL, 478, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (114, 1, 'MAMA DEMBELE', NULL, 479, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (115, 1, 'MOUSSA DEMBELE', NULL, 480, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (116, 1, 'MAMADOU TIENTA', NULL, 481, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (117, 1, 'AMADOU MIENTA', NULL, 482, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (118, 1, 'adama kantao', NULL, 483, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (119, 1, 'LAMINE', NULL, 484, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (120, 1, 'BOUBA KAMANTA', NULL, 485, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (121, 1, 'DAOU', NULL, 486, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (122, 1, 'DJIDANI KABENTA', NULL, 487, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (123, 1, 'BOUREMA SERETA', NULL, 488, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (124, 1, 'LASSANA', NULL, 489, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (125, 1, 'SOLO', NULL, 490, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (126, 1, 'MADY FAMANTA', NULL, 491, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (127, 1, 'BABA', NULL, 492, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (128, 1, 'MADY DIENTA', NULL, 493, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (129, 1, 'PAPA', NULL, 494, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (130, 1, 'BOUBACAR DIENTA', NULL, 495, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (131, 1, 'MAYERE', NULL, 496, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (132, 1, 'BAKARY', NULL, 497, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (133, 1, 'MADOU SAMANTA', NULL, 498, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (134, 1, 'BOUREMA KONTA', NULL, 499, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (135, 1, 'GAOUSSOU FAMANTA', NULL, 500, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (136, 1, 'MOUSSA', NULL, 501, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (137, 1, 'BOUGADER', NULL, 502, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (138, 1, 'BABOU KAMENTA', NULL, 503, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (139, 1, 'MAMA DJEGUENI', NULL, 504, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (140, 1, 'SEKOU NABO', NULL, 505, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (141, 1, 'KALILOU TRAORE', NULL, 506, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (142, 1, 'BOUREMA DIENTA', NULL, 507, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (143, 1, 'MADY SAMPANA', NULL, 508, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (144, 1, 'ALY KEMOU', NULL, 509, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (145, 1, 'YOUSSOUF NABO', NULL, 510, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (146, 1, 'INCONNU', NULL, 511, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (147, 1, 'MAMOUTOU', NULL, 512, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (148, 1, 'KEBOUARI KOUARA', NULL, 513, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (149, 1, 'AFO', NULL, 514, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (150, 1, 'LASSANA KONTA', NULL, 515, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (151, 1, 'BOURAMA DIENTA', NULL, 516, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (152, 1, 'BAKARY KANAKOMO', NULL, 518, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (153, 1, 'BAFOW KONTA', NULL, 519, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (154, 1, 'TIEMOKO DIARRA', NULL, 520, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (155, 1, 'OUMAR KONTA', NULL, 521, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (156, 1, 'MOUSSA DIEGUENI', NULL, 522, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (157, 1, 'MOUSSA KANAKOMO', NULL, 523, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (158, 1, 'SEKOU MOKONTA', NULL, 524, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (159, 1, 'ABDOULAYE TIENTA', NULL, 525, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (160, 1, 'MAMAN KONTA', NULL, 526, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (161, 1, 'mamadou bilakoro', NULL, 527, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (162, 1, 'soumaila tikombo', NULL, 528, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (163, 1, 'amadou tienta', NULL, 532, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (164, 1, 'garba kagnon', NULL, 533, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (165, 1, 'SEKOU KAMINA', NULL, 534, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (166, 1, 'mody dienta', NULL, 535, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (167, 1, 'bouba kamata ', NULL, 536, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (168, 1, 'mory sampana', NULL, 537, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (169, 1, 'moussa sembe', NULL, 538, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (170, 1, 'djidani kota', NULL, 539, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (171, 1, 'MAMA', NULL, 540, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (172, 1, 'MAMADOU ALY', NULL, 541, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (173, 1, 'AFO KOMOU', NULL, 542, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (174, 1, 'MORY KAMONTA', NULL, 543, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (175, 1, 'ALY KOMOU', NULL, 544, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (176, 1, 'KEOU', NULL, 545, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (177, 1, 'ADAMA', NULL, 546, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (178, 1, 'BOUKADER', NULL, 547, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (179, 1, 'BOUBACAR', NULL, 548, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (180, 1, 'AFOU KEITA', NULL, 549, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (181, 1, 'BOUBACAR KAMANTA', NULL, 550, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (182, 1, 'MAMA KONINA', NULL, 551, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (183, 1, 'SORY', NULL, 552, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (184, 1, 'BOURAMA KEITA', NULL, 553, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (185, 1, 'NADY DIENTA', NULL, 554, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (186, 1, 'ALY KAMOU', NULL, 555, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (187, 1, 'MAMADOU', NULL, 556, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (188, 1, 'MORY KOMONTA', NULL, 557, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (189, 1, 'BAGNINI SERETA', NULL, 558, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (190, 1, 'KEOU KONOGNON', NULL, 559, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (191, 1, 'MODIBO', NULL, 560, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (192, 1, 'MAMADOU NABO', NULL, 561, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (193, 1, 'KEOU KOROGNON', NULL, 562, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (194, 1, 'SEKOU KOMINA', NULL, 563, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (195, 1, 'BOUREMA SINENTA', NULL, 564, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (196, 1, 'BAFRO KONTA', NULL, 565, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (197, 1, 'LASSANA NIAFO', NULL, 566, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (198, 1, 'MORY KAMANTA', NULL, 567, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (199, 1, 'MOUSSA DJEGUENI', NULL, 568, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (200, 1, 'SOUMAILA KAMANTA', NULL, 569, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (201, 1, 'INOKO KONTA', NULL, 570, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (202, 1, 'SAMBA TAMBARA', NULL, 571, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (203, 1, 'BOUKADARY KONTA', NULL, 572, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (204, 1, 'TIALIANE KONTA', NULL, 573, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (205, 1, 'MOUSSA KALLOPO', NULL, 574, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (206, 1, 'boubacary gronso', NULL, 575, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (207, 1, 'inoka konta', NULL, 576, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (208, 1, 'MAHI KONTA', NULL, 1037, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (209, 1, 'SEKOU SALLA', NULL, 1038, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (210, 1, 'BOUBACAR FAMANTA', NULL, 1039, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (211, 1, 'BOUREMA TRIPO', NULL, 1040, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (212, 1, 'BABA TRIPO', NULL, 1041, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (213, 1, 'MADOU DRIPO', NULL, 1042, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (214, 1, 'ISSA DJIGUENI', NULL, 1043, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (215, 1, 'BOUBACAR COULIBALY', NULL, 1044, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (216, 1, 'MAHAMANE KANTA', NULL, 1045, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (217, 1, 'MOUSSA FAMANTA', NULL, 1046, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (218, 1, 'KEREMUGNON', NULL, 1047, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (219, 1, 'LADJI KANTA', NULL, 1048, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (220, 1, 'MAHI FAMANTA', NULL, 1049, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (221, 1, 'DAOUDA KARABEINTA', NULL, 1050, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (222, 1, 'BOUREIMA FAMANTA', NULL, 1051, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (223, 1, 'BAKARY TIENTA', NULL, 1052, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (224, 1, 'BABA FAMANTA', NULL, 1053, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (225, 1, 'DJIENKINA TRIFO', NULL, 1054, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (226, 1, 'AFO TRIFO', NULL, 1055, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (227, 1, 'OUMAR TRIFO', NULL, 1056, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (228, 1, 'DJIKINA SYLLA', NULL, 1057, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (229, 1, 'SIH TERETA', NULL, 1058, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (230, 1, 'BAKAYE FAMANTA', NULL, 1059, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (231, 1, 'KONO KANTA', NULL, 1060, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (232, 1, 'AMADOU FAMANTA', NULL, 1061, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (233, 1, 'SEKOU AMADOU SAMPANA', NULL, 1062, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (234, 1, 'MADOU  TIENTA', NULL, 1063, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (235, 1, 'LASSANA DICKO', NULL, 1064, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (236, 1, 'SAMBA MA�GA', NULL, 1065, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (237, 1, 'SEKOU FAMANTA', NULL, 1066, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (238, 1, 'MAMA SANGHO', NULL, 1067, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (239, 1, 'BIRRA TOMOTA', NULL, 1068, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (240, 1, 'LAMINE FAMANTA', NULL, 1069, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (241, 1, 'SEKOU KANTA', NULL, 1070, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (242, 1, 'MAMA FAMANTA ', NULL, 1071, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (243, 1, 'KEMADI TERETA', NULL, 1072, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (244, 1, 'GAPI FAMANTA', NULL, 1073, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (245, 1, 'MAMADOU DJEKINI', NULL, 1074, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (246, 1, 'SOUMANA TRAORE', NULL, 1075, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (247, 1, 'BAMOYE NIOUMATA', NULL, 1076, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (248, 1, 'DJIDANI KONTA', NULL, 1077, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (249, 1, 'GALY FAMANTA', NULL, 1078, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (250, 1, 'ABDOULAYE KONTA', NULL, 1079, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (251, 1, 'LASSANA NIOUMANTA', NULL, 1080, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (252, 1, 'SIDI MAIGA', NULL, 1081, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (253, 1, 'BAYE FAMANTA', NULL, 1082, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (254, 1, 'BINA TOMOTA', NULL, 1083, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (255, 1, 'DJIDANI FAMANTA', NULL, 1084, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (256, 1, 'KONO KONTA', NULL, 1085, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (257, 1, 'KAMAYE NIOUMANTA', NULL, 1086, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (258, 1, 'LASSINE FAMANTA', NULL, 1087, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (259, 1, 'BAMOYE NIOUMANTA', NULL, 1088, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (260, 1, 'AGALY', NULL, 1089, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (261, 1, 'MAMA NIOUMANTA', NULL, 1090, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (262, 1, 'BOUBACAR SERETA', NULL, 1091, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (263, 1, 'BABOYE DIENTA', NULL, 1092, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (264, 1, 'BAKOYE FAMANTA', NULL, 1093, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (265, 1, 'KAKO DIENTA', NULL, 1094, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (266, 1, 'SOUMANA TOURE', NULL, 1095, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (267, 1, 'KAMORO NIOUMANTA', NULL, 1096, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (268, 1, 'KARAMOKO', NULL, 1097, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (269, 1, 'BLAYE BAH', NULL, 1098, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (270, 1, 'KEMOUSSA KONTA', NULL, 1099, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (271, 1, 'ABDOULAYE FAMANTA', NULL, 1100, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (272, 1, 'SEKOU KONTA', NULL, 1101, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (273, 1, 'SAMBA MAIGA', NULL, 1102, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (274, 1, 'SEKOU A SERETA', NULL, 1103, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (275, 1, 'KEREMUGNOU KANTA', NULL, 1104, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (276, 1, 'SOUMANA', NULL, 1105, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (277, 1, 'BAKARAMOKO KONTA', NULL, 1106, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (278, 1, 'SEKOUBA TRAORE', NULL, 1107, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (279, 1, 'MAHI', NULL, 1108, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (280, 1, 'KAMAYE MA�GA', NULL, 1109, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (281, 1, 'ALASSANE', NULL, 1110, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (282, 1, 'HAROUNA', NULL, 1111, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (283, 1, 'AMALA KONTA', NULL, 1112, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (284, 1, 'SOLO TRAORE', NULL, 1113, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (285, 1, 'BAKARAMOKO', NULL, 1114, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (286, 1, 'KARIM TRAORE', NULL, 1115, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (287, 1, 'KEMOUSSA', NULL, 1116, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (288, 1, 'KOUANA KONTA', NULL, 1117, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (289, 1, 'BA DAOUDA', NULL, 1118, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (290, 1, 'BABA LISSE', NULL, 1119, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (291, 1, 'OUSMANE', NULL, 1120, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (292, 1, 'TIDIANI KONTA', NULL, 1121, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (293, 1, 'BAH SABE', NULL, 1122, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (294, 1, 'ALY KARABENTA', NULL, 1123, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (295, 1, 'MAHI TIKABO', NULL, 1124, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (296, 1, 'SEKOU KARAWANA', NULL, 1125, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (297, 1, 'LASSANA KARABENTA', NULL, 1126, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (298, 1, 'SIDI MA�GA', NULL, 1127, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (299, 1, 'BOUREHIMA TRAORE', NULL, 1128, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (300, 1, 'GOBI KONTA', NULL, 1129, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (301, 1, 'BABOU TIENTA', NULL, 1130, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (302, 1, 'MAMA SERETA', NULL, 1131, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (303, 1, 'SOUMANA KOMINA', NULL, 1132, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (304, 1, 'BABA TIENTA', NULL, 1133, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (305, 1, 'OUMAR FAMANTA', NULL, 1134, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (306, 1, 'OUSMANE KIMINA', NULL, 1135, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (307, 1, 'BABA KAMINA', NULL, 1136, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (308, 1, 'MAMADOU SYLLA', NULL, 1137, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (309, 1, 'SEYDOU KONTA', NULL, 1138, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (310, 1, 'DIARRA ', NULL, 1139, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (311, 1, 'ABDOULAYE', NULL, 1140, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (312, 1, 'KAMANI FAMANTA', NULL, 1141, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (313, 1, 'SEYDOU', NULL, 1142, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (314, 1, 'SEKOUBA', NULL, 1143, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (315, 1, 'MADOU SIMINTA', NULL, 1144, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (316, 1, 'LASSINA FAMANTA', NULL, 1145, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (317, 1, 'GALI FAMANTA', NULL, 1146, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (318, 1, 'MAMADOU DJEKENI', NULL, 1147, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (319, 1, 'BAKARY SAPANA', NULL, 1148, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (320, 1, 'MAMA FAMATA', NULL, 1149, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (321, 1, 'OUSMANE DICKO', NULL, 1150, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (322, 1, 'BREHIMA NABO', NULL, 1151, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (323, 1, 'MOUSSA KARABA�TA', NULL, 1152, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (324, 1, 'MAHAMED DIARRA', NULL, 1153, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (325, 1, 'BREHIMA NOBO', NULL, 1154, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (326, 1, 'MOUSSA KARBA�TA', NULL, 1155, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (327, 0, 'MOUSSA KARABA�TA', NULL, 1156, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (328, 1, 'BREHIMA NOBA', NULL, 1157, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (329, 1, 'MOHAMED DIARRA', NULL, 1158, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (330, 1, 'CHEIK OMAR KE�TA', NULL, 1159, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (331, 1, 'BREMA KANTA', NULL, 1160, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (332, 1, 'BORY SIMBE', NULL, 1161, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (333, 1, 'SEKOU CISSE', NULL, 1162, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (334, 1, 'AMADOU TAMBOURA', NULL, 1163, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (335, 1, 'KAOUDON TRAORE', NULL, 1164, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (336, 1, 'ABDOULAYE TRAORE', NULL, 1165, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (337, 1, 'BOUBACAR TRAORE', NULL, 1166, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (338, 1, 'SAYON TRAORE', NULL, 1167, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (339, 1, 'AMADOU KALAPO', NULL, 1168, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (340, 1, 'DEMBA GUINDO', NULL, 1169, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (341, 1, 'BA�DY GUINDO', NULL, 1170, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (342, 1, 'MOUSSA KONTA', NULL, 1171, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (343, 1, 'BREMA NABO', NULL, 1172, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (344, 1, 'CHEICK OMAR KE�TA', NULL, 1173, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (345, 1, 'FOUSSENY DJEMINTA', NULL, 1174, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (346, 1, 'AMADOU TRAORE', NULL, 1175, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (347, 1, 'BOUBACAR DIARRA', NULL, 1176, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (348, 1, 'BOUBACAR MINTA', NULL, 1177, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (349, 1, 'BOUBACAR KONTA', NULL, 1178, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (350, 1, 'MADY TIKAMBO', NULL, 1179, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (351, 1, 'OUMAR TRAORE', NULL, 1180, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (352, 1, 'HAROUNA DIARRA', NULL, 1181, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (353, 1, 'DABO CISSE', NULL, 1182, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (354, 1, 'HADYA SACKO', NULL, 1183, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (355, 1, 'MAHI TRAORE', NULL, 1184, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (356, 1, 'MADOU DIARRA', NULL, 1185, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (357, 1, 'TALBY KONTA', NULL, 1186, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (358, 1, 'BAGNING TRAORE', NULL, 1187, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (359, 1, 'ALASSANE TRAORE', NULL, 1188, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (360, 1, 'ADAMA KANE', NULL, 1189, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (361, 1, 'KARIM', NULL, 1190, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (362, 1, 'KARAMOKO KONTA', NULL, 1191, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (363, 1, 'MOUSSA CISSE', NULL, 1192, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (364, 1, 'OUSMANA KOMOTA', NULL, 1193, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (365, 1, 'AMADOU TOURE', NULL, 1194, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (366, 1, 'OUSMANE KONTA', NULL, 1195, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (367, 1, 'BABA CISSE', NULL, 1196, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (368, 1, 'HADY SACKO', NULL, 1197, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (369, 1, 'NKA KARABENTA', NULL, 1198, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (370, 1, 'AMADOU', NULL, 1199, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (371, 1, 'BASSIRA KONTA', NULL, 1200, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (372, 1, 'ALY FAMANTA', NULL, 1201, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (373, 1, 'BAMA KONTA', NULL, 1202, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (374, 1, 'OUSMANE DIARRA', NULL, 1203, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (375, 1, 'BOUREMA TRAORE', NULL, 1204, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (376, 1, 'BASSOUMANA KONTA', NULL, 1205, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (377, 1, 'MAHAMADOU DEBOKENE', NULL, 1206, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (378, 1, 'SEKOU DEBOKENE 1', NULL, 1207, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (379, 1, 'SEKOU DEBOKENE', NULL, 1208, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (380, 1, 'MADJOU KOSSIMBO', NULL, 1209, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (381, 1, 'KARAMOKO DJIRE', NULL, 1210, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (382, 1, 'SOUMA�LA KONTA', NULL, 1211, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (383, 1, 'MAMA DEBOKENE', NULL, 1212, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (384, 1, 'SEKOU DEBOKENE 2', NULL, 1213, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (385, 1, 'KASSOUM KONTA', NULL, 1214, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (386, 1, 'ABDOULAYE KOTA', NULL, 1215, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (387, 1, 'MADJOU KASSIMBO', NULL, 1216, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (388, 1, 'HANOU KANTA', NULL, 1217, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (389, 1, 'MOUSSA DEBOKENE', NULL, 1218, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (390, 1, 'SOUMA�LA KANTA', NULL, 1219, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (391, 1, 'KASSOUM KONTA 1', NULL, 1220, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (392, 1, 'KASSOUM KONTA 2', NULL, 1221, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (393, 1, 'ALPHA KOUNTA', NULL, 1222, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (394, 1, 'MAMA� KONTAO', NULL, 1223, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (395, 1, 'KENSI DABITAO', NULL, 1224, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (396, 1, 'DRAMANI KOUNTA', NULL, 1225, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (397, 1, 'BROULAYE KOUNTAO', NULL, 1226, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (398, 1, 'KEOU KALAPO', NULL, 1227, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (399, 2, 'KENSI DABITAO', NULL, 1228, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (400, 1, 'MAMA� KOUNTAO', NULL, 1229, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (401, 1, 'ADAMA KOUNTA', NULL, 1230, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (402, 1, 'MOUSSA KALAPO', NULL, 1231, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (403, 1, 'KAMA KONE', NULL, 1232, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (404, 1, 'MAHAMADI TERETA', NULL, 1233, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (405, 1, 'SEKO KOUNTA', NULL, 1234, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (406, 1, 'SEYNI TERETA', NULL, 1235, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (407, 1, 'SOULEY MA�GA', NULL, 1236, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (408, 1, 'BREHIMA DIALLO', NULL, 1237, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (409, 1, 'DRISSA KAMBO', NULL, 1238, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (410, 1, 'MAMADOU DRAMANI KOUNTA', NULL, 1239, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (411, 1, 'MANSOUR TERETA', NULL, 1240, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (412, 1, 'MOUSSA KOUNTA', NULL, 1241, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (413, 1, 'ALI TERETA', NULL, 1242, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (414, 1, 'MAMAH KONTAO', NULL, 1243, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (415, 1, 'MOUSSA NIOUMANTA', NULL, 1244, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (416, 1, 'SIDI KAMBO', NULL, 1245, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (417, 1, 'MAMADI KAMBO', NULL, 1246, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (418, 1, 'MOCTAR MA�GA', NULL, 1247, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (419, 1, 'MOUCTAR KAMBO', NULL, 1248, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (420, 1, 'DRAMANE KOUNTA', NULL, 1249, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (421, 1, 'LASSINA KOUNTA', NULL, 1250, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (422, 1, 'LASSINA KOUNTAO', NULL, 1251, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (423, 1, 'SOUMANA KOUNTA', NULL, 1252, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (424, 1, 'MAMAYE KONTAO', NULL, 1253, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (425, 1, 'MARAMA KOUNTA', NULL, 1254, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (426, 1, 'MA�ACHALA KOUNTA', NULL, 1255, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (427, 1, 'FOUSSEYNI KOUNTA', NULL, 1256, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (428, 1, 'SEYDOU KOUNTA', NULL, 1257, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (429, 1, 'LASSINA KONTAO', NULL, 1258, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (430, 1, 'MAMAYE KOUNTAO', NULL, 1259, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (431, 1, 'KASSIM KOUNTA', NULL, 1260, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (432, 1, 'FOUSSEYNI KOUNTAO', NULL, 1261, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (433, 1, 'SOUMA�LA TERETA', NULL, 1262, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (434, 1, 'MAMADOU TERETA', NULL, 1263, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (435, 1, 'BA SEYDOU KOUNTA', NULL, 1264, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (436, 1, 'MAYAMA KONTAO', NULL, 1265, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (437, 1, 'KALAYE DABITAO', NULL, 1266, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (438, 1, 'MAMADOU KONE', NULL, 1267, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (439, 1, 'SINALY DRAME', NULL, 1268, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (440, 1, 'CHEICK BREHIMA KALAPO', NULL, 1269, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (441, 1, 'CHEICK AMADOU TERETA', NULL, 1270, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (442, 1, 'MOCTAR TRAORE', NULL, 1271, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (443, 1, 'DJIBRIL MA�GA', NULL, 1272, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (444, 1, 'DRISSA KAMPO', NULL, 1273, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (445, 1, 'MAMAH MINTA', NULL, 1274, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (446, 1, 'KASSIM TEINTA', NULL, 1275, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (447, 1, 'MANARIE MINTA', NULL, 1276, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (448, 1, 'BOUBACAR SALAMANTA', NULL, 1277, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (449, 1, 'BABA KEITA', NULL, 1278, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (450, 1, 'MOUSTAPHA KE�TA', NULL, 1279, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (451, 1, 'CHEYDINA ALY KARABINTA', NULL, 1280, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (452, 1, 'CHEICK AMADOU SAOUNTA', NULL, 1281, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (453, 1, 'DIMBA TRAORE', NULL, 1282, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (454, 1, 'OUMAR SACKO', NULL, 1283, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (455, 1, 'KASSIM TIENTA', NULL, 1284, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (456, 1, 'MAMAH SACKO', NULL, 1285, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (457, 1, 'DAOUDA SALAMANTA', NULL, 1286, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (458, 1, 'MAMAH SINAYOGO', NULL, 1287, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (459, 1, 'SOUMANA TEINTA', NULL, 1288, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (460, 1, 'ADAMA MINTA', NULL, 1289, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (461, 1, 'MANI SINAYOGO', NULL, 1290, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (462, 1, 'SOUMANA TIENTA', NULL, 1291, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (463, 1, 'KASSIM TIENTA 2', NULL, 1292, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (464, 1, 'TAHIROU SOUMAORO', NULL, 1293, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (465, 1, 'ALI SANGARE', NULL, 1294, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (466, 1, 'ALI MA�GA', NULL, 1295, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (467, 1, 'BAH KOUANTA', NULL, 1296, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (468, 1, 'DAOUDA SALAMATA', NULL, 1297, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (469, 1, 'SINALY KARABINTA', NULL, 1298, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (470, 1, 'ADAMA SALAMANA', NULL, 1299, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (471, 1, 'ADAMA KONTAO', NULL, 1300, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (472, 1, 'MOUSTAPHA KEITA', NULL, 1301, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (473, 1, 'SIDI TOURE', NULL, 1302, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (474, 1, 'BROULAYE KOUANTA', NULL, 1303, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (475, 1, 'BABA KE�TA', NULL, 1304, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (476, 1, 'KASSIM TIENTA 1', NULL, 1305, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (477, 1, 'MANARIE MINTAW', NULL, 1306, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (478, 1, 'BOUBACARY SACKO', NULL, 1307, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (479, 1, 'ADAMA MINTAW', NULL, 1308, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (480, 1, 'ALI DIARRA', NULL, 1309, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (481, 1, 'OUSSOUMANE GNOUMATA', NULL, 1310, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (482, 1, 'BROULAYE KONTAO', NULL, 1311, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (483, 1, 'BREHIMA MINTAW', NULL, 1312, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (484, 1, 'LADJI TEINTA', NULL, 1313, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (485, 1, 'LARABI SACKO', NULL, 1314, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (486, 2, 'OUMAR TRAORE', NULL, 1315, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (487, 1, 'HAMIDOU SALAMANTA', NULL, 1316, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (488, 1, 'BOUBACAR SALAMATA', NULL, 1317, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (489, 1, 'LADJI MAMAH SINAYAGO', NULL, 1318, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (490, 1, 'KASSIM TEINTA 1', NULL, 1319, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (491, 1, 'MAMAH KOUANTA', NULL, 1320, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (492, 1, 'MOULAYE KANTA', NULL, 1321, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (493, 1, 'KASSIM TEINTA 2', NULL, 1322, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (494, 1, 'DAOUDA SALAMANA', NULL, 1323, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (495, 1, 'BOUBACAR MINTAW', NULL, 1324, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (496, 1, 'SOUMANA MINTAW', NULL, 1325, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (497, 1, 'KAYENE SALAMATA', NULL, 1326, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (498, 1, 'CHEICK AMADOU SOUMAORO', NULL, 1327, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (499, 1, 'BREHIMA NTIANRO', NULL, 1328, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (500, 1, 'TIDIANE SALAMATA', NULL, 1329, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (501, 1, 'MOULAYE KONTA', NULL, 1330, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (502, 1, 'MOHAMED DICKO', NULL, 1331, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (503, 1, 'BOUBACAR KARABINTA', NULL, 1332, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (504, 1, 'BROULAYE KOUNTA', NULL, 1333, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (505, 1, 'ADAMA SALAMATA', NULL, 1334, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (506, 1, 'BA CHAKA KANE', NULL, 1335, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (507, 1, 'DJOMINE DRAME', NULL, 1336, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (508, 1, 'LADJI KASSIM TIENTA', NULL, 1337, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (509, 1, 'AMDJATA KONTA', NULL, 1338, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (510, 1, 'ZOUMANA NIOUMANTA', NULL, 1339, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (511, 1, 'LARABI KONOTA', NULL, 1340, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (512, 1, 'BAKARY TRAORE', NULL, 1341, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (513, 1, 'SOUMANA MINTA', NULL, 1342, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (514, 1, 'MAMADOU SINAYOGO', NULL, 1343, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (515, 1, 'DJOMANE DRAME', NULL, 1344, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (516, 1, 'ALI MAIGA', NULL, 1345, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (517, 1, 'MANAH KOUNTA', NULL, 1346, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (518, 1, 'BAH KOUNTA', NULL, 1347, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (519, 1, 'IBRAHIMA GOURANSO', NULL, 1348, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (520, 1, 'MAMAH KOUNTA', NULL, 1349, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (521, 1, 'OUSMANI TRAORE', NULL, 1350, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (522, 1, 'LASSINA KOUANTA', NULL, 1351, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (523, 1, 'MAMAYE KOUANTA', NULL, 1352, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (524, 1, 'SEKOU KAMBO', NULL, 1353, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (525, 1, 'KARIM TERETA', NULL, 1354, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (526, 1, 'DAOUDA TERETA', NULL, 1355, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (527, 1, 'IBREHIMA MA�GA', NULL, 1356, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (528, 1, 'CHEICK MAGNI TERETA', NULL, 1357, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (529, 1, 'MAMAH KONTA', NULL, 1358, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (530, 1, 'SAADOU SAOUNTA', NULL, 1359, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (531, 1, 'LADJI MAMAH SINAYOGO', NULL, 1360, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (532, 1, 'KOMANI MINTA', NULL, 1361, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (533, 1, 'KABORO SINAYOGO', NULL, 1362, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (534, 1, 'NALYA SAOUNTA', NULL, 1363, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (535, 1, 'DIMBA DICKO', NULL, 1364, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (536, 1, 'HAMDIATA KE�TA', NULL, 1365, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (537, 1, 'BA CHAAKA KANE', NULL, 1366, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (538, 1, 'SEKOU GOURANSO', NULL, 1367, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (539, 1, 'DAOUDA SALAMTA', NULL, 1368, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (540, 1, 'MAMADOU NAFO', NULL, 1369, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (541, 1, 'KOMANI SORITAO', NULL, 1370, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (542, 1, 'FATOUMATA SALAMANTA', NULL, 1371, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (543, 1, 'FATOUMAT SALAMANTA', NULL, 1372, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (544, 1, 'ADAMA KOUNTAO', NULL, 1373, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (545, 1, 'MANANI SINAYOGO', NULL, 1374, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (546, 1, 'MOUSSA KANTA', NULL, 1375, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (547, 1, 'SOUMANA KANTA', NULL, 1376, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (548, 1, 'SADIO DJINTA', NULL, 1377, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (549, 1, 'CHEIK AMADOU DABITAO', NULL, 1378, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (550, 1, 'MAMAH DABITAO', NULL, 1379, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (551, 1, 'LASSINA TRAORE', NULL, 1380, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (552, 1, 'AMADOU MA�GA', NULL, 1381, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (553, 1, 'A�CHA DABITAO', NULL, 1382, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (554, 1, 'FOUSSEYNI TRAORE', NULL, 1383, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (555, 1, 'CHEICK AMADOU DABITAO', NULL, 1384, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (556, 1, 'ALMAMY CISSE', NULL, 1385, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (557, 1, 'MOUSSA DJINTA', NULL, 1386, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (558, 1, 'MOCTAR SININTA', NULL, 1387, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (559, 1, 'OUMAR DABITAO', NULL, 1388, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (560, 1, 'BOUBACAR SANGARE', NULL, 1389, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (561, 1, 'YORO SAMAKE', NULL, 1390, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (562, 1, 'BINKE TRAORE', NULL, 1391, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (563, 1, 'OUMAR COURANSO', NULL, 1392, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (564, 1, 'LADJI MINTA', NULL, 1393, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (565, 1, 'IBRAHIMA TERETA', NULL, 1394, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (566, 1, 'MOHAMED KONE', NULL, 1395, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (567, 1, 'YOUSSOUF KINTA', NULL, 1396, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (568, 1, 'KALPHALA KOUNTA', NULL, 1397, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (569, 1, 'ZOUMANA KONTA', NULL, 1398, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (570, 1, 'MAHAMADI KAMBO', NULL, 1399, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (571, 1, 'SOULEYMANE KALAPO', NULL, 1400, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (572, 1, 'KADRI TANAPO', NULL, 1401, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (573, 1, 'MAMADOU DRAMANE KOUNTA', NULL, 1402, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (574, 1, 'ADAMA KONTA', NULL, 1403, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (575, 1, 'YAYA NAPO', NULL, 1404, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (576, 1, 'MOUSSA KEITA', NULL, 1405, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (577, 1, 'MAMADOU SINAYOKO', NULL, 1406, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (578, 1, 'LADJI KONE', NULL, 1407, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (579, 1, 'LASSANA MINTA', NULL, 1408, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (580, 1, 'MAMA SECRE', NULL, 1409, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (581, 1, 'ISSA DOUMANKORO', NULL, 1410, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (582, 1, 'BOUBACAR KONE', NULL, 1411, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (583, 1, 'BOUKADARI KEITA', NULL, 1412, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (584, 1, 'KOMANI KOUNTAO', NULL, 1413, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (585, 1, 'KO NABO', NULL, 1414, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (586, 1, 'SINALY SECRE', NULL, 1415, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (587, 1, 'KELEYA KAMATOU', NULL, 1416, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (588, 1, 'BOUREIMA TANAPO', NULL, 1417, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (589, 1, 'BASSIROU TERETA', NULL, 1418, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (590, 1, 'DRISSA TERETA', NULL, 1419, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (591, 1, 'MOUSSA KAMPO', NULL, 1420, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (592, 1, 'SIDIKY KONE', NULL, 1421, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (593, 1, 'TIDIANE KEITA', NULL, 1422, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (594, 1, 'KOMANI KONE', NULL, 1423, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (595, 1, 'LASSINA MINTA', NULL, 1424, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (596, 1, 'TAMANA SINAYOKO', NULL, 1425, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (597, 1, 'BOUBACAR DJIRE', NULL, 1426, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (598, 1, 'DJEDJE SONGHO', NULL, 1427, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (599, 1, 'SOUMAILA KANTA', NULL, 1428, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (600, 1, 'BORY SIMBO', NULL, 1429, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (601, 1, 'YAYA TIKAMBO', NULL, 1430, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (602, 1, 'AMADOU TIKAMBO', NULL, 1431, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (603, 1, 'YAYA KONE', NULL, 1432, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (604, 1, 'SEKOU SALLA TIKAMBO', NULL, 1433, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (605, 1, 'BAREMA DIOUANDE', NULL, 1434, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (606, 1, 'ZOUMANA MAIGA', NULL, 1435, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (607, 1, 'MAMADOU MAIGA', NULL, 1436, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (608, 1, 'ALY KAMBO', NULL, 1437, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (609, 1, 'MAMADY KAMBO', NULL, 1438, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (610, 1, 'BINKE NTINI TIKAMBO', NULL, 1439, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (611, 1, 'LAMINE TIKAMBO ', NULL, 1440, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (612, 1, 'MAMA MINTA', NULL, 1441, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (613, 1, 'ABDOULAYE SERETA', NULL, 1442, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (614, 1, 'YOUSSOUF TIKAMBO', NULL, 1443, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (615, 1, 'BOUACAR MAIGA', NULL, 1444, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (616, 1, 'BABA SININTA', NULL, 1445, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (617, 1, 'TETE MAMADY TIKAMBO', NULL, 1446, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (618, 1, 'BOUBACAR TIKAMBO', NULL, 1447, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (619, 1, 'BAYE TRAORE', NULL, 1448, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (620, 1, 'ALASSANE TOURE', NULL, 1449, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (621, 1, 'BOUKADARY SININTA', NULL, 1450, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (622, 1, 'OUDOU TIKAMBO', NULL, 1451, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (623, 1, 'DJIBRIL TIENTA', NULL, 1452, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (624, 1, 'ABDOULAYE KOUNTA', NULL, 1453, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (625, 1, 'SOULEYMANI TRAORE', NULL, 1454, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (626, 1, 'LADJI KOUNTA', NULL, 1455, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (627, 1, 'MAMAI KOUNTA', NULL, 1456, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (628, 1, 'ADAMA KOTA', NULL, 1457, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (629, 1, 'HADI KOUNTA', NULL, 1458, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (630, 1, 'ADAMA MAIGA', NULL, 1459, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (631, 1, 'DJIBRIL MAIGA', NULL, 1460, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (632, 1, 'ALI KAMBO', NULL, 1461, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (633, 1, 'MAMAH KOUNTAO', NULL, 1462, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (634, 1, 'MOCTAR MAIGA', NULL, 1463, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (635, 1, 'SOUMAILA TERETA', NULL, 1464, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (636, 1, 'SOULEY MAIGA', NULL, 1465, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (637, 1, 'KARAMOKO DIARRA', NULL, 1466, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (638, 2, 'KARAMOKO KONTA', NULL, 1467, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (639, 1, 'MAMA KARAWANTA', NULL, 1468, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (640, 1, 'ADAMA SABE', NULL, 1469, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (641, 1, 'BA NDOLO TRAORE', NULL, 1470, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (642, 1, 'DAOUDA KONTA', NULL, 1471, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (643, 1, 'BOURI', NULL, 1472, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (644, 1, 'ADAMA SERETA', NULL, 1473, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (645, 1, 'KOCHOU', NULL, 1474, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (646, 1, 'BARIMA NIARE', NULL, 1475, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (647, 1, 'SAMBA TRAORE', NULL, 1476, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (648, 1, 'KOKE KONTA', NULL, 1477, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (649, 1, 'ALMAMY', NULL, 1478, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (650, 1, 'SAMBA CISSE', NULL, 1479, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (651, 1, 'BASOUMANA DOROGOU', NULL, 1480, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (652, 1, 'BINA NIARE', NULL, 1481, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (653, 1, 'SAMBA SAMAKE', NULL, 1482, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (654, 1, 'BAKARY SOGORE', NULL, 1483, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (655, 1, 'SOUMANA SAMPANA', NULL, 1484, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (656, 1, 'SIDI BREMA SININTA', NULL, 1485, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (657, 1, 'BAKARI DIARRA', NULL, 1486, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (658, 1, 'LASSANA TRAORE 1', NULL, 1487, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (659, 1, 'BANGO KONTA', NULL, 1488, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (660, 1, 'MAMA KOUANTA', NULL, 1489, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (661, 1, 'MAMADY TRAORE', NULL, 1490, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (662, 1, 'FANTA MADY SAMPANA', NULL, 1491, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (663, 1, 'SEKOU NIARE', NULL, 1492, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (664, 1, 'SITAPHA', NULL, 1493, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (665, 1, 'MATAFILI', NULL, 1494, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (666, 1, 'SOULEYE', NULL, 1495, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (667, 1, 'KOBA KONTA', NULL, 1496, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (668, 1, 'KOUANA  KONTA', NULL, 1497, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (669, 1, 'SIRA KONTA', NULL, 1498, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (670, 1, 'ALOU DOUCOURE', NULL, 1499, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (671, 1, 'BINA DIARRA', NULL, 1500, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (672, 1, 'BAKARI SOGORE', NULL, 1501, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (673, 1, 'BONGO KONTA', NULL, 1502, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (674, 1, 'FANTAMDY SAMPANA', NULL, 1503, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (675, 1, 'YACOUBA SINETA', NULL, 1504, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (676, 1, 'ABDOU KADER JENTA', NULL, 1505, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (677, 1, 'AMADOU WASSONKO', NULL, 1506, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (678, 1, 'HAMIDOU JENTA', NULL, 1507, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (679, 1, 'NOUHOU FAMATA', NULL, 1508, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (680, 1, 'SEKOU KONAKOMO', NULL, 1509, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (681, 1, 'AMADOU SOW', NULL, 1511, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (682, 1, 'BOUKARY SAPANA', NULL, 1767, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (683, 1, 'BREHIMA NIOUMATA', NULL, 1768, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (684, 1, 'BAKARY NADJAN', NULL, 1769, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (685, 1, 'BOURAMA NOBO', NULL, 1770, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (686, 1, 'BOURAMA NABO', NULL, 1771, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (687, 1, 'MOUSSA KARABAITA', NULL, 1772, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (688, 1, 'MADOU DIANGO KANTAO', NULL, 1773, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (689, 1, 'BOUBACAR NADJAN', NULL, 1774, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (690, 1, 'MADOU KOBLA', NULL, 1775, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (691, 1, 'MOUSSA KOMOU', NULL, 1776, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (692, 1, 'YACOUBA KARABANA', NULL, 1777, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (693, 1, 'OUSMANE MINTA', NULL, 1778, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (694, 1, 'SEKOU BREMA HONONTA', NULL, 1779, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (695, 1, 'DIMBA MINTA', NULL, 1780, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (696, 1, 'ABDOULAYE MAIGA', NULL, 1781, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (697, 1, 'AMADOU MINTA', NULL, 1782, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (698, 1, 'LADJI KONTA', NULL, 1783, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (699, 1, 'LASSINA KONTA', NULL, 1784, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (700, 1, 'BOYE SOW', NULL, 1785, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (701, 1, 'DIADIE MINTA', NULL, 1786, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (702, 1, 'ALMAMY ENOUMANTA', NULL, 1787, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (703, 1, 'ASSANE MINTA', NULL, 1788, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (704, 1, 'AMADOU DIMBA MINTA', NULL, 1789, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (705, 1, 'BAKARY DIAKITE', NULL, 1790, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (706, 1, 'YACOUBA DOUMANGOUROU', NULL, 1791, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (707, 1, 'MOHAMED DOUMANGOUROU', NULL, 1792, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (708, 1, 'MOUSSA KAMOU', NULL, 1793, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (709, 1, 'MOUSSA TICAMBO', NULL, 1794, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (710, 1, 'NIAGA TOUNKARA', NULL, 1795, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (711, 1, 'SENI TAGAKE', NULL, 1796, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (712, 1, 'ASSIM TICAMBO', NULL, 1797, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (713, 1, 'ASSANA KANTA', NULL, 1798, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (714, 1, 'ASSANA MINTA', NULL, 1799, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (715, 1, 'MOUSSA DIT BATA DONOUGOU', NULL, 1800, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (716, 1, 'SENY TAGAKE', NULL, 1801, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (717, 1, 'BAYE SOW', NULL, 1802, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (718, 1, 'NGARBA KOROTA', NULL, 1803, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (719, 1, 'OUSMANA MINTA', NULL, 1804, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (720, 1, 'LADJI KONTE', NULL, 1805, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (721, 1, 'ASSANE KANTA', NULL, 1806, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (722, 1, 'ALMAMY HAIDARA', NULL, 1807, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (723, 1, 'BREMA KONTA', NULL, 1808, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (724, 1, 'INAKA KANTA', NULL, 1809, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (725, 1, 'MAHAMBE TOUKARA', NULL, 1810, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (726, 1, 'BOUBACARY CRONGO', NULL, 1811, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (727, 1, 'TIDIANE KANTA', NULL, 1812, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (728, 1, 'ALMAMY TEMBE', NULL, 1813, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (729, 1, 'AMADOU NADJAN', NULL, 1814, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (730, 1, 'SAMBA DEMBELE', NULL, 1815, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (731, 1, 'ALMAMY NADJAN', NULL, 1816, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (732, 1, 'SINALY HAIDARA', NULL, 1817, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (733, 1, 'MAMA KANTE', NULL, 1818, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (734, 1, 'NOUHOU TAMOTA', NULL, 1819, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (735, 1, 'BOUBACARYT CRONGO', NULL, 1820, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (736, 1, 'MODIBO KONATE', NULL, 1821, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (737, 1, 'AMADOU SARR', NULL, 1822, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (738, 1, 'MAMA KANTA', NULL, 1823, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (739, 1, 'LASSANA COULIBALY', NULL, 1824, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (740, 1, 'ABDOULAYE  TRAORE', NULL, 1825, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (741, 1, 'KAOUDOU TRORE', NULL, 1826, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (742, 1, 'AMADOU  TAMBOURA', NULL, 1827, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (743, 1, 'KAOUDOU  TRAORE', NULL, 1828, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (744, 1, 'FOUSSEYNI DJEMINTA', NULL, 1829, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (745, 1, 'BORY  SIMBE', NULL, 1830, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (746, 1, 'KAOUDOU TRAORE', NULL, 1831, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (747, 1, 'HAMA COULIBALY', NULL, 1832, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (748, 1, 'YOUSSOUF  KAOMOU', NULL, 1833, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (749, 1, 'ASSANE DIARRA', NULL, 1834, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (750, 1, 'ISSA KAMOU', NULL, 1835, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (751, 0, 'AMADOU TAMBOURA', NULL, 1836, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (752, 1, 'BOURE�MA KANE', NULL, 1837, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (753, 1, 'SOLOMANE NIARE', NULL, 1838, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (754, 1, 'MOUSSA  DOUCOURE', NULL, 1839, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (755, 1, 'MAMA KAMOTAO', NULL, 1840, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (756, 1, 'SOLOMANE KANE', NULL, 1841, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (757, 1, 'HAMA COUKIBALY', NULL, 1842, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (758, 1, 'BOURE�MA KOME', NULL, 1843, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (759, 1, 'YOUSSOUF KAMOU', NULL, 1844, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (760, 1, 'BEIDY SIDIBE', NULL, 1845, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (761, 1, 'AMADOU TAMBOUR', NULL, 1846, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (762, 1, 'ISSA KOUMOU', NULL, 1847, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (763, 1, 'BOUREIMA KANE', NULL, 1848, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (764, 1, 'NKA PA�TO', NULL, 1849, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (765, 1, 'SODIO WOSSOKO', NULL, 1850, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (766, 1, 'MOUHAMADOU BARRY', NULL, 1851, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (767, 1, 'SAIDO WOSSONKO', NULL, 1852, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (768, 1, 'AMADOU WASSOONKO', NULL, 1853, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (769, 1, 'DJIBRIL SALAMTA', NULL, 1854, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (770, 1, 'BAKARI FOFANA', NULL, 1855, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (771, 1, 'MOUHAMADOU  BARRY ', NULL, 1856, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (772, 1, 'BAABDOULAYE SANCAFE', NULL, 1857, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (773, 1, 'HASSIM DIENTA', NULL, 1858, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (774, 1, 'ABDOUL KADER FOFANA', NULL, 1859, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (775, 1, 'MOUHAMED FOFANA', NULL, 1860, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (776, 1, 'MOUHAMADOU DIENTA', NULL, 1861, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (777, 1, 'ABDOUL KADER DIENTA', NULL, 1862, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (778, 1, 'SIDI TANEMPO', NULL, 1863, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (779, 1, 'MADJOU KOSSOUMBO', NULL, 1864, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (780, 0, 'BOUBACAR TRAORE', NULL, 1865, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (781, 1, 'FAROUGOU TENEMPO', NULL, 1866, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (782, 1, 'MADJOU KOSSONKO', NULL, 1867, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (783, 1, 'NKA   PA�TO', NULL, 1868, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (784, 1, 'BOUBACAR  NADIAN ', NULL, 1869, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (785, 1, 'HASSIM KOMBLA', NULL, 1870, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (786, 1, 'MAHAMADOU  BARRY ', NULL, 1871, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (787, 1, 'FAROUGOU  TANEMPO', NULL, 1872, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (788, 1, 'BARYMA  SANCAFE', NULL, 1873, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (789, 1, 'MAHAMOUDOU DIENTA', NULL, 1874, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (790, 1, 'BORY SIMB�', NULL, 1875, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (791, 1, 'KAOUDOU TRAOR�', NULL, 1876, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (792, 1, 'FOUSS�NY DJ�MINTA', NULL, 1877, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (793, 1, 'ABDOULAYE TRAOR�', NULL, 1878, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (794, 1, 'ABDOULAYE  TRAOR�', NULL, 1879, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (795, 1, 'BORY SYMB�', NULL, 1880, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (796, 1, 'BOUBACAR TRAOR� ', NULL, 1881, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (797, 1, 'BOUBACAR  TRAOR�', NULL, 1882, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (798, 1, 'KAOUDON TRAOR�', NULL, 1883, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (799, 1, 'MAHAMB� TOUNKARA', NULL, 1884, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (800, 1, 'SINOLY A�DARA', NULL, 1885, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (801, 1, 'ALMAMY A�DARA', NULL, 1886, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (802, 1, 'MAMA KONAKOMO', NULL, 1887, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (803, 1, 'MAMADOU KALLAPO', NULL, 1888, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (804, 1, 'OUSMANE KONAKOMO', NULL, 1889, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (805, 1, 'BOUBACARY DANSO', NULL, 1890, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (806, 1, 'DEMBO KALLOPO', NULL, 1891, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (807, 1, 'FAMORY DEMBELE', NULL, 1892, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (808, 1, 'AMADOU SORO', NULL, 1893, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (809, 1, 'BOUBAKARY DANSO', NULL, 1894, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (810, 1, 'BOUBACAR DANSO', NULL, 1895, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (811, 1, 'BEKAYE YATARA', NULL, 1896, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (812, 1, 'OUSMANE NIOUMATA', NULL, 1897, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (813, 0, 'TIDIANE KONTA', NULL, 1898, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (814, 1, 'TIDIANE  KONTA', NULL, 1899, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (815, 1, 'LASSANA FAROTO', NULL, 1900, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (816, 1, 'SAMBA TEMBOURA', NULL, 1901, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (817, 1, 'TIDJANE KONTA', NULL, 1902, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (818, 1, 'BOUBAKAR DANSO', NULL, 1903, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (819, 1, 'KONOBA COULIBALY', NULL, 1904, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (820, 1, 'YAYA SAMAK�', NULL, 1905, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (821, 1, 'ALMAMY FOFANA', NULL, 1906, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (822, 1, 'INAKO KONTA', NULL, 1907, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (823, 1, 'BR�MA KONTA', NULL, 1908, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (824, 1, 'LASSANA FARATA', NULL, 1909, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (825, 1, 'SAMBOU DEMB�L�', NULL, 1910, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (826, 1, 'DEMBA KALLAPO', NULL, 1911, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (827, 1, 'BREMA SOW', NULL, 1912, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (828, 1, 'DIADIE NAHJAN', NULL, 1913, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (829, 1, 'SOUMANA KALLAPO', NULL, 1914, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (830, 1, 'OUSMANE KANOKOMO', NULL, 1915, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (831, 1, 'NONHOU TOMOTA', NULL, 1916, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (832, 1, 'MAMADOU KALAPO', NULL, 1917, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (833, 1, 'DEMBO KALLAPO', NULL, 1918, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (834, 1, 'SAMBA TOUNKARA', NULL, 1919, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (835, 1, 'SEKOU A KE�TA', NULL, 1920, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (836, 1, 'BOUKADARY OULOLE', NULL, 1921, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (837, 1, 'MAMADOU DEMBELE', NULL, 1922, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (838, 1, 'AMAMDOU NADJAN', NULL, 1923, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (839, 1, 'MAHAMBE KONTA', NULL, 1924, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (840, 1, 'BREMA SOCKO', NULL, 1925, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (841, 1, 'TIEBA SALAMATA', NULL, 1926, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (842, 1, 'SEKOU AMADOU TERETA', NULL, 1927, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (843, 1, 'BABYLAYE KOUNTA', NULL, 1928, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (844, 1, 'MAMAH KONTAN', NULL, 1929, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (845, 1, 'BANO SALAMATA', NULL, 1930, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (846, 1, 'MANY SINAYOGO', NULL, 1931, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (847, 1, 'BAOULAYE KOUNTAO', NULL, 1932, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (848, 1, 'BAOULAYE KONTAO', NULL, 1933, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (849, 1, 'BAKARY SALAMATA', NULL, 1934, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (850, 1, 'MAHAMADOU KONTA', NULL, 1935, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (851, 1, 'KOROMOGO KANTA', NULL, 1936, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (852, 1, 'NANABA TERETA', NULL, 1937, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (853, 1, 'BA ADAMA KONTA', NULL, 1938, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (854, 1, 'BROULALAYE KOUNTAO', NULL, 1939, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (855, 1, 'MANI SINAYAGO', NULL, 1940, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (856, 1, 'MANE SIMAYOGO', NULL, 1941, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (857, 1, 'KALIME DRAME', NULL, 1942, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (858, 1, 'ALY MAIGA', NULL, 1943, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (859, 1, 'MAMADOU SINAYO', NULL, 1944, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (860, 1, 'ALY SANGARE', NULL, 1945, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (861, 1, 'SEKOU KOURANSO', NULL, 1946, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (862, 1, 'KANTA MOULAYE', NULL, 1947, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (863, 1, 'DAOUDA SALAMANTO', NULL, 1948, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (864, 1, 'YORO SANGARE', NULL, 1949, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (865, 1, 'MAMADOU NAMBO', NULL, 1950, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (866, 1, 'KAKAYE MINTA', NULL, 1951, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (867, 1, 'ABDOULAYE KOUNTAO', NULL, 1952, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (868, 1, 'LASSINA SAMPANA', NULL, 1953, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (869, 1, 'BOUBACAR SAMASSEKOU', NULL, 1954, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (870, 1, 'MOUSSA KOUNTAO', NULL, 1955, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (871, 1, 'SERIBA SIBIBE', NULL, 1956, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (872, 1, 'LADJI SAMPANA', NULL, 1957, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (873, 1, 'DIMBA KASSABARA', NULL, 1958, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (874, 1, 'BOUBACAR KASSABARA', NULL, 1959, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (875, 1, 'SOUMANA KAYANTAO', NULL, 1960, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (876, 1, 'MAMADOU SININTA', NULL, 1961, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (877, 1, 'KONKOURY KEKERE', NULL, 1962, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (878, 1, 'AMADOU KOUNTAO', NULL, 1963, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (879, 1, 'MAMAH TRAORE', NULL, 1964, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (880, 1, 'MAMAH NAMBO', NULL, 1965, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (881, 1, 'MAMAH HAIDRA', NULL, 1966, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (882, 1, 'SIDIKI DABITAO', NULL, 1967, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (883, 1, 'OUSMANI DABITAO', NULL, 1968, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (884, 1, 'SINALY DABITAO', NULL, 1969, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (885, 1, 'MADY', NULL, 1970, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (886, 1, 'MAMA TIEDA', NULL, 1971, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (887, 1, 'KOLA', NULL, 1972, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (888, 1, 'BOUKAR KOMONTA', NULL, 1973, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (889, 1, 'MORY', NULL, 1974, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (890, 1, 'BALY', NULL, 1975, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (891, 1, 'ABDOULA TIENTA', NULL, 1976, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (892, 1, 'PLORY KOMONTA', NULL, 1977, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (893, 1, 'SOUMANA SALAMATA', NULL, 1978, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (894, 1, 'ADAMAMA NIOUMANTA', NULL, 1979, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (895, 1, 'SOUMAILA', NULL, 1980, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (896, 1, 'BOUBACAR KOMONTA', NULL, 1981, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (897, 1, 'BOUGADER TAPO', NULL, 1982, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (898, 1, 'TALY', NULL, 1983, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (899, 1, 'TIEBA', NULL, 1984, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (900, 1, 'KALY', NULL, 1985, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (901, 1, 'MODOU', NULL, 1986, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (902, 1, 'MADOU ', NULL, 1987, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (903, 1, 'OUMAR KANTA', NULL, 1988, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (904, 1, 'SORY KOMOU', NULL, 1989, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (905, 1, 'KOLA KAROGNON', NULL, 1990, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (906, 1, 'TOTO', NULL, 1991, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (907, 1, 'AMADOU DIADYE', NULL, 1992, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (908, 1, 'ISSOUFI SERETA', NULL, 1993, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (909, 1, 'KOLA KOGNON', NULL, 1994, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (910, 1, 'BOUACOU KOMONTA', NULL, 1995, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (911, 1, 'AMADOU DADIE', NULL, 1996, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (912, 1, 'DIANA', NULL, 1997, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (913, 1, 'MOHAMANE TOURE', NULL, 1998, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (914, 1, 'MAMANE', NULL, 1999, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (915, 1, 'BOUACAR KOMONTA', NULL, 2000, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (916, 1, 'MADOU MAMAYE', NULL, 2001, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (917, 1, 'ADAMA NIOUMANTA', NULL, 2002, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (918, 1, 'MAHAMANE', NULL, 2003, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (919, 1, 'KEVU KOROGNON', NULL, 2004, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (920, 1, 'AFOU KOROGNON', NULL, 2005, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (921, 1, 'BAFORO KONTA', NULL, 2006, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (922, 1, 'ADAMA KOMONTA', NULL, 2007, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (923, 1, 'MAMADOU BILOKORO', NULL, 2008, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (924, 1, 'BOUACARY KOMONTA', NULL, 2009, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (925, 1, 'KOLA KOROGNON', NULL, 2010, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (926, 1, 'MOUSSA   SEMBE', NULL, 2011, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (927, 1, 'KEBOUARI KOMONTA', NULL, 2012, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (928, 1, 'ALMAMY FAMANTA', NULL, 2013, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (929, 1, 'MODOU KOMINA', NULL, 2014, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (930, 1, 'SORY KOMINA', NULL, 2015, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (931, 1, 'MANA TAPO', NULL, 2016, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (932, 1, 'BABA KOMOU', NULL, 2017, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (933, 1, 'BOUBACAR DOUMBIA', NULL, 2018, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (934, 1, 'MADOU KOMINA', NULL, 2019, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (935, 1, 'SERIBA', NULL, 2020, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (936, 1, 'KA KONTA', NULL, 2021, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (937, 1, 'AFOU KOMOU', NULL, 2022, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (938, 1, 'TOMA KONTA', NULL, 2023, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (939, 1, 'SERIBA KONTA', NULL, 2024, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (940, 1, 'MOUSSA DIENTA', NULL, 2025, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (941, 1, 'BAGAOUSSOU FAMANTA', NULL, 2026, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (942, 1, 'SINALY KOMONTA', NULL, 2027, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (943, 1, 'SANU KONTA', NULL, 2028, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (944, 1, 'ZOUMANA', NULL, 2029, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (945, 1, 'KEBROUMA', NULL, 2030, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (946, 1, 'MAMA KOMINA', NULL, 2031, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (947, 1, 'MOUSSA SALAMANTA', NULL, 2032, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (948, 1, 'NOUNOUKE', NULL, 2033, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (949, 1, 'SEKOU', NULL, 2034, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (950, 1, 'SORY KOMONTA', NULL, 2035, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (951, 1, 'ADAMA NIAFO', NULL, 2036, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (952, 1, 'DIADIER SIENTA', NULL, 2037, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (953, 1, 'MOUSSA TIENTA', NULL, 2038, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (954, 1, 'AFOU', NULL, 2039, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (955, 1, 'KEMAMA', NULL, 2040, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (956, 2, 'BABA', NULL, 2041, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (957, 1, 'YOUSSOUF KOMINA', NULL, 2042, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (958, 1, 'MODOU SALAMATA', NULL, 2043, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (959, 1, 'BAGAOUSSOU', NULL, 2044, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (960, 1, 'TOMA', NULL, 2045, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (961, 1, 'ZOUMANA TAPO', NULL, 2046, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (962, 1, 'SERIBA COULIBALY', NULL, 2047, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (963, 1, 'AFO KOROGNON', NULL, 2048, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (964, 1, 'GARBA KONTA', NULL, 2049, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (965, 1, 'POULO', NULL, 2050, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (966, 1, 'SOLAMANE ', NULL, 2051, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (967, 1, 'SAM KONTA', NULL, 2052, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (968, 1, 'SOUMA�LA', NULL, 2053, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (969, 1, 'MOUSSA SORITA', NULL, 2054, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (970, 1, 'KEMADOU', NULL, 2055, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (971, 1, 'BOKARY', NULL, 2056, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (972, 1, 'NIAGA', NULL, 2057, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (973, 1, 'ALI CISSE', NULL, 2058, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (974, 1, 'DODO DABITAO', NULL, 2061, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (975, 1, 'BOUBACAR SEKERE', NULL, 2062, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (976, 1, 'MADOU SYNINTA', NULL, 2063, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (977, 1, 'AMADOU MAIGA', NULL, 2064, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (978, 1, 'MAMADOU NOVOGO', NULL, 2065, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (979, 1, 'ALY KONTA', NULL, 2066, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (980, 1, 'MAMA NAPOGO', NULL, 2067, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (981, 1, 'NOUHOU KINTAO', NULL, 2068, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (982, 1, 'MAMA PAKO', NULL, 2069, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (983, 1, 'BABA DJENEPO', NULL, 2070, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (984, 1, 'AMADOU KEITA', NULL, 2071, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (985, 1, 'KELEYA KOMATOU', NULL, 2072, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (986, 1, 'MAMADOU FINAYOKO', NULL, 2073, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (987, 1, 'BOUKADARY KEITA', NULL, 2074, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (988, 1, 'MOUSSA KANTE', NULL, 2075, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (989, 1, 'KELEYE KOMATOU', NULL, 2076, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (990, 1, 'KO NAPO', NULL, 2077, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (991, 1, 'KOMANI KWANTA', NULL, 2078, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (992, 1, 'MAMA NADIO', NULL, 2079, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (993, 1, 'SIDI TERETA', NULL, 2080, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (994, 1, 'SOUMAILA SINAYOGO', NULL, 2081, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (995, 1, 'MOHAMED DOUKOURE', NULL, 2082, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (996, 1, 'BARA DIARRA', NULL, 2083, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (997, 1, 'BOUBACAR SACKO', NULL, 2084, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (998, 1, 'ALDJOUMA CISSE', NULL, 2085, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (999, 1, 'MAHI CISSE', NULL, 2086, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1000, 1, 'SOUMAILA SINAYOKO', NULL, 2087, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1001, 1, 'SEKOU AMADOU KWANTA', NULL, 2088, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1002, 1, 'IBRAHIMA DIARRA', NULL, 2089, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1003, 1, 'ABDOULAYE SAMPANA', NULL, 2090, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1004, 1, 'BREHIMA TRAORE', NULL, 2091, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1005, 1, 'ZOUMANA SEKERE', NULL, 2092, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1006, 1, 'KASSIM SACKO', NULL, 2093, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1007, 1, 'BAKARY SACKO', NULL, 2094, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1008, 1, 'YOUSSOUF KALAPO', NULL, 2095, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1009, 1, 'AMADOU PAMANTA', NULL, 2096, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1010, 1, 'BOUBACAR KWANTA', NULL, 2097, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1011, 1, 'SOULEYMANE TERETA', NULL, 2098, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1012, 1, 'BIRAMA DONOGO', NULL, 2099, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1013, 1, 'MALAMINE FOFANA', NULL, 2100, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1014, 1, 'MOCTAR KONE', NULL, 2101, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1015, 1, 'MAMADI SININTA ', NULL, 2102, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1016, 1, 'MOHAMED KAYANTAO', NULL, 2103, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1017, 1, 'KARIM SIDIBE', NULL, 2104, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1018, 1, 'ABDOULAYE KONTAO', NULL, 2105, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1019, 1, 'ALY CISSE', NULL, 2106, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1020, 1, 'BADE DABITAO', NULL, 2107, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1021, 1, 'MAMADOU NAABO', NULL, 2108, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1022, 1, 'MAMADOU SAMASSEKOU', NULL, 2109, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1023, 1, 'MAMAH SANFANA ', NULL, 2110, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1024, 1, 'KONGOU SEREKE', NULL, 2111, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1025, 1, 'MAMAH BABITAO', NULL, 2112, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1026, 1, 'BADE BABITAO', NULL, 2113, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1027, 1, 'SYNALY DABITAO', NULL, 2114, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1028, 1, 'KAYANTAO SOUMANA', NULL, 2115, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1029, 1, 'SOLOMANE MINMANTAO', NULL, 2116, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1030, 1, 'TABA TANAPO', NULL, 2117, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1031, 1, 'MAMOUTOU SAMPANA', NULL, 2118, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1032, 1, 'KALIFA TRAORE', NULL, 2119, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1033, 1, 'SIDIKI MINMANTAO', NULL, 2120, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1034, 1, 'MAMA MINMANTAO', NULL, 2121, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1035, 1, 'AMADOU DAOU', NULL, 2122, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1036, 2, 'LASSINA KOMOTAO', NULL, 2123, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1037, 1, 'KANDE KOMOTAO', NULL, 2124, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1038, 1, 'MOHAMED TRAORE', NULL, 2125, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1039, 1, 'ABZAKARI MAIGA', NULL, 2126, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1040, 1, 'BOUBACAR LELENTA', NULL, 2127, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1041, 1, 'ABOUBACAR KOITA', NULL, 2128, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1042, 1, 'MAMADY SACKO', NULL, 2129, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1043, 1, 'MAMADY TOUNKARA', NULL, 2130, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1044, 1, 'ALASSANA TOURE', NULL, 2131, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1045, 1, 'ZOUMANA DIENTA', NULL, 2132, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1046, 1, 'ABDOULAY LALENTA', NULL, 2133, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1047, 1, 'BOUKADARI SININTA   ', NULL, 2134, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1048, 1, 'MAMADY KOITA', NULL, 2135, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1049, 1, 'LASSINA KOBILA', NULL, 2136, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1050, 1, 'SIDY TRAORE', NULL, 2137, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1051, 1, 'BIRAMA TIKAMBO                              ', NULL, 2138, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1052, 1, 'OUMAR DIENTA', NULL, 2139, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1053, 1, 'OUMAR TIKAMBO', NULL, 2140, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1054, 1, 'ABZAKARIA MAIGA', NULL, 2141, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1055, 1, 'BREHIMA SININTA', NULL, 2142, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1056, 1, 'MAMA PAKOU', NULL, 2143, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1057, 1, 'ALY KONTAO', NULL, 2144, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1058, 1, 'MADOU SINAYOKO', NULL, 2145, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1059, 1, 'MAMADOU NAPOGO', NULL, 2146, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1060, 1, 'BREHIMA KINTAO', NULL, 2147, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1061, 1, 'BOUACAR KANE', NULL, 2148, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1062, 1, 'SIDIKI KANE', NULL, 2149, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1063, 1, 'M OUSSA KEITA', NULL, 2150, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1064, 1, 'SIDIKI TERETA', NULL, 2151, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1065, 1, 'SEKOU KOBIPA', NULL, 2152, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1066, 1, 'MOULAYE TOUNKARA', NULL, 2153, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1067, 1, 'MAHAMANE MAIGA', NULL, 2154, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1068, 1, 'KARAMOKO KANE', NULL, 2155, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1069, 1, 'SOUMANA TIKAMBO', NULL, 2156, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1070, 1, 'SOUMAILA TRAORE', NULL, 2157, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1071, 1, 'SOUNKALO DIARRA', NULL, 2158, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1072, 1, 'DRISSA TRAORE', NULL, 2159, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1073, 1, 'BOUACAR KWANTA', NULL, 2160, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1074, 1, 'BROULAYE KWANTA', NULL, 2161, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1075, 1, 'KALILOU DRAME', NULL, 2162, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1076, 1, 'MAMADOU DOUCOURE', NULL, 2163, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1077, 1, 'BOUACAR TOURE', NULL, 2164, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1078, 1, 'ALPHAMOHI TIGNETA', NULL, 2165, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1079, 1, 'ABOUBACAR SIDIKI NADJIO', NULL, 2166, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1080, 1, 'SOULEMANE TRAORE', NULL, 2167, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1081, 1, 'BOI TRAORE', NULL, 2168, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1082, 1, 'BOURAMA TIGNETA', NULL, 2169, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1083, 1, 'HAMADY MAIGA', NULL, 2170, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1084, 1, 'BREHIM SACKO', NULL, 2171, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1085, 1, 'OUSMANE DABITAO', NULL, 2172, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1086, 1, 'ZOUMANA KAYANTAO', NULL, 2173, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1087, 1, 'SEYDOU SIDIBE', NULL, 2174, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1088, 1, 'MAMDOU MAIGA', NULL, 2175, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1089, 1, 'MAMAH KAYANTAO', NULL, 2176, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1090, 1, 'AMADOU SAMASSEKOU', NULL, 2177, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1091, 1, 'SERIBA DOUMBIA', NULL, 2178, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1092, 1, 'ADA DJINTA', NULL, 2179, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1093, 1, 'MAMADI KOUNTA', NULL, 2180, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1094, 1, 'FARIOUGOU TANEMPO', NULL, 2181, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1095, 1, 'LASSNA TRAORE ', NULL, 2182, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1096, 1, 'LASSINA KANE', NULL, 2183, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1097, 1, 'SEKOU KEITA', NULL, 2184, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1098, 1, 'HAMIDOU DJIENTA', NULL, 2185, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1099, 1, 'KEKOU KEITA', NULL, 2186, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1100, 1, 'BARMA SANCAFE', NULL, 2187, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1101, 1, 'BARMA KONTA', NULL, 2188, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1102, 1, 'HAMIDOU DJETA', NULL, 2189, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1103, 1, 'ADAMA DRAME', NULL, 2190, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1104, 1, 'KEKOU SINAYOKO', NULL, 2191, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1105, 1, 'MAMA A MIENTA', NULL, 2192, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1106, 1, 'SEKOU A SALANA', NULL, 2193, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1107, 1, 'SEKOU A SAMPANA', NULL, 2194, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1108, 1, 'MARIKE DEMBELE', NULL, 2195, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1109, 1, 'AMADOU MANE', NULL, 2196, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1110, 1, 'MAMADOU KONTA', NULL, 2197, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1111, 1, 'MAOUDOU TIENTA', NULL, 2198, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1112, 1, 'BOUKADARY SECRY', NULL, 2199, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1113, 1, 'DADIE KOUNTA', NULL, 2200, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1114, 1, 'ATOU NAMOKO', NULL, 2201, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1115, 1, 'MOUSSA NABO', NULL, 2202, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1116, 1, 'SEKOU NINAYOKO', NULL, 2203, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1117, 1, 'ATOU NAMAGO', NULL, 2204, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1118, 1, 'SEKOU A SAPANA', NULL, 2205, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1119, 1, 'MAMA NABO', NULL, 2206, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1120, 1, 'AMADOU COULIBALY', NULL, 2207, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1121, 1, 'ABOUDOU COULIBALY', NULL, 2208, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1122, 2, 'MAMA NABO', NULL, 2209, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1123, 1, 'BEIDY GUINALO', NULL, 2210, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1124, 1, 'BEIDY GUINDO', NULL, 2211, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1125, 1, 'MAMADOU KOBLA', NULL, 2212, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1126, 1, 'MAMADOU DIARRA', NULL, 2213, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1127, 1, 'BEINDY GUINDO', NULL, 2214, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1128, 1, 'MAMADOU KABLO', NULL, 2215, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1129, 1, 'MAHAMADOU DIARRA', NULL, 2216, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1130, 1, 'BAKARY SAMPANA', NULL, 2217, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1131, 1, 'BAKARY KANTAO', NULL, 2218, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1132, 1, 'CHEIK OMAR KEITA ', NULL, 2219, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1133, 1, 'SEKOU AMADOU KONTA', NULL, 2220, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1134, 1, 'SEKOU MAGNI CISSE', NULL, 2221, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1135, 1, 'SOLOMANI SACKO', NULL, 2222, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1136, 1, 'SOUNGALO DIARRA', NULL, 2223, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1137, 1, 'KARAMOGO KANE', NULL, 2224, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1138, 1, 'BOUA TRAORE', NULL, 2225, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1139, 1, 'DONDIGUI DONOGO', NULL, 2226, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1140, 1, 'SIDI KOBITA', NULL, 2227, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1141, 1, 'LADJI TRAORE', NULL, 2228, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1142, 1, 'AMADOU DIARRA', NULL, 2229, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1143, 1, 'DJAFARA SACKO', NULL, 2230, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1144, 1, 'BAGUI NASSIRE', NULL, 2231, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1145, 1, 'IDRISSA MINTA', NULL, 2232, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1146, 1, 'MOULAYE NTOUGARA', NULL, 2233, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1147, 1, 'SOULEYMANI TERETA', NULL, 2234, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1148, 1, 'BIRAMA DOMOGO', NULL, 2235, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1149, 1, 'MOUSSA TRAORE1', NULL, 2236, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1150, 1, 'MOUSSA TRAORE2', NULL, 2237, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1151, 1, 'DODIGUI ', NULL, 2238, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1152, 1, 'MAMOUDOU KARABINTA', NULL, 2239, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1153, 1, 'SIDI KOBITAO', NULL, 2240, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1154, 1, 'LAMINI KANE', NULL, 2241, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1155, 1, 'SIDI KOBILA', NULL, 2242, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1156, 1, 'KONO TOMOTA', NULL, 2243, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1157, 1, 'MAMOUTOU KARABAITA', NULL, 2244, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1158, 1, 'BAKARY  TRAORE', NULL, 2245, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1159, 1, 'DRISSA SACKO', NULL, 2246, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1160, 1, 'MOUSSA SACKO', NULL, 2247, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1161, 1, 'MAMOUTOU KARABINTA', NULL, 2248, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1162, 1, 'LAMINI  KONE', NULL, 2249, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1163, 1, 'DRISSA MINTA', NULL, 2250, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1164, 1, 'HAMALAHOU TERETA', NULL, 2251, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1165, 1, 'BASSIROU  NTOUGUI ', NULL, 2252, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1166, 1, 'KORKORY SECRE', NULL, 2253, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1167, 1, 'TOKA HAIDARA', NULL, 2254, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1168, 1, 'HAMA HAIDARA', NULL, 2255, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1169, 1, 'YALFA DABITAO ', NULL, 2256, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1170, 1, 'KALY KONTA', NULL, 2257, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1171, 1, 'MAMADOU KONTAO ', NULL, 2258, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1172, 1, 'DESSE TAMBOURA', NULL, 2259, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1173, 1, 'KABORO SECRE', NULL, 2260, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1174, 1, 'SADIO DIENTA', NULL, 2261, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1175, 1, 'CKEIK AMADOU DABITAO ', NULL, 2262, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1176, 1, 'YAYA HAIDARA', NULL, 2263, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1177, 1, 'BOUBACAR KASSAMBARO', NULL, 2264, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1178, 1, 'BROULAYE KONTA', NULL, 2265, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1179, 1, 'HAMADY KASSAMBARA', NULL, 2266, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1180, 1, 'ALASSANE MAIGA', NULL, 2267, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1181, 1, 'YAYA COULIBALY', NULL, 2268, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1182, 1, 'SOULEYMANE KOBILA', NULL, 2269, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1183, 1, 'SOULEYMANE KABILO', NULL, 2270, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1184, 1, 'SEKOU AMAFOU KWANTA', NULL, 2271, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1185, 1, 'SEKOU TOMOTA', NULL, 2272, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1186, 1, 'SEKOU TAMOTA', NULL, 2273, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1187, 1, 'LABAS TRAORE', NULL, 2274, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1188, 1, 'ZOUMANA TRAORE', NULL, 2275, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1189, 1, 'MAHAMADOU DOUKOURE', NULL, 2276, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1190, 1, 'MAMA DEBOKENE 1 ', NULL, 2277, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1191, 1, 'MAMA DEBOKENE 2', NULL, 2278, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1192, 1, 'MAMADI BARRY', NULL, 2279, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1193, 1, 'YOUSSOUF KONTA', NULL, 2280, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1194, 1, 'BAKOROBA DIENTA', NULL, 2281, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1195, 1, 'SIDI SANCAFE', NULL, 2282, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1196, 1, 'BA GNONFO', NULL, 2283, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1197, 1, 'BAKARY SANCAFE', NULL, 2284, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1198, 1, 'NOUHOUN DIENTA', NULL, 2285, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1199, 1, 'ALMAMY SANCAFE', NULL, 2286, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1200, 1, 'MAMADOU BARRY', NULL, 2287, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1201, 1, 'SIDI BREMA KONTA ', NULL, 2288, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1202, 1, 'MADJOU KOSSOUMBA', NULL, 2289, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1203, 1, 'MAMADY BARRY ', NULL, 2290, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1204, 1, 'MADJOU TRAORE', NULL, 2291, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1205, 1, 'FAROUKOU TANEMPO', NULL, 2292, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1206, 1, 'YACOUBA YACOUBA  BARRY', NULL, 2293, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1207, 1, 'MAHAMADOU NADIAN ', NULL, 2294, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1208, 1, 'MADJOU KASSOUMBO ', NULL, 2295, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1209, 2, 'MAHAMADOU NADIAN ', NULL, 2296, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1210, 1, 'MADJOU ', NULL, 2297, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1211, 1, 'BOUBA ', NULL, 2298, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1212, 1, 'KARIM KOFORE', NULL, 2299, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1213, 1, 'HARONA FOFANA', NULL, 2300, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1214, 1, 'DAOUDA DIARRA', NULL, 2301, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1215, 1, 'PAGNIRI TRAORE', NULL, 2302, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1216, 1, 'BOH SABE', NULL, 2303, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1217, 1, 'YACOUBA DIARRA', NULL, 2304, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1218, 1, 'BATIDIANI KONTA', NULL, 2305, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1219, 1, 'KARIM SAGORE', NULL, 2306, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1220, 1, 'SOLO DIARRA', NULL, 2307, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1221, 1, 'DRAMANE DIARRA', NULL, 2308, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1222, 1, 'BALAOU TRAORE', NULL, 2309, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1223, 1, 'YAMOUSSOU KONTA ', NULL, 2310, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1224, 1, 'BOUA KONTA', NULL, 2311, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1225, 1, 'BALAOU DIARRA ', NULL, 2312, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1226, 1, 'DIAMANE DIARRA', NULL, 2313, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1227, 1, 'HAROUNA FOFANA ', NULL, 2314, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1228, 1, 'YAMOUSSA KONTA ', NULL, 2315, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1229, 1, 'AMADI  SAMAKE ', NULL, 2316, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1230, 1, 'AMADI SAMAKE', NULL, 2317, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1231, 1, 'BAKARI KONTA ', NULL, 2318, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1232, 1, 'BAGNIRI TRAORE ', NULL, 2319, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1233, 1, 'SEKOUBA MINTA', NULL, 2320, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1234, 1, 'SEYNI KONTA', NULL, 2321, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1235, 1, 'BOUBACAR MAIGA', NULL, 2322, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1236, 1, 'ABOUZARACT MAIGA', NULL, 2323, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1237, 1, 'ZOU MAIGA', NULL, 2324, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1238, 1, 'NOUHAM TIKAMBO', NULL, 2325, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1239, 1, 'SEKOU SILLA', NULL, 2326, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1240, 1, 'ABZARACK MAIGA', NULL, 2327, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1241, 1, 'NOUHOUM TIKAMBO', NULL, 2328, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1242, 1, 'SEKOU A MINTA', NULL, 2329, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1243, 1, 'ABOUZARACK MAIGA', NULL, 2330, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1244, 1, 'KAITA TIKAMBO', NULL, 2331, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1245, 1, 'ABOUZARACK', NULL, 2332, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1246, 1, 'SEKOU MINTA', NULL, 2333, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1247, 1, 'CAMARA SINAYOKO', NULL, 2334, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1248, 1, 'BREHIMA KINTA', NULL, 2335, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1249, 1, 'TIDIANE TRAORE', NULL, 2336, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1250, 1, 'BOUACAR TRAORE', NULL, 2337, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1251, 1, 'MAMADI  TRAORE 1', NULL, 2338, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1252, 1, 'MAMADI TRAORE 2', NULL, 2339, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1253, 1, 'DODIGUI DONOGO', NULL, 2340, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1254, 1, 'YAYI SINAYOGO', NULL, 2341, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1255, 1, 'SAMBA KONIO', NULL, 2342, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1256, 1, 'FADJOU SINAYOKO', NULL, 2343, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1257, 1, 'BOUACAR TRAORE 2', NULL, 2344, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1258, 1, 'MAMADI TRAORE 3', NULL, 2345, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1259, 1, 'TAMANA SINAYAKO ', NULL, 2346, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1260, 1, 'YAYI SINAYOKO ', NULL, 2347, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1261, 1, 'BOUKADARI  KEITA ', NULL, 2348, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1262, 1, 'MAMADI TRAORE', NULL, 2349, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1263, 1, 'BOUBACAR TRAORE 1', NULL, 2350, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1264, 1, 'MAMADI TRAORE 1', NULL, 2351, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1265, 1, 'DONIGUI DONOGO ', NULL, 2352, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1266, 1, 'BOUACAR TRAORE 1 ', NULL, 2353, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1267, 1, 'ABOURAZACK MAIGA', NULL, 2354, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1268, 1, 'AMI TIKAMBO ', NULL, 2355, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1269, 1, 'MOUSSA TIKAMBO ', NULL, 2356, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1270, 1, 'ZOU TIKAMBO', NULL, 2357, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1271, 1, 'MOUSSA CAMARA ', NULL, 2358, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1272, 1, 'YAYA SINAYOKO ', NULL, 2359, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1273, 1, 'YAYA NABO ', NULL, 2360, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1274, 1, 'YAYI BINAYOKO ', NULL, 2361, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1275, 1, 'TIDIANI KEITA', NULL, 2362, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1276, 1, 'SEKOU BREMA KARABANA', NULL, 2363, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1277, 1, 'MOUSSA BALA KEITA', NULL, 2364, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1278, 1, 'BOKADARY DIARRA', NULL, 2365, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1279, 1, 'SAMBA SOW', NULL, 2366, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1280, 1, 'BANA MINTA', NULL, 2367, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1281, 1, 'ABOULAYE TRAORE', NULL, 2368, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1282, 1, 'ALMAMY GNOUMATA', NULL, 2369, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1283, 1, 'BAKARY DIARRA', NULL, 2370, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1284, 1, 'OUSMANE MAIGA', NULL, 2371, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1285, 1, 'DJONCONDA DEMBELE', NULL, 2372, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1286, 1, 'NGARBA KAROTA', NULL, 2373, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1287, 1, 'MOUSSA KOUMOU', NULL, 2374, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1288, 1, 'BAKARY TICAMBO', NULL, 2375, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1289, 1, 'DRISSA', NULL, 2376, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1290, 1, 'KAYMA NIOUMANTA', NULL, 2377, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1291, 1, 'BA GAOUSSOU', NULL, 2378, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1292, 1, 'KWAMA', NULL, 2379, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1293, 1, 'BA YOUSSOUF', NULL, 2380, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1294, 1, 'KAYIMA NIOUMANTA', NULL, 2381, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1295, 1, 'SOLO MINTA', NULL, 2382, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1296, 1, 'BOUACARI COUILIBALY', NULL, 2383, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1297, 1, 'SIRIKI NIOUMANTA', NULL, 2384, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1298, 1, 'SEKOUBA KOMINA', NULL, 2385, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1299, 1, 'DRISSA KOTA', NULL, 2386, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1300, 1, 'OUSMANE KONIA', NULL, 2387, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1301, 1, 'KEREMUGNON KONTA', NULL, 2388, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1302, 1, 'BACKI KONTA', NULL, 2389, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1303, 1, 'BASSOUMA KONTA', NULL, 2390, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1304, 1, 'BASOUMANA KONTA', NULL, 2391, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1305, 1, 'AMI KONTA', NULL, 2392, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1306, 1, 'KOUANA KWANTA', NULL, 2393, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1307, 1, 'ADY SACKO', NULL, 2394, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1308, 1, 'KAMAYE MAIGA', NULL, 2395, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1309, 1, 'DJIBRIL  SALAMATA', NULL, 2396, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1310, 1, 'BARYMA S7ANCAFE', NULL, 2397, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1311, 1, 'YAYON TRAORE ', NULL, 2398, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1312, 1, 'FOUSSEYNY DJEMINTA ', NULL, 2399, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1313, 1, 'DJAMBALY BARRY ', NULL, 2400, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1314, 1, 'DEMBA GUINADO', NULL, 2401, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1315, 1, 'MOUSSA KRABAITA', NULL, 2402, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1316, 1, 'BAKARY KONTAO', NULL, 2403, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1317, 1, 'INAKA  KANTA ', NULL, 2404, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1318, 1, 'DIADJE NADJIAN', NULL, 2405, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1319, 1, 'KANIBA COULIBALY', NULL, 2406, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1320, 1, 'MOHAMBE TOUNKARA ', NULL, 2407, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1321, 1, 'MAMA TRAORE', NULL, 2408, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1322, 1, 'BEKAYE YATARO', NULL, 2409, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1323, 1, 'SYNALY HAIDARA ', NULL, 2410, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1324, 1, 'GAOUSSOU SANGAFE', NULL, 2411, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1325, 1, 'MAMA KANAMOKO', NULL, 2412, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1326, 1, 'MAMADOU DAOU ', NULL, 2413, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1327, 1, 'BOUBACAR CRONSO', NULL, 2414, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1328, 1, 'ALI TIMBA ', NULL, 2415, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1329, 1, 'GOUANOU SANGAFE', NULL, 2416, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1330, 1, 'MAMADOYU TRAORE ', NULL, 2417, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1331, 1, 'KANIBA COULYBALY', NULL, 2418, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1332, 1, 'OUSMANE KANAMOKO ', NULL, 2419, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1333, 1, 'KONIBA KOULIBALY ', NULL, 2420, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1334, 1, 'DJADJE NADIAN ', NULL, 2421, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1335, 1, 'BOUKADARY OULLALE', NULL, 2422, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1336, 1, 'BOUBACARY KONTA ', NULL, 2423, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1337, 1, 'BREMA  TRAORE', NULL, 2424, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1338, 1, 'SIDI TRAORE', NULL, 2425, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1339, 1, 'NOUHOU TAMATO ', NULL, 2426, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1340, 1, 'DIADIE NADIAN ', NULL, 2427, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1341, 1, 'MAMA TOUNKARA ', NULL, 2428, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1342, 1, 'SEKOU KAMAKOMO', NULL, 2429, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1343, 1, 'BREME SACKO ', NULL, 2430, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1344, 1, 'BORRY SIMBE ', NULL, 2431, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1345, 2, 'ABDOULAYE TRAORE ', NULL, 2432, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1346, 1, 'FOUSSENI DJEMINTA ', NULL, 2433, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1347, 1, 'KOUADOU TRAORE', NULL, 2434, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1348, 1, 'BREMA KANTAO', NULL, 2435, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1349, 1, 'MOUSSA KARABAITO ', NULL, 2436, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1350, 1, 'MAMADOU GUINDO ', NULL, 2437, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1351, 1, 'BOUBAKARY CRONSO ', NULL, 2438, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1352, 1, 'NOUHOU TOMATA', NULL, 2439, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1353, 1, 'SEKOU A KEITA ', NULL, 2440, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1354, 1, 'BOUKADARY CRONSO ', NULL, 2441, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1355, 1, 'BOUKADARY OULALE ', NULL, 2442, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1356, 1, 'MODY DIALLO', NULL, 2443, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1357, 1, 'BOUBACAR SECRY ', NULL, 2444, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1358, 1, 'BOKADARY KIRE ', NULL, 2445, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1359, 1, 'FOUSSENI ARMA ', NULL, 2446, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1360, 2, 'BOURAMA BOUARE', NULL, 2447, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1361, 1, 'MADY DIALLO ', NULL, 2448, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1362, 1, 'SEKOU A KARABANA', NULL, 2449, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1363, 1, 'FOUSSEYNI ARMA ', NULL, 2450, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1364, 1, 'DAMARY CAMARA ', NULL, 2451, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1365, 1, 'ALI NASIRE ', NULL, 2452, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1366, 1, 'BAKORABA KANE ', NULL, 2453, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1367, 1, 'BAKARY KANE ', NULL, 2454, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1368, 1, 'MOCTAR DENOU ', NULL, 2455, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1369, 1, 'KARABANA KANE ', NULL, 2456, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1370, 1, 'LAMINE TRAORE ', NULL, 2457, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1371, 1, 'MAMA SINAYAKO ', NULL, 2458, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1372, 1, 'DRISSA SANGARE', NULL, 2459, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1373, 1, 'BAKORABA KIRE', NULL, 2460, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1374, 1, 'DOUDOU RAMPO', NULL, 2461, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1375, 1, 'MODIBO KANTA ', NULL, 2462, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1376, 1, 'SEKOU DEBOKENE1', NULL, 2463, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1377, 1, 'SEKOU DEBOKENE2', NULL, 2464, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1378, 1, 'KASOUM KONTA', NULL, 2465, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1379, 1, 'MAHAMADOU DEBIOKENE', NULL, 2466, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1380, 1, 'SOUMAILA KONTA', NULL, 2467, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1381, 1, 'SOUMAILA  KANTA', NULL, 2468, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1382, 1, 'MAHAMADOU DABOKENE', NULL, 2469, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1383, 1, 'FAROUKOU TANRMPO ', NULL, 2470, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1384, 1, 'MAMAN FAMANTA ', NULL, 2471, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1385, 1, 'NKA PAIO ', NULL, 2472, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1386, 1, 'MAHAMOUDOU  DIENTA ', NULL, 2473, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1387, 1, 'BOUBACAR SANCAFE', NULL, 2474, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1388, 1, 'MAHAMADOU SAMPANA ', NULL, 2475, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1389, 1, 'BARIMA TIKAMBO', NULL, 2476, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1390, 1, 'NOUHOU TIKAMBO', NULL, 2477, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1391, 1, 'BOUACARY MAIGA', NULL, 2478, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1392, 1, 'SEYNI', NULL, 2479, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1393, 1, 'NIMA ', NULL, 2480, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1394, 1, 'BINTOU MINTA', NULL, 2481, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1395, 1, 'ABOURAZACK', NULL, 2482, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1396, 1, 'BARIMA ', NULL, 2483, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1397, 1, 'SIRIKI', NULL, 2484, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1398, 1, 'TIEDIAN', NULL, 2485, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1399, 1, 'BINTA TCHINY', NULL, 2486, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1400, 1, 'KOBARIMA TIKAMBO', NULL, 2487, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1401, 1, 'DJENEBA TRAORE', NULL, 2488, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1402, 1, 'FAKAYE SISSOKO', NULL, 2489, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1403, 1, 'KASSOUM KANTA', NULL, 2490, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1404, 1, 'SEKOUN DEBOKENE 1', NULL, 2491, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1405, 1, 'ABDOUL DJIRE ', NULL, 2492, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1406, 1, 'MAMADOU DEBOKENE ', NULL, 2493, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1407, 2, 'SEKOU DEBOKENE 2', NULL, 2494, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1408, 1, 'YOUSSOUF KOMORE', NULL, 2495, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1409, 1, 'SEKOU MAHI DIARRA', NULL, 2496, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1410, 2, 'MOUSSA DOUKOURE', NULL, 2497, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1411, 1, 'GOURRO TAMBOURA', NULL, 2498, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1412, 2, 'ASSANA DIARRA', NULL, 2499, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1413, 1, 'YOUSSOUY KOMOU', NULL, 2500, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1414, 1, 'MAMA    KOMOTAO', NULL, 2501, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1415, 1, 'MOUSSA DOUCOUR�', NULL, 2502, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1416, 1, 'ADAMA YOUANA ', NULL, 2503, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1417, 1, 'MAMADOU SATAO ', NULL, 2504, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1418, 1, 'MOHAMED SISSOKO', NULL, 2505, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1419, 1, 'YOUNOUSSA TRAORE ', NULL, 2506, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1420, 1, 'ZOUMANA COULIBALY ', NULL, 2507, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1421, 1, 'MAMA FARATA ', NULL, 2508, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1422, 1, 'BOUKADARY KIRE', NULL, 2509, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1423, 1, 'ADAMA YOUANAOU ', NULL, 2510, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1424, 1, 'MOUSSA YOUANOU ', NULL, 2511, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1425, 1, 'MAHAMAOUDOU DIENTA', NULL, 2512, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1426, 2, 'BAKARY SAPANA ', NULL, 2513, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1427, 1, 'KASSOUM COULIBALY', NULL, 2514, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1428, 1, 'MAMADOU KANTAO', NULL, 2515, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1429, 1, 'BREMA NAPO', NULL, 2516, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1430, 1, 'BREHIMA NIOUMANTA', NULL, 2517, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1431, 2, 'BREMA NABO', NULL, 2518, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1432, 1, 'MODOU KOBLA', NULL, 2519, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1433, 1, 'MADOU KANTAO DIANGO', NULL, 2520, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1434, 1, 'MODIBO KONTA', NULL, 2521, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1435, 1, 'MOHAMED SISSAKO', NULL, 2522, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1436, 1, 'BOURAMA BAORE', NULL, 2523, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1437, 1, 'MAMADOU SANTA', NULL, 2524, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1438, 1, 'MADIBO KONTA', NULL, 2525, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1439, 1, 'DIADIE KOUNNTA', NULL, 2526, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1440, 1, 'BOUKOUDARY SECRY', NULL, 2527, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1441, 1, 'DINDIE KOUNTA', NULL, 2528, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1442, 1, 'BOUVAMA BOUARE', NULL, 2529, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1443, 1, 'ADAMA YOUONOU', NULL, 2530, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1444, 1, 'MODIBOU KONTA', NULL, 2531, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1445, 1, 'MOHAMADOU SISSOKO', NULL, 2532, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1446, 1, 'ATOU NIMOKO', NULL, 2533, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1447, 1, 'BOUROUMOU BOUARE', NULL, 2534, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1448, 1, 'MOHAMADOU KONTA', NULL, 2535, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1449, 1, 'MAMOUDOU SANTA', NULL, 2536, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1450, 1, 'BAKORADA KONE', NULL, 2537, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1451, 1, 'ZOUMANA KOUNTA', NULL, 2538, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1452, 1, 'MADIBO KANTA', NULL, 2539, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1453, 1, 'BOUBACARY KARABAITA', NULL, 2540, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1454, 1, 'LADJI KANAKOMO', NULL, 2541, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1455, 1, 'SIDY COULIBALY ', NULL, 2542, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1456, 1, 'KANIBA KOULIBALY ', NULL, 2543, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1457, 1, 'ALI TEMBO ', NULL, 2544, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1458, 1, 'MAMA  TRAORE', NULL, 2545, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1459, 1, 'BOUNBACARY CROSO ', NULL, 2546, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1460, 1, 'BOUKADARYB OULLALE', NULL, 2547, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1461, 1, 'MAMDOU TRAORE ', NULL, 2548, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1462, 1, 'DIDIE NADJAN ', NULL, 2549, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1463, 1, 'NOUHOUN TOMOTA ', NULL, 2550, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1464, 1, 'AMADOU MOHAMED DOUMBIA', NULL, 2551, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1465, 1, 'BASSIROU SANCAFE', NULL, 2552, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1466, 1, 'SADIO DIARRA', NULL, 2553, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1467, 1, 'BOUBACAR NADAIN', NULL, 2554, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1468, 1, 'FAROUGNE TANEMPO', NULL, 2555, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1469, 1, 'IBRAHIM KOMOTAO', NULL, 2556, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1470, 1, 'MME DOUCOURE TORA SOGORE', NULL, 2557, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1471, 1, 'LASSINA KOMOTAO 1', NULL, 2558, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1472, 1, 'LASSINA KOMOTAO 2', NULL, 2559, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1473, 1, ' BOKADARY SATAO', NULL, 2560, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1474, 1, 'MAMA TIMBO', NULL, 2561, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1475, 1, 'TEBABA TANOPO', NULL, 2562, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1476, 1, 'TEBEBE TANAPO ', NULL, 2563, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1477, 1, 'SEKOU BREMA HONONDA ', NULL, 2564, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1478, 1, 'TALY CISSE', NULL, 2565, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1479, 1, 'ALMAMY GNOUMANTA ', NULL, 2566, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1480, 1, 'N GARBA KOROTA ', NULL, 2567, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1481, 1, 'BOKADARY DOUMANGOUROU ', NULL, 2568, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1482, 1, 'ABDOULAYE CISSE', NULL, 2569, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1483, 2, 'SEKOU TIDIANE DOUMANGOUROU', NULL, 2570, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1484, 1, 'HASSIM TIKAMBO ', NULL, 2571, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1485, 1, 'BABA MINTA ', NULL, 2572, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1486, 1, 'DRAMANE TICAMBO ', NULL, 2573, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1487, 1, 'TAHIROU TICAMBO ', NULL, 2574, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1488, 1, 'BOUKADARY DOUMANGOUROU', NULL, 2575, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1489, 1, 'ASSIM TICOMBO', NULL, 2576, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1490, 1, 'SEKOU TIDIANE DOUMANGOUROU', NULL, 2577, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1491, 2, 'SOUMANA KONTA', NULL, 2578, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1492, 1, 'SIDI MINMANTAO', NULL, 2579, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1493, 1, 'MAHAMADOU KALAPO', NULL, 2580, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1494, 1, 'LASSINA SALAMATA', NULL, 2581, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1495, 1, 'SOULEMANE KARABANA', NULL, 2582, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1496, 1, 'MADOU KABLA', NULL, 2583, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1497, 1, 'BOUREMA KANTA', NULL, 2584, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1498, 1, 'MADOU KANTAO', NULL, 2585, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1499, 1, 'BREHIMA NIOUMANATA', NULL, 2586, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1500, 1, 'OUMAR TIMBE', NULL, 2587, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1501, 1, 'TABABA TANAPO', NULL, 2588, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1502, 1, 'OUMAR TIMBA', NULL, 2589, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1503, 1, 'BREMA COULIBALY', NULL, 2590, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1504, 1, 'KKA PA�TO ', NULL, 2592, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1505, 0, 'MAHAMADOU BARRY', NULL, 2593, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1506, 1, 'SEKOU TRAORE', NULL, 2594, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1507, 1, 'KARAMOKO KWANTA', NULL, 2595, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1508, 1, 'BAKOROBA KONTA', NULL, 2596, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1509, 1, 'YORO FOFANA', NULL, 2597, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1510, 1, 'BOURI TRAORE', NULL, 2598, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1511, 1, 'SEKOUBA DIARRA', NULL, 2599, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1512, 1, 'SAMBA COULIBALY', NULL, 2600, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1513, 1, 'BOUBACAR KOROGNON', NULL, 2601, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1514, 1, 'SINALY', NULL, 2602, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1515, 1, 'SEKOU DIARRA', NULL, 2603, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1516, 1, 'ABOU', NULL, 2604, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1517, 1, 'SEYDOU TRAORE', NULL, 2605, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1518, 1, 'GABI KONTA', NULL, 2606, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1519, 1, 'BAGNINY TRAORE', NULL, 2607, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1520, 1, 'MAMA KWANTA', NULL, 2608, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1521, 1, 'NIAGA TOUMKARA', NULL, 2609, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1522, 2, 'YACOUBA DOUMANGOUROU', NULL, 2610, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1523, 1, 'AMADOU DIMBO MINTA', NULL, 2611, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1524, 1, 'MOHAMED DOUMOUGOUROU', NULL, 2612, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1525, 1, 'NIAGA TOUNKARO', NULL, 2613, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1526, 1, 'ALMAMY FAMANTAO', NULL, 2614, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1527, 1, 'ABDOULA MAIGA', NULL, 2615, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1528, 1, 'ALAMY FAMANTAO', NULL, 2616, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1529, 1, 'BAKARY DIAKETE', NULL, 2617, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1530, 1, 'DIAGA TOUNKARA', NULL, 2618, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1531, 1, 'ABOUBACAR KONTA', NULL, 2619, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1532, 1, 'YOUCOUBA DOUMANGOUROU', NULL, 2620, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1533, 1, 'SEKOU BREMA HOMONTA', NULL, 2621, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1534, 1, 'SEKOU BREMA KONONTA', NULL, 2622, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1535, 1, 'YOUSSOUF KOUMOU', NULL, 2623, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1536, 1, 'BOKADARI SATAO ', NULL, 2624, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1537, 1, 'SIDIKI MIMANTAO ', NULL, 2625, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1538, 1, 'SIDI BREMA SANGAFE', NULL, 2626, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1539, 1, 'SIDI BREMA SANCAFE ', NULL, 2627, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1540, 1, 'LASSANA KANE ', NULL, 2628, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1541, 1, 'MAMA TOMBO ', NULL, 2629, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1542, 1, 'NOUHOU DIENTA ', NULL, 2630, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1543, 1, 'AMADY DEMBELE', NULL, 2631, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1544, 1, 'OUSMANE DEBA ', NULL, 2632, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1545, 1, 'MAMADOU KANE', NULL, 2633, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1546, 1, 'ABDOULAYE DIARRE', NULL, 2634, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1547, 1, 'IBRAHIM KOURANSO', NULL, 2635, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1548, 1, 'MOUSSA COULIBALY', NULL, 2636, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1549, 1, 'ABDOULAYE DIARRA ', NULL, 2637, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1550, 1, 'MAMADY KANE ', NULL, 2638, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1551, 1, 'SOLOMANE NIARRE', NULL, 2639, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1552, 1, 'MOSSA COULIBALY ', NULL, 2640, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1553, 1, 'ABDOULAYE MA�GA', NULL, 2641, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1554, 1, 'BOKADARI DOUMANGOUROU', NULL, 2642, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1555, 1, 'OUSMANE DOUMANGOUROU', NULL, 2643, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1556, 1, 'OUMAR DOUMANGOUROU', NULL, 2644, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1557, 1, 'YANCOUBA DOUMANGOUROU', NULL, 2645, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1558, 1, 'BAKAYE TICAMBO', NULL, 2646, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1559, 1, 'NANA MINTA', NULL, 2647, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1560, 1, 'HAMADY DEMBELE', NULL, 2648, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1561, 1, 'IBRAHIMA KOURANSO', NULL, 2649, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1562, 1, 'BOKADARY LABITAO', NULL, 2650, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1563, 1, 'HAMA COULIBAY', NULL, 2651, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1564, 1, 'IBRAHIMA KOMOTAO ', NULL, 2652, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1565, 1, 'YOUSSDOUF KOMOU ', NULL, 2653, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1566, 1, 'ALMAMY DEMBELE', NULL, 2654, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1567, 1, 'MADJOU  KOSSOUMBO ', NULL, 2655, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1568, 1, 'BOUBACAR   NADIAN ', NULL, 2656, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1569, 1, 'BOUBACAR   TRAORE ', NULL, 2657, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1570, 1, 'SADIO  WOSSONKO ', NULL, 2658, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1571, 1, 'YACOUBA    BARRY ', NULL, 2659, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1572, 1, 'BAKARY  FOFANA ', NULL, 2660, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1573, 1, 'CHAKA  MENINDJOU', NULL, 2661, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1574, 1, 'MADJOU KOSSIMBA ', NULL, 2662, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1575, 1, 'SOULEYMANE TOMOTA', NULL, 2663, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1576, 1, 'AMADOU DEMBELE ', NULL, 2664, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1577, 1, 'MOUSSA COILIBALY ', NULL, 2665, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1578, 1, 'DIMBA KOMOU ', NULL, 2666, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1579, 1, 'BASSIROU TRAORE', NULL, 2667, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1580, 1, 'MAMADOU NAPO', NULL, 2668, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1581, 1, 'SOUMANA KOBILA', NULL, 2669, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1582, 1, 'SOUL KOBILA', NULL, 2670, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1583, 1, 'SIDI KEITA', NULL, 2671, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1584, 1, 'NOUHOU KINTA', NULL, 2672, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1585, 1, 'MOUSSA KARABENTA', NULL, 2673, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1586, 1, 'SINALY SERETA', NULL, 2674, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1587, 1, 'SALIOU TERETA', NULL, 2675, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1588, 1, 'BASSIROU KARABENTA', NULL, 2676, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1589, 1, 'BOUBACAR TERETA', NULL, 2677, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1590, 1, 'BOURAMA TRAORE', NULL, 2678, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1591, 1, 'BASSOUMANA DIARRA', NULL, 2679, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1592, 1, 'BOUAKARI TERETA', NULL, 2680, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1593, 2, 'ALASSANE TRAORE', NULL, 2681, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1594, 1, 'BASINALY', NULL, 2682, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1595, 1, 'YACOUBA ', NULL, 2683, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1596, 1, 'KADOKE', NULL, 2684, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1597, 1, 'AROUNA DIARRA', NULL, 2685, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1598, 1, 'BASSOUMA DIARRA', NULL, 2686, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1599, 1, 'BAFITINI TRAORE', NULL, 2687, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1600, 1, 'ADAM', NULL, 2688, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1601, 1, 'KAMAYE MAI&uml;GA', NULL, 2689, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1602, 1, 'BAH SADE', NULL, 2690, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1603, 1, 'BASSINALY KUTA', NULL, 2691, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1604, 1, 'BAKAYE KONTA', NULL, 2692, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1605, 1, 'SOUMANA KWANTA', NULL, 2693, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1606, 1, 'KARIM SOGORE', NULL, 2694, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1607, 1, 'YOUSSOUF TRAORRE', NULL, 2695, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1608, 1, 'BOUACAR KONTA', NULL, 2696, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1609, 1, 'DRISSA SANGAFE', NULL, 2697, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1610, 1, 'YOUNOUSSA KONTA', NULL, 2698, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1611, 1, 'LAOUDE TRAORE', NULL, 2699, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1612, 1, 'KEKO KONTA', NULL, 2700, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1613, 1, 'LAOUDE', NULL, 2701, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1614, 1, 'ADAMA DIARRA', NULL, 2702, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1615, 1, 'BAH KONTA', NULL, 2703, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1616, 1, 'AMAL KONTA', NULL, 2704, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1617, 1, 'ALY DICKO', NULL, 2705, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1618, 1, 'BATIDIANE', NULL, 2706, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1619, 1, 'BA MOULAYE DIARRA', NULL, 2707, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1620, 1, 'YOUSSOUF TRAORE', NULL, 2708, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1621, 1, 'BAKARI TRAORE', NULL, 2709, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1622, 1, 'BAGNINI TRAORE', NULL, 2710, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1623, 1, 'BAKARI DIENTA', NULL, 2711, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1624, 1, 'AMADI SAMKE', NULL, 2712, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1625, 1, 'NAKABA', NULL, 2713, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1626, 1, 'BABINA', NULL, 2714, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1627, 1, 'ALASSANE DICKO', NULL, 2715, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1628, 1, 'LASSANA DIARRA', NULL, 2716, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1629, 1, 'AMADOU SAMAKE', NULL, 2717, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1630, 1, 'BADRA DIARRA', NULL, 2718, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1631, 1, 'BINA KARAMOKO DIARRA', NULL, 2719, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1632, 1, 'BADRISSA SANGAFE', NULL, 2720, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1633, 1, 'BAGNINI KONTA', NULL, 2721, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1634, 1, 'SEKOUBA SOGORE', NULL, 2722, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1635, 1, 'AMMADI SAMAKE', NULL, 2723, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1636, 1, 'DOUDA DIARRA', NULL, 2724, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1637, 1, 'YOUSSOUFTRAORE', NULL, 2725, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1638, 1, 'AMADI TRAORE', NULL, 2726, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1639, 1, 'BABA TRAORE', NULL, 2727, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1640, 1, 'DIANGULE', NULL, 2728, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1641, 1, 'NGORI MANA', NULL, 2729, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1642, 1, 'BAGUINI KONTA', NULL, 2730, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1643, 1, 'KENOU KONTA', NULL, 2731, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1644, 1, 'DIANGOLE', NULL, 2732, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1645, 1, 'SAMBA', NULL, 2733, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1646, 1, 'BATIDIANE KONTA', NULL, 2734, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1647, 1, 'BALAOU', NULL, 2735, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1648, 1, 'BATIDIANA KONTA', NULL, 2736, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1649, 1, 'BABOU', NULL, 2737, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1650, 1, 'DRA DIARRA', NULL, 2738, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1651, 1, 'MFA ADAMA', NULL, 2739, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1652, 1, 'KABA TRAORE', NULL, 2740, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1653, 1, 'DAOUDA KONTE', NULL, 2741, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1654, 1, 'YOUSSOUF', NULL, 2742, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1655, 1, 'BAMOUKOUTARI KONTA', NULL, 2743, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1656, 1, 'DJINI TRAORE', NULL, 2744, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1657, 1, 'HASSANA', NULL, 2745, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1658, 1, 'ADAMA TRAORE', NULL, 2746, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1659, 1, 'MADI SACKO', NULL, 2747, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1660, 1, 'KARAMOKO TRAORE', NULL, 2748, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1661, 1, 'AMADOU TERETA', NULL, 2749, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1662, 1, 'ABOURAZACK MA�GA', NULL, 2750, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1663, 1, 'BAREMA DJONDE', NULL, 2751, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1664, 1, 'ZOUMANA TIKAMBO', NULL, 2752, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1665, 1, 'LASSI TERETA', NULL, 2753, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1666, 1, 'FOUSEINI TRAORE', NULL, 2754, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1667, 1, 'SEKOU H. TIENTA', NULL, 2755, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1668, 1, 'LASSINA MA�GA', NULL, 2756, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1669, 1, 'BOUBACAR MA�GA', NULL, 2757, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1670, 1, 'SIDI DJONDE', NULL, 2758, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1671, 1, 'MOHAMED TERETA', NULL, 2759, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1672, 1, 'AMADOU KOITA', NULL, 2760, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1673, 1, 'AMADOU KO�TA', NULL, 2761, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1674, 1, 'FOUSSEYNI', NULL, 2762, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1675, 1, 'SEKOU A TIENTA', NULL, 2763, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1676, 1, 'ADAMA TERETA', NULL, 2764, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1677, 1, 'BOURAMA TIKAMBO', NULL, 2765, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1678, 1, 'BOUBACAR SINLINTA', NULL, 2766, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1679, 1, 'DRAMANE TOUNKARA', NULL, 2767, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1680, 1, 'ADAMA KEITA', NULL, 2768, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1681, 1, 'LADJI', NULL, 2769, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1682, 1, 'KOLOTA DIENTA', NULL, 2770, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1683, 1, 'MASSEOU', NULL, 2771, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1684, 1, 'MAHAMADI', NULL, 2772, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1685, 1, 'SEKOU GNINE', NULL, 2773, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1686, 1, 'BOU TIKAMBO', NULL, 2774, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1687, 1, 'SIDI', NULL, 2775, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1688, 1, 'SOGNIMA', NULL, 2776, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1689, 1, 'BALARASSIM', NULL, 2777, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1690, 1, 'MAMADY', NULL, 2778, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1691, 1, 'BAREMA DJENDE', NULL, 2779, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1692, 1, 'BENKE GNINI', NULL, 2780, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1693, 1, 'SEKOU AMADOU DIENTA', NULL, 2781, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1694, 1, 'ALY', NULL, 2782, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1695, 1, 'MAMADI', NULL, 2783, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1696, 1, 'SEKOU TIKAMBO', NULL, 2784, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1697, 1, 'BAH ALI', NULL, 2785, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1698, 1, 'FOUSSEINI TRAORE', NULL, 2786, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1699, 1, 'SOKO GNINE', NULL, 2787, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1700, 1, 'MODIBO TIENTA', NULL, 2788, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1701, 1, 'CHEKOU TERETA', NULL, 2789, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1702, 1, 'LASSI MA�GA', NULL, 2790, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1703, 1, 'MAMA SEKOU', NULL, 2791, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1704, 1, 'SEKOU A TERETA ', NULL, 2792, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1705, 1, 'YOUSSOUF SAMPANA ', NULL, 2793, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1706, 1, 'KOBORO NIOUMANTA', NULL, 2794, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1707, 1, 'BABOULAYE ', NULL, 2795, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1708, 1, 'MAKOLO FAMANTA ', NULL, 2796, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1709, 1, 'ALY SACKO', NULL, 2797, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1710, 1, 'BABOUARI FAMANTA ', NULL, 2798, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1711, 1, 'BOULAYE FAMANTA', NULL, 2799, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1712, 1, 'NKERE FAMANTA', NULL, 2800, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1713, 1, 'LASSINA ', NULL, 2801, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1714, 1, 'KOBOU NIOUMANTA ', NULL, 2802, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1715, 1, 'BABENI NIOUMANTA', NULL, 2803, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1716, 1, 'KOMANI SACKO', NULL, 2804, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1717, 1, 'BAH OUMAROU', NULL, 2805, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1718, 1, 'MADY TERETA ', NULL, 2806, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1719, 1, 'BABA KOMINA ', NULL, 2807, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1720, 1, 'BOUARI FAMANTA ', NULL, 2808, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1721, 1, 'SEKOU MAHI ', NULL, 2809, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1722, 1, 'KALY FAMANTA ', NULL, 2810, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1723, 1, 'BOUBACAR KANTA', NULL, 2811, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1724, 1, 'BA SEYDOU TERETA', NULL, 2812, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1725, 1, 'AKY KOMOU ', NULL, 2813, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1726, 1, 'BABA YERO ', NULL, 2814, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1727, 1, 'BROUAMA TERETA ', NULL, 2815, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1728, 1, 'MOUSSA TERETA', NULL, 2816, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1729, 1, 'BOUBA KOMANTA ', NULL, 2817, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1730, 1, 'AMY KANTA ', NULL, 2818, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1731, 1, 'OUMAR TERETA', NULL, 2819, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1732, 1, 'SEKOU H TERETA', NULL, 2820, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1733, 1, 'BINA TOMOTAO', NULL, 2821, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1734, 1, 'YAYI SAMPANA ', NULL, 2822, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1735, 1, 'ADAMA KOMINA', NULL, 2823, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1736, 1, 'ASSANE GUINDO ', NULL, 2824, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1737, 1, 'GOURA TAMBOURA ', NULL, 2825, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1738, 1, 'OUMAR TAMBOURA ', NULL, 2826, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1739, 1, 'ABDOULMAYE DIARRE ', NULL, 2827, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1740, 1, 'HAMA KOMOTAO', NULL, 2828, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1741, 1, 'BEIDY SIDIDE', NULL, 2829, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1742, 1, 'OUSMANE BEBA', NULL, 2830, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1743, 1, 'MADI TERETA', NULL, 2831, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1744, 1, 'BABANANI FAMANTA', NULL, 2832, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1745, 1, 'ALY KOMINA ', NULL, 2833, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1746, 1, 'ADAMA SAMPANA ', NULL, 2834, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1747, 1, 'BABA YERE KOMINA ', NULL, 2835, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1748, 1, 'ZOU KONTA', NULL, 2836, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1749, 1, 'DRISSA KONTA ', NULL, 2837, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1750, 1, 'MAMADOU TOMOTA', NULL, 2838, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1751, 1, 'SOUMAILA SAMPANA ', NULL, 2839, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1752, 1, 'LAMINA KOMINA ', NULL, 2840, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1753, 1, 'BA OUMAROU ', NULL, 2841, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1754, 1, 'BARIMA TRIPO', NULL, 2842, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1755, 1, 'KERE FAMANTA', NULL, 2843, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1756, 1, 'BOULAYE TIENTA ', NULL, 2844, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1757, 1, 'YACOUBA DIENTA ', NULL, 2845, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1758, 1, 'LAMINE TERETA', NULL, 2846, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1759, 1, 'BABAYERI KOMINA ', NULL, 2847, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1760, 1, 'BARAMA TIPO', NULL, 2848, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1761, 1, 'BABA TIPO', NULL, 2849, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1762, 1, 'LAMINE SAYO', NULL, 2850, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1763, 1, 'BALA KOMINA ', NULL, 2851, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1764, 1, 'BARIMA TIPO', NULL, 2852, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1765, 1, 'BALLA MOUSSA ', NULL, 2853, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1766, 1, 'MAMA SONO ', NULL, 2854, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1767, 1, 'BOUARI COULIBALY ', NULL, 2855, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1768, 1, 'BABOUANI FAMANTA ', NULL, 2856, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1769, 1, 'BOUARY COULIBALY ', NULL, 2857, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1770, 1, 'BALLA ', NULL, 2858, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1771, 1, 'BABA YERO KOMINA', NULL, 2859, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1772, 1, 'BAGAOUSSA FAMANTA', NULL, 2860, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1773, 1, 'ALI FAMANTA', NULL, 2861, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1774, 1, 'LASSINA KOMINA', NULL, 2862, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1775, 1, 'KEREMUGNON KANTA', NULL, 2863, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1776, 1, 'MAHAMADOU SINAYOKO', NULL, 2864, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1777, 1, 'BOURAMA KINTAO', NULL, 2865, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1778, 1, 'OUMAR SERETA', NULL, 2866, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1779, 1, 'ZOUMANA SACKO', NULL, 2867, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1780, 1, 'ALY PANTAO', NULL, 2868, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1781, 1, 'MAMA PAPOU', NULL, 2869, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1782, 1, 'KOMANI KWANTAO', NULL, 2870, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1783, 1, 'BASSIROU CERETA', NULL, 2871, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1784, 1, 'OUSMANE TRAORE', NULL, 2872, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1785, 1, 'SIDIKY KANE', NULL, 2873, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1786, 1, 'MAMA KAPO', NULL, 2874, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1787, 1, 'BOUREIMA CANAPO', NULL, 2875, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1788, 1, 'ABDOULAYE SIRETA', NULL, 2876, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1789, 1, 'BINKE TIKAMBO', NULL, 2877, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1790, 1, 'MODIBO TIKAMBO', NULL, 2878, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1791, 1, 'MAMADI SERETA', NULL, 2879, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1792, 1, 'BAREMA TIKAMBO', NULL, 2880, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1793, 1, 'SOULEY SIDIBE', NULL, 2881, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1794, 1, 'KAYE TIKAMBO', NULL, 2882, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1795, 1, 'MAMA SIRETA', NULL, 2883, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1796, 1, 'BOUREIMA MAIGA', NULL, 2884, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1797, 1, 'BOUACAR SACKO', NULL, 2885, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1798, 1, 'MADY DJIRE', NULL, 2886, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1799, 1, 'SINALY TRAORE', NULL, 2887, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1800, 1, 'KALIFA TIENTA', NULL, 2888, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1801, 1, 'DODIGUE DONOGO', NULL, 2889, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1802, 1, 'ALMAMI TRAORE', NULL, 2890, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1803, 1, 'IBRAHIM DIARRA', NULL, 2891, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1804, 1, 'MAO BAGAYOKO', NULL, 2892, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1805, 1, 'LASSANA TERETA', NULL, 2893, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1806, 1, 'TAKO SACKO', NULL, 2894, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1807, 1, 'TIEKOROBA FAMANTA', NULL, 2895, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1808, 1, 'SEKOU TERETA', NULL, 2896, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1809, 1, 'LAMINE KANTA', NULL, 2897, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1810, 1, 'BAKARYDIAN', NULL, 2898, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1811, 1, 'BOUBACAR COULYBALY', NULL, 2899, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1812, 1, 'MOHI KONTA', NULL, 2900, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1813, 1, 'KEREMOUGNON KANTA', NULL, 2901, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1814, 1, 'TALAHA KOUNTA', NULL, 2902, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1815, 1, 'TALAHA KOUNTAO', NULL, 2903, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1816, 2, 'TALAHA KOUNTAO', NULL, 2904, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1817, 1, 'SIDID BREHIMA KOUNTA', NULL, 2905, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1818, 1, 'MOCTAR TANAMPO', NULL, 2906, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1819, 1, 'DJAO KARABENTA', NULL, 2907, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1820, 1, 'IBRHIMA DIALLO', NULL, 2908, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1821, 1, 'CHEICK BRAHIMA KALAPO', NULL, 2909, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1822, 1, 'MOCTAR TAMAMPO', NULL, 2910, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1823, 1, 'KAIMA NIOUMANTA', NULL, 2911, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1824, 1, 'TOKA SONGHO', NULL, 2912, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1825, 1, 'BOURAMA ', NULL, 2913, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1826, 1, 'OUSMANE KOMINA', NULL, 2914, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1827, 1, 'ALASSANE KONTA', NULL, 2915, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1828, 1, 'MAAM KONTA', NULL, 2916, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1829, 1, 'MADOU FAMANTA', NULL, 2917, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1830, 1, 'FATOUMATA YENA', NULL, 2918, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1831, 1, 'ALY KUMOU', NULL, 2919, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1832, 1, 'YACOUBA TERETA ', NULL, 2920, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1833, 1, 'FOUSSENI TRAORE ', NULL, 2921, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1834, 1, 'LADJI KEITA ', NULL, 2922, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1835, 1, 'KARIM KANE ', NULL, 2923, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1836, 1, 'ISSA DOUKANKORO ', NULL, 2924, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1837, 1, 'YAYA NOPO', NULL, 2925, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1838, 1, 'SINALY TERETA ', NULL, 2926, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1839, 1, 'MAMOUTOU NAPO', NULL, 2927, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1840, 1, 'KOMOU KONE', NULL, 2928, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1841, 1, 'KAMANI KONE ', NULL, 2929, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1842, 1, 'BABO DENEPO ', NULL, 2930, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1843, 1, 'BOSSIROU KARABENTA ', NULL, 2931, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1844, 1, 'KOKORY SECRE ', NULL, 2932, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1845, 1, 'KAKAYI MINTA ', NULL, 2933, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1846, 1, 'BOUBACAR KASSAMBARA', NULL, 2934, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1847, 1, 'TALA DABITAO ', NULL, 2935, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1848, 1, 'MAMOUTOU KANTAO', NULL, 2936, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1849, 1, 'SEKOU AMADOU DABITAO ', NULL, 2937, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1850, 1, 'HAMADY SININTA ', NULL, 2938, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1851, 1, 'KELEYA DOUMAKOUROU ', NULL, 2939, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1852, 1, 'MAMOUTOU KONTON', NULL, 2940, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1853, 1, 'SEKOU OUMAR DABITAO ', NULL, 2941, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1854, 1, 'KELEYA DOUMANKORO ', NULL, 2942, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1855, 1, 'MAMA PAITO', NULL, 2943, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1856, 1, 'SEKOU FOFANA ', NULL, 2944, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1857, 1, 'LASSINE SACKO', NULL, 2945, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1858, 1, 'LASSINA TERETA ', NULL, 2946, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1859, 1, 'OUSMANE KANE ', NULL, 2947, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1860, 1, 'IBRAHIMA FOFANA ', NULL, 2948, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1861, 1, 'MOUSSA TRAORE 1 ', NULL, 2949, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1862, 1, 'MOUSSA TRAORE 2', NULL, 2950, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1863, 1, 'SOUMAILA SACKO ', NULL, 2951, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1864, 1, 'QSOUNKALO DIARRA ', NULL, 2952, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1865, 2, 'SEKOU FOFANA ', NULL, 2953, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1866, 1, 'ALI NASSIRE', NULL, 2954, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1867, 1, 'LASSANA KANTAO ', NULL, 2955, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1868, 1, 'SINALY DIARRA ', NULL, 2956, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1869, 1, 'DIADIE KANTA ', NULL, 2957, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1870, 1, 'ALI SASSIRE', NULL, 2958, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1871, 1, 'MOCTAR TANAPO', NULL, 2959, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1872, 1, 'SEKOU BREHIMA KALAPO', NULL, 2960, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1873, 1, 'CHEIKH AMADOU TERETA ', NULL, 2961, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1874, 1, 'SEYDOU KOUNTAO ', NULL, 2962, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1875, 1, 'DJAOU KARABINTA ', NULL, 2963, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1876, 1, 'HAMAT SIMBE ', NULL, 2964, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1877, 1, 'KAMAYE KOUNTA', NULL, 2965, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1878, 1, 'MAMADI TERETA ', NULL, 2966, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1879, 1, 'KAMAYE KOUNTAO ', NULL, 2967, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1880, 1, 'OUMAR GOURANSO ', NULL, 2968, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1881, 1, 'CHIEECK AMADOU TERETA ', NULL, 2969, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1882, 1, 'SEKOU SALA KAMPO', NULL, 2970, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1883, 1, 'ALMAMY SIENTA', NULL, 2971, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1884, 1, 'MAMADOU KOMONTA', NULL, 2972, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1885, 1, 'AFOU KEMOU', NULL, 2973, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1886, 2, 'POULO', NULL, 2974, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1887, 1, 'MAMADY FAMANTA', NULL, 2975, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1888, 1, 'MORY KOMOTA', NULL, 2976, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1889, 1, 'AFOU COULIBALY', NULL, 2977, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1890, 1, 'BONKO FAMANTA', NULL, 2978, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1891, 1, 'MARIAM KANONTA', NULL, 2979, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1892, 1, 'YOUSSOU KOMONTA', NULL, 2980, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1893, 1, 'KEON KOROGNON', NULL, 2981, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1894, 1, 'NAMADY FAMANTA', NULL, 2982, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1895, 1, 'BABORY TAPO', NULL, 2983, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1896, 1, 'KOLADO', NULL, 2984, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1897, 1, 'BENKE KOMONTA', NULL, 2985, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1898, 1, 'MARIAM KOMONTA', NULL, 2986, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1899, 1, 'KALY MADY', NULL, 2987, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1900, 1, 'MADY SALAMANTA', NULL, 2988, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1901, 1, 'MATIN DIENTA', NULL, 2989, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1902, 1, 'SORY KOROGNON', NULL, 2990, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1903, 1, 'BENKE FAMANTA', NULL, 2991, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1904, 1, 'BATAMANI TRAORE', NULL, 2992, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1905, 1, 'HAMIDOU TRAORE', NULL, 2993, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1906, 1, 'ALY KOMON', NULL, 2994, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1907, 1, 'LASSINE NIAFO', NULL, 2995, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1908, 1, 'DJAO KARABETA', NULL, 2996, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1909, 1, 'IBRHIMA TERETA', NULL, 2997, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1910, 1, 'ISSA TERETA', NULL, 2998, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1911, 1, 'ALI TRAORE', NULL, 2999, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1912, 1, 'TALAHA KUNTAO', NULL, 3000, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1913, 1, 'MAMAYE KOUNTA', NULL, 3001, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1914, 1, 'MAYAMA KOUNTAO', NULL, 3002, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1915, 1, 'MAMADOU KON�', NULL, 3003, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1916, 1, 'TAHALA KOUNTAO', NULL, 3004, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1917, 1, 'SOUMANA TRAOR�', NULL, 3005, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1918, 1, 'MOUSSA TRAOR�', NULL, 3006, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1919, 1, 'MOCTAR TRAOR�', NULL, 3007, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1920, 1, 'ALPHA KONTA', NULL, 3008, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1921, 1, 'ISSA DJENA ', NULL, 3009, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1922, 1, 'TALAHA KONOKO', NULL, 3010, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1923, 2, 'ISSA DJENA ', NULL, 3011, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1924, 1, 'CKEICK AMADOU ', NULL, 3012, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1925, 1, 'MOCTAR TANOPO', NULL, 3013, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1926, 1, 'BILA TAMBOURA ', NULL, 3014, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1927, 1, 'SEYDOU COURANSO', NULL, 3015, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1928, 1, 'LASSANA KOUNTAO', NULL, 3016, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1929, 1, 'MACTAR TANAPO', NULL, 3017, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1930, 1, 'CHIECK AMADOU TERETA', NULL, 3018, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1931, 1, 'SIDI SACKO', NULL, 3019, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1932, 1, 'LASSINA KALAPO', NULL, 3020, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1933, 1, 'SEKOU AMADOU KANTA', NULL, 3021, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1934, 1, 'MALAMINI FOFANA ', NULL, 3022, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1935, 1, 'MASSOROKO KARABINTA ', NULL, 3023, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1936, 1, 'DEDJIGUI DONOGO ', NULL, 3024, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1937, 1, 'SEKOU KOBILA ', NULL, 3025, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1938, 1, 'DJIA BOUA  TRAORE', NULL, 3026, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1939, 1, 'KEBOYI KARONTA', NULL, 3027, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1940, 1, 'MOUSSA DJIENTA ', NULL, 3028, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1941, 1, 'ALMAMY TRAORE ', NULL, 3029, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1942, 1, 'DJA BOUA TRAORE ', NULL, 3030, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1943, 1, 'ABDOULAYE TERETA ', NULL, 3031, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1944, 1, 'SOLO SACKO ', NULL, 3032, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1945, 1, 'ALAMAMY TRAORE ', NULL, 3033, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1946, 1, 'NOUHOUN KINTA', NULL, 3034, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1947, 1, 'NOUHOUM KINTA ', NULL, 3035, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1948, 1, 'YAYI  SINAYOKO ', NULL, 3036, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1949, 1, 'BECHE TAMBOURA', NULL, 3037, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1950, 1, 'SOUMANA SYNAYOGO', NULL, 3038, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1951, 1, 'BOUBACAR SEREKE', NULL, 3039, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1952, 1, 'FATOUMATA DJAMAKOUROU', NULL, 3040, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1953, 1, 'MADOU TANAPO', NULL, 3041, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1954, 1, 'BRAMA TRAORE', NULL, 3042, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1955, 1, 'TIDIANI SIENTA', NULL, 3043, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1956, 1, 'MAMOUTOU SIENTA', NULL, 3044, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1957, 1, 'AMAH HAIDARA', NULL, 3045, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1958, 1, 'DIADIE SIENTA', NULL, 3046, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1959, 1, 'MAMA SIENTA', NULL, 3047, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1960, 1, 'BABA DIENTA', NULL, 3048, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1961, 1, 'KOCHOU TRAORE ', NULL, 3049, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1962, 1, 'SINE TRAORE', NULL, 3050, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1963, 1, 'AWA', NULL, 3051, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1964, 1, 'BADAOUDA', NULL, 3052, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1965, 1, 'KA KONABENTA', NULL, 3053, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1966, 1, 'MORI MAMA', NULL, 3054, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1967, 1, 'BA SINALY', NULL, 3055, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1968, 1, 'KEBOUARI', NULL, 3056, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1969, 1, 'BOUARI', NULL, 3057, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1970, 1, 'HAMIDOU', NULL, 3058, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1971, 1, 'BASSOUMANA DENEKOU', NULL, 3059, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1972, 1, 'KE MOUSSA', NULL, 3060, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1973, 1, 'ISSOUFI', NULL, 3061, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1974, 1, 'BOUBA TRAORE', NULL, 3062, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1975, 1, 'MANI SINAYOKO ', NULL, 3063, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1976, 1, 'KARAMOGO SALAMATA ', NULL, 3064, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1977, 1, 'MAMADOU KOUNTAO ', NULL, 3065, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1978, 1, 'DJAMINE DRAME ', NULL, 3066, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1979, 1, 'CHEIK AMADOU SALAMATA ', NULL, 3067, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1980, 1, 'BOKADARY SALAMATA ', NULL, 3068, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1981, 1, 'NANABA SALAMANTA ', NULL, 3069, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1982, 1, 'LABARI SAOUNTA', NULL, 3070, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1983, 1, 'ZOUMANA NIOUMANTAO', NULL, 3071, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (1984, 1, 'MAMA KOUNTA', NULL, 3072, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1985, 1, 'ALY DIARRA ', NULL, 3073, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1986, 1, 'SEKOU MAGNI SALAMA ', NULL, 3074, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1987, 1, 'AMADOU GOURANSO ', NULL, 3075, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1988, 1, 'LARABI SAOUNTA ', NULL, 3076, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1989, 1, 'YACOUBA SACKO ', NULL, 3077, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1990, 1, 'SINALY MINTA ', NULL, 3078, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1991, 1, 'LASSINE SININTA ', NULL, 3079, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1992, 1, 'ALPHA DABITAO ', NULL, 3080, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1993, 1, 'SOUMANA LABITA ', NULL, 3081, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1994, 1, 'AMADOU NABO ', NULL, 3082, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1995, 1, 'OUMAR DIAWARA ', NULL, 3083, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1996, 1, 'OUSMANE LABITAO ', NULL, 3084, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1997, 1, 'FATOUMATA DIENTA ', NULL, 3085, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1998, 1, 'YALPHA DABITAO ', NULL, 3086, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (1999, 1, 'BOUACAR DICKO ', NULL, 3087, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2000, 1, 'BOUBACAR KASSAMBAROU ', NULL, 3088, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2001, 1, 'FOUSSEYNU TRAORE', NULL, 3089, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2002, 1, 'HAMADY KASSOUMBARA ', NULL, 3090, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2003, 1, 'MAMA SAMPANA ', NULL, 3091, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2004, 1, 'SEKOU MAHI MINTA ', NULL, 3092, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2005, 1, 'SOMANA ', NULL, 3093, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2006, 1, 'SEYNI TIENTA', NULL, 3094, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2007, 1, 'BEKENGNINI TIKAMBO', NULL, 3095, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2008, 1, 'BALLA KASSIM', NULL, 3096, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2009, 1, 'AMIDJA', NULL, 3097, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2010, 1, 'BARIMA DIOUNDE', NULL, 3098, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2011, 1, 'HAMDJA', NULL, 3099, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2012, 1, 'LASSINA MAIGA ', NULL, 3100, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2013, 1, 'SEKOU H MINTA ', NULL, 3101, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2014, 1, 'SIDI LOPOTA ', NULL, 3102, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2015, 1, 'BAYAYA', NULL, 3103, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2016, 1, 'KOMAN ', NULL, 3104, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2017, 1, 'BAMADI TIKAMBO', NULL, 3105, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2018, 1, 'SIDY DJOUDE', NULL, 3106, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2019, 1, 'MADI TOUKARA', NULL, 3107, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2020, 1, 'MOHAMED TOUKARA', NULL, 3108, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2021, 1, 'NOUHOUN TIKAMBO', NULL, 3109, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2022, 1, 'MOHAMED SERETA', NULL, 3110, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2023, 1, 'BALLA KASSIM 2', NULL, 3111, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2024, 1, 'BARIMA DJOUDE', NULL, 3112, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2025, 1, 'TIKAMBO BETENGUINI', NULL, 3113, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2026, 1, 'BALLA KASSIM 1', NULL, 3114, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2027, 1, 'BEKENGUINI TIKANBO ', NULL, 3115, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2028, 1, 'HAMDJE', NULL, 3116, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2029, 1, 'MADI TOUNKARA ', NULL, 3117, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2030, 1, 'NIANE ', NULL, 3118, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2031, 1, 'KAYE SERETA ', NULL, 3119, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2032, 1, 'BOUBACAR TIENTA ', NULL, 3120, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2033, 1, 'NIASSE', NULL, 3121, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2034, 1, 'MADI ', NULL, 3122, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2035, 1, 'LASSI MAIGA ', NULL, 3123, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2036, 1, 'MOHAMED TOUNKARA ', NULL, 3124, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2037, 1, 'BEKENGUINI TIKAMBO', NULL, 3125, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2038, 1, 'BAKARY TERETA ', NULL, 3126, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2039, 1, 'SEKOU M MINTA ', NULL, 3127, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2040, 1, 'HASSIM ', NULL, 3128, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2041, 1, 'ABOUZARAK MAIGA ', NULL, 3129, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2042, 1, 'DRAMAE TOUNKARA ', NULL, 3130, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2043, 1, 'KAYE', NULL, 3131, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2044, 1, 'SOUMANA TERETA ', NULL, 3132, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2045, 1, 'BENKEGUINI TIKAMBO ', NULL, 3133, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2046, 1, 'SIDI MINTA', NULL, 3134, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2047, 1, 'TOUNKARA DRAMANE', NULL, 3135, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2048, 1, 'SERETA ABDOULAYE', NULL, 3136, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2049, 1, 'BENKENGUI TIKAMBO', NULL, 3137, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2050, 1, 'SALIF TRAORE', NULL, 3138, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2051, 1, 'SEKOU MAHI TERETA', NULL, 3139, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2052, 1, 'BARIMA DJONDE', NULL, 3140, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2053, 1, 'BOULAYE TERETA', NULL, 3141, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2054, 1, 'MASSEOU TERETA', NULL, 3142, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2055, 1, 'SEKOU M TERETA', NULL, 3143, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2056, 1, 'KAYE TOUNKARA ', NULL, 3144, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2057, 1, 'DRAMANI TOUNKARA ', NULL, 3145, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2058, 1, 'NIASSE TRAORE', NULL, 3146, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2059, 1, 'BENKE KOITA', NULL, 3147, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2060, 1, 'MOUSSA YATTARA', NULL, 3148, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2061, 1, 'BAMOUSSA ', NULL, 3149, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2062, 1, 'BAYAYA TIKAMBO', NULL, 3150, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2063, 1, 'BAMADI TERETA ', NULL, 3151, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2064, 1, 'ABOURARACK MAIGA', NULL, 3152, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2065, 1, 'BAMADI TOUNKARA', NULL, 3153, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2066, 1, 'MAMADI KOITA', NULL, 3154, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2067, 1, 'HASSIM MINTA', NULL, 3155, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2068, 1, 'MOHAMED ', NULL, 3156, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2069, 1, 'BINKE KOITA', NULL, 3157, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2070, 1, 'BOULAYE SERETA ', NULL, 3158, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2071, 1, 'AMADOU BINTA', NULL, 3159, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2072, 1, 'MANDA', NULL, 3160, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2073, 1, 'TIEBLE', NULL, 3161, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2074, 1, 'LAOU TERETA ', NULL, 3162, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2075, 1, 'HAMSSA ', NULL, 3163, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2076, 1, 'MOUHAMED DOUMANGOUROU', NULL, 3164, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2077, 1, 'KAKARY TICAMBO', NULL, 3165, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2078, 1, 'ASSANA KONTA', NULL, 3166, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2079, 2, 'MOUSSA COULIBALY', NULL, 3167, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2080, 1, 'IBRAHIM KARANSO', NULL, 3168, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2081, 1, 'LADJI TICAMBO', NULL, 3169, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2082, 1, 'BAKARY DOUMANGOUROU', NULL, 3170, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2083, 1, 'ABDOULAUE CISSE', NULL, 3171, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2084, 1, 'TALY CISS�', NULL, 3172, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2085, 1, 'AMADOU TIMINTO', NULL, 3173, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2086, 1, 'MOUSSA TAKAMBO', NULL, 3174, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2087, 1, 'AMADOU TINMINTA', NULL, 3175, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2088, 1, 'BAKARY DIRRA', NULL, 3176, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2089, 1, 'GARABA KAROTA', NULL, 3177, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2090, 1, 'AMADOU TIMINTA', NULL, 3178, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2091, 1, 'TAMANA SINAPO', NULL, 3179, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2092, 1, 'YAYI SINAPO', NULL, 3180, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2093, 1, 'SEKOU DOUCOURE', NULL, 3181, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2094, 1, 'SEKOU DONOGO', NULL, 3182, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2095, 1, 'LASSANA KINTA', NULL, 3183, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2096, 1, 'SOUNKALA DIARRA', NULL, 3184, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2097, 1, 'ALPHOUSSENI MAIGA', NULL, 3185, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2098, 1, 'MOUSSA TRAORE N�2', NULL, 3186, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2099, 1, 'DEMBA YATTARA', NULL, 3187, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2100, 1, 'SOLO KOBILA', NULL, 3188, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2101, 1, 'BOUACAR CACKO', NULL, 3189, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2102, 1, 'BOUBAKARY KONTA', NULL, 3190, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2103, 1, 'MADOU NADION', NULL, 3191, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2104, 1, 'LASSINA SACKO', NULL, 3192, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2105, 1, 'MOUSSA TRAORE N�1', NULL, 3193, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2106, 1, 'IBRAHIMA TRAORE', NULL, 3194, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2107, 1, 'YOUSSOUPH KALAPO', NULL, 3195, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2108, 1, 'SORY SACKO ', NULL, 3196, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2109, 1, 'MAMA TERETA ', NULL, 3197, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2110, 1, 'BOKADARY SACKO ', NULL, 3198, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2111, 1, 'AFO DICKO ', NULL, 3199, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2112, 1, 'SOLO TANGARA ', NULL, 3200, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2113, 1, 'KARAMAKO KANE ', NULL, 3201, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2114, 1, 'SOUMANA SACKO ', NULL, 3202, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2115, 1, 'ABDOULAYE  SAMPANA ', NULL, 3203, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2116, 1, 'LAMINE KANE ', NULL, 3204, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2117, 1, 'BASSIROU TOUNKARA ', NULL, 3205, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2118, 1, 'BOUBA TANAPO ', NULL, 3206, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2119, 1, 'ALMAMY AJANA ', NULL, 3207, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2120, 1, 'DIAFARA SACKO ', NULL, 3208, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2121, 1, 'NOUHOUM SAMPANA ', NULL, 3209, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2122, 1, 'MAMADOU DOUKOURE ', NULL, 3210, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2123, 1, 'MUOSSATRAORE 2', NULL, 3211, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2124, 1, 'MAMAYI KONTAO ', NULL, 3212, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2125, 1, 'KAMAYE KONTAO', NULL, 3213, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2126, 1, 'KOMANI KONTAO', NULL, 3214, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2127, 1, 'SOUMAILA  MAIGA ', NULL, 3215, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2128, 1, 'MAHAMADOU TERETA ', NULL, 3216, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2129, 1, 'MANAYI KONTAO ', NULL, 3217, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2130, 1, 'BREHIMA TERETA ', NULL, 3218, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2131, 1, 'LAHOU DOUMANHOUROU', NULL, 3219, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2132, 1, 'DRAMANI KONTA ', NULL, 3220, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2133, 1, 'SEKOU KAMPO ', NULL, 3221, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2134, 1, 'HADI KONTA ', NULL, 3222, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2135, 1, 'MAMAH KANTA ', NULL, 3223, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2136, 1, 'ALOU KANTA ', NULL, 3224, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2137, 1, 'OUMAR KANE ', NULL, 3225, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2138, 1, 'BADJA SALAMATA ', NULL, 3226, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2139, 1, 'BAMOU SALAMATA ', NULL, 3227, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2140, 1, 'CHEICK AMADOU SALAMATA ', NULL, 3228, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2141, 1, 'SADIO MINTA ', NULL, 3229, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2142, 1, 'MAGNI SALAMATA ', NULL, 3230, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2143, 1, 'MAMAH SALAMANTA ', NULL, 3231, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2144, 1, 'MAMAH TIENTA ', NULL, 3232, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2145, 1, 'POLY DIARRA ', NULL, 3233, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2146, 1, 'KASSIM MINTA ', NULL, 3234, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2147, 1, 'DJOMINA DRAME', NULL, 3235, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2148, 1, 'MAGNI SALAMANTA ', NULL, 3236, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2149, 1, 'SEKOU COURANSO ', NULL, 3237, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2150, 1, 'CHAKA KANE ', NULL, 3238, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2151, 1, 'MOHAHED SISSOKO', NULL, 3239, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2152, 1, 'ADAMA YAOUNA ', NULL, 3240, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2153, 1, 'MOHAMAD SISSOKO ', NULL, 3241, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2154, 1, 'BOKADARY KANE ', NULL, 3242, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2155, 1, 'AMADOU YOUANOU', NULL, 3243, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2156, 1, 'SEKOU SINAYOKO 2', NULL, 3244, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2157, 1, 'SEKOU SINAYOKO 1', NULL, 3245, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2158, 1, 'SOLOMANE SACKO ', NULL, 3246, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2159, 1, '05/02/03', NULL, 3247, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2160, 1, 'ABOUBACAR TANAPO', NULL, 3248, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2161, 1, 'MODOU NADIO ', NULL, 3249, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2162, 1, 'ALPHAMOYE TIENTA ', NULL, 3250, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2163, 1, 'BAMOUSSA TRAORE ', NULL, 3251, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2164, 1, 'ALPHOUSSEYNOU MAIGA ', NULL, 3252, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2165, 1, 'IBAHIMA DIARRA', NULL, 3253, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2166, 1, 'BAKORAKA KANE ', NULL, 3254, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2167, 1, 'BAKARY KIRE ', NULL, 3255, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2168, 1, 'MODIBA KANTA ', NULL, 3256, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2169, 1, 'DIADIE KONTA ', NULL, 3257, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2170, 1, 'MAMANE DENON', NULL, 3258, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2171, 1, 'DJEDJE SAGHO', NULL, 3259, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2172, 1, 'DJEDJE SANGHO', NULL, 3260, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2173, 1, 'SADIO TRAORE', NULL, 3261, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2174, 1, 'ADAMA KAMINA', NULL, 3262, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2175, 1, 'BIRA TOMOTA', NULL, 3263, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2176, 1, 'BORY BORY FAMANTA', NULL, 3264, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2177, 1, 'SOLO SIMPANA', NULL, 3265, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2178, 1, 'KABORO NIOUMANTA', NULL, 3266, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2179, 1, 'SOLO SAMPANA', NULL, 3267, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2180, 1, 'YAYE SAMPANA', NULL, 3268, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2181, 1, 'BABACAR COULIBALY', NULL, 3269, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2182, 1, 'BA MOUSSA', NULL, 3270, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2183, 1, 'OUSMANE KAMINA', NULL, 3271, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2184, 1, 'HASSOUMOU', NULL, 3272, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2185, 1, 'SEKOU A KONTA', NULL, 3273, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2186, 1, 'ABBA FAMANTA', NULL, 3274, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2187, 1, 'SONO MAMA', NULL, 3275, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2188, 1, 'LONI', NULL, 3276, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2189, 1, 'MADY ZERETA', NULL, 3277, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2190, 1, 'BACARI', NULL, 3278, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2191, 1, 'VIEUX KANTA', NULL, 3279, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2192, 1, 'BOU KANTA', NULL, 3280, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2193, 1, 'SEKOU A SAMPANA 2', NULL, 3281, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2194, 1, 'SEKOU B. HONONTA', NULL, 3282, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2195, 1, 'TAHIROU DIARRA', NULL, 3283, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2196, 1, 'LAIDJI KONTA', NULL, 3284, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2197, 1, 'ASSA MINTA', NULL, 3285, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2198, 1, 'MOUSSA BALA CISSE', NULL, 3286, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2199, 1, 'LADJI BREHIMA KONTA', NULL, 3287, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2200, 1, 'SAMBA SIDIBE', NULL, 3288, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2201, 1, 'LASSANA SOCKO', NULL, 3289, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2202, 1, 'LASSANA SACKO', NULL, 3290, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2203, 1, 'ASSIN TICAMBO', NULL, 3291, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2204, 1, 'AMADOU D MINTA', NULL, 3292, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2205, 1, 'OUSMANEMINTA', NULL, 3293, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2206, 1, 'KEREMUGNAN KANTA', NULL, 3294, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2207, 1, 'MAKOLA KANTA', NULL, 3295, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2208, 1, 'BINA TOMATA', NULL, 3296, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2209, 1, 'SEKOU FORE', NULL, 3297, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2210, 1, 'KABORE NIOUMANTA', NULL, 3298, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2211, 1, 'LADJI DJENEPO', NULL, 3299, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2212, 1, 'BAGAOUSSOU DAMANTA', NULL, 3300, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2213, 0, 'LAJI  DJIENEPO', NULL, 3301, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2214, 1, 'KEREMUGNAN KONTA', NULL, 3302, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2215, 1, 'KONIO KANTA', NULL, 3303, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2216, 1, 'MAHANDA KONTA', NULL, 3304, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2217, 1, 'KEREMOGNON KONTA', NULL, 3305, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2218, 1, 'KEREMUGNA KANTA', NULL, 3306, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2219, 1, 'MODI TERETA', NULL, 3307, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2220, 1, 'BOUANI KOMONTA', NULL, 3308, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2221, 1, 'KEREMUGA KANTA', NULL, 3309, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2222, 1, 'KEREBOGANI FAMANTA', NULL, 3310, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2223, 1, 'BOUACAR KANTA ', NULL, 3311, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2224, 1, 'MAMA SALAMATA ', NULL, 3312, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2225, 1, 'SEKOU MAHI SALAMANTA', NULL, 3313, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2226, 1, 'BASSOUMANA', NULL, 3314, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2227, 1, 'BAKARY FAMANTA', NULL, 3315, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2228, 1, 'YAKOUBA', NULL, 3316, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2229, 1, 'BOUACAR SERETA', NULL, 3317, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2230, 1, 'BAFITINI', NULL, 3318, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2231, 1, 'SOUMANA DIARRA', NULL, 3319, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2232, 1, 'MOHAMED KONTA', NULL, 3320, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2233, 1, 'BA MORIKE', NULL, 3321, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2234, 1, 'BAFITINI KONTA', NULL, 3322, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2235, 1, 'SINALY KONTA', NULL, 3323, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2236, 1, 'TOKA OUSMANE HAIDARA', NULL, 3324, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2237, 1, 'MAMADOU KONTON', NULL, 3325, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2238, 1, 'MAMAH SAMPANA', NULL, 3326, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2239, 1, 'SALA TRAORE', NULL, 3327, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2240, 1, 'TOKO OUSMANE HAIDARA', NULL, 3328, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2241, 1, 'CHEIKH AMADOU DABITAO', NULL, 3329, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2242, 1, 'FOUSSENI KONTA', NULL, 3330, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2243, 1, 'ISSOUF KONTA', NULL, 3331, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2244, 1, 'KASSIM KONTA', NULL, 3332, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2245, 1, 'SEKOU BREHIMA KONTA', NULL, 3333, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2246, 1, 'MOUSSA NIOUMATA', NULL, 3334, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2247, 1, 'MADOU TERETA', NULL, 3335, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2248, 1, 'MAMADOU DRAMANE KONTA', NULL, 3336, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2249, 1, 'IBRAHIM KOLONSE', NULL, 3337, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2250, 1, 'KARAMOGO KAMPO', NULL, 3338, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2251, 2, 'BA ISSA DJINTA', NULL, 3339, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2252, 1, 'ALI KAMPO', NULL, 3340, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2253, 1, 'YAYA KAMPO', NULL, 3341, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2254, 1, 'MOUSA KONTA', NULL, 3342, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2255, 1, 'DRISSA SEKOU KAMBO', NULL, 3343, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2256, 1, 'ALMAMY TIENTA', NULL, 3344, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2257, 1, 'DEMBA  GUINADO ', NULL, 3345, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2258, 1, 'SOUMANA SEKERE', NULL, 3346, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2259, 1, 'SIDIKI DABITA', NULL, 3347, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2260, 1, 'MAMADOU KOUNTA', NULL, 3348, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2261, 1, 'SOUMANA SEREKE', NULL, 3349, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2262, 1, 'SEKOU BA DOUMBIA', NULL, 3350, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2263, 1, 'AMADOU KASSAMBARA', NULL, 3351, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2264, 1, 'OUMAR SABITAO', NULL, 3352, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2265, 1, 'BOUBACAR TRAIRE', NULL, 3353, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2266, 1, 'MAMADY SINETA', NULL, 3354, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2267, 1, 'KOKORY BECRE', NULL, 3355, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2268, 1, 'SEKOU SININTA', NULL, 3356, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2269, 1, 'HAMADI KASSAMBARA', NULL, 3357, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2270, 1, 'MAMADY SININTA', NULL, 3358, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2271, 1, 'MAMA HAIDARA', NULL, 3359, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2272, 1, 'CHEIK OUMAR DABITAO', NULL, 3360, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2273, 1, 'BACARI FAMANTA', NULL, 3361, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2274, 1, 'KOMAMA SACKO', NULL, 3362, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2275, 1, 'SEKOU A TER�TA', NULL, 3363, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2276, 1, 'OUMAROU FAMANTA', NULL, 3364, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2277, 1, 'BABA SERETA', NULL, 3365, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2278, 1, 'MAMADOU TOMOTO', NULL, 3366, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2279, 1, 'ABDOULAYE KOTO', NULL, 3367, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2280, 1, 'BIBOUARI FAMANTA', NULL, 3368, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2281, 1, 'LASSINA TRIPO', NULL, 3369, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2282, 1, 'BIBA TRIPO', NULL, 3370, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2283, 1, 'TALLY TRIPO', NULL, 3371, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2284, 1, 'ISSA DRAME', NULL, 3372, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2285, 1, 'BAMOYE SAYO', NULL, 3373, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2286, 1, 'MAMADOU MINTA', NULL, 3374, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2287, 1, 'DJEKINE FAMANTA', NULL, 3375, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2288, 1, 'MADI YERETA', NULL, 3376, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2289, 1, 'BALSA FORE', NULL, 3377, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2290, 1, 'BOULAYE KOTA', NULL, 3378, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2291, 1, 'SEKOU TIENTA', NULL, 3379, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2292, 1, 'OUSMANE FAMANTA', NULL, 3380, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2293, 1, 'A NKERE FAMANTA', NULL, 3381, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2294, 1, 'KAMAMA SACKO', NULL, 3382, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2295, 1, 'KANTA KEREMUGNON', NULL, 3383, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2296, 1, 'MAMODOU TOMOTA', NULL, 3384, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2297, 1, 'BABA COULIBALY', NULL, 3385, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2298, 1, 'BAHA TRIPO', NULL, 3386, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2299, 1, 'BADRA ALOU', NULL, 3387, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2300, 1, 'BABA ALY', NULL, 3388, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2301, 1, 'SEGA', NULL, 3389, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2302, 1, 'MANA SIABATA', NULL, 3390, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2303, 1, 'BAMOYE', NULL, 3391, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2304, 1, 'SOLOMANE TRAORE', NULL, 3392, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2305, 1, 'YACOUBA TRAORE', NULL, 3393, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2306, 1, 'MOULAYE NTOUGARY', NULL, 3394, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2307, 1, 'HAMIDOU SACKO', NULL, 3395, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2308, 1, 'SEKOU M CISSE', NULL, 3396, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2309, 1, 'MOULAYE NTOUGARE', NULL, 3397, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2310, 1, 'MADOU KARABINTA', NULL, 3398, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2311, 1, 'LASSINA TANAPO', NULL, 3399, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2312, 1, 'SEKOU KAKE DOUCOURE', NULL, 3400, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2313, 1, 'LASSINA SABATA', NULL, 3401, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2314, 1, 'MOULAYE NTOUKARA', NULL, 3402, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2315, 1, 'SOULO TRAORE', NULL, 3403, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2316, 1, 'SEKOU TOMONTA', NULL, 3404, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2317, 1, 'HAMALA LASSINA TERETA', NULL, 3405, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2318, 1, 'DJA-BOUA TRAORE', NULL, 3406, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2319, 1, 'BIRAMA KONTA', NULL, 3407, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2320, 1, 'DJI BOUA TRAORE', NULL, 3408, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2321, 1, 'CHEICK AMADOU KONTA', NULL, 3409, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2322, 2, 'POULO NGNAPOGOU', NULL, 3410, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2323, 1, 'MADOU GNOUMANTA', NULL, 3411, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2324, 1, 'BOURI KONDO', NULL, 3412, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2325, 1, 'MAMADOU FAMANTA', NULL, 3413, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2326, 1, 'FOUSSEYNI FAROTA', NULL, 3414, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2327, 1, 'MORY KOMANA', NULL, 3415, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2328, 1, 'LASSI NAFO', NULL, 3416, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2329, 1, 'BAKARY DIENTA', NULL, 3417, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2330, 1, 'LASSINA GNIAFO', NULL, 3418, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2331, 1, 'POULO NIAPOUGOU', NULL, 3419, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2332, 1, 'ALY KOMU', NULL, 3420, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2333, 1, 'SEKOU MOKANTA', NULL, 3421, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2334, 1, 'BOUBACAR SININTA', NULL, 3422, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2335, 1, 'KEOU TIENTA', NULL, 3423, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2336, 1, 'MAMADOU KOROGNON', NULL, 3424, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2337, 1, 'OUSMANE TAPO', NULL, 3425, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2338, 1, 'MOUSSA BOIRE', NULL, 3426, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2339, 1, 'NGADA KORYON', NULL, 3427, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2340, 1, 'AFO KORYON', NULL, 3428, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2341, 1, 'MAMADOU SALAMANTA', NULL, 3429, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2342, 1, 'MAMADOU GNOUMANTA', NULL, 3430, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2343, 1, 'BOURI KOROGNON', NULL, 3431, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2344, 1, 'MORY KAMAINA', NULL, 3432, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2345, 1, 'ZOUMANA BIRAKORO', NULL, 3433, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2346, 1, 'DORY SIMBE', NULL, 3434, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2347, 1, 'BOUBACAR MINTA 1', NULL, 3435, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2348, 1, 'BOUBACAR MINTA 2', NULL, 3436, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2349, 1, 'BASIDIKI TOUNKARA', NULL, 3438, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2350, 1, 'BOCAR SACKO', NULL, 3439, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2351, 1, 'BASSIDIKI TOUNKARA', NULL, 3440, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2352, 1, 'BAH TAMANTA', NULL, 3441, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2353, 1, 'SOUMAILA NADIO', NULL, 3442, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2354, 1, 'OUSMANE KANOUTE', NULL, 3443, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2355, 1, 'MOULAYE TRAORE', NULL, 3444, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2356, 1, 'ZOUMANA CEKERE', NULL, 3445, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2357, 1, 'BOURAMA DONOGO', NULL, 3446, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2358, 1, 'MAMA KARABETA', NULL, 3447, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2359, 1, 'BASSALIBA FOFANA', NULL, 3448, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2360, 1, 'SEKOU AMADOU KOUANTA', NULL, 3449, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2361, 1, 'ZOUMANA KARONTA', NULL, 3450, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2362, 1, 'LASSINE KOBILA', NULL, 3451, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2363, 1, 'LASSANA TINGOBO', NULL, 3452, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2364, 1, 'SENOU FAROTA', NULL, 3453, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2365, 1, 'SOULAKATA KONTA', NULL, 3454, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2366, 1, 'BREHIMA MAIGA', NULL, 3455, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2367, 1, 'KASSIME SACKO ', NULL, 3456, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2368, 1, 'BOUBACARY MINTA', NULL, 3457, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2369, 1, 'DJOMINAI DRAME', NULL, 3458, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2370, 2, 'MAMAH MINTA', NULL, 3459, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2371, 1, 'FATOUMATA SALAMATA', NULL, 3460, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2372, 1, 'ZOUMANA NIOUMANATA', NULL, 3461, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2373, 1, 'CHEIKH MAGNI SALAMANTA', NULL, 3462, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2374, 1, 'TAHIROU SOUMARO', NULL, 3463, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2375, 1, 'BAZAN SALAMANTA', NULL, 3464, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2376, 1, 'BAKARY SALAMANTA', NULL, 3465, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2377, 1, 'MOUTAR TANAFO', NULL, 3466, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2378, 1, 'DRAMANI KOUNTAO', NULL, 3467, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2379, 1, 'CHEICK AMADOU', NULL, 3468, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2380, 1, 'MAMA COULIBALY ', NULL, 3469, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2381, 1, 'BOURAIMA KANE ', NULL, 3470, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2382, 1, 'BASINALY KONTA', NULL, 3471, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2383, 1, 'BELLA KARAKATA', NULL, 3472, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2384, 1, 'MAHAMADOU BAYE', NULL, 3473, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2385, 1, 'BAGNINY KONTA', NULL, 3474, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2386, 1, 'TALLY KONTA', NULL, 3475, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2387, 1, 'KAMA KONTA', NULL, 3476, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2388, 1, 'AROUNA FOFANA', NULL, 3477, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2389, 1, 'KALY FMANTA', NULL, 3478, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2390, 1, 'BALLA KEITA', NULL, 3479, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2391, 1, 'TALY KONTA', NULL, 3480, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2392, 1, 'ALOU DICKO', NULL, 3481, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2393, 1, 'AMADOU AM�GA', NULL, 3482, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2394, 1, 'BOUBA DIARRA', NULL, 3483, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2395, 1, 'ALI KARABENTA', NULL, 3484, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2396, 1, 'BABA KANE ', NULL, 3485, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2397, 1, 'BAKARY SAPANO ', NULL, 3486, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2398, 1, 'KAMA TRAORE ', NULL, 3487, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2399, 1, 'BAKARY NADJIAN', NULL, 3488, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2400, 1, 'BAKARY KONTA ', NULL, 3489, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2401, 1, 'SIRAKOTO KANTA ', NULL, 3490, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2402, 1, 'BOUBA COULIBALY ', NULL, 3491, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2403, 1, 'BOUBA COUIBALY', NULL, 3492, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2404, 1, 'BOUKADARY SECEY ', NULL, 3493, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2405, 1, 'BAKOROBA KIRE', NULL, 3494, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2406, 1, 'LASSINA ARMA', NULL, 3495, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2407, 1, 'SEKOU A KAREBANA ', NULL, 3496, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2408, 1, 'BAKARABA KANE', NULL, 3497, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2409, 1, 'SIRAKATA KANTA ', NULL, 3498, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2410, 1, 'DEMBA COULIBALY', NULL, 3499, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2411, 1, 'SIRAKA KANTA ', NULL, 3500, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2412, 1, 'SOUMANA KOKILA ', NULL, 3506, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2413, 1, 'BAKAYE SACKO ', NULL, 3507, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2414, 1, 'CHEICK AMADOU SACKO ', NULL, 3508, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2415, 1, 'KASSIM TRAORE ', NULL, 3509, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2416, 1, 'ALMAMY SACKO', NULL, 3510, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2417, 1, 'BROULAYE TERETA', NULL, 3511, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2418, 1, 'CHEICK AMADOU  KONTA ', NULL, 3512, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2419, 2, 'BOUBACAR TRAORE ', NULL, 3513, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2420, 1, 'MOUSSA DONOGO ', NULL, 3514, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2421, 1, 'BAKARY BLE TRAORE ', NULL, 3515, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2422, 1, 'SEKOU SACKO ', NULL, 3516, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2423, 1, 'SEKOU AMADOU PAMANTA ', NULL, 3517, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2424, 1, 'SEKOU MAGNI', NULL, 3518, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2425, 1, 'SOUMAILA KOBILA ', NULL, 3519, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2426, 1, 'KASSIM SINAITAO ', NULL, 3520, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2427, 2, 'SOUMAILA KOBILA ', NULL, 3521, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2428, 1, 'AMADOU COURANSO', NULL, 3522, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2429, 1, 'MAMAH SINAYOKO', NULL, 3523, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2430, 1, 'ADAMA COURANSO ', NULL, 3524, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2431, 1, 'ALIOU MINTA ', NULL, 3525, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2432, 1, 'SAMBA KONIA ', NULL, 3526, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2433, 1, 'BABA BABA  DJENEPO', NULL, 3527, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2434, 1, 'BAREMA TRAORE', NULL, 3528, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2435, 1, 'IBRAHIM TERETA', NULL, 3529, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2436, 1, 'BARIMA KORABINTA', NULL, 3530, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2437, 1, 'MAMADI SAOUNTA', NULL, 3531, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2438, 1, 'MAMADI SALAMANTA', NULL, 3532, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2439, 1, 'MOCTA TANAPO', NULL, 3533, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2440, 1, 'DRAMANE KONTA', NULL, 3534, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2441, 1, 'BOUBACAR DEBOKENE ', NULL, 3535, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2442, 1, 'DJEDJJE SONGHO', NULL, 3536, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2443, 1, 'BASSIROU  TOUNKARA ', NULL, 3537, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2444, 1, 'BOUKADARY TRAORE ', NULL, 3538, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2445, 1, 'MOULAYE KOUNTAO ', NULL, 3539, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2446, 1, 'BE SARO', NULL, 3540, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2447, 1, 'SEKOU TIDIANI DOUMANGOUROU', NULL, 3541, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2448, 1, 'BOCKADARY DOUMANGOUROU', NULL, 3542, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2449, 1, 'NGARBA DEMBELE', NULL, 3543, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2450, 1, 'AMADOU DEMBA MINTA', NULL, 3544, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2451, 1, 'SEYDOU DEMBELE', NULL, 3545, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2452, 1, 'KAKARY DIAKITE', NULL, 3546, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2453, 1, 'MAMA MIMINTAO', NULL, 3547, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2454, 1, 'KOKO TRAORE ', NULL, 3548, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2455, 1, 'BAKADARY SATAO ', NULL, 3549, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2456, 1, 'DEMBA TANGORA ', NULL, 3550, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2457, 1, 'UOSMANE KANAKOMO', NULL, 3551, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2458, 1, 'DIARY DIENTA ', NULL, 3552, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2459, 1, 'SIDY COULYBALY ', NULL, 3553, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2460, 1, 'SAMAKE YAYA ', NULL, 3554, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2461, 1, 'AMADOU NADIAN', NULL, 3555, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2462, 1, 'NOUHOU TAMATA', NULL, 3556, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2463, 1, 'YOUCOUBA BARRY', NULL, 3557, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2464, 1, 'MAMOUTOU DIENTA', NULL, 3558, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2465, 1, 'SIDI SANGAF�', NULL, 3559, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2466, 1, 'KALIFA TRAOR�', NULL, 3560, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2467, 1, 'SIDI  SANGAFE', NULL, 3561, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2468, 1, 'ALI SANGAFE', NULL, 3562, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2469, 1, 'TEBABA  TANAPO', NULL, 3563, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2470, 1, 'TEBEBA TANAPO', NULL, 3564, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2471, 1, 'MAM MINMANTAO', NULL, 3565, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2472, 1, 'ALI DIENTA', NULL, 3566, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2473, 1, 'SIDIKI MINMABTAO', NULL, 3567, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2474, 1, 'BOUKADARI DOUMANGOUROU', NULL, 3568, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2475, 1, 'YOUCOUBA KARABANA', NULL, 3569, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2476, 1, 'KAROTA NGARBO', NULL, 3570, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2477, 1, 'NGARABA KAROTA', NULL, 3571, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2478, 1, 'SAMBA SARR', NULL, 3572, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2479, 1, 'BOKADARY DIAKITE', NULL, 3573, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2480, 1, 'SOLOMANE MINANTA', NULL, 3574, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2481, 1, 'MAMA TIMBA', NULL, 3575, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2482, 1, 'MOUSSA MINMANTAO', NULL, 3576, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2483, 1, 'BOKADARY COULIBALY', NULL, 3577, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2484, 1, 'YOUSSOUPH KOMOU', NULL, 3578, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2485, 1, 'HAMA  COULIBALY', NULL, 3579, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2486, 1, 'BAIDY SIDIBE', NULL, 3580, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2487, 1, 'MASTAN TININTAO', NULL, 3581, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2488, 1, 'YOUUSOUPH KOMOU', NULL, 3582, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2489, 1, 'NOUHOUM TOMOTA', NULL, 3584, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2490, 1, 'SIDILI MINMANTAO', NULL, 3585, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2491, 1, 'MAMADOU DIENTA', NULL, 3586, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2492, 1, 'AMAMDOU DAOU', NULL, 3587, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2493, 1, 'BAKADARI SATAO', NULL, 3588, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2494, 1, 'TEBAB TANAPO', NULL, 3589, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2495, 1, 'BABA TIKAMBO', NULL, 3590, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2496, 2, 'MAMADI SERETA', NULL, 3591, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2497, 1, 'ADAMA TIKAMBO', NULL, 3592, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2498, 1, 'MAMADOU SIRETA', NULL, 3593, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2499, 1, 'MADI DJIRE', NULL, 3594, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2500, 1, 'ALMAMY SECRE', NULL, 3595, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2501, 1, 'NOUHOU NADIA', NULL, 3596, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2502, 1, 'LALA TRAORE', NULL, 3597, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2503, 1, 'BOUKADAU KEITA', NULL, 3598, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2504, 2, 'MAMA PAKO', NULL, 3599, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2505, 1, 'YAHI SINAYOKO', NULL, 3600, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2506, 1, 'MAMOUTOU SINAYOKO', NULL, 3601, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2507, 1, 'CHEIK OUMAR KEITA', NULL, 3602, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2508, 1, 'KAOUDO GUINDO', NULL, 3603, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2509, 1, 'MAMADOU KANTAO DIANGO', NULL, 3604, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2510, 1, 'BOKARY SAPANA', NULL, 3605, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2511, 1, 'BABADICKO', NULL, 3606, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2512, 1, 'KHALIFA TRAORE', NULL, 3607, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2513, 1, 'MAMATIMBO', NULL, 3608, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2514, 1, 'CHEICK MAHI KARABANA', NULL, 3610, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2515, 1, 'Y-KARABANA', 'Y-KARABANA', 3611, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2516, 1, 'SEKOU B-KEITA', 'SEKOU B-KEITA', 3612, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2517, 1, 'OUMAR KARABANA', 'OUMAR KARABANA', 3613, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2518, NULL, 'NFA A-KANAKOMO', 'NFA A-KANAKOMO', 3614, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2519, 1, 'LASSANA KOMOTA', 'LASSANA KOMOTA', 3615, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2520, NULL, 'OUMAR KONTAO', 'OUMAR KONTAO', 3616, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2521, NULL, 'MADOU KANTA', 'SOUMAILA KANTA', 3617, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2522, 1, 'SURAGATA KANTA', 'SURAGATA KANTA', 3618, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2523, NULL, 'MAMA KAMPO', 'MAMA KAMPO', 3619, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2524, NULL, 'B-KARABENTA', 'B-KARABENTA', 3620, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2525, 1, 'DIADIE KOUNTA', 'DIADIE KOUNTA', 3621, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2526, 1, 'Z-KARABENTA', 'Z-KARABENTA', 3622, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2527, NULL, 'YAYA TIENTA', 'SOUMANA TIENTA', 3623, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2528, NULL, 'LASSINE NAPHO', 'LASSINE NAPHO', 3624, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2529, NULL, 'LASSINE NAPO', 'SOUMANA TIENTA', 3625, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2530, 1, 'SOUMANA TIENTA', 'SOUMANA TIENTA', 3626, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2531, NULL, 'L-SINEYOGO', 'L-SINEYOGO', 3627, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2532, 1, 'LASSINE TIENTA', 'LASSINE TIENTA', 3628, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2533, 1, 'MAMADOU MAINTA', 'MAMADOU MAINTA', 3629, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2534, NULL, 'MAMA NAPO', 'MAMA NAPO', 3630, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2535, 1, 'SORY KONE KEO', 'SORY KONE KEO', 3631, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2536, NULL, 'L-KANAKOMO', 'NFA A-KANAKOMO', 3632, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2537, NULL, 'OUMAR KONTAO', 'OUMAR KONTA', 3633, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2538, NULL, 'L-KANAKOMO', 'L-KANAKOMO', 3634, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2539, NULL, 'A-KARABANA', 'Y-KARABANA', 3635, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2540, NULL, 'S-KARABANA', 'OUMAR KARABANA', 3636, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2541, NULL, 'WARA TIENTA', 'WARA TIENTA', 3637, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2542, NULL, 'S-KARABANA', 'OUMAR', 3638, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2543, NULL, 'S-COULIBALY', 'S-COULIBALY', 3639, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2544, 1, 'MOUSSA DIENTA', 'MOUSSA DIENTA', 3640, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2545, NULL, 'YACOUBA BARRY', 'YACOUBA BARRY', 3641, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2546, 2, 'OUMAR TRAORE', 'OUMAR TRAORE', 3642, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2547, 1, 'HAMADOU BARRY', 'HAMADOU BARRY', 3643, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2548, NULL, 'NKA NDIENTA', 'MOUSSA DIENTA', 3644, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2549, 1, 'M-CHIAWATA', 'M-CHIAWATA', 3645, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2550, 1, 'ALMAMY TIENTA', 'ALMAMY TIENTA', 3646, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2551, NULL, 'H-CHIAWATA', 'H-CHIAWATA', 3647, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2552, 1, 'ISSIAKA TRAORE', 'ISSIAKA TRAORE', 3648, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2553, NULL, 'NKA DIENTA', 'MOUSSA DIENTA', 3649, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2554, NULL, 'OUMAROU TRAORE', 'OUMAROU TRAORE', 3650, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2555, NULL, 'YACOUBA BARRY', 'HAMADOU BARRY', 3651, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2556, NULL, 'FARI KOU TANAPO', 'FARI KOU TANAPO', 3652, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2557, 1, 'LASSINE FOFANA', 'LASSINE FOFANA', 3653, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2558, 1, 'DAOUDA SERETA', 'DAOUDA SERETA', 3654, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2559, 1, 'BOUBACAR SERETA', 'BOUBACAR SERETA', 3655, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2560, NULL, 'DAOUDA SERATA', 'DAOUDA SERETA', 3656, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2561, NULL, 'DAOUDA SERETA', 'SAOUDA SERETA', 3657, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2562, 1, 'AMADOU TAMBORA', 'AMADOU TAMBORA', 3658, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2563, 1, 'MAMADOU KONTAO', 'MAMADOU KONTAO', 3659, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2564, 1, 'ALMAMY TIENTAO', 'ALMAMY TIENTAO', 3660, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2565, 1, 'DAOUDA TRAORE', 'DAOUDA TRAORE', 3661, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2566, 1, 'BOUBACAR TRAORE', 'BOUBACAR TRAORE', 3662, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2567, 1, 'D-COULIBALY', 'D-COULIBALY', 3663, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2568, 1, 'B-TIENTAO', 'B-TIENTAO', 3664, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2569, 1, 'OUMAR KEITA', 'OUMAR KEITA', 3665, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2570, NULL, 'IBRAHIM BARRY', 'TIAMBAL BARRY', 3666, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2571, NULL, 'BOUBACAR MINTA', 'BOUBACAR MINTA', 3667, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2572, NULL, 'MAMA SAKOUMA', 'B-NIENTAO', 3668, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2573, 1, 'MOUSSA KONTA', 'MOUSSA KONTA', 3669, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2574, NULL, 'DRAMANE KONTA', 'B-MOUSSA KONTA', 3670, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2575, NULL, 'BOUBACAR MINTAO', 'A-MINTAO', 3671, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2576, NULL, 'HAMA SAKOUMA', 'B-NIENTAO', 3672, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2577, NULL, 'DRAMANE KONTA', 'BOUAKARI KONTA', 3673, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2578, NULL, 'BOUAKARY MINTAO', 'A-MINTAO', 3674, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2579, NULL, 'BOUAKARI MINTAO', 'A-MINTAO', 3675, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2580, 1, 'BOUAKAR MAIGA', 'BOUAKAR MAIGA', 3676, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2581, NULL, 'BOUAKARY MINTA', 'BOUAKARY MINTA', 3677, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2582, NULL, 'DRAMANE KONTA', 'DRAMANE KONTA', 3678, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2583, NULL, 'MAKAN DEMBELE', 'TIAMBAL BARRY', 3679, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2584, NULL, 'IBRAHIM BARRY', 'TIAMBA BARRY', 3680, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2585, NULL, 'BOUAKAR MINTAO', 'A-MINTAO', 3681, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2586, NULL, 'IBRAHIM BARRY', 'IBRAHIM BARRY', 3682, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2587, 1, 'SEKOU PAMATA', 'SEKOU PAMATA', 3683, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2588, 1, 'NOUH TOMOTA', 'NOUH TOMOTA', 3684, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2589, 1, 'DEMBA MAGNINTA', 'DEMBA MAGNINTA', 3685, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2590, 1, 'MAMA DIARRA', 'MAMA DIARRA', 3686, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2591, 1, 'MOUSSA KARAWATA', 'MOUSSA KARAWATA', 3687, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2592, 1, 'KAKA TIENTA', 'KAKA TIENTA', 3688, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2593, NULL, 'AMADOU DRAME', 'AMADOU DRAME', 3689, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2594, NULL, 'DEMBA MAIGNINTA', 'DEMBA MAIGNINTA', 3690, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2595, NULL, 'YACOUBA BOIRE', 'YACOUBA BOIRE', 3691, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2596, NULL, 'DAOUDA PLEA', 'DOUDA PLEA', 3692, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2597, NULL, 'IBRAHIM TRAORE', 'IBRAHIM TRAORE', 3693, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2598, 1, 'OUMAR TIMBO', 'OUMAR TIMBO', 3694, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2599, 1, 'TIMBABA TANAPO', 'TIMBABA TANAPO', 3695, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2600, NULL, 'KONO KARABENTA', 'KONO KARABENTA', 3696, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2601, NULL, 'OUMAR TAMBOURA', 'OUMAR TAMBOURA', 3697, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2602, NULL, 'B-SIATAO', 'B-SIATAO', 3698, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2603, 1, 'KONO KARABINTA', 'KONO KARABINTA', 3699, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2604, NULL, 'OUMAR TAMBOURA', 'AFFEL TAMBOURA', 3700, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2605, NULL, 'KONA KARABINTA', 'KONO KARABINTA', 3701, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2606, 1, 'HAROUNA KEITA', 'HAROUNA KEITA', 3702, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2607, 1, 'BOUAKAR NADIO', 'BOUAKAR NADIO', 3703, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2608, 2, 'O-KANAKOMO', 'O-KANAKOMO', 3704, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2609, 1, 'ALOU KARONTA', 'ALOU KARONTA', 3705, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2610, NULL, 'Y-MAGNENTAO', 'Y-MAGNENTAO', 3706, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2611, NULL, 'O-KANAKOMO', 'H-KANAKOMO', 3707, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2612, NULL, 'Y-MAGNINTAO', 'Y-MAGNINTAO', 3708, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2613, NULL, 'BOUAKAR KEITA', 'HAROUNA KEITA', 3709, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2614, NULL, 'BAKARY KEITA', 'HAROUNA KEITA', 3710, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2615, NULL, 'TIDIANI KEITA', 'TIDIANI KEITA', 3711, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2616, NULL, 'BAKARY TRAORE', 'BAKARY TRAORE', 3712, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2617, NULL, 'BOUAKAR KEITA', 'BOUAKAR KEITA', 3713, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2618, NULL, 'BAKARI KEITA', 'HAROUNA KEITA', 3714, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2619, 1, 'BOUAKARI TRAORE', 'BOUAKARI TRAORE', 3715, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2620, NULL, 'BAKARY KEITA', 'BAKARY KEITA', 3716, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2621, NULL, 'BAKARI KEITA', 'BAKARI KEITA', 3717, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2622, NULL, 'SALIF KOBILA', 'O-KANAKOMO', 3718, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2623, NULL, 'SOLO KOITA', 'SOLO KOITA', 3719, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2624, NULL, 'Y-MAGNENTA', 'Y-MAGNENTA', 3720, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2625, NULL, 'L-SALAMANTA', 'L-SALAMANTA', 3721, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2626, NULL, 'KOMBA MAGNENTA', 'Y-MAGNENTA', 3722, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2627, NULL, 'TIDIANI KOITA', 'TIDIANI KOITA', 3723, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2628, NULL, 'MAMA KANTAO', 'MAMA KANTAO', 3724, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2629, 1, 'KAKA FAMANTA', 'KAKA FAMANTA', 3725, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2630, 1, 'LASSINE FAMANTA', 'LASSINE FAMANTA', 3726, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2631, 1, 'YOUSSOUF KOMOU', 'YOUSSOUF KOMOU', 3727, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2632, 1, 'H-MAGNANTAO', 'H-MAGNANTAO', 3728, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2633, 1, 'MARE SININTA', 'MARE SININTA', 3729, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2634, 1, 'MAMA KONTAO', 'MAMA KONTAO', 3730, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2635, NULL, 'H-MAGNENTA', 'H-MAGNENTA', 3731, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2636, NULL, 'YOUSSOUF KAMOU', 'YOUSSOUF KAMOU', 3732, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2637, NULL, 'H-MAGNANTA', 'H-MAGNANTA', 3733, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2638, NULL, 'MARE SININTA', 'MARE SININITA', 3734, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2639, NULL, 'MARE SININTA', 'MARE SNINTA', 3735, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2640, NULL, 'BAKARY DRAME', 'MAMADOU DRAME', 3736, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2641, 1, 'MAMADOU DRAME', 'MAMADOU DRAME', 3737, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2642, 1, 'KIMBA YONOU', 'KIMBA YONOU', 3738, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2643, 1, 'K-COULIBALY', 'K-COULIBALY', 3739, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2644, 1, 'LADJI KANTA', 'LADJI KANTA', 3740, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2645, 1, 'A-YATTARA', 'A-YATTARA', 3741, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2646, 1, 'ZOUMANA DRAME', 'ZOUMANA DRAME', 3742, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2647, NULL, 'DEMBA MINTA', 'DEMBA MINTA', 3743, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2648, 1, 'BABA SIMPANA', 'BABA SIMPANA', 3744, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2649, 1, 'INAKA KANTA', 'INAKA KANTA', 3745, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2650, NULL, 'INAKA KANTA', 'ANAKA KANTA', 3746, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2651, NULL, 'MAMADOU PAMANTA', 'ADOU PAMANTA', 3747, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2652, 1, 'I-TOUNKARA', 'I-TOUNKARA', 3748, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2653, 1, 'ALMAMI HAIDARA', 'ALMAMI HAIDARA', 3749, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2654, 1, 'ADOU PAMATA', 'ADOU PAMATA', 3750, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2655, NULL, 'S-COULIBALY', 'K-COULIBALY', 3751, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2656, NULL, 'OUMAR TOUNAKARA', 'I-TOUNKARA', 3752, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2657, NULL, 'MAMADOU PAMATA', 'ADOU PAMATA', 3753, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2658, 1, 'BOCAR SERETA', 'BOCAR SERETA', 3754, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2659, NULL, 'OUMAR TOUNKARA', 'I-TOUNKARA', 3755, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2660, NULL, 'OUMAR TOUNKARA', 'OUMAR TOUNKARA', 3756, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2661, NULL, 'MAMADOU PAMATA', 'MAMADOU PAMATA', 3757, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2662, NULL, 'MAMA TOUNKARA', 'I-TOUNKARA', 3758, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2663, NULL, 'MOUSSA MINTA', 'KOMBA MINTAO', 3759, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2664, NULL, 'MAMADOU NADIO', 'LADJI DIENTA', 3760, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2665, NULL, 'MAMA DIENTA', 'BORIS NADIO', 3761, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2666, NULL, 'MOUSSA MINTA', 'BOUAKAR MINTA', 3762, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2667, NULL, 'NKA PAITA', 'MOUSSA DIENTA', 3763, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2668, NULL, 'LADJI DIENTA', 'ALMAMY TIENTA', 3764, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2669, NULL, 'BORIS NADIO', 'MOUSSA DIENTA', 3765, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2670, NULL, 'SALIF COULIBALY', 'S-COULIBALY', 3766, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2671, NULL, 'MOUSSA MINTA', 'MOUSSA MINTA', 3767, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2672, NULL, 'LAMINE', 'OUMAR TRAORE', 3768, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2673, NULL, 'MOUSSA MINTA', 'KOMBA MINTA', 3769, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2674, NULL, 'L-COULIBALY', 'L-COULIBALY', 3770, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2675, NULL, 'LAMINE FOFANA', 'OUMAR TRAORE', 3771, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2676, NULL, 'MOUSSA TERETA', 'FARIKOU TANAPO', 3772, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2677, 2, 'LAMINE FOFANA', 'LAMINE FOFANA', 3773, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2678, 1, 'MADY CISSE', 'MADY CISSE', 3774, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2679, NULL, 'B-NIOUMANTA', 'B-NIOUMANTA', 3775, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2680, NULL, 'L-KANAKOUMOU', 'N-A-KANAKOUMOU', 3776, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2681, NULL, 'TIDIANI KOMOTA', 'TIDIANI KOMOTA', 3777, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2682, NULL, 'MOLAYE TRAORE', 'MOLAYE TRAORE', 3778, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2683, NULL, 'AMADOU KONOTA', 'AMADOU KONOTA', 3779, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2684, 1, 'KADRY KONOTA', 'KADRY KONOTA', 3780, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2685, NULL, 'ADAMA KONOTA', 'ADAMA KONOTA', 3781, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2686, 1, 'GARBA', 'GARBA', 3782, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2687, NULL, 'N-A-KANAKOUMOU', 'N-A-KANAKOUMOU', 3783, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2688, NULL, 'SOULEYMANE', 'OUMAR KARABANA', 3784, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2689, NULL, 'MAMOUTOU TRAORE', 'AMADOU TRAORE', 3785, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2690, NULL, 'B-NIOUMINTA', 'B-NIOUMINTA', 3786, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2691, NULL, 'YACOUBA MOLAYE', 'SENI TRAORE', 3787, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2692, NULL, 'SEKOU B-KEITA', 'EKOU B-KEITA', 3788, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2693, NULL, 'SOULEYMANE', 'OUMAR KARANA', 3789, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2694, NULL, 'YACOUBA', 'SENI TRAORE', 3790, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2695, NULL, 'BREHIMA', 'S-KONOTA', 3791, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2696, NULL, 'LADJI KONOTA', 'LADJI KONOTA', 3792, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2697, NULL, 'DJIBRIL DIARRA', 'BOUBACAR DIARRA', 3793, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2698, NULL, 'ZOUMANA', 'AMADOU KONOTA', 3794, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2699, NULL, 'MAMOUTOU TRAORE', 'MAMOUTOU TRAORE', 3795, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2700, NULL, 'BASSIROU KONTA', 'HADY DIARRA', 3796, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2701, NULL, 'DJIBRIL DIARR', 'BOUBACAR DIARRA', 3797, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2702, NULL, 'MOUSSA TRAORE', 'MOUSSA TRAORE', 3798, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2703, NULL, 'Z-KARABANA', 'Z-KARABANA', 3799, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2704, NULL, 'BOUCADARI', 'B-KARABINTA', 3800, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2705, NULL, 'MAMADOU TROUPO', 'MAMA TROUPO', 3801, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2706, 1, 'ALLAYE KANTA', 'ALLAYE KANTA', 3802, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2707, NULL, 'SORY KONE KOE', 'SORY KONE KEO', 3803, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2708, 1, 'MOUSSA TIEOU', 'MOUSSA TIEOU', 3804, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2709, NULL, 'LASSINE SINEYO', 'LASSINE SINEYO', 3805, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2710, NULL, 'B-KARABINTA', 'B-KARABINTA', 3806, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2711, NULL, 'Z-KARABINTA', 'Z-KARABINTA', 3807, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2712, NULL, 'MAMA SAKOUMANA', 'B-NIENTAO', 3808, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2713, NULL, 'MAKAN DEMBELE', 'TIAMBA BARRY', 3809, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2714, 1, 'A-MINTAO', 'A-MINTAO', 3810, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2715, NULL, 'ABDOULAYE MINTA', 'ABDOULAYE MINTA', 3811, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2716, NULL, 'GAMADOU TIENTAO', 'ALMAMY TIENTAO', 3812, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2717, NULL, 'MADOU SIATAO', 'B-SIATAO', 3813, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2718, NULL, 'KONO', 'KONO KARABENTA', 3814, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2719, NULL, 'MADOU SIATAO', 'BOUKADARY SITAO', 3815, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2720, NULL, 'MOUSSA', 'B-SIATAO', 3816, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2721, NULL, 'S-TRAORE', 'S-TRAORE', 3817, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2722, NULL, 'DAOUDA PLEA', 'DAOUDA PLEA', 3818, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2723, NULL, 'MOUSSA KARAVATA', 'MOUSSA KARAVATA', 3819, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2724, 1, 'IBRAHIMA TRAORE', 'IBRAHIMA TRAORE', 3820, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2725, NULL, 'BOUREMA SACKO', 'BOUREMA SACKO', 3821, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2726, NULL, 'A-MAINTA', 'A-MAINTA', 3822, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2727, NULL, 'BOUAKARI KEITA', 'BOUAKARI KEITA', 3823, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2728, NULL, 'S-MAGNENTAO', 'Y-MAGNENTAO', 3824, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2729, NULL, 'SALIF KOBILA', 'S-KANAKOMO', 3825, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2730, NULL, 'BOUAKAR TRAORE', 'BOUAKAR TRAORE', 3826, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2731, NULL, 'BOUAKARI NADIO', 'BOUAKARI NADIO', 3827, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2732, NULL, 'O-MAGNENTA', 'Y-MAGNENTA', 3828, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2733, NULL, 'SEKOU FAMANTA', 'KOKO FAMANTA', 3829, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2734, NULL, 'MAHALADY DIARRA', 'MAHAMADY DIARRA', 3830, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2735, NULL, 'MAHMADOU DIARRA', 'MAHMADOU DIARRA', 3831, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2736, NULL, 'SEKOU FAMANTA', 'KAKA FAMANTA', 3832, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2737, NULL, 'SEKOU FAMANTA', 'SEKOU FAMANTA', 3833, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2738, NULL, 'YOUSSOUF KOMOU', 'YOUSSOU KOMOU', 3834, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2739, NULL, 'MORY MAMA', 'BABA SIMPANA', 3835, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2740, NULL, 'LADJI', 'LADJI KANTA', 3836, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2741, NULL, 'MAMA', 'MAMADOU DRAME', 3837, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2742, NULL, 'NKA', 'MAMADOU DRAME', 3838, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2743, NULL, 'SOLO KONIMBA', 'SOLO KONIMBA', 3839, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2744, NULL, 'BAKARY', 'MAMADOU DRAME', 3840, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2745, NULL, 'KIMBA', 'KIMBA YONOU', 3841, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2746, NULL, 'KONIMBA', 'KONIMBA', 3842, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2747, NULL, 'MORY SIMPANA', 'BABA SIMPANA', 3843, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2748, NULL, 'MORY', 'BABA SIMPANA', 3844, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2749, NULL, 'INAKA', 'INAKA KANTA', 3845, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2750, NULL, 'ZOUMANA', 'ZOUMANA DRAME', 3846, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2751, NULL, 'ALMAMI HAIDARA', 'ALMALI HAIDARA', 3847, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2752, NULL, 'DRISSA TOUNKARA', 'I-TOUNKARA', 3848, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2753, NULL, 'MADOU PAMATA', 'ADOU PAMATA', 3849, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2754, NULL, 'MADOU PAMATA', 'MADOU PAMATA', 3850, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2755, NULL, 'MAMA KOANTA', 'ADOU KOANTA', 3851, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2756, NULL, 'A-NIOUMANTA', 'A-NIOUMANTA', 3852, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2757, NULL, 'OUMAR BARRY', 'OUMAR BARRY', 3853, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2758, NULL, 'ABDOULAYE', 'Y-KARABANA', 3854, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2759, NULL, 'LADJI', 'LADJI KONOTA', 3855, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2760, NULL, 'B-GNOUMANTA', 'S-KOMOTA', 3856, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2761, NULL, 'MAMOUTA', 'MAMOUTA DIARRA', 3857, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2762, NULL, 'YOUSSOUF', 'YACOUBA TRAORE', 3858, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2763, NULL, 'SOLO KARABAN', 'OUMAR KARABANA', 3859, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2764, NULL, 'OUMAR', 'OUMAR KARABANA', 3860, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2765, NULL, 'NFAH ADAMA', 'NFAH A-KANAKOMU', 3861, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2766, NULL, 'SEKOU BRAHIMA', 'SEKOU B-KEITA', 3862, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2767, NULL, 'YOUSSOUF BARINO', 'YACOUBA TRAORE', 3863, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2768, NULL, 'MODIBO', 'ADAMA KONOTA', 3864, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2769, NULL, 'MADY', 'MADY CISSE', 3865, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2770, NULL, 'LADDJI', 'LADJI KONOTA', 3866, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2771, NULL, 'YACOUBA', 'YACOUBA TRAORE', 3867, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2772, NULL, 'KADRY', 'KADRY KONOTA', 3868, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2773, NULL, 'BAYE', 'BOUBACAR DIARRA', 3869, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2774, NULL, 'SEKOU BRAHIMA', 'SEKOI B-KEITA', 3870, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2775, NULL, 'SOLO KARABANA', 'OUMAR KARABANA', 3871, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2776, NULL, 'LASSANA', 'NFAH A-KANAKOMU', 3872, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2777, NULL, 'SOLO', 'OUMAR KARABANA', 3873, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2778, 1, 'DRISSA KOANTA', 'DRISSA KOANTA', 3874, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2779, NULL, 'MAMA NABOMBO', 'MAMA TROUPA', 3875, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2780, NULL, 'MADOU KONTA', 'MADOU KONTA', 3876, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2781, NULL, 'MAMA TIENTA', 'SOUMANA TIENTA', 3877, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2782, NULL, 'MADOU NABOBO', 'MAMA TROUPO', 3878, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2783, NULL, 'O-MAGNANTA', 'Y-MAGNANTA', 3879, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2784, NULL, 'O-MAGNENTA', 'Y-MAGNANTA', 3880, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2785, NULL, 'LADDJI DIENTA', 'ALMAMY TIENTA', 3881, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2786, NULL, 'LAMINE KANE', 'OUMAR TRAORE', 3882, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2787, NULL, 'L-COULIBALY', 'S-COULIBALY', 3883, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2788, NULL, 'NKA PAITO', 'BORIS NADIO', 3884, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2789, NULL, 'KONIBA CHIAWATA', 'M-CHIAWATA', 3885, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2790, NULL, 'NKA PAITO', 'BORI PAITO', 3886, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2791, NULL, 'L-COULIBALY', 'SEDOU COULIBALY', 3887, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2792, NULL, 'LADJI DJENTA', 'ALMAMY TIENTA', 3888, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2793, NULL, 'MOUSSA MINTAO', 'BOUAKARI MINTAO', 3889, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2794, NULL, 'MOUSSA MINTAO', 'BOUAKRI MINTAO', 3890, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2795, NULL, 'LAMINE TRAORE', 'OUMAR TRAORE', 3891, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2796, NULL, 'SORY FOFANA', 'HAMADOUN BARRY', 3892, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2797, NULL, 'KASSIM CHIAWATA', 'M-CHIAWATA', 3893, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2798, NULL, 'MAMADI BARRY', 'HAMADOU BARRY', 3894, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2799, NULL, 'MOUSSA TIENTAO', 'FARIKOU TIENTAO', 3895, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2800, NULL, 'MOUSSA MINTAO', 'MOUSSA MINTAO', 3896, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2801, NULL, 'BOUAKARI MAIGA', 'BOUAKARI MAIGA', 3897, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2802, NULL, 'HOUSSEYNI BARRY', 'IBRAHIM BARRY', 3898, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2803, NULL, 'MOUSSA MINTAO', 'A-MINTAO', 3899, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2804, NULL, 'BOUAKARI MAIGA', 'BOUAKARY MAIGA', 3900, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2805, NULL, 'MAKAN DEMBELE', 'TIAMBAL DEMBELE', 3901, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2806, 1, 'SEKOU KANAKOMO', 'SEKOU KANAKOMO', 3902, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2807, NULL, 'DAOUDA SERETA', 'DOUDA SERETA', 3903, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2808, NULL, 'LASSINE FONANA', 'LASSINE FOFANA', 3904, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2809, NULL, 'SEKOU KAKAKOMO', 'SEKOU KANAKOMO', 3905, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2810, NULL, 'BOUBACAR TIENTA', 'BOUBACAR TIENTA', 3906, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2811, NULL, 'BOUBAKAR TRAORE', 'BOUBACAR TRAORE', 3907, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2812, 1, 'ZOUMANA FAMANTA', 'ZOUMANA FAMANTA', 3908, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2813, NULL, 'ZOUMANA TRAORE', 'ZOUMANA TRAORE', 3909, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2814, NULL, 'MODIBO KEITA', 'ADAMA KONOTA', 3910, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2815, NULL, 'AMADOU', 'AMADOU KONOTA', 3911, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2816, NULL, 'MAMOUTOU', 'MAMOUTOU DIARRA', 3912, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2817, NULL, 'NFAH ADAMA', 'NFAH ADAMA', 3913, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2818, NULL, 'KADRY', 'KADRY KONTA', 3914, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2819, NULL, 'AMDOU', 'AMADOU KONOTA', 3915, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2820, NULL, 'SOLO', 'AMADOU KONOTA', 3916, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2821, NULL, 'B-GNOUMINTA', 'S-KONOTA', 3917, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2822, NULL, 'KADJI', 'LADJI KONOTA', 3918, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2823, NULL, 'ISSA TRAORE', 'ISSA TRAORE', 3919, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2824, NULL, 'MOHAMED', 'MOHAMED TRAORE', 3920, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2825, NULL, 'ISSA TRAORE', 'SENI TRAORE', 3921, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2826, NULL, 'BOUA', 'MADY CISSE', 3922, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2827, NULL, 'SOLO', 'OUMAR KARABAN', 3923, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2828, NULL, 'BOUKADARY', 'B-SIATAO', 3924, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2829, NULL, 'TIMBABA', 'TIMBABA TANAPO', 3925, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2830, 1, 'ALI KONTA', 'ALI KONTA', 3926, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2831, NULL, 'BOUKADARY SIATA', 'BOUKADARY SIATA', 3927, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2832, NULL, 'ALI KANTA', 'ALI KANTA', 3928, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2833, NULL, 'BOUKADARY SATAO', 'BOUKADARY SATAO', 3929, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2834, NULL, 'SORY KONEKEO', 'SORY KONEKEO', 3930, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2835, NULL, 'MAMADOU MINTA', 'MAMADOU MINTA', 3931, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2836, NULL, 'LASSINE NABO', 'SOUMANA TIENTA', 3932, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2837, NULL, 'MAMA NABOBO', 'MAMA TROUPO', 3933, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2838, 2, 'MAMA TIENTA', 'MAMA TIENTA', 3934, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2839, NULL, 'ADAMA KOUNTA', 'DIADIE KOUNTA', 3935, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2840, NULL, 'ALLAYE KANTA', 'ALLAUYE KANTA', 3936, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2841, NULL, 'MADOU KANTA', 'MADOU KANTA', 3937, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2842, NULL, 'ADAMA KOUNTA', 'ADAMA KOUNTA', 3938, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2843, NULL, 'WARA TIENTA', 'KAKA TIENTA', 3939, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2844, NULL, 'DEMBA KOANTA', 'NOUH TOMOTA', 3940, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2845, NULL, 'DEMBA MAGNENTA', 'DEMBA MAGNENTA', 3941, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2846, NULL, 'DEMBA MAIGNENTA', 'DEMBA MAIGNENTA', 3942, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2847, NULL, 'BOCAR TIENTA', 'BOCAR TIENTA', 3943, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2848, 1, 'IBRAHIM SOW', 'IBRAHIM SOW', 3944, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2849, 1, 'KALIFA KOMOU', 'KALIFA KOMOU', 3945, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2850, 2, 'BOUAKARI KONTA', 'BOUAKARI KONTA', 3946, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2851, 1, 'BOUKARI NIENTAO', 'BOUKARI NIENTAO', 3947, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2852, 1, 'TIAMBAL BARRY', 'TIAMBAL BARRY', 3948, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2853, 1, 'MAMA SAKOUMANA', 'MAMA SAKOUMANA', 3949, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2854, 1, 'LADJI M-KOUANTA', 'LADJI M-KOUANTA', 3950, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2855, 1, 'S-MAGNANTAO', 'S-MAGNANTAO', 3951, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2856, 1, 'MAMADOU DIARRA', 'MAMADOU DIARRA', 3952, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2857, 1, 'SOUMAILA KANTA', 'SOUMAILA KANTA', 3953, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2858, 1, 'NFAH A-KARABANA', 'NFAH A-KARABANA', 3954, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2859, 1, 'ADAMA KOMOTA', 'ADAMA KOMOTA', 3955, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2860, 1, 'AMADOU KOMOTA', 'AMADOU KOMOTA', 3956, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2861, 1, 'YACUBA MAGNENTA', 'YACUBA MAGNENTA', 3957, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2862, 1, 'TIDIANE KOITA', 'TIDIANE KOITA', 3958, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2863, 1, 'MAMADI SINENTA', 'MAMADI SINENTA', 3959, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2864, 1, 'MOUSSA TIKAMBO', 'MOUSSA TIKAMBO', 3960, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2865, 1, 'SEYDOU CULIBALY', 'SEYDOU CULIBALY', 3961, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2866, 1, 'NKA PAITO', 'NKA PAITO', 3962, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2867, 1, 'BORIS NADIO', 'BORIS NADIO', 3963, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2868, 1, 'KADARA TERETAO', 'KADARA TERETAO', 3964, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2869, 1, 'FARIKOU TANAPO', 'FARIKOU TANAPO', 3965, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2870, 1, 'BUKADARY SIATAO', 'BUKADARY SIATAO', 3966, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2871, 1, 'AFFEL TAMBOURA', 'AFFEL TAMBOURA', 3967, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2872, NULL, 'SIDIKI DABITA', 'MAMADOUN DABITA', 3968, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2873, NULL, 'MAMA KEBE', 'LADJI SEKERE', 3969, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2874, 2, 'KAKAYE MAGNANTA', 'KAKAYE MAGNANTA', 3970, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2875, NULL, 'BOUREIMA CISSE', 'MAMADOU MAGNANT', 3971, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2876, NULL, 'MOUSSA MAGNANTA', 'SOUMAILA NACIRE', 3972, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2877, NULL, 'HAMIDOU MENINTA', 'HAMIDOU MENINTA', 3973, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2878, NULL, 'MOUSSA MAGNINTA', 'SOUMAILA NACIRE', 3974, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2879, NULL, 'SIDIKI DABITA', 'MAMADOU DABITA', 3975, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2880, 1, 'LADJI SEKERE', 'LADJI SEKERE', 3976, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2881, NULL, 'SEKOU TIENTA', 'MOUSSA DOKOUNOU', 3977, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2882, 1, 'HADY KONTA', 'HADY KONTA', 3978, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2883, NULL, 'A-TROUPO', 'AMADOU TROUPO', 3979, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2884, NULL, 'SINALY KOBILA', 'MAMADI KOBILA', 3980, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2885, NULL, 'ADAMA KONTA', 'ADAMA KONTA', 3981, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2886, NULL, 'SOUNGALO DIARRA', 'SOUNGALO DIARRA', 3982, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2887, NULL, 'IBRAHIM DIENTA', 'MAMADOU TIENTA', 3983, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2888, NULL, 'BOUREIMA TROUPO', 'BOUREIMA TROUPO', 3984, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2889, NULL, 'MAMADOU NABO', 'KONGA NABO', 3985, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2890, NULL, 'BABAYE TROUPO', 'MOUSSA DOKOUNOU', 3986, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2891, NULL, 'KAH KOBILA', 'OUMAROU KOBILA', 3987, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2892, 1, 'MAMA SACKO', 'MAMA SACKO', 3988, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2893, NULL, 'OUMAROU KEITA', 'OUMAROU KEITA', 3989, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2894, NULL, 'NOUHOU KOITA', 'LASSINA KOITA', 3990, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2895, NULL, 'HADY DOKOUNOU', 'HADY DOKOUNOU', 3991, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2896, NULL, 'BE SARRO', 'HADA SARRO', 3992, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2897, NULL, 'BOUREIMA SACKO', 'BOUREIMA SACKO', 3993, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2898, NULL, 'KAH KOBILA', 'OUMAROU KOBBILA', 3994, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2899, NULL, 'OUMAROU TIKAMBA', 'OUMAROU TIKAMBA', 3995, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2900, NULL, 'FADAMA DIARRA', 'MOUSSA DIARRA', 3996, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2901, NULL, 'BE KOBILA', 'OUMAROU KOBILA', 3997, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2902, NULL, 'SIDY BAREMA', 'NOUHOU KONTA', 3998, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2903, NULL, 'OUSMANE TOURE', 'OUSMANE TOURE', 3999, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2904, NULL, 'LACENI TEMATA', 'LACENI TEMATA', 4000, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2905, NULL, 'BAKAYE SACKO', 'BAKAYE SACKO', 4001, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2906, NULL, 'ALIDJI TOURE', 'ALIDJI TOURE', 4002, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2907, NULL, 'AMADOU KOBILA', 'ABUBACAR KOBILA', 4003, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2908, NULL, 'L-MAGNANTAO', 'L-MAGNANTAO', 4004, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2909, NULL, 'AMADOU FOFANA', 'AMADOU FOFANA', 4005, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2910, NULL, 'M-DOUMAKORO', 'I-DOUMAKORO', 4006, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2911, NULL, 'LASSINE MOGOTAO', 'LASSINE MOGOTAO', 4007, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2912, NULL, 'ELHADJI KONE', 'ELHADJI KONE', 4008, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2913, NULL, 'PATE DICKO', 'PATE DICKO', 4009, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2914, NULL, 'B-SINAYOGO', 'B-SINAYOGO', 4010, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2915, NULL, 'BOCAR SINAYOGO', 'BOCAR SINAYOGO', 4011, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2916, 1, 'DEDE TRAORE', 'DEDE TRAORE', 4012, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2917, 1, 'TAHIROU KANTA', 'TAHIROU KANTA', 4013, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2918, 1, 'MOULAYE KANTA', 'MOULAYE KANTA', 4014, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2919, NULL, 'SEKOU COURANSO', 'SEKOU COURANSO', 4015, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2920, NULL, 'ALI LABITA', 'ALI LABITA', 4016, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2921, NULL, 'ALI CHABATA', 'ALI CHABATA', 4017, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2922, NULL, 'BASIDIKI FOFANA', 'BASIDIKI FOFANA', 4018, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2923, NULL, 'SOLO MAGER', 'MOUSSA MAGER', 4019, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2924, NULL, 'BOKARY KONTA', 'BOKARY KONTA', 4020, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2925, 2, 'MAMA KONTA', 'MAMA KONTA', 4021, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2926, 1, 'MAMADI KONTA', 'MAMADI KONTA', 4022, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2927, NULL, 'TIHAMOU SACKO', 'TIHAMOU SACKO', 4023, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2928, NULL, 'ADAMA TRAORE', 'ADAMA TRAORE', 4024, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2929, NULL, 'DJIBRIL CHABATA', 'DJIBRIL CHABATA', 4025, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2930, NULL, 'KASSOUM TRAORE', 'MOUSSA KONTA', 4026, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2931, NULL, 'SEKOU KONTA', 'SEKOU A-KONTA2', 4027, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2932, NULL, 'K-CHABATA', 'OUSMANE CHABATA', 4028, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2933, NULL, 'OUMAR KANTA', 'MOUSSA KANTA', 4029, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2934, NULL, 'MAMA KOMOU', 'MAMA KOMOU', 4030, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2935, NULL, 'A-TIENTA', 'A-TIENTA', 4031, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2936, NULL, 'BA KONTAO', 'BA KONTAO', 4032, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2937, NULL, 'B-KORGNON', 'B-KORGNON', 4033, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2938, NULL, 'A-THIENTA', 'A-THIENTA', 4034, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2939, NULL, 'LADJI THIENTA', 'LADJI THIENTA', 4035, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2940, NULL, 'MAMA THIENTA', 'MAMA THIENTA', 4036, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2941, NULL, 'B-KELINTA', 'B-KELINTA', 4037, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2942, NULL, 'SEKOU THIENTA', 'SEKOU THIENTA', 4038, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2943, NULL, 'AMADOU KANTA', 'AMADOU KANTA', 4039, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2944, NULL, 'BOCAR KARONTA', 'BOCAR KARONTA', 4040, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2945, NULL, 'S-MAIGA', 'S-MAIGA', 4041, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2946, NULL, 'M-SINAYOGO', 'M-SINAYOGO', 4042, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2947, NULL, 'ISSA PAGOU', 'ISSA PAGOU', 4043, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2948, NULL, 'BOUCADER KORGNO', 'BOUCADER KORGNO', 4044, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2949, 1, 'OUSMANE DIALLO', 'OUSMANE DIALLO', 4045, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2950, 2, 'HAMIDOU KOMOU', 'HAMIDOU KOMOU', 4046, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2951, 1, 'B-COULIBALY', 'B-COULIBALY', 4047, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2952, NULL, 'BAKARY SANGARE', 'BACARY SANGARE', 4048, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2953, 2, 'B-SANGAFE', 'B-SANGAFE', 4049, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2954, 1, 'MAMA KARABENTA', 'MAMA KARABENTA', 4050, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2955, 1, 'HADY TRAORE', 'HADY TRAORE', 4051, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2956, NULL, 'S-SANGAFE', 'B-SANGAFE', 4052, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2957, 1, 'SINALY SANGAFE', 'SINALY SANGAFE', 4053, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2958, NULL, 'LADJI NIENTA', 'LADJI NIENTA', 4054, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2959, NULL, 'B-SANGARE', 'B-SANGARE', 4055, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2960, NULL, 'ADAMA MAIGA', 'ADAMA MAIGA', 4056, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2961, NULL, 'S-TERETA', 'S-TERETA', 4057, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2962, NULL, 'MAMADI TOUNKARA', 'MAMADI TOUNKARA', 4058, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2963, 1, 'KAZON SACKO', 'KAZON SACKO', 4059, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2964, NULL, 'SINALY SEKERE', 'SINALY SEKERE', 4060, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2965, NULL, 'B-TANGARA', 'B-TANGARA', 4061, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2966, NULL, 'MAMADI DOUCOURE', 'MAMADI DOUCOURE', 4062, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2967, NULL, 'HAMADI TOUNKARA', 'HAMADI TOUNKARA', 4063, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2968, NULL, 'LASSINE TIKAMBO', 'S-TOUKAMBO', 4064, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2969, NULL, 'SAMBA MEMINTA', 'SAMBA MEMINTA', 4065, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2970, NULL, 'AMDJATA KONTA', 'AMDJATA KONTA', 4066, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2971, NULL, 'SALIA FOFANA', 'SALIA FOFANA', 4067, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2972, NULL, 'SIDI B-DONOGO', 'SIDI B-DONOGO', 4068, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2973, NULL, 'SAMBA MENINTA', 'HAMIDOU MENINTA', 4069, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2974, NULL, 'LASSINA TIKAMBO', 'S-TIKAMBO', 4070, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2975, NULL, 'LASSINE TOMOTA', 'LASSINE TOMOTA', 4071, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2976, NULL, 'OUSMANE TRAORE', 'OUSMANE TRAORE', 4072, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2977, NULL, 'MOHAMED YATTARA', 'MOHAMED YATTARA', 4073, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2978, 2, 'OUMAROU SACKO', 'OUMAROU SACKO', 4074, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2979, NULL, 'YOUNOUS KOUMARE', 'YOUNOUS KOUMARE', 4075, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2980, NULL, 'BOAUAKAR TRAORE', 'SOUMANA TRAORE', 4076, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2981, NULL, 'BOCAR FAMANTA', 'BOCAR FAMANTA', 4077, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2982, NULL, 'AMADOU MAIGA', 'AMADOU MAIGA', 4078, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2983, 2, 'IDRISSA WATTARA', 'IDRISSA WATTARA', 4079, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2984, 2, 'ABDOULAYE DICKO', 'ABDOULAYE DICKO', 4080, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2985, 2, 'OUSMANE KONTA', 'OUSMANE KONTA', 4081, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2986, NULL, 'MADOU TRAORE', 'MADOU TRAORE', 4082, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2987, NULL, 'SIDI DICKO', 'SIDI DICKO', 4083, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2988, NULL, 'MAHAMANE', 'MAHAMANE', 4084, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2989, NULL, 'MAHAMANE YATARA', 'MAHAMANE YATARA', 4085, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2990, 2, 'MAHAMANE MAIGA', 'MAHAMANE MAIGA', 4086, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2991, NULL, 'MAHAMANE DICKO', 'MAHAMANE DICKO', 4087, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2992, NULL, 'SEKOU DJAN KONE', 'SEKOU DJAN KONE', 4088, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2993, NULL, 'KAN BOUREMA', 'KAN BOURAMA', 4089, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2994, NULL, 'B-DABITAO', 'B-DABITAO', 4090, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2995, NULL, 'KAKAYE', 'KAKAYE', 4091, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2996, NULL, 'KAN S-DABITAO', 'KAN S-DABITAO', 4092, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2997, NULL, 'KA-DABITAO', 'KA-DABITAO', 4093, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (2998, 2, 'SEKOU KONE', 'SEKOU KONE', 4094, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (2999, NULL, 'SEKOU SININTAO', 'SEKOU SININTAO', 4095, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3000, NULL, 'KAN BOURAMA', 'KAN BOURAMA', 4096, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3001, NULL, 'KAKAYE NIENTAO', 'KAKAYE NIENTAO', 4097, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3002, NULL, 'K-MIANTAO', 'K-MIANTAO', 4098, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3003, NULL, 'SEKOU DJAN', 'SEKOU DJAN', 4099, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3004, NULL, 'SEKOU SININTA', 'SEKOU SININTA', 4100, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3005, 2, 'OUMAR DABITAO', 'OUMAR DABITAO', 4101, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3006, NULL, 'KABO KONTAO', 'KABO KONTAO', 4102, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3007, NULL, 'MOHAMED FAMANTA', 'MOHAMED FAMANTA', 4103, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3008, NULL, 'KASSIM KOMINA', 'KASSIL KOMINA', 4104, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3009, 1, 'D-NIOBOINA', 'D-NIOBOINA', 4105, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3010, 2, 'AMADOU TRAORE', 'AMADOU TRAORE', 4106, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3011, 1, 'KASSIM KOMINA', 'KASSIM KOMINA', 4107, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3012, 1, 'MAMA SAMPANA', 'MAMA SAMPANA', 4108, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3013, 1, 'S-SAMPANA', 'S-SAMPANA', 4109, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3014, NULL, 'KAKA TROUPO', 'MOUSSA DOKONOU', 4110, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3015, NULL, 'HAMADOU SAMPANA', 'HAMADOU SAMPANA', 4111, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3016, NULL, 'KASSIM KONIBA', 'KASSIM KONIBA', 4112, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3017, NULL, 'A-TROUPO', 'A-TROUPO', 4113, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3018, NULL, 'KAKA TRAORE', 'MOUSSA DOGONOU', 4114, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3019, 1, 'AMADOU TROUPO', 'AMADOU TROUPO', 4115, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3020, NULL, 'DRISSA KONTA', 'DRISSA KONTA', 4116, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3021, NULL, 'MACON KONTA', 'ALI KISSE', 4117, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3022, NULL, 'NKA MINTA', 'KOKO MINTA', 4118, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3023, NULL, 'BOUREIMA CISSE', 'BOUREIMA CISSE', 4119, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3024, 1, 'KOKO MINTA', 'KOKO MINTA', 4120, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3025, NULL, 'MAMADOU NIENTAO', 'MAMADOU NIENTAO', 4121, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3026, NULL, 'MAMA KEBE', 'LADJI KEBE', 4122, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3027, NULL, 'MAMA TANAPO', 'SOUMAILA NACIRE', 4123, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3028, NULL, 'SIDIKI DABITAO', 'MAMADOU DABITAO', 4124, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3029, NULL, 'LADJI KEBE', 'LADJI KEBE', 4125, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3030, 1, 'MAMA NACIRE', 'MAMA NACIRE', 4126, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3031, NULL, 'MAMA KEBE', 'MAMA KEBE', 4127, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3032, 1, 'SOUMAILA NACIRE', 'SOUMAILA NACIRE', 4128, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3033, NULL, 'F-SOYATA', 'BROULAYE KONTA', 4129, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3034, 2, 'M-MAGNANTA', 'M-MAGNANTA', 4130, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3035, 1, 'BASINALY KONTA', 'BASINALY KONTA', 4131, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3036, 1, 'BOUBACAR KOBILA', 'BOUBACAR KOBILA', 4132, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3037, 1, 'KAMA KONTAO', 'KAMA KONTAO', 4133, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3038, 1, 'OUSMANE KOITA', 'OUSMANE KOITA', 4134, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3039, 1, 'BOUBACAR KOITA', 'BOUBACAR KOITA', 4135, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3040, 1, 'AMADOU TIENTA', 'AMADOU TIENTA', 4136, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3041, NULL, 'A-DABITAO', 'A-DABITAO', 4137, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3042, NULL, 'SAMBA KOMOU', 'SIDIKI KOMOU', 4138, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3043, 1, 'SIDIKI KOMOU', 'SIDIKI KOMOU', 4139, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3044, NULL, 'BOUBACAR KONTA', 'BASINALY KONTA', 4140, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3045, NULL, 'LASSANA KONTA', 'BASINALY KONTA', 4141, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3046, NULL, 'KALILOU DRAME', 'KALILOU DRAME', 4142, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3047, NULL, 'SEKOU NAPO', 'SEKOU NAPO', 4143, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3048, NULL, 'MARIFOU TRAORE', 'MARIFOU TRAORE', 4144, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3049, 1, 'AMADOU NASSIRE', 'AMADOU NASSIRE', 4145, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3050, NULL, 'MAMADOU KANTA', 'MAMADOU KANTA', 4146, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3051, 2, 'BOCAR DJENEPO', 'BOCAR DJENEPO', 4147, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3052, NULL, 'SEKOU DIABI', 'SEKOU DIABI', 4148, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3053, NULL, 'MAMA KOMINA', 'MAMA KOMINA', 4149, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3054, NULL, 'BABA KARABENTA', 'BABA KARABENTA', 4150, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3055, NULL, 'B-TIENTA', 'B-TIENTA', 4151, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3056, NULL, 'NGADA KORGNON', 'NGADA KORGNON', 4152, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3057, NULL, 'K-KANAKOMO', 'K-KANAKOMO', 4153, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3058, NULL, 'BABA NAMAKIRI', 'BABA NAMAKIRI', 4154, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3059, NULL, 'OUSMANE KOMOU', 'OUSMANE KOMOU', 4155, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3060, NULL, 'MOUSSA KOMOU', 'MOUSSA KOMOU', 4156, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3061, NULL, 'ALI KOMOU', 'ALI KOMOU', 4157, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3062, NULL, 'SYNALI', 'SYNALI', 4158, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3063, NULL, 'LALA KOMOU', 'LALA KOMOU', 4159, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3064, NULL, 'KANSO SINAYOBO', 'KANSO SINAYOBO', 4160, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3065, NULL, 'L-SININTAO', 'L-SININTAO', 4161, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3066, NULL, 'BREHIMA NAPO', 'BREHIMA NAPO', 4162, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3067, NULL, 'S-SINAYOBO', 'S-SINAYOBO', 4163, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3068, NULL, 'LASSINA MIANTAO', 'LASSINA MIANTAO', 4164, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3069, NULL, 'KOMANE KONTAO', 'KOMANE KONTAO', 4165, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3070, 1, 'KAMARI NAPO', 'KAMARI NAPO', 4166, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3071, 1, 'GALI KONE', 'GALI KONE', 4167, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3072, NULL, 'B-KANAKOMO', 'B-KANAKOMO', 4168, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3073, 1, 'KOMANE KONTA', 'KOMANE KONTA', 4169, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3074, NULL, 'HAMADI ALASSANE', 'HAMADI ALASSANE', 4170, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3075, NULL, 'LADJI KORE', 'LADJI KORE', 4171, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3076, NULL, 'YAYI SINAYOGO', 'YAYI SINAYOGO', 4172, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3077, NULL, 'KAMANA SINAYOBO', 'KAMANA SINAYOBO', 4173, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3078, 1, 'MOUSSA TERETA', 'MOUSSA TERETA', 4174, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3079, NULL, 'MAMA MIENTA', 'MAMA MIENTA', 4175, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3080, NULL, 'BOUBACAR CAMARA', 'BOUBACAR CAMARA', 4176, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3081, NULL, 'KAMA TIENTA', 'KAMA TIENTA', 4177, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3082, 1, 'MAMADOU TIENTA', 'MAMADOU TIENTA', 4178, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3083, NULL, 'DIADIE FOFANA', 'DIADIE FOFANA', 4179, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3084, 1, 'MAMADOU KONTA', 'MAMADOU KONTA', 4180, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3085, NULL, 'IBRAHIM TIENTA', 'IBRAHIM TIENTA', 4181, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3086, 1, 'BAKAYE FAMANTA', 'BAKAYE FAMANTA', 4182, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3087, NULL, 'ALOU GNARE', 'ALOU GNARE', 4183, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3088, NULL, 'MAMADI TIKAMBO', 'MAMADI TIKAMBO', 4184, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3089, NULL, 'KO SECRE', 'KO SECRE', 4185, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3090, NULL, 'B-TIKAMBO', 'B-TIKAMBO', 4186, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3091, 1, 'ISSA SOGORE', 'ISSA SOGORE', 4187, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3092, NULL, 'FAMA CISSE', 'FAMA CISSE', 4188, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3093, 1, 'TIDIANI TRAORE', 'TIDIANI TRAORE', 4189, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3094, NULL, 'MAHU SYNANTA', 'MAHI SYNANTA', 4190, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3095, NULL, 'FAMA CISSE', '25MA CISSE', 4191, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3096, NULL, 'MAHI SYNANTA', 'MAHI SINANTA', 4192, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3097, 2, 'KONA KONTA', 'KONA KONTA', 4193, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3098, 1, 'ALIOU GNARE', 'ALIOU GNARE', 4194, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3099, 1, 'MAHI SYNANTA', 'MAHI SYNANTA', 4195, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3100, NULL, 'BOCAR L-TRAORE', 'BOCAR L-TRAORE', 4196, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3101, NULL, 'BOURI O-BARRY', 'BOURI O-BARRY', 4197, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3102, NULL, 'BOCARI SACKO', 'BACARI SACKO', 4198, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3103, NULL, 'ALIMATA TRAORE', 'LASSANA TRAORE', 4199, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3104, NULL, 'SOUMANA SACKO', 'SOUMANA SACKO', 4200, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3105, NULL, 'KABABA DIENTA', 'KABABA DIENTA', 4201, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3106, NULL, 'M-KARABENTA', 'M-KARABENTA', 4202, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3107, NULL, 'BOUGADARY KOITA', 'BOUGADARY KOITA', 4203, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3108, NULL, 'SOUMAILA KONTA', 'SOUMAILA KONTA', 4204, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3109, NULL, 'BOUAKAR TIKAMBO', 'BOUAKAR TIKAMBO', 4205, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3110, NULL, 'SAMBA BOKARI', 'SAMBA BOCARI', 4206, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3111, NULL, 'WOGINI DONOGO', 'HADY DONOGO', 4207, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3112, NULL, 'DIAFAR SACKO', 'ABDOULAYE SACKO', 4208, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3113, NULL, 'YACOUBA DANOGO', 'BAREMA DANOGO', 4209, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3114, NULL, 'M-KARABINTA', 'M-KARABINTA', 4210, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3115, NULL, 'BOCAR BARRI', 'BOCAR BARRI', 4211, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3116, NULL, 'SAMBA KORIGNON', 'SAMBA KORIGNON', 4212, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3117, NULL, 'BOUREIMA MIANTA', 'BOUREIMA MIANTA', 4213, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3118, NULL, 'ALI DABITA', 'ALI DABITA', 4214, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3119, 1, 'SADIO TANAPO', 'SADIO TANAPO', 4215, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3120, NULL, 'KAMA KONTA', 'KAMA KONTA', 4216, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3121, NULL, 'ALMAMI KANTA', 'ALMAMI KANTA', 4217, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3122, NULL, 'ALMAMI KONTA', 'ALMAMI KONTA', 4218, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3123, NULL, 'B-NIANTAO', 'B-NIANTAO', 4219, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3124, NULL, 'ALI B-SANGARE', 'ALI B-SANGARE', 4220, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3125, NULL, 'MAMA DABITA', 'MAMA DABITA', 4221, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3126, NULL, 'BOURAMA MAIGA', 'BOURAMA MAIGA', 4222, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3127, NULL, 'BETAR DIARRA', 'BETAR DIARRA', 4223, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3128, NULL, 'SAMBA SANGARE', 'SAMBA SANGARE', 4224, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3129, NULL, 'YORO SAMAKE', 'YORO SAMAKE', 4225, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3130, NULL, 'GAOUSSOU TRAORE', 'GAOUSSOU TRAORE', 4226, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3131, NULL, 'ADAMA TANGARA', 'ADAMA TANGARA', 4227, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3132, NULL, 'SEKOU A-KANTA', 'SEKOU A-KANTA', 4228, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3133, NULL, 'KASSIM H-HASSIO', 'KASSIM H-HASSIO', 4229, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3134, NULL, 'MOHAMED HASSIM', 'MOHAMED HASSIM', 4230, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3135, NULL, 'K-CHABATA', 'K-CHABATA', 4231, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3136, NULL, 'OUMAROU KONTA', 'SEKOU A-KONTA', 4232, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3137, NULL, 'MAMA KONTA', 'ALI KONTA', 4233, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3138, NULL, 'LASSANA KONTA', 'HADY KONTA', 4234, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3139, NULL, 'HAMADI KONTA', 'HAMADI KONTA', 4235, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3140, NULL, 'BOUAKAR KONTA', 'MAMADI KOBILA', 4236, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3141, NULL, 'MAMADI TRAORE', 'MAMADI TRAORE', 4237, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3142, NULL, 'BOUAKAR KONTA', 'ALI KONTA', 4238, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3143, 1, 'BENGUE KANTA', 'BENGUE KANTA', 4239, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3144, NULL, 'SINALY SANGARE', 'SINALY SANGARE', 4240, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3145, NULL, 'LADJ NIENTAO', 'LADJ NIENTAO', 4241, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3146, NULL, 'B-KOLINTA', 'B-KOLINTA', 4242, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3147, 2, 'BABA TIENTA', 'BABA TIENTA', 4243, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3148, 2, 'KEMAMA TIENTA', 'KEMAMA TIENTA', 4244, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3149, NULL, 'SAMBA KOMOU', 'SIDIKI KOUMOU', 4245, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3150, NULL, 'MAMADOU KORNIO', 'MAMADOU KORNIO', 4246, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3151, NULL, 'BOUGADARI KOMOU', 'SIDIKI KOMOU', 4247, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3152, NULL, 'SAMBA KOMOU', 'SAMBA KOMOU', 4248, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3153, NULL, 'MAMA SINAYOGO', 'MAMA SINAYOGO', 4249, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3154, NULL, 'KEOU SINAYOKO', 'KEOU SINAYOKO', 4250, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3155, NULL, 'LASSINA KONTA', 'BASINALY KONTA', 4251, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3156, NULL, 'BOUGADARY KOMOU', 'SIDIKI KOMOU', 4252, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3157, NULL, 'LASSINA KONTA', 'LASSINA KONTA', 4253, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3158, 1, 'HAMIDOU MEMINTA', 'HAMIDOU MEMINTA', 4254, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3159, NULL, 'SIDIKI DABITAO', 'SIDIKI DABITAO', 4255, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3160, NULL, 'FATOUMATA SATAO', 'BROULAYE KONTA', 4256, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3161, NULL, 'KOUMANI SEKERE', 'KOUMANI SEKERE', 4257, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3162, NULL, 'OUSMANE SEKERE', 'LADJI SEKERE', 4258, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3163, NULL, 'KAMANI SEKERE', 'KAMANI SEKERE', 4259, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3164, NULL, 'KEMAROU KOMINA', 'KEMAROU KOMINA', 4260, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3165, NULL, 'SOUNGHOI KOMINA', 'SOUNGHOI KOMINA', 4261, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3166, NULL, 'LASSINE KOMINA', 'LASSINE KOMINA', 4262, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3167, 2, 'SEYNI TIENTA', 'SEYNI TIENTA', 4263, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3168, NULL, 'ISSA KOMOU', 'ISSA KOMOU', 4264, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3169, 1, 'BRAHIMA KOMINA', 'BRAHIMA KOMINA', 4265, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3170, NULL, 'TAHIROU FAMANTA', 'TAHIROU FAMANTA', 4266, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3171, NULL, 'MAMOUTOU KONTA', 'MAMOUTOU KONTA', 4267, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3172, NULL, 'MORY SOULA', 'MORY SOULA', 4268, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3173, NULL, 'SOUNGHOI KOMATA', 'SOUNGHOI KOMOTA', 4269, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3174, NULL, 'MAMOU KOMINA', 'MAMOU KOMINA', 4270, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3175, NULL, 'MAMOUTOU KANTA', 'MAMOUTOU KANTA', 4271, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3176, NULL, 'KOMANI NAPO', 'KOMANI NAPO', 4272, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3177, NULL, 'TAMANA SINAYOBO', 'TAMANA SINAYOBO', 4273, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3178, NULL, 'YAYI SINAYOBO', 'YAYI SINAYOBO', 4274, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3179, 1, 'MIEKA NASSIRE', 'MIEKA NASSIRE', 4275, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3180, 1, 'YAYA TROUPO', 'YAYA TROUPO', 4276, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3181, NULL, 'ADAMA KONTAO', 'ADAMA KONTAO', 4277, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3182, NULL, 'BASALOKA FOFANA', 'BASALOKA FOFANA', 4278, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3183, NULL, 'BEH KOBILA', 'OUMAROU KOBILA', 4279, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3184, NULL, 'SEKOU A-TERETA', 'SEKOU A-TERETA', 4280, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3185, NULL, 'ZAKARIA KOITA', 'ZAKARIA KOITA', 4281, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3186, NULL, 'SEYDOU KANE', 'MAMADOU KANE', 4282, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3187, NULL, 'DIAFARA SACKO', 'KOKE SACKO', 4283, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3188, NULL, 'SAMBA POKOU', 'SAMBA POKOU', 4284, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3189, NULL, 'SEYDOU KANE', 'SEYDOU KANE', 4285, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3190, NULL, 'SOUMANA FOFANA', 'SOUMANA FOFANA', 4286, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3191, NULL, 'MOUSSA TRAORE', 'SEKOU A-TRAORE', 4287, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3192, NULL, 'MAMOUTOU DONOGO', 'MAMOUTOU DONOGO', 4288, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3193, NULL, 'A-CISSE', 'A-CISSE', 4289, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3194, NULL, 'BOURI KONTA', 'BOURI KONTA', 4290, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3195, NULL, 'ELHAYE MAIGA', 'ELHAYE MAIGA', 4291, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3196, NULL, 'BOCAR SOUBOULE', 'BOCAR SOUBOULE', 4292, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3197, NULL, 'AMADOU SADIO', 'AMADOU SADIO', 4293, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3198, NULL, 'LABANOU TRAORE', 'LABANOU TRAORE', 4294, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3199, NULL, 'BOCAR YATTARA', 'BOCAR YATTARA', 4295, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3200, NULL, 'FONO KONTA', 'FONO KONTA', 4296, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3201, 1, 'AMADOU MIANTAO', 'AMADOU MIANTAO', 4297, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3202, 1, 'KALY KONTAO', 'KALY KONTAO', 4298, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3203, NULL, 'MAMAI KONTAO', 'MAMAI KONTAO', 4299, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3204, NULL, 'SORY NIENTAO', 'SORY NIENTAO', 4300, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3205, NULL, 'A-KONTAO', 'A-KONTAO', 4301, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3206, 1, 'KAKAYE MIANTAO', 'KAKAYE MIANTAO', 4302, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3207, NULL, 'LASSINA KONTAO', 'LASSINA KONTAO', 4303, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3208, NULL, 'MOUSSA TIENTAO', 'MOUSSA TIENTAO', 4304, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3209, 1, 'ISSA KONTA', 'ISSA KONTA', 4305, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3210, NULL, 'O-NIOBOINA', 'O-NIOBOINA', 4306, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3211, NULL, 'BOUAKAR SACKO', 'BOUAKAR SACKO', 4307, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3212, NULL, 'OUSMANE KONTA', 'NOUH KONTA', 4308, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3213, NULL, 'DIAFARA SACKO', 'DIAFARA SACKO', 4309, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3214, NULL, 'LASSINE TIKAMBO', 'NFADAMA TIKAMBO', 4310, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3215, NULL, 'MOUSSA TANAPO', 'SORY TANAPO', 4311, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3216, NULL, 'BEH KOBILA', 'OUMAR KOBILA', 4312, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3217, NULL, 'DIAKARIDIA', 'BOUGADARY KOITA', 4313, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3218, NULL, 'ADAMA MAIGA', 'DAMA MAIGA', 4314, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3219, NULL, 'BAH TOMOTA', 'BAH TOMOTA', 4315, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3220, NULL, 'S-TIENTA', 'S-TIENTA', 4316, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3221, NULL, 'BASALIKA FOFANA', 'BASALIKA FOFANA', 4317, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3222, NULL, 'ABDOULAYE CISSE', 'ABDOULAYE CISSE', 4318, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3223, NULL, 'AFO CISSE', 'AFO CISSE', 4319, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3224, NULL, 'DAOUDA KOITA', 'DAOUDA KOITA', 4320, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3225, NULL, 'MAMA KORGNON', 'MAMA KORGNON', 4321, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3226, NULL, 'BOUN A-KONTA', 'BOUN A-KONTA', 4322, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3227, NULL, 'YOUSSOUF KANTE', 'YOUSSOUF KANTE', 4323, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3228, NULL, 'DAOUDA KEITA', 'DAOUDA KEITA', 4324, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3229, NULL, 'NKA', 'NKA', 4325, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3230, NULL, 'NKA CISSE', 'NKA CISSE', 4326, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3231, NULL, 'BOCAR KANAKOMO', 'BOCAR KANAKOMO', 4327, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3232, NULL, 'LASSANA TIKAMBO', 'LASSANA TIKAMBO', 4328, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3233, 1, 'SALIF KONTA', 'SALIF KONTA', 4329, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3234, NULL, 'A-DJEGUENE', 'A-DJEGUENE', 4330, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3235, NULL, 'Z-FAMANTA', 'Z-FAMANTA', 4331, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3236, NULL, 'A-FAMANTA', 'A-FAMANTA', 4332, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3237, NULL, 'LAMINE FAMANTA', 'LAMINE FAMANTA', 4333, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3238, 1, 'BABA SALAMANTA', 'BABA SALAMANTA', 4334, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3239, NULL, 'MAMA TRAORE', 'MAMA TRAORE', 4335, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3240, NULL, 'SIKO M-KONTAO', 'SIKO M-KONTAO', 4336, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3241, NULL, 'KASSIM TIENTA', 'KASSIM TIENTA', 4337, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3242, NULL, 'SAMBA KORIGNO', 'SAMBA KORIGNO', 4338, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3243, NULL, 'MAMADY TRAORE', 'MAMADY TRAORE', 4339, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3244, NULL, 'MAHAMANE KONTAO', 'MAHAMANE KONTAO', 4340, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3245, NULL, 'MAMADI MANGER', 'SEJOU A-MANGER', 4341, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3246, NULL, 'MOUSSA KONTA', 'HAMADI KONTA', 4342, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3247, NULL, 'K-KARABENTA', 'K-KARABENTA', 4343, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3248, NULL, 'SIDY TRAORE', 'SIDY TRAORE', 4344, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3249, NULL, 'BOUAKAR KONTA', 'BOUAKAR KONTA', 4345, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3250, NULL, 'K-TCHABATA', 'K-TCHABATA', 4346, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3251, NULL, 'ACHEICK MAIGA', 'ACHEIIK MAIGA', 4347, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3252, NULL, 'MOUSSA TIENTA', 'MOUSSA TIENTA', 4348, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3253, NULL, 'BAH KONTAO', 'BAH KONTAO', 4349, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3254, NULL, 'MAMA TOMOTA', 'MAMA TOMOTA', 4350, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3255, NULL, 'TAHIROU NABO', 'TAHIROU NABO', 4351, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3256, NULL, 'KEMA TIENTA', 'KEMA TIENTA', 4352, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3257, NULL, 'BOCAR TOMOTA', 'BOCAR TOMOTA', 4353, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3258, 1, 'SEKOU KARABENTA', 'SEKOU KARABENTA', 4354, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3259, NULL, 'ALI TIENTA', 'ALI TIENTA', 4355, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3260, NULL, 'SIDI MAIGA', 'SIDI MAIGA', 4356, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3261, NULL, 'L-KARABENTA', 'L-KARABENTA', 4357, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3262, NULL, 'ACHEIK MAIGA', 'ACHEIK MAIGA', 4358, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3263, NULL, 'GOLO KARABENTA', 'GOLO KARABENTA', 4359, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3264, NULL, 'GALO KARABENTA', 'GALO KARABENTA', 4360, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3265, NULL, 'BAH KOMOTA', 'BAH KOMOTA', 4361, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3266, 1, 'MOUSSA KANTA', 'MOUSSA KANTA', 4362, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3267, NULL, 'IDRISSA KONTA', 'IDRISSA KONTA', 4363, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3268, 1, 'SEKOU S-KONTA', 'SEKOU S-KONTA', 4364, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3269, 1, 'KOMA KONTA', 'KOMA KONTA', 4365, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3270, NULL, 'MAMA TROUPO', 'MAMA TROUPO', 4366, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3271, NULL, 'BENGUE KONTA', 'BENGUE KONTA', 4367, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3272, NULL, 'IDRISSA TRAORE', 'IDRISSA TRAORE', 4368, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3273, NULL, 'M-YATTARA', 'M-YATTARA', 4369, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3274, NULL, 'LASSINE DICKO', 'LASSINE DICKO', 4370, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3275, NULL, 'LASSINA DICKO', 'LASSINA DICKO', 4371, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3276, NULL, 'BENOGO DRAME', 'ZOUMANA DRAME', 4372, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3277, NULL, 'MAMA SALAMANTA', 'S-B-SALAMANTA', 4373, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3278, NULL, 'BENOGOU DRAME', 'BENOGOU DRAME', 4374, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3279, NULL, 'KERE NIOBOINA', 'KERE NIOBOINA', 4375, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3280, NULL, 'M-SALAMANTA', 'M-SALAMANTA', 4376, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3281, NULL, 'F-NACIRE', 'MAMA NACIRE', 4377, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3282, NULL, 'KAKAYE KONTAO', 'KAKAYE KONTAO', 4378, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3283, NULL, 'BOURAMA DABITAO', 'BOURAMA DABITAO', 4379, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3284, NULL, 'LADJI DABITAO', 'LADJI DABITAO', 4380, NULL, 'mali2');
INSERT INTO art_unite_peche VALUES (3285, 1, 'MAMADOU KORNION', 'MAMADOU KORNION', 4381, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3286, 1, 'BROULAYE KONTA', 'BROULAYE KONTA', 4382, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3287, 1, 'MAMADOU DABITA', 'MAMADOU DABITA', 4383, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3288, 2, 'SEKOU A-KONTA', 'SEKOU A-KONTA', 4384, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3289, 1, 'O-K-CHABATA', 'O-K-CHABATA', 4385, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3290, 2, 'MAMA SAGONTA', 'MAMA SAGONTA', 4386, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3291, 2, 'BOUGADARY KONTA', 'BOUGADARY KONTA', 4387, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3292, 2, 'SIDI B-TIKAMBO', 'SIDI B-TIKAMBO', 4388, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3293, 2, 'BAZ-TIKAMBO', 'BAZ-TIKAMBO', 4389, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3294, 1, 'NOUHOUM TIKAMBO', 'NOUHOUM TIKAMBO', 4390, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3295, 2, 'BNOUMA TIKAMBO', 'BNOUMA TIKAMBO', 4391, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3296, 2, 'KOKE SACKO', 'KOKE SACKO', 4392, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3297, 2, 'BABA KANE', 'BABA KANE', 4393, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3298, 2, 'KONGA NABO', 'KONGA NABO', 4394, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3299, 2, 'NFADAMA TIKAMBO', 'NFADAMA TIKAMBO', 4395, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3300, 1, 'NOUHOU KONTA', 'NOUHOU KONTA', 4396, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3301, 1, 'MANA MIENTA', 'MANA MIENTA', 4397, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3302, 1, 'Y-KARABENTA', 'Y-KARABENTA', 4398, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3303, 1, 'ABD-TROUPO', 'ABD-TROUPO', 4399, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3304, 2, 'K-DABITAO', 'K-DABITAO', 4400, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3305, 2, 'KINKA DABITAO', 'KINKA DABITAO', 4401, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3306, 1, 'BINKE TRAORE', 'BINKE TRAORE', 4402, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3307, 1, 'MOUSSA DIENTAO', 'MOUSSA DIENTAO', 4403, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3308, 2, 'BOCARI KONTA', 'BOCARI KONTA', 4404, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3309, 2, 'BOCAR SOUBILIA', 'BOCAR SOUBILIA', 4405, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3310, 2, 'ALHAI MAIGA', 'ALHAI MAIGA', 4406, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3311, 2, 'SAMBA BORE', 'SAMBA BORE', 4407, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3312, 1, 'YACOUBA KANTA', 'YACOUBA KANTA', 4408, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3313, 1, 'LADJI MINTA', 'LADJI MINTA', 4409, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3314, 1, 'BOCAR TOMANTA', 'BOCAR TOMANTA', 4410, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3315, 2, 'BOCAR TIKAMBO', 'BOCAR TIKAMBO', 4411, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3316, 2, 'MAMA SAMBE', 'MAMA SAMBE', 4412, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3317, 1, 'HAMADOU KANTA', 'HAMADOU KANTA', 4413, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3318, 2, 'BOUBACAR KOMOU', 'BOUBACAR KOMOU', 4414, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3319, 1, 'SIDI YAYA', 'SIDI YAYA', 4415, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3320, 1, 'MAMADOU KONE', 'MAMADOU KONE', 4416, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3321, 2, 'Y-GNOUMANTA', 'Y-GNOUMANTA', 4417, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3322, 1, 'SOUNGHOI KOMOTA', 'SOUNGHOI KOMOTA', 4418, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3323, 2, 'MORIYERE KOMINA', 'MORIYERE KOMINA', 4419, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3324, 1, 'MAMA SOULA', 'MAMA SOULA', 4420, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3325, 1, 'M-PAYANTAO', 'M-PAYANTAO', 4421, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3326, 1, 'KOMBA KOOTA', 'KOMBA KOOTA', 4422, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3327, 1, 'K-SINAYOBO', 'K-SINAYOBO', 4423, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3328, 1, 'S-SINAYOGO', 'S-SINAYOGO', 4424, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3329, 1, 'KANSO SINAYOGO', 'KANSO SINAYOGO', 4425, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3330, 1, 'MOUSSA KEITA', 'MOUSSA KEITA', 4426, 1, 'mali2');
INSERT INTO art_unite_peche VALUES (3331, 1, 'BASIDIKI TRAORE', 'BASIDIKI TRAORE', 4427, 1, 'mali2');


--
-- Data for Name: art_vent; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO art_vent VALUES (0, 'Inconnu');
INSERT INTO art_vent VALUES (1, 'Absence de vent');
INSERT INTO art_vent VALUES (2, 'Vent l�ger');
INSERT INTO art_vent VALUES (3, 'Vent fort');
INSERT INTO art_vent VALUES (4, 'Vent tr�s fort');


--
-- Data for Name: exp_biologie; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_campagne; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_contenu; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_coup_peche; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_debris; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_engin; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_environnement; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_force_courant; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_fraction; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_position; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_qualite; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_remplissage; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_sediment; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_sens_courant; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_sexe; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_stade; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_station; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_trophique; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_vegetation; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: pg_ts_cfg; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: pg_ts_cfgmap; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: pg_ts_dict; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: pg_ts_parser; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ref_categorie_ecologique; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_categorie_ecologique VALUES ('C', 'Continentale');
INSERT INTO ref_categorie_ecologique VALUES ('Ce', 'Continentale � affinit� estuarienne');
INSERT INTO ref_categorie_ecologique VALUES ('Co', 'Continentale occasionnelle');
INSERT INTO ref_categorie_ecologique VALUES ('Ec', 'Estuarienne d''origine continentale');
INSERT INTO ref_categorie_ecologique VALUES ('Em', 'Estuarienne d''origine marine');
INSERT INTO ref_categorie_ecologique VALUES ('Es', 'Estuarienne stricte');
INSERT INTO ref_categorie_ecologique VALUES ('Ma', 'Marine accessoire');
INSERT INTO ref_categorie_ecologique VALUES ('ME', 'Marine-estuarienne');
INSERT INTO ref_categorie_ecologique VALUES ('Mo', 'Marine occasionnelle');


--
-- Data for Name: ref_categorie_trophique; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_categorie_trophique VALUES ('he-de', 'Herbivore d�tritivore ou brouteur');
INSERT INTO ref_categorie_trophique VALUES ('he-ph', 'Herbivore � pr�dominance phytoplanctonophage ou microphytophage');
INSERT INTO ref_categorie_trophique VALUES ('om-ge', 'Omnivore g�n�raliste');
INSERT INTO ref_categorie_trophique VALUES ('om-in', 'Omnivore � pr�dominance insectivore');
INSERT INTO ref_categorie_trophique VALUES ('p1-bt', 'Pr�dateur de premier niveau � pr�dominance benthophage (mollusques,vers)');
INSERT INTO ref_categorie_trophique VALUES ('p1-in', 'Pr�dateur de premier niveau � pr�dominance insectivore');
INSERT INTO ref_categorie_trophique VALUES ('p1-mc', 'Pr�dateur de premier niveau g�n�raliste (crustac�s,insectes)');
INSERT INTO ref_categorie_trophique VALUES ('p1-zo', 'Zooplanctonophagie dominante');
INSERT INTO ref_categorie_trophique VALUES ('p2-ge', 'Pr�dateur de deuxi�me niveau g�n�raliste (poisson et autres proies)');
INSERT INTO ref_categorie_trophique VALUES ('p2-pi', 'Pr�dateur de deuxi�me niveau � pr�dominance piscivore');


--
-- Data for Name: ref_espece; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_espece VALUES ('AAM', 'Hemicaranx bicolor', NULL, 15, 'Mo', 'p2-ge', 1.4933, 3.0334001, 9, NULL);
INSERT INTO ref_espece VALUES ('ABA', 'Alestes baremoze', NULL, 3, 'Co', 'om-ge', 2.6429999, 2.868, 2, NULL);
INSERT INTO ref_espece VALUES ('ABI', 'Auchenoglanis biscutatus', NULL, 10, 'C', NULL, 5.0900002, 2.885, 2, NULL);
INSERT INTO ref_espece VALUES ('ACI', 'Alectis ciliaris', NULL, 15, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ACS', 'Porogobius schlegelii', NULL, 41, 'Es', 'om-ge', 2.5190001, 2.743, 1, NULL);
INSERT INTO ref_espece VALUES ('ADE', 'Alestes dentex', NULL, 3, 'C', NULL, 2.6229999, 2.8959999, 2, NULL);
INSERT INTO ref_espece VALUES ('AGA', 'Arius latiscutatus', NULL, 9, 'ME', 'p2-ge', 1.3200001, 2.994, 4, NULL);
INSERT INTO ref_espece VALUES ('AGI', 'Arius gigas', NULL, 9, 'C', NULL, 1, 3, 0, NULL);
INSERT INTO ref_espece VALUES ('AGU', 'Engraulis encrasicolus', NULL, 35, 'Ma', 'p1-zo', 0, 0, 0, NULL);
INSERT INTO ref_espece VALUES ('AHE', 'Arius heudelotii', NULL, 9, 'ME', 'p2-ge', 0.67510003, 3.1124001, 9, NULL);
INSERT INTO ref_espece VALUES ('AHI', 'Ablennes hians', NULL, 13, 'Mo', 'p2-pi', 0.0040000002, 3.322, 8, NULL);
INSERT INTO ref_espece VALUES ('ALE', 'Alestes spp.', 'JME 15/05/03', 3, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ALI', 'Brycinus imberi', NULL, 3, 'Co', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ALO', 'Brycinus longipinnis', NULL, 3, 'Ce', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('AMA', 'Brycinus macrolepidotus', NULL, 3, 'Ce', 'om-ge', 2.6429999, 2.868, 2, NULL);
INSERT INTO ref_espece VALUES ('AMI', 'Apogon imberbis', NULL, 8, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('AMO', 'Acanthurus monroviae', NULL, 1, 'Mo', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ANO', 'Antennarius striatus', NULL, 5, 'Ma', NULL, 3.03, 3.036, 4, NULL);
INSERT INTO ref_espece VALUES ('ANU', 'Brycinus nurse', NULL, 3, 'Co', 'om-ge', 2.3099999, 2.9590001, 7, NULL);
INSERT INTO ref_espece VALUES ('AOC', 'Auchenoglanis occidentalis', NULL, 10, 'C', NULL, 3.553, 2.9230001, 2, NULL);
INSERT INTO ref_espece VALUES ('APA', 'Antennarius pardalis', NULL, 5, 'Mo', 'p2-ge', 0, 0, 0, 'ANO');
INSERT INTO ref_espece VALUES ('APY', 'Aplysia spp.', NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ARA', 'Aplocheilichthys rancureli', NULL, 27, 'Co', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ARE', 'Argyrosomus regius', NULL, 86, 'Mo', 'p2-pi', 0.99800003, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('ARI', 'Arius spp.', NULL, 9, NULL, NULL, 1.36, 2.9909999, 4, NULL);
INSERT INTO ref_espece VALUES ('ARP', 'Arius parkii', NULL, 9, 'ME', 'p2-pi', 0.50650001, 3.1677999, 9, NULL);
INSERT INTO ref_espece VALUES ('ASE', 'Arca senilis', 'Demande JME 21/06/04', 108, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ASP', 'Aplocheilichthys spilauchen', NULL, 27, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ATH', 'Auxis thazard', NULL, 87, 'Ma', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ATR', 'Atherina sp.', 'VDG - Pgm Saloum', 109, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('AUC', 'Auchenoglanis spp.', 'JME 15/05/03', 10, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('AVU', 'Albula vulpes', NULL, 2, 'Mo', 'p1-bt', 1.176, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('BAB', 'Barbus ablabes', NULL, 26, 'Co', NULL, 0, 0, 0, 'BOC');
INSERT INTO ref_espece VALUES ('BAG', 'Bagrus spp.', 'JME 15/05/03', 10, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BAL', 'Balistes spp.', NULL, 11, 'Ma', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BAR', 'Barbus spp.', NULL, 26, 'C', NULL, 0, 0, 0, 'BDS');
INSERT INTO ref_espece VALUES ('BAU', 'Brachydeuterus auritus', NULL, 45, 'ME', 'om-ge', 0.89999998, 3.1159999, 4, NULL);
INSERT INTO ref_espece VALUES ('BBA', 'Synodontis batensoda', NULL, 57, 'Co', 'om-ge', 4.8070002, 2.925, 2, NULL);
INSERT INTO ref_espece VALUES ('BBO', 'Boops boops', NULL, 92, 'Mo', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BDM', 'Bagrus bajad', NULL, 10, 'C', NULL, 0.57099998, 3.132, 2, NULL);
INSERT INTO ref_espece VALUES ('BDO', 'Bagrus docmak', NULL, 10, 'C', NULL, 1.04, 3.076, 8, NULL);
INSERT INTO ref_espece VALUES ('BDS', 'Barbus perince', NULL, 26, 'C', NULL, 0.21699999, 3.5, 2, NULL);
INSERT INTO ref_espece VALUES ('BES', 'Strongylura senegalensis', NULL, 13, 'Em', 'p2-ge', 4.2410002, 2.4130001, 1, NULL);
INSERT INTO ref_espece VALUES ('BFI', 'Bagrus filamentosus', NULL, 10, 'C', NULL, 0, 0, 0, 'BDO');
INSERT INTO ref_espece VALUES ('BKO', 'Butis koilomatodon', 'VDG - Pgm Saloum', 33, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BLB', 'Batanga lebretonis', NULL, 33, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BLE', 'Parablennius goreensis', 'Paro... corrige en Para... le 27/03/6 (LT)', 14, 'Es', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BLI', 'Batrachoides liberiensis', NULL, 12, 'Ma', 'p1-mc', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BLN', 'Blennius sp.', 'VDG - Pgm Saloum', 14, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BMA', 'Barbus macrops', NULL, 26, 'C', NULL, 0, 0, 0, 'BDS');
INSERT INTO ref_espece VALUES ('BOC', 'Barbus bynni occidentalis', 'V�rifi� dans L�v�que, Paugy, Teugels, 90 (7/02/02)', 26, 'C', NULL, 0.21699999, 3.5, 2, NULL);
INSERT INTO ref_espece VALUES ('BRL', 'Brycinus leuciscus', NULL, 3, 'C', NULL, 3, 3, 2, NULL);
INSERT INTO ref_espece VALUES ('BRY', 'Brycinus spp.', 'JME 15/05/03', 3, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BSO', 'Bathygobius soporator', NULL, 41, 'Es', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BWA', 'Barbus bynni waldroni', 'V�rifi� dans L�v�que, Paugy, Teugels, 90 (7/02/02)', 26, 'Co', NULL, 0, 0, 0, 'BOC');
INSERT INTO ref_espece VALUES ('CAA', 'Callinectes amnicola', NULL, 78, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CAL', 'Callinectes sp.', NULL, 78, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CAR', 'Caranx spp.', NULL, 15, NULL, NULL, 1.67, 3.036, 4, NULL);
INSERT INTO ref_espece VALUES ('CAS', 'Caranx senegallus', 'corrig� le 26/02/02', 15, 'ME', 'p2-ge', 6.4400001, 2.7190001, 4, NULL);
INSERT INTO ref_espece VALUES ('CCE', 'Dalophis cephalopeltis', NULL, 70, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CCH', 'Carcharhinus spp.', NULL, 16, NULL, NULL, 0, 0, 0, 'RCE');
INSERT INTO ref_espece VALUES ('CCI', 'Citharinus citharus', NULL, 21, 'C', NULL, 2.168, 3.0610001, 2, NULL);
INSERT INTO ref_espece VALUES ('CCR', 'Caranx crysos', 'demande JME 03/03', 15, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CFI', 'Chrysichthys auratus', NULL, 10, 'Ec', 'p1-bt', 1.6, 2.8800001, 8, NULL);
INSERT INTO ref_espece VALUES ('CGA', 'Clarias gariepinus', NULL, 22, 'Co', NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('CGL', 'Callinectes pallidus', NULL, 78, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CHG', 'Chaetodipterus goreensis', NULL, 36, 'Mo', 'p1-bt', 0, 0, 0, 'CLI');
INSERT INTO ref_espece VALUES ('CHI', 'Caranx hippos', NULL, 15, 'ME', 'p2-ge', 1.37, 3.0829999, 10, NULL);
INSERT INTO ref_espece VALUES ('CHL', 'Chloroscombrus chrysurus', NULL, 15, 'ME', 'p2-ge', 1.17, 3.053, 4, NULL);
INSERT INTO ref_espece VALUES ('CHM', 'Chromis chromis', NULL, 77, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CHO', 'Chaetodon hoefleri', NULL, 18, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CHY', 'Chrysichthys spp.', NULL, 10, NULL, NULL, 2.73, 2.8829999, 4, NULL);
INSERT INTO ref_espece VALUES ('CIL', 'Citharinus latus', NULL, 21, 'C', NULL, 0, 0, 3, 'CCI');
INSERT INTO ref_espece VALUES ('CIT', 'Citharinus spp.', '18/11/02', 21, 'C', NULL, 0, 0, 0, 'CCI');
INSERT INTO ref_espece VALUES ('CJO', 'Chrysichthys johnelsi', NULL, 10, 'Ce', 'p1-bt', 0, 0, 0, 'CHY');
INSERT INTO ref_espece VALUES ('CKI', 'Ctenopoma kingsleyae', NULL, 4, 'Co', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CLA', 'Clarotes laticeps', NULL, 10, 'Co', NULL, 1.531, 3.01, 2, NULL);
INSERT INTO ref_espece VALUES ('CLC', 'Carcharhinus leucas', 'Bamboung 09', 16, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CLE', 'Clarias ebriensis', NULL, 22, 'Es', NULL, 0, 0, 0, NULL);
INSERT INTO ref_espece VALUES ('CLI', 'Chaetodipterus lippei', NULL, 36, 'Ma', 'p1-bt', 3.4319999, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('CLL', 'Clarias laeviceps', NULL, 22, 'C', NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('CLM', 'Carcharhinus limbatus', 'JME 25/02/05', 16, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CLP', 'Clarias spp.', NULL, 22, NULL, NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('CLR', 'Clarioides spp.', NULL, 22, NULL, NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('CLS', 'Clarias anguillaris', NULL, 22, 'Co', 'p1-mc', 0.93400002, 3.0339999, 2, NULL);
INSERT INTO ref_espece VALUES ('CMB', 'Cymbium sp.', NULL, 102, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CNI', 'Chrysichthys nigrodigitatus', NULL, 10, 'Ec', 'p1-bt', 2.1300001, 2.9170001, 4, NULL);
INSERT INTO ref_espece VALUES ('COR', 'Corvina spp.', NULL, 86, NULL, NULL, 0, 0, 0, 'PSS');
INSERT INTO ref_espece VALUES ('CRG', 'Crassostrea gasar', 'Demande JME 21/06/04', 107, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CRH', 'Caranx rhonchus', NULL, 15, 'Mo', 'p1-bt', 0, 0, 0, 'CAR');
INSERT INTO ref_espece VALUES ('CST', 'Citharichthys stampflii', NULL, 72, 'Em', 'p2-ge', 0.23, 3.1470001, 4, NULL);
INSERT INTO ref_espece VALUES ('CTA', 'Campylomormyrus tamandua', NULL, 60, 'C', NULL, 0, 0, 0, 'PBA');
INSERT INTO ref_espece VALUES ('CTL', 'Ctenogobius lepturus', 'Baran (21/12/01)', 41, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CTR', 'Scomberomorus tritor', NULL, 87, 'Ma', 'p2-pi', 1.08, 2.9849999, 4, NULL);
INSERT INTO ref_espece VALUES ('CVO', 'Dactylopterus volitans', 'corrig� le 26/02/02', 28, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CWA', 'Chrysichthys maurus', NULL, 10, 'Ec', 'p1-bt', 1.77, 2.983, 4, NULL);
INSERT INTO ref_espece VALUES ('CYM', 'Cynoglossus monodi', NULL, 25, 'Mo', 'p1-bt', 0, 0, 0, 'CYS');
INSERT INTO ref_espece VALUES ('CYN', 'Cynoglossus spp.', NULL, 25, NULL, NULL, 0, 0, 0, 'CYS');
INSERT INTO ref_espece VALUES ('CYS', 'Cynoglossus senegalensis', NULL, 25, 'Em', 'p1-bt', 0.31999999, 2.9860001, 4, NULL);
INSERT INTO ref_espece VALUES ('DAF', 'Drepane africana', NULL, 31, 'ME', 'p1-bt', 0.69, 3.2720001, 4, NULL);
INSERT INTO ref_espece VALUES ('DAM', 'Dasyatis margaritella', NULL, 29, 'Em', 'p1-bt', 0, 0, 0, 'DMA');
INSERT INTO ref_espece VALUES ('DAS', 'Dasyatis spp.', NULL, 29, NULL, NULL, 4.039, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('DBE', 'Diplodus bellottii', NULL, 92, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DBR', 'Distichodus brevipinnis', NULL, 21, 'C', NULL, 0, 0, 0, 'DRO');
INSERT INTO ref_espece VALUES ('DCA', 'Dentex canariensis', NULL, 92, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DEN', 'Distichodus engrycephalus', NULL, 21, 'C', NULL, 0, 0, 0, 'DRO');
INSERT INTO ref_espece VALUES ('DEP', 'Decapterus punctatus', NULL, 15, 'Ma', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DIM', 'Diodon holocanthus', NULL, 30, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DIS', 'Distichodus spp.', 'JME 15/05/03', 21, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DIV', 'Divers-Melange', NULL, 49, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DMA', 'Dasyatis margarita', NULL, 29, 'Em', 'p1-bt', 16.83, 2.7479999, 6, NULL);
INSERT INTO ref_espece VALUES ('DPU', 'Dicentrarchus punctatus', NULL, 61, 'Mo', 'p2-ge', 1.245, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('DRO', 'Distichodus rostratus', NULL, 21, 'Co', NULL, 1.99, 3, 7, NULL);
INSERT INTO ref_espece VALUES ('DSA', 'Diplodus sargus', 'ss-esp. cadenati seule pr�sente sur zone (7/02/02)', 92, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DUK', 'Dasyatis ukpam', NULL, 29, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DVU', 'Diplodus vulgaris', NULL, 92, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('EAE', 'Epinephelus aeneus', NULL, 90, 'ME', 'p2-pi', 1.33, 2.9760001, 4, NULL);
INSERT INTO ref_espece VALUES ('EAL', 'Euthynnus alletteratus', NULL, 87, 'Ma', NULL, 0, 0, 0, NULL);
INSERT INTO ref_espece VALUES ('ECH', 'Epiplatys chaperi', NULL, 6, 'Ce', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('EDA', 'Eleotris daganensis', NULL, 33, 'Es', NULL, 0, 0, 0, 'ELE');
INSERT INTO ref_espece VALUES ('EES', 'Epinephelus esonue', NULL, 90, 'Mo', NULL, 0, 0, 0, 'EAE');
INSERT INTO ref_espece VALUES ('EFI', 'Ethmalosa fimbriata', NULL, 23, 'Em', 'he-ph', 0.75, 3.1719999, 4, NULL);
INSERT INTO ref_espece VALUES ('EGU', 'Ephippion guttifer', NULL, 98, 'ME', 'p1-bt', 5.6399999, 2.8239999, 4, NULL);
INSERT INTO ref_espece VALUES ('ELA', 'Elops lacerta', NULL, 34, 'ME', 'p2-ge', 0.93000001, 2.9890001, 4, NULL);
INSERT INTO ref_espece VALUES ('ELE', 'Eleotris spp.', NULL, 33, NULL, NULL, 0.83999997, 3.075, 4, NULL);
INSERT INTO ref_espece VALUES ('ELS', 'Elops senegalensis', NULL, 34, 'Ma', 'p2-ge', 0, 0, 0, 'ELA');
INSERT INTO ref_espece VALUES ('EME', 'Schilbe mandibularis', NULL, 85, 'Ce', 'p2-ge', 0.34599999, 3.187, 1, NULL);
INSERT INTO ref_espece VALUES ('ENA', 'Echeneis naucrates', NULL, 32, 'Mo', 'p1-zo', 0.23800001, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('ENI', 'Schilbe niloticus', NULL, 85, 'C', NULL, 0.59200001, 3.154, 2, NULL);
INSERT INTO ref_espece VALUES ('EPG', 'Epinephelus guaza', 'syst�matique d`apres Seret et Leveque - remplace code EGA de VDG', 90, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ESE', 'Eleotris senegalensis', NULL, 33, 'Es', NULL, 8.2290001, 2.6170001, 1, NULL);
INSERT INTO ref_espece VALUES ('EVI', 'Eleotris vittata', NULL, 33, 'Es', NULL, 3.79, 2.7909999, 5, NULL);
INSERT INTO ref_espece VALUES ('FAC', 'Fodiator acutus', NULL, 37, 'Ma', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('FTA', 'Fistularia tabacaria', NULL, 38, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('FVI', 'Fistularia petimba', NULL, 38, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GAL', 'Galathea spp.', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GAN', 'Gobioides sagitta', NULL, 41, 'Es', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GDE', 'Galeoides decadactylus', NULL, 75, 'ME', 'p1-bt', 0.89999998, 3.1459999, 4, NULL);
INSERT INTO ref_espece VALUES ('GER', 'Gerres spp.', NULL, 40, NULL, NULL, 1.09, 3.135, 4, NULL);
INSERT INTO ref_espece VALUES ('GGU', 'Chonophorus lateristriga', NULL, 41, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GME', 'Eucinostomus melanopterus', NULL, 40, 'ME', 'om-ge', 0.5, 3.29, 4, NULL);
INSERT INTO ref_espece VALUES ('GMI', 'Gymnura micrura', NULL, 44, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GNE', 'Breinomyrus niger', NULL, 60, 'C', NULL, 0, 0, 0, 'PBA');
INSERT INTO ref_espece VALUES ('GNI', 'Gerres nigri', NULL, 40, 'Es', 'om-ge', 1.52, 3.056, 5, NULL);
INSERT INTO ref_espece VALUES ('GOB', 'Gobiidae spp.', NULL, 41, NULL, NULL, 0, 0, 0, 'ACS');
INSERT INTO ref_espece VALUES ('GRU', 'Gobius rubropunctatus', 'Baran (21/12/01)', 41, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GSE', 'Marcusenius senegalensis', NULL, 60, 'C', NULL, 0, 0, 0, 'MRU');
INSERT INTO ref_espece VALUES ('GTH', 'Yongeichthys thomasi', NULL, 41, 'Es', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GYA', 'Gymnura altavela', NULL, 44, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GYM', 'Gymnarchus spp.', NULL, 43, NULL, NULL, 0, 0, 0, 'GYN');
INSERT INTO ref_espece VALUES ('GYN', 'Gymnarchus niloticus', NULL, 43, 'C', NULL, 0.38999999, 2.9779999, 0, NULL);
INSERT INTO ref_espece VALUES ('HAF', 'Bostrychus africanus', NULL, 33, 'Es', 'p1-mc', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HBA', 'Hemiramphus balao', NULL, 46, 'Em', 'p1-zo', 0, 0, 0, 'HPI');
INSERT INTO ref_espece VALUES ('HBI', 'Hemichromis bimaculatus', NULL, 20, 'Co', NULL, 7.3330002, 2.8770001, 3, NULL);
INSERT INTO ref_espece VALUES ('HBL', 'Haplochromis bloyeti', NULL, 20, 'C', NULL, 1.378, 0.30599999, 3, NULL);
INSERT INTO ref_espece VALUES ('HBO', 'Hyperopisus bebe', 'ss-esp. occidentalis supprim�e le 7/02/02', 60, 'Co', 'p1-bt', 0.34999999, 3.151, 2, NULL);
INSERT INTO ref_espece VALUES ('HBR', 'Hemiramphus brasiliensis', NULL, 46, 'Em', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HEB', 'Heterobranchus bidorsalis', NULL, 22, 'Co', NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('HET', 'Heterobranchus spp.', '18/11/02', 22, 'C', NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('HFA', 'Hemichromis fasciatus', NULL, 20, 'Ec', 'p2-ge', 0.33000001, 3.3340001, 4, NULL);
INSERT INTO ref_espece VALUES ('HFO', 'Hydrocynus forskalii', NULL, 3, 'Co', 'p2-pi', 0.78899997, 3.098, 2, NULL);
INSERT INTO ref_espece VALUES ('HHA', 'Hippopotamyrus harringtoni', NULL, 60, 'C', NULL, 0, 0, 0, 'PBA');
INSERT INTO ref_espece VALUES ('HIN', 'Rhabdalestes septentrionalis', NULL, 3, 'Co', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HIP', 'Hippopotamyrus pictus', 'Mali 03', 60, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HIS', 'Heterobranchus isopterus', NULL, 22, 'Ce', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HLA', 'Hypleurochilus langi', 'Bamboung 09', 14, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HLO', 'Heterobranchus longifilis', NULL, 22, 'Ce', NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('HME', 'Synodontis membranaceus', NULL, 57, 'Co', NULL, 1.46, 3.119, 8, NULL);
INSERT INTO ref_espece VALUES ('HNI', 'Heterotis niloticus', NULL, 71, 'Co', NULL, 3.0150001, 2.865, 2, NULL);
INSERT INTO ref_espece VALUES ('HOD', 'Hepsetus odoe', NULL, 47, 'Co', 'p2-ge', 0, 0, 0, 'HYB');
INSERT INTO ref_espece VALUES ('HPI', 'Hyporamphus picarti', NULL, 46, 'Ma', 'he-de', 3.5190001, 2.6029999, 1, NULL);
INSERT INTO ref_espece VALUES ('HPU', 'Hippocampus algiricus', NULL, 96, 'Ma', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HYB', 'Hydrocynus brevis', NULL, 3, 'Co', 'p2-pi', 0.55000001, 3.201, 3, NULL);
INSERT INTO ref_espece VALUES ('HYD', 'Hydrocynus spp.', 'JME 15/05/03', 3, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('IAF', 'Ilisha africana', NULL, 23, 'Em', 'p1-zo', 2.73, 2.7909999, 4, NULL);
INSERT INTO ref_espece VALUES ('INC', 'Inconnu', NULL, 49, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('IND', 'Ind�termin�', 'VDG - Pgm Saloum', 49, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('KKR', 'Kribia kribensis', 'Baran (21/12/01)', 33, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LAB', 'Labeo spp.', 'JME 15/05/03', 26, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LAD', 'Laeviscutella dekimpei', NULL, 23, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LAF', 'Gymnothorax afer', NULL, 64, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LAG', 'Lutjanus agennes', 'Baran (21/12/01)', 53, 'Mo', NULL, 0, 0, 0, 'LGO');
INSERT INTO ref_espece VALUES ('LAT', 'Lethrinus atlanticus', NULL, 50, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LBA', 'Liza bandialensis', 'JME - 16/12/05 - espece nouvelle pgme Saloum - cf these PSD; 96', 62, NULL, NULL, 0, 0, 0, 'LGR');
INSERT INTO ref_espece VALUES ('LCO', 'Labeo coubie', NULL, 26, 'Co', NULL, 3.3469999, 2.9679999, 2, NULL);
INSERT INTO ref_espece VALUES ('LDU', 'Liza dumerili', NULL, 62, 'Em', 'he-de', 3.9100001, 2.7750001, 6, NULL);
INSERT INTO ref_espece VALUES ('LED', 'Lepidotrigla cadmani', NULL, 101, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LEN', 'Lutjanus endecacanthus', 'Baran (21/12/01)', 53, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LEP', 'Leptoc�phale', 'VDG - Pgm Saloum', 49, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LFA', 'Liza falcipinnis', NULL, 62, 'Em', 'he-de', 1.1900001, 2.987, 4, NULL);
INSERT INTO ref_espece VALUES ('LGL', 'Trachinotus ovatus', NULL, 15, 'Ma', 'p1-bt', 6.0320001, 2.6960001, 1, NULL);
INSERT INTO ref_espece VALUES ('LGO', 'Lutjanus goreensis', NULL, 53, 'Ma', 'p2-ge', 2.95, 2.8829999, 4, NULL);
INSERT INTO ref_espece VALUES ('LGR', 'Liza grandisquamis', NULL, 62, 'Em', 'he-de', 1.5700001, 2.9590001, 4, NULL);
INSERT INTO ref_espece VALUES ('LIA', 'Lichia amia', NULL, 15, 'Ma', 'p2-pi', 0, 0, 0, 'LGL');
INSERT INTO ref_espece VALUES ('LIZ', 'Liza spp', 'Demande JME 21/06/04', 62, NULL, NULL, 0, 0, 0, 'LFA');
INSERT INTO ref_espece VALUES ('LLA', 'Lagocephalus laevigatus', NULL, 98, 'Ma', 'p2-ge', 0, 0, 0, NULL);
INSERT INTO ref_espece VALUES ('LMO', 'Lithognathus mormyrus', NULL, 92, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LNI', 'Lates niloticus', NULL, 17, 'Co', 'p2-pi', 0.77399999, 3.089, 7, NULL);
INSERT INTO ref_espece VALUES ('LPA', 'Labeo parvus', 'Mali 03', 26, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LSE', 'Labeo senegalensis', NULL, 26, 'C', NULL, 2.3840001, 2.9949999, 2, NULL);
INSERT INTO ref_espece VALUES ('LSU', 'Lobotes surinamensis', NULL, 51, 'Mo', 'p2-ge', 0.042800002, 2.8399999, 8, NULL);
INSERT INTO ref_espece VALUES ('LUD', 'Lutjanus dentatus', NULL, 53, 'Mo', 'p2-ge', 0, 0, 0, 'LGO');
INSERT INTO ref_espece VALUES ('LUT', 'Lutjanus spp.', NULL, 53, NULL, NULL, 0, 0, 0, 'LGO');
INSERT INTO ref_espece VALUES ('MAN', 'Mormyrops anguilloides', NULL, 60, 'Co', 'p2-ge', 0, 0, 0, 'MDE');
INSERT INTO ref_espece VALUES ('MAR', 'Marcusenius spp.', 'JME 15/05/03', 60, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MBA', 'Mugil bananensis', NULL, 62, 'ME', 'he-de', 0.86000001, 3.0969999, 6, NULL);
INSERT INTO ref_espece VALUES ('MBR', 'Marcusenius bruyerei', NULL, 60, 'Co', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MCE', 'Mugil cephalus', NULL, 62, 'ME', 'he-ph', 0, 0, 0, 'MUG');
INSERT INTO ref_espece VALUES ('MCU', 'Mugil curema', NULL, 62, 'Em', 'he-ph', 1.02, 3.0650001, 4, NULL);
INSERT INTO ref_espece VALUES ('MCY', 'Marcusenius cyprinoides', NULL, 60, 'C', NULL, 0, 0, 0, 'MRU');
INSERT INTO ref_espece VALUES ('MDE', 'Mormyrops deliciosus', NULL, 60, 'C', NULL, 1.5, 2.8699999, 7, NULL);
INSERT INTO ref_espece VALUES ('MED', 'Meduse', NULL, 111, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MEL', 'Malapterurus electricus', NULL, 55, 'Co', NULL, 1.08, 3.069, 7, NULL);
INSERT INTO ref_espece VALUES ('MFU', 'Marcusenius furcidens', NULL, 60, 'Co', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MHA', 'Mormyrus hasselquistii', NULL, 60, 'Co', NULL, 1.6900001, 2.7449999, 8, NULL);
INSERT INTO ref_espece VALUES ('MIB', 'Microphis brachyurus', NULL, 96, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MIC', 'Micralestes spp.', 'JME - 18/12/02', 3, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MIE', 'Micralestes elongatus', 'JME - 18/12/02', 3, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MMA', 'Mormyrus macrophthalmus', NULL, 60, 'C', NULL, 1.288, 2.9330001, 2, NULL);
INSERT INTO ref_espece VALUES ('MOO', 'Mormyrops spp.', 'JME 15/05/03', 60, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MOR', 'Mormyrus spp.', 'JME 15/05/03', 60, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MOU', 'Mormyrops oudoti', NULL, 60, 'C', NULL, 0, 0, 0, 'MDE');
INSERT INTO ref_espece VALUES ('MPL', 'Myrophis plumbeus', NULL, 70, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MRU', 'Mormyrus rume', NULL, 60, 'Co', NULL, 1.288, 2.9330001, 2, NULL);
INSERT INTO ref_espece VALUES ('MTH', 'Marcusenius thomasi', NULL, 60, 'Co', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MUG', 'Mugilidae', NULL, 62, NULL, NULL, 1.45, 2.9749999, 4, NULL);
INSERT INTO ref_espece VALUES ('MUL', 'Mugil spp', 'Demande JME 21/06/04', 62, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MUR', 'Murex sp.', NULL, 65, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MVO', 'Macrobrachius volenvoli', NULL, 66, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('NHA', 'Nematopalaemon hastatus', '18/11/02', 105, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('NMA', 'Nematogobius maindroni', NULL, 41, 'Es', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('NUD', 'Nudibranche', 'demande JME 03/03', 111, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('OAU', 'Oreochromis aureus', NULL, 20, 'C', NULL, 0, 0, 0, 'TNI');
INSERT INTO ref_espece VALUES ('OLI', 'Calamar', NULL, 52, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('OOC', 'Gobionellus occidentalis', NULL, 41, 'Es', 'p1-bt', 118.5, 1.841, 1, NULL);
INSERT INTO ref_espece VALUES ('OUN', 'Orcynopsis unicolor', NULL, 87, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('OVU', 'Octopus vulgaris', NULL, 69, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PAA', 'Papyrochranus afer', NULL, 68, 'Co', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PAB', 'Pagellus bellotii', 'Demande JME 21/06/04', 92, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PAF', 'Panopeus africanus', NULL, 103, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PAN', 'Protopterus annectens', NULL, 80, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PAT', 'Parapenaeopsis atlantica', 'corrig� le 18/11/02 (anc. Parapeneus atlanticus ??)', 73, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PBA', 'Petrocephalus bane', NULL, 60, 'C', NULL, 0.76899999, 3.1760001, 2, NULL);
INSERT INTO ref_espece VALUES ('PBE', 'Psettodes belcheri', NULL, 81, 'Mo', 'p2-ge', 0.0057000001, 3.2218001, 8, NULL);
INSERT INTO ref_espece VALUES ('PBI', 'Polypterus bichir', NULL, 76, 'C', NULL, 0, 0, 0, 'PEN');
INSERT INTO ref_espece VALUES ('PBO', 'Petrocephalus bovei', NULL, 60, 'Co', 'p1-mc', 0, 0, 0, 'PBA');
INSERT INTO ref_espece VALUES ('PBR', 'Pseudotolithus brachygnathus', NULL, 86, 'ME', 'p2-ge', 0.36000001, 3.135, 4, NULL);
INSERT INTO ref_espece VALUES ('PDU', 'Penaeus notialis', NULL, 73, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PEA', 'Petrocephalus ansorgii', 'LTDM - Mali 01', 60, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PEF', 'Pellonula leonensis', NULL, 23, 'Ec', 'p1-mc', 2.02, 2.855, 4, NULL);
INSERT INTO ref_espece VALUES ('PEH', 'Pagrus caeruleostictus', NULL, 92, 'Ma', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PEL', 'Pseudotolithus elongatus', NULL, 86, 'Em', 'p2-ge', 0.27000001, 3.1930001, 4, NULL);
INSERT INTO ref_espece VALUES ('PEM', 'Penaeus monodon', 'Gambie 02', 73, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PEN', 'Polypterus endlicheri', NULL, 76, 'Co', 'p2-ge', 0.84799999, 3.0150001, 8, NULL);
INSERT INTO ref_espece VALUES ('PEP', 'Pseudotolithus epipercus', NULL, 86, 'Mo', 'p2-ge', 0, 0, 0, 'PSS');
INSERT INTO ref_espece VALUES ('PER', 'Thysia ansorgii', NULL, 20, 'Co', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PET', 'Petrocephalus spp.', 'demande JME 03/03', 60, 'C', NULL, 0, 0, 0, 'PBA');
INSERT INTO ref_espece VALUES ('PGU', 'Chromidotilapia guentheri', NULL, 20, 'Co', 'p1-mc', 2.1329999, 2.9860001, 3, NULL);
INSERT INTO ref_espece VALUES ('PHP', 'Parailia pellucida', NULL, 85, 'Ce', 'p1-bt', 0.43000001, 3.3710001, 8, NULL);
INSERT INTO ref_espece VALUES ('PIN', 'Pomadasys incisus', NULL, 45, 'Ma', 'p1-bt', 0, 0, 0, 'POM');
INSERT INTO ref_espece VALUES ('PIS', 'Pisodonophis semicinctus', 'Pisonodophis corrige en Pisodonophis le 27/03/06 (LT)', 70, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PJU', 'Pomadasys jubelini', NULL, 45, 'Em', 'p1-bt', 1.23, 3.043, 4, NULL);
INSERT INTO ref_espece VALUES ('PKE', 'Penaeus kerathurus', NULL, 73, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PLG', 'Solitas gruveli', NULL, 74, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PLM', 'Plectorhinchus macrolepis', NULL, 45, 'Em', 'p2-pi', 3.1400001, 2.915, 4, NULL);
INSERT INTO ref_espece VALUES ('PLO', 'Parapenaeus longirostris', '18/11/02', 73, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PMA', 'Parakuhlia macrophthalmus', 'Saloum 34 - Mars 04 - JDD', 45, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PME', 'Plectorhinchus mediteraneus', 'JME 25/02/05', 45, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PMO', 'Pseudotolithus moorii', NULL, 86, 'Ma', 'p1-bt', 0, 0, 0, 'PSS');
INSERT INTO ref_espece VALUES ('PNI', 'Cephalopholis nigri', NULL, 90, 'Mo', NULL, 0, 0, 0, 'EAE');
INSERT INTO ref_espece VALUES ('POB', 'Parachanna obscura', NULL, 19, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('POL', 'Polypterus spp.', NULL, 76, NULL, NULL, 0, 0, 0, 'PEN');
INSERT INTO ref_espece VALUES ('POM', 'Pomadasys spp.', NULL, 45, NULL, NULL, 3.1700001, 2.868, 4, NULL);
INSERT INTO ref_espece VALUES ('POQ', 'Polydactylus quadrifilis', NULL, 75, 'ME', 'p2-ge', 0.76999998, 3.0929999, 4, NULL);
INSERT INTO ref_espece VALUES ('PPA', 'Periophtalmus barbarus', NULL, 41, 'Es', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PPE', 'Pomadasys perotaei', NULL, 45, 'Em', 'p1-bt', 8.71, 2.677, 6, NULL);
INSERT INTO ref_espece VALUES ('PPR', 'Pseudupeneus prayensis', NULL, 63, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PQQ', 'Pentanemus quinquarius', NULL, 75, 'Ma', 'p2-ge', 0.1851, 3.3912001, 9, NULL);
INSERT INTO ref_espece VALUES ('PRA', 'Priacanthus arenatus', NULL, 79, 'Mo', 'p1-mc', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PRO', 'Pomadasys rogerii', NULL, 45, 'Mo', 'p1-bt', 0, 0, 0, 'POM');
INSERT INTO ref_espece VALUES ('PSB', 'Monodactylus sebae', NULL, 59, 'Es', 'p2-ge', 10.28, 2.7479999, 4, NULL);
INSERT INTO ref_espece VALUES ('PSE', 'Polypterus senegalus', 'ss-esp.  Senegalus supprim�e le 7/02/02', 76, 'C', NULL, 0, 0, 0, 'PEN');
INSERT INTO ref_espece VALUES ('PSN', 'Pseudotolithus senegalensis', NULL, 86, 'Ma', 'p2-ge', 0.30000001, 3.1819999, 4, NULL);
INSERT INTO ref_espece VALUES ('PSO', 'Petrocephalus soudanensis', 'LTDM - Mali 01', 60, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PSS', 'Pseudotolithus spp.', NULL, 86, NULL, NULL, 0.56, 3.0550001, 4, NULL);
INSERT INTO ref_espece VALUES ('PSU', 'Pomadasys suillus', NULL, 45, 'Mo', NULL, 0, 0, 0, 'POM');
INSERT INTO ref_espece VALUES ('PTB', 'Pteromylaeus bovinus', 'BBG 10 (27/03/06)', 67, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PTE', 'Petrocephalus tenuicauda', NULL, 60, 'Co', 'p1-mc', 0, 0, 0, 'PBA');
INSERT INTO ref_espece VALUES ('PTP', 'Pteroscion peli', NULL, 86, 'ME', 'p2-ge', 6.1500001, 2.6949999, 5, NULL);
INSERT INTO ref_espece VALUES ('PTR', 'Pegusa triophtalma', NULL, 91, 'Ma', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PTY', 'Pseudotolithus typus', NULL, 86, 'ME', 'p2-ge', 0.2613, 3.1503, 9, NULL);
INSERT INTO ref_espece VALUES ('PVA', 'Portunus validus', 'Bamboung 6', 78, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PYM', 'Pythonichthys macrurus', NULL, 48, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('RAC', 'Rhizoprionodon acutus', NULL, 16, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('RAL', 'Rhinobatos albomaculatus', NULL, 83, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('RBO', 'Rhinoptera bonasus', NULL, 67, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('RCA', 'Rachycentron canadum', NULL, 82, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('RCE', 'Rhinobatos cemiculus', NULL, 83, 'Ma', 'p2-ge', 9.1400003, 2.4579999, 6, NULL);
INSERT INTO ref_espece VALUES ('RHI', 'Rhinobatos spp.', NULL, 83, NULL, NULL, 0, 0, 0, 'RCE');
INSERT INTO ref_espece VALUES ('RNI', 'Raiamas nigeriensis', NULL, 26, 'C', NULL, 0, 0, 0, 'BDS');
INSERT INTO ref_espece VALUES ('RSE', 'Raiamas senegalensis', NULL, 26, 'C', NULL, 0, 0, 0, 'BDS');
INSERT INTO ref_espece VALUES ('SAC', 'Sarotherodon caudomarginatus', 'Baran (21/12/01)', 20, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SAL', 'Alectis alexandrinus', NULL, 15, 'Mo', 'p1-bt', 1.826, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('SAN', 'Scorpaena angolensis', NULL, 88, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SAR', 'Sardinella spp.', NULL, 23, NULL, NULL, 0, 0, 0, 'SEB');
INSERT INTO ref_espece VALUES ('SAU', 'Sardinella aurita', NULL, 23, 'Ma', 'om-ge', 0, 0, 0, 'SEB');
INSERT INTO ref_espece VALUES ('SBA', 'Synodontis bastiani', NULL, 57, 'Co', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SBU', 'Synodontis budgetti', NULL, 57, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SCA', 'Synaptura cadenati', NULL, 91, 'Mo', 'p1-bt', 0.63700002, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('SCH', 'Schilbe spp.', '18/11/02', 85, 'C', NULL, 0, 0, 0, 'SMY');
INSERT INTO ref_espece VALUES ('SCL', 'Synodontis clarias', NULL, 57, 'C', NULL, 2.2490001, 3.0699999, 2, NULL);
INSERT INTO ref_espece VALUES ('SCM', 'Scorpaena madurensis', NULL, 88, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SCO', 'Synodontys courteti', NULL, 57, 'C', NULL, 0, 0, 0, 'SYO');
INSERT INTO ref_espece VALUES ('SCR', 'Selar crumenophtalmus', NULL, 15, 'Ma', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SCS', 'Scorpaena scrofa', NULL, 88, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SCU', 'Sarmatum curvatum', NULL, 111, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SEB', 'Sardinella maderensis', NULL, 23, 'ME', 'om-ge', 1.61, 2.9779999, 4, NULL);
INSERT INTO ref_espece VALUES ('SEP', 'Sepia sp.', NULL, 89, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SEU', 'Synodontis eupterus', NULL, 57, 'C', NULL, 9.1739998, 2.779, 2, NULL);
INSERT INTO ref_espece VALUES ('SFI', 'Stromateus fiatola', NULL, 95, 'Mo', 'p2-ge', 1.9299999, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('SGA', 'Sarotherodon galilaeus', NULL, 20, 'C', NULL, 1.778, 3.04, 11, NULL);
INSERT INTO ref_espece VALUES ('SGU', 'Sphyraena guachancho', NULL, 93, 'ME', 'p2-pi', 0, 0, 0, 'SPI');
INSERT INTO ref_espece VALUES ('SHI', 'Stephanolepis hispidus', NULL, 58, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SHO', 'Scarus hoefleri', NULL, 84, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SHU', 'Sesarma (chiromantes) huzardi', NULL, 42, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SIA', 'Siluranodon auritus', NULL, 85, 'C', NULL, 3, 3, 2, NULL);
INSERT INTO ref_espece VALUES ('SIN', 'Schilbe intermedius', NULL, 85, 'Ce', 'p1-mc', 0.2701, 3.2593, 9, NULL);
INSERT INTO ref_espece VALUES ('SKA', 'Enneacampus kaupi', NULL, 96, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SLE', 'Sierrathrissa leonensis', NULL, 23, 'C', NULL, 0, 0, 0, 'PEF');
INSERT INTO ref_espece VALUES ('SLU', 'Synaptura lusitanica', NULL, 91, 'Ma', 'p1-bt', 0.63700002, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('SMI', 'Schilbe micropogon', NULL, 85, 'Co', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SMY', 'Schilbe mystus', NULL, 85, 'Ce', NULL, 6.447, 2.5680001, 1, NULL);
INSERT INTO ref_espece VALUES ('SNE', 'Synodontis nigrita', NULL, 57, 'C', NULL, 7.3940001, 2.8429999, 2, NULL);
INSERT INTO ref_espece VALUES ('SOC', 'Synodontis ocellifer', NULL, 57, 'C', NULL, 2.28, 2.9920001, 7, NULL);
INSERT INTO ref_espece VALUES ('SOL', 'Solea spp.', NULL, 91, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SPA', 'Saurida brasiliensis', NULL, 97, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SPE', 'Syngnathus pelagicus', 'Bamboung 02', 96, 'Ma', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SPH', 'Sphyraena spp.', 'JME 15/05/03', 93, NULL, NULL, 0, 0, 0, 'SPI');
INSERT INTO ref_espece VALUES ('SPI', 'Sphyraena afra', NULL, 93, 'ME', 'p2-pi', 1.84, 2.8010001, 4, NULL);
INSERT INTO ref_espece VALUES ('SQM', 'Squilla mantis', NULL, 94, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SSC', 'Synodontis schall', NULL, 57, 'Co', 'om-ge', 3.9860001, 2.951, 2, NULL);
INSERT INTO ref_espece VALUES ('SSO', 'Synodontis sorex', NULL, 57, 'C', NULL, 2.0239999, 3.0369999, 2, NULL);
INSERT INTO ref_espece VALUES ('SSP', 'Sphoeroides spengleri', NULL, 98, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SST', 'Scorpaena stephanica', '25/11/02 (Saloum 31)', 88, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('STE', 'Stenorynchus', NULL, 54, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SY1', 'Synodontis sp. 1', 'Mali 03', 57, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SYF', 'Synodontis filamentosus', NULL, 57, 'C', NULL, 3, 3, 2, NULL);
INSERT INTO ref_espece VALUES ('SYG', 'Synodontis gambiensis', NULL, 57, 'Ce', 'om-ge', 0.14910001, 3.4765, 9, NULL);
INSERT INTO ref_espece VALUES ('SYN', 'Syngnathidae', NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SYO', 'Synodontis spp.', NULL, 57, NULL, NULL, 0.389, 3.29, 11, NULL);
INSERT INTO ref_espece VALUES ('TAT', 'Megalops atlanticus', NULL, 56, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TBR', 'Tilapia brevimanus', NULL, 20, 'Co', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TBU', 'Tilapia buttikoferi', 'Baran (21/12/01)', 20, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TCR', 'Tylosurus crocodilus', NULL, 13, 'Mo', 'p2-pi', 0, 0, 0, 'HPI');
INSERT INTO ref_espece VALUES ('TDA', 'Tilapia dageti', NULL, 20, 'C', NULL, 0, 0, 0, 'TIL');
INSERT INTO ref_espece VALUES ('TET', 'Tetraodon sp.', NULL, 98, NULL, NULL, 0, 0, 0, 'LLA');
INSERT INTO ref_espece VALUES ('TFA', 'Trachinotus teraia', NULL, 15, 'Em', 'p1-bt', 1.84, 3.049, 4, NULL);
INSERT INTO ref_espece VALUES ('TGO', 'Trachinotus goreensis', 'Demande JME 21/06/04', 15, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TGU', 'Tilapia guineensis', NULL, 20, 'Es', 'he-ph', 3.6900001, 2.898, 4, NULL);
INSERT INTO ref_espece VALUES ('THE', 'Sarotherodon melanotheron', NULL, 20, 'Es', 'he-ph', 6.7800002, 2.7780001, 4, NULL);
INSERT INTO ref_espece VALUES ('TIL', 'Tilapia spp.', NULL, 20, NULL, NULL, 4.5799999, 2.8559999, 4, NULL);
INSERT INTO ref_espece VALUES ('TIN', 'Tylochromis intermedius', NULL, 20, 'Co', 'he-de', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TJE', 'Tylochromis jentinki', NULL, 20, 'Es', 'he-de', 1.378, 3.0580001, 1, NULL);
INSERT INTO ref_espece VALUES ('TLE', 'Trichiurus lepturus', NULL, 100, 'ME', 'p2-pi', 0.003, 3.473, 4, NULL);
INSERT INTO ref_espece VALUES ('TLI', 'Tetraodon lineatus', NULL, 98, 'C', NULL, 3.1800001, 3, 8, NULL);
INSERT INTO ref_espece VALUES ('TMA', 'Tilapia mariae', NULL, 20, 'Ec', 'om-ge', 0, 0, 0, 'TIL');
INSERT INTO ref_espece VALUES ('TMY', 'Trachinocephalus myops', 'Bamboung 8', 97, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TNI', 'Oreochromis niloticus', NULL, 20, 'Co', NULL, 2.1329999, 2.9860001, 2, NULL);
INSERT INTO ref_espece VALUES ('TOM', 'Torpedo marmorata', NULL, 99, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TOR', 'Torpedo sp.', NULL, 99, NULL, 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TRA', 'Tylosurus acus rafale', NULL, 13, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TRM', 'Trachinotus maxillosus', 'Demande JME 21/06/04', 15, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TSU', 'Tylochromis sudanensis', 'DCN (4/02/02)', 20, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TTR', 'Trachurus trecae', NULL, 15, 'Mo', 'p1-zo', 0, 0, 0, 'CAR');
INSERT INTO ref_espece VALUES ('TYL', 'Tylochromis leonensis', NULL, 20, 'Co', 'he-de', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TZI', 'Tilapia zillii', NULL, 20, 'C', NULL, 2.138, 2.96, 11, NULL);
INSERT INTO ref_espece VALUES ('UAF', 'Urogymnus asperrimus', NULL, 29, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('UCA', 'Umbrina canariensis', NULL, 86, NULL, NULL, 1.1, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('ULE', 'Uroconger lepturus', NULL, 24, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('URO', 'Umbrina ronchus', 'Gambie 02', 86, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('UTA', 'Uca tangeri', '18/11/02', 106, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('VSE', 'Selene dorsalis', NULL, 15, 'ME', 'p2-ge', 6.0300002, 2.7190001, 4, NULL);
INSERT INTO ref_espece VALUES ('ZFA', 'Zeus faber', NULL, 104, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);


--
-- Data for Name: ref_famille; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_famille VALUES (72, 'Paralichthyidae', 24, 0);
INSERT INTO ref_famille VALUES (18, 'Chaetodontidae', 23, 0);
INSERT INTO ref_famille VALUES (6, 'Aplocheilidae', 12, 0);
INSERT INTO ref_famille VALUES (64, 'Muraenidae', 2, 0);
INSERT INTO ref_famille VALUES (24, 'Congridae', 2, 0);
INSERT INTO ref_famille VALUES (75, 'Polynemidae', 23, 0);
INSERT INTO ref_famille VALUES (53, 'Lutjanidae', 23, 0);
INSERT INTO ref_famille VALUES (44, 'Gymnuridae', 26, 0);
INSERT INTO ref_famille VALUES (15, 'Carangidae', 23, 0);
INSERT INTO ref_famille VALUES (52, 'Loliginidae', 33, 1);
INSERT INTO ref_famille VALUES (103, 'Xanthidae', 13, 1);
INSERT INTO ref_famille VALUES (20, 'Cichlidae', 23, 0);
INSERT INTO ref_famille VALUES (51, 'Lobotidae', 23, 0);
INSERT INTO ref_famille VALUES (2, 'Albulidae', 1, 0);
INSERT INTO ref_famille VALUES (74, 'Platycephalidae', 27, 0);
INSERT INTO ref_famille VALUES (55, 'Malapterudidae', 29, 0);
INSERT INTO ref_famille VALUES (79, 'Priacanthidae', 23, 0);
INSERT INTO ref_famille VALUES (102, 'Volutidae', 7, 1);
INSERT INTO ref_famille VALUES (90, 'Serranidae', 23, 0);
INSERT INTO ref_famille VALUES (23, 'Clupeidae', 10, 0);
INSERT INTO ref_famille VALUES (89, 'Sepiidae', 28, 1);
INSERT INTO ref_famille VALUES (4, 'Anabantidae', 23, 0);
INSERT INTO ref_famille VALUES (1, 'Acanthuridae', 23, 0);
INSERT INTO ref_famille VALUES (99, 'Torpedinidae', 34, 0);
INSERT INTO ref_famille VALUES (69, 'Octopodidae', 20, 1);
INSERT INTO ref_famille VALUES (86, 'Sciaenidae', 23, 0);
INSERT INTO ref_famille VALUES (19, 'Channidae', 23, 0);
INSERT INTO ref_famille VALUES (8, 'Apogonidae', 23, 0);
INSERT INTO ref_famille VALUES (57, 'Mochokidae', 29, 0);
INSERT INTO ref_famille VALUES (29, 'Dasyatidae', 26, 0);
INSERT INTO ref_famille VALUES (85, 'Schilbeidae', 29, 0);
INSERT INTO ref_famille VALUES (31, 'Drepaneidae', 23, 0);
INSERT INTO ref_famille VALUES (106, 'Ocypodidae', 13, 1);
INSERT INTO ref_famille VALUES (28, 'Dactylopteridae', 27, 0);
INSERT INTO ref_famille VALUES (76, 'Polypteridae', 25, 0);
INSERT INTO ref_famille VALUES (14, 'Blenniidae', 23, 0);
INSERT INTO ref_famille VALUES (42, 'Grapsidae', 13, 1);
INSERT INTO ref_famille VALUES (56, 'Megalopidae', 14, 0);
INSERT INTO ref_famille VALUES (43, 'Gymnarchidae', 22, 0);
INSERT INTO ref_famille VALUES (71, 'Osteoglossidae', 22, 0);
INSERT INTO ref_famille VALUES (111, 'Inconnu non poisson', 39, 1);
INSERT INTO ref_famille VALUES (38, 'Fistulariidae', 31, 0);
INSERT INTO ref_famille VALUES (96, 'Syngnathidae', 31, 0);
INSERT INTO ref_famille VALUES (34, 'Elopidae', 14, 0);
INSERT INTO ref_famille VALUES (105, 'Palaemonidae', 13, 1);
INSERT INTO ref_famille VALUES (39, 'Galatheidae', 13, 1);
INSERT INTO ref_famille VALUES (16, 'Carcharhinidae', 8, 0);
INSERT INTO ref_famille VALUES (107, 'Ostreidae', 36, 1);
INSERT INTO ref_famille VALUES (5, 'Antennariidae', 17, 0);
INSERT INTO ref_famille VALUES (26, 'Cyprinidae', 11, 0);
INSERT INTO ref_famille VALUES (32, 'Echeneidae', 23, 0);
INSERT INTO ref_famille VALUES (3, 'Alestiidae', 9, 0);
INSERT INTO ref_famille VALUES (40, 'Gerreidae', 23, 0);
INSERT INTO ref_famille VALUES (87, 'Scombridae', 23, 0);
INSERT INTO ref_famille VALUES (70, 'Ophichthidae', 2, 0);
INSERT INTO ref_famille VALUES (100, 'Trichiuridae', 23, 0);
INSERT INTO ref_famille VALUES (49, 'Inconnu Poisson', 15, 0);
INSERT INTO ref_famille VALUES (81, 'Psettodidae', 24, 0);
INSERT INTO ref_famille VALUES (62, 'Mugilidae', 23, 0);
INSERT INTO ref_famille VALUES (47, 'Hepsetidae', 9, 0);
INSERT INTO ref_famille VALUES (17, 'Centropomidae', 23, 0);
INSERT INTO ref_famille VALUES (84, 'Scaridae', 23, 0);
INSERT INTO ref_famille VALUES (67, 'Myliobatidae', 26, 0);
INSERT INTO ref_famille VALUES (12, 'Batrachoididae', 5, 0);
INSERT INTO ref_famille VALUES (59, 'Monodactylidae', 23, 0);
INSERT INTO ref_famille VALUES (37, 'Exocoetidae', 6, 0);
INSERT INTO ref_famille VALUES (68, 'Notopteridae', 22, 0);
INSERT INTO ref_famille VALUES (7, 'Aplysiidae', 21, 1);
INSERT INTO ref_famille VALUES (88, 'Scorpaenidae', 27, 0);
INSERT INTO ref_famille VALUES (65, 'Muricidae', 19, 1);
INSERT INTO ref_famille VALUES (93, 'Sphyraenidae', 23, 0);
INSERT INTO ref_famille VALUES (46, 'Hemiramphidae', 6, 0);
INSERT INTO ref_famille VALUES (66, 'Mycetophilidae', 18, 1);
INSERT INTO ref_famille VALUES (45, 'Haemulidae', 23, 0);
INSERT INTO ref_famille VALUES (82, 'Rhachycentridae', 23, 0);
INSERT INTO ref_famille VALUES (25, 'Cynoglossidae', 24, 0);
INSERT INTO ref_famille VALUES (97, 'Synodontidae', 4, 0);
INSERT INTO ref_famille VALUES (50, 'Lethrinidae', 23, 0);
INSERT INTO ref_famille VALUES (27, 'Cyprinodontidae', 12, 0);
INSERT INTO ref_famille VALUES (33, 'Eleotridae', 23, 0);
INSERT INTO ref_famille VALUES (11, 'Balistidae', 32, 0);
INSERT INTO ref_famille VALUES (109, 'Atherinidae', 38, 0);
INSERT INTO ref_famille VALUES (91, 'Soleidae', 24, 0);
INSERT INTO ref_famille VALUES (63, 'Mullidae', 23, 0);
INSERT INTO ref_famille VALUES (48, 'Heterenchelyidae', 2, 0);
INSERT INTO ref_famille VALUES (41, 'Gobiidae', 23, 0);
INSERT INTO ref_famille VALUES (80, 'Protopteridae', 16, 0);
INSERT INTO ref_famille VALUES (9, 'Ariidae', 29, 0);
INSERT INTO ref_famille VALUES (104, 'Zeidae', 35, 0);
INSERT INTO ref_famille VALUES (22, 'Clariidae', 29, 0);
INSERT INTO ref_famille VALUES (54, 'Magidae', 13, 1);
INSERT INTO ref_famille VALUES (36, 'Ephippidae', 23, 0);
INSERT INTO ref_famille VALUES (94, 'Squillidae', 30, 1);
INSERT INTO ref_famille VALUES (77, 'Pomacentridae', 23, 0);
INSERT INTO ref_famille VALUES (61, 'Moronidae', 23, 0);
INSERT INTO ref_famille VALUES (30, 'Diodontidae', 32, 0);
INSERT INTO ref_famille VALUES (13, 'Belonidae', 6, 0);
INSERT INTO ref_famille VALUES (92, 'Sparidae', 23, 0);
INSERT INTO ref_famille VALUES (58, 'Monacanthidae', 32, 0);
INSERT INTO ref_famille VALUES (83, 'Rhinobatidae', 26, 0);
INSERT INTO ref_famille VALUES (10, 'Bagridae', 29, 0);
INSERT INTO ref_famille VALUES (108, 'Arcidae', 37, 1);
INSERT INTO ref_famille VALUES (21, 'Citharinidae', 9, 0);
INSERT INTO ref_famille VALUES (73, 'Penaeidae', 13, 1);
INSERT INTO ref_famille VALUES (35, 'Engraulidae', 10, 0);
INSERT INTO ref_famille VALUES (101, 'Triglidae', 27, 0);
INSERT INTO ref_famille VALUES (98, 'Tetraodontidae', 32, 0);
INSERT INTO ref_famille VALUES (60, 'Mormyridae', 22, 0);
INSERT INTO ref_famille VALUES (78, 'Portunidae', 13, 1);
INSERT INTO ref_famille VALUES (95, 'Stromateidae', 23, 0);


--
-- Data for Name: ref_ordre; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_ordre VALUES (1, 'Albuliformes');
INSERT INTO ref_ordre VALUES (2, 'Anguilliformes');
INSERT INTO ref_ordre VALUES (4, 'Aulopiformes');
INSERT INTO ref_ordre VALUES (5, 'Batrachoidiformes');
INSERT INTO ref_ordre VALUES (6, 'Beloniformes');
INSERT INTO ref_ordre VALUES (7, 'Caenogast�ropodes');
INSERT INTO ref_ordre VALUES (8, 'Carcharhiniformes');
INSERT INTO ref_ordre VALUES (9, 'Characiformes');
INSERT INTO ref_ordre VALUES (10, 'Clup�iformes');
INSERT INTO ref_ordre VALUES (11, 'Cypriniformes');
INSERT INTO ref_ordre VALUES (12, 'Cyprinodontiformes');
INSERT INTO ref_ordre VALUES (13, 'D�capodes');
INSERT INTO ref_ordre VALUES (14, 'Elopiformes');
INSERT INTO ref_ordre VALUES (15, 'Inconnu Poisson');
INSERT INTO ref_ordre VALUES (16, 'Lepidosir�niformes');
INSERT INTO ref_ordre VALUES (17, 'Lophiiformes');
INSERT INTO ref_ordre VALUES (18, 'Nematoc�res');
INSERT INTO ref_ordre VALUES (19, 'Neogast�ropodes');
INSERT INTO ref_ordre VALUES (20, 'Octopodes');
INSERT INTO ref_ordre VALUES (21, 'Opisthobranches');
INSERT INTO ref_ordre VALUES (22, 'Ost�oglossiformes');
INSERT INTO ref_ordre VALUES (23, 'Perciformes');
INSERT INTO ref_ordre VALUES (24, 'Pleuronectiformes');
INSERT INTO ref_ordre VALUES (25, 'Polypt�riformes');
INSERT INTO ref_ordre VALUES (26, 'Rajiformes');
INSERT INTO ref_ordre VALUES (27, 'Scorpaeniformes');
INSERT INTO ref_ordre VALUES (28, 'Sepiida');
INSERT INTO ref_ordre VALUES (29, 'Siluriformes');
INSERT INTO ref_ordre VALUES (30, 'Stomatopodes');
INSERT INTO ref_ordre VALUES (31, 'Syngnathiformes');
INSERT INTO ref_ordre VALUES (32, 'T�traodontiformes');
INSERT INTO ref_ordre VALUES (33, 'Teutho�d�s');
INSERT INTO ref_ordre VALUES (34, 'Torp�diniformes');
INSERT INTO ref_ordre VALUES (35, 'Zeiformes');
INSERT INTO ref_ordre VALUES (36, 'Filibranches');
INSERT INTO ref_ordre VALUES (37, 'Arcoida');
INSERT INTO ref_ordre VALUES (38, 'Atheriniformes');
INSERT INTO ref_ordre VALUES (39, 'Inconnu non poisson');


--
-- Data for Name: ref_origine_kb; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_origine_kb VALUES (0, 'Inconnu');
INSERT INTO ref_origine_kb VALUES (1, 'Bert & Ecoutin, 1982');
INSERT INTO ref_origine_kb VALUES (2, 'Delta Central du Niger');
INSERT INTO ref_origine_kb VALUES (3, 'Lacs Maliens');
INSERT INTO ref_origine_kb VALUES (4, 'Ecoutin & Albaret, 2003');
INSERT INTO ref_origine_kb VALUES (5, 'Lagune Ebri� (Ecoutin & Albaret, 2003)');
INSERT INTO ref_origine_kb VALUES (6, 'Sin� Saloum (Ecoutin & Albaret, 2003)');
INSERT INTO ref_origine_kb VALUES (7, 'Fishbase (mediane)');
INSERT INTO ref_origine_kb VALUES (8, 'Fishbase (article)');
INSERT INTO ref_origine_kb VALUES (9, 'Estuaire de la Gambie');
INSERT INTO ref_origine_kb VALUES (10, 'Toutes donnees MEL');
INSERT INTO ref_origine_kb VALUES (11, 'Peuplements Lacs Maliens');
INSERT INTO ref_origine_kb VALUES (12, 'Moyenne b=3');


--
-- Data for Name: ref_pays; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_pays VALUES ('BN', 'Benin');
INSERT INTO ref_pays VALUES ('GA', 'Gambia, The');
INSERT INTO ref_pays VALUES ('GH', 'Ghana');
INSERT INTO ref_pays VALUES ('GV', 'Guinee');
INSERT INTO ref_pays VALUES ('IN', 'Inconnu');
INSERT INTO ref_pays VALUES ('IV', 'Cote d''Ivoire');
INSERT INTO ref_pays VALUES ('LI', 'Liberia');
INSERT INTO ref_pays VALUES ('ML', 'Mali');
INSERT INTO ref_pays VALUES ('MR', 'Mauritanie');
INSERT INTO ref_pays VALUES ('NG', 'Niger');
INSERT INTO ref_pays VALUES ('PU', 'Guinee Bissau');
INSERT INTO ref_pays VALUES ('SG', 'Senegal');
INSERT INTO ref_pays VALUES ('SL', 'Sierra Leone');
INSERT INTO ref_pays VALUES ('TO', 'Togo');
INSERT INTO ref_pays VALUES ('UV', 'Burkina Faso');


--
-- Data for Name: ref_secteur; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_secteur VALUES (1, 1, 'Inconnu', 0, 1);
INSERT INTO ref_secteur VALUES (2, 1, 'Secteur I', 22, 3);
INSERT INTO ref_secteur VALUES (3, 2, 'Secteur II', 62, 3);
INSERT INTO ref_secteur VALUES (4, 3, 'Secteur III', 71, 3);
INSERT INTO ref_secteur VALUES (5, 4, 'Secteur IV', 86, 3);
INSERT INTO ref_secteur VALUES (6, 5, 'Secteur V', 170, 3);
INSERT INTO ref_secteur VALUES (7, 6, 'Secteur VI', 135, 3);
INSERT INTO ref_secteur VALUES (8, 1, 'Niger Amont', 0, 4);
INSERT INTO ref_secteur VALUES (9, 2, 'Djenneri', 0, 4);
INSERT INTO ref_secteur VALUES (10, 3, 'Diaka', 0, 4);
INSERT INTO ref_secteur VALUES (11, 4, 'Lacs', 2240, 4);
INSERT INTO ref_secteur VALUES (12, 5, 'Nord Dunaire', 0, 4);
INSERT INTO ref_secteur VALUES (13, 6, 'Niger Aval', 0, 4);
INSERT INTO ref_secteur VALUES (14, 1, 'Barrage', 0, 5);
INSERT INTO ref_secteur VALUES (15, 2, 'Centre', 0, 5);
INSERT INTO ref_secteur VALUES (16, 3, 'Amont', 0, 5);
INSERT INTO ref_secteur VALUES (18, 1, 'Barrage', 0, 6);
INSERT INTO ref_secteur VALUES (19, 2, 'Sankarani', 0, 6);
INSERT INTO ref_secteur VALUES (20, 3, 'Bale', 0, 6);
INSERT INTO ref_secteur VALUES (21, 1, 'Secteur I', 0, 7);
INSERT INTO ref_secteur VALUES (22, 2, 'Secteur II', 0, 7);
INSERT INTO ref_secteur VALUES (23, 1, 'Aval', 0, 10);
INSERT INTO ref_secteur VALUES (24, 2, 'Centre', 0, 10);
INSERT INTO ref_secteur VALUES (25, 3, 'Amont', 0, 10);
INSERT INTO ref_secteur VALUES (26, 1, 'Bandiala Aval', 0, 8);
INSERT INTO ref_secteur VALUES (27, 2, 'Bandiala Centre', 0, 8);
INSERT INTO ref_secteur VALUES (28, 3, 'Bandiala Amont', 0, 8);
INSERT INTO ref_secteur VALUES (29, 4, 'Diomboss', 0, 8);
INSERT INTO ref_secteur VALUES (30, 5, 'Saloum aval', 0, 8);
INSERT INTO ref_secteur VALUES (31, 6, 'Saloum zone 6', 0, 8);
INSERT INTO ref_secteur VALUES (32, 7, 'Saloum zone 7', 0, 8);
INSERT INTO ref_secteur VALUES (33, 8, 'Saloum amont', 0, 8);
INSERT INTO ref_secteur VALUES (34, 1, 'Nord', 0, 2);
INSERT INTO ref_secteur VALUES (35, 2, 'Sud', 0, 2);
INSERT INTO ref_secteur VALUES (36, 3, 'Tendo', 0, 2);
INSERT INTO ref_secteur VALUES (37, 4, 'Ehy', 0, 2);
INSERT INTO ref_secteur VALUES (38, 9, 'Mer devant Saloum', 0, 8);
INSERT INTO ref_secteur VALUES (39, 1, 'Aval', 0, 12);
INSERT INTO ref_secteur VALUES (40, 2, 'Centre', 0, 12);
INSERT INTO ref_secteur VALUES (41, 3, 'Amont', 0, 12);
INSERT INTO ref_secteur VALUES (42, 1, 'Dangara', 0, 13);
INSERT INTO ref_secteur VALUES (43, 1, 'Embouchure', 0, 14);
INSERT INTO ref_secteur VALUES (44, 2, 'Aval', 0, 14);
INSERT INTO ref_secteur VALUES (45, 3, 'Centre', 0, 14);
INSERT INTO ref_secteur VALUES (46, 4, 'Amont', 0, 14);
INSERT INTO ref_secteur VALUES (47, 4, 'Bale Centre', 0, 6);
INSERT INTO ref_secteur VALUES (48, 5, 'Bale Amont', 0, 6);
INSERT INTO ref_secteur VALUES (49, 6, 'Sankarani Centre', 0, 6);
INSERT INTO ref_secteur VALUES (50, 7, 'Sankarani Amont', 0, 6);
INSERT INTO ref_secteur VALUES (51, 1, 'Bolong Bamboung', 0, 17);
INSERT INTO ref_secteur VALUES (52, 1, 'Bijagos', 0, 15);
INSERT INTO ref_secteur VALUES (53, 1, 'Rio Buba', 0, 16);


--
-- Data for Name: ref_systeme; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_systeme VALUES (1, 'Inconnu', 'IN', 0);
INSERT INTO ref_systeme VALUES (2, 'Lagune Aby', 'IV', 424);
INSERT INTO ref_systeme VALUES (3, 'Lagune Ebrie', 'IV', 566);
INSERT INTO ref_systeme VALUES (4, 'Delta Central du Niger', 'ML', 27986);
INSERT INTO ref_systeme VALUES (5, 'Lac de Manantali', 'ML', 485);
INSERT INTO ref_systeme VALUES (6, 'Lac de Selingue', 'ML', 409);
INSERT INTO ref_systeme VALUES (7, 'Lac Togo', 'TO', 64);
INSERT INTO ref_systeme VALUES (8, 'Sine Saloum', 'SG', 900);
INSERT INTO ref_systeme VALUES (9, 'Lac de Korientze', 'ML', 0);
INSERT INTO ref_systeme VALUES (10, 'Estuaire de la Gambie', 'GA', 864);
INSERT INTO ref_systeme VALUES (11, 'Lagune de Grand Lahou', 'IV', 190);
INSERT INTO ref_systeme VALUES (12, 'Casamance', 'SG', 0);
INSERT INTO ref_systeme VALUES (13, 'Dangara', 'GV', 0);
INSERT INTO ref_systeme VALUES (14, 'Estuaire de la Fatala', 'GV', 0);
INSERT INTO ref_systeme VALUES (15, 'Archipel des Bijagos', 'PU', 0);
INSERT INTO ref_systeme VALUES (16, 'Rio Buba', 'PU', 0);
INSERT INTO ref_systeme VALUES (17, 'Bolong Bamboung', 'SG', 0.68000001);


--
-- Data for Name: sys_activites_a_migrer; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46302, 167, 167, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46303, 168, 168, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46304, 169, 169, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46305, 170, 170, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46306, 171, 171, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46307, 172, 172, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46308, 173, 173, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46309, 174, 174, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46310, 175, 175, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46311, 176, 176, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46312, 177, 177, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46313, 178, 178, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46314, 179, 179, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46315, 180, 180, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46316, 181, 181, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46317, 182, 182, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46318, 183, 183, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46319, 184, 184, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46320, 185, 185, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46321, 186, 186, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46322, 187, 187, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46323, 188, 188, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46324, 189, 189, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46325, 190, 190, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46326, 191, 191, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46327, 192, 192, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46328, 193, 193, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46329, 194, 194, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46330, 195, 195, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46331, 196, 196, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46332, 197, 197, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46333, 198, 198, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46334, 199, 199, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46335, 200, 200, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46336, 201, 201, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46337, 202, 202, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46338, 203, 203, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46339, 110, 110, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46340, 111, 111, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46341, 112, 112, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46342, 113, 113, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46343, 114, 114, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46344, 115, 115, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46345, 116, 116, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46346, 117, 117, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46347, 118, 118, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46348, 119, 119, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46349, 120, 120, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46350, 121, 121, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46351, 122, 122, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46352, 123, 123, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46353, 124, 124, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46354, 125, 125, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46355, 126, 126, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46356, 127, 127, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46357, 128, 128, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46358, 129, 129, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46359, 130, 130, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46360, 131, 131, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46361, 132, 132, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46362, 133, 133, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46363, 134, 134, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46364, 135, 135, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46365, 136, 136, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46366, 137, 137, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46367, 138, 138, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46368, 139, 139, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46369, 140, 140, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46370, 141, 141, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46371, 142, 142, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46372, 143, 143, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46373, 144, 144, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46374, 145, 145, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46375, 146, 146, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46376, 147, 147, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46377, 148, 148, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46378, 149, 149, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46379, 150, 150, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46380, 151, 151, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46381, 152, 152, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46382, 153, 153, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46383, 154, 154, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46384, 155, 155, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46385, 156, 156, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46386, 157, 157, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46387, 158, 158, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46388, 159, 159, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46389, 160, 160, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46390, 161, 161, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46391, 162, 162, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46392, 163, 163, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46393, 164, 164, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46394, 165, 165, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46395, 166, 166, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46396, 55, 55, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46397, 56, 56, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46398, 57, 57, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46399, 58, 58, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46400, 59, 59, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46401, 60, 60, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46402, 61, 61, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46403, 62, 62, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46404, 63, 63, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46405, 64, 64, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46406, 65, 65, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46407, 66, 66, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46408, 67, 67, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46409, 68, 68, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46410, 69, 69, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46411, 70, 70, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46412, 71, 71, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46413, 72, 72, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46414, 73, 73, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46415, 74, 74, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46416, 75, 75, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46417, 76, 76, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46418, 77, 77, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46419, 78, 78, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46420, 79, 79, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46421, 80, 80, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46422, 81, 81, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46423, 82, 82, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46424, 83, 83, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46425, 84, 84, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46426, 85, 85, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46427, 86, 86, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46428, 87, 87, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46429, 88, 88, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46430, 89, 89, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46431, 90, 90, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46432, 91, 91, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46433, 92, 92, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46434, 93, 93, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46435, 94, 94, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46436, 95, 95, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46437, 96, 96, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46438, 97, 97, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46439, 98, 98, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46440, 99, 99, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46441, 100, 100, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46442, 101, 101, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46443, 102, 102, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46444, 103, 103, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46445, 104, 104, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46446, 105, 105, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46447, 106, 106, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46448, 107, 107, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46449, 108, 108, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46450, 109, 109, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46451, 1, 1, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46452, 2, 2, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46453, 3, 3, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46454, 4, 4, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46455, 5, 5, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46456, 6, 6, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46457, 7, 7, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46458, 8, 8, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46459, 9, 9, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46460, 10, 10, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46461, 11, 11, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46462, 12, 12, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46463, 13, 13, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46464, 14, 14, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46465, 15, 15, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46466, 16, 16, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46467, 17, 17, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46468, 18, 18, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46469, 19, 19, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46470, 20, 20, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46471, 21, 21, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46472, 22, 22, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46473, 23, 23, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46474, 24, 24, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46475, 25, 25, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46476, 26, 26, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46477, 27, 27, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46478, 28, 28, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46479, 29, 29, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46480, 30, 30, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46481, 31, 31, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46482, 32, 32, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46483, 33, 33, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46484, 34, 34, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46485, 35, 35, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46486, 36, 36, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46487, 37, 37, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46488, 38, 38, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46489, 39, 39, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46490, 40, 40, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46491, 41, 41, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46492, 42, 42, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46493, 43, 43, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46494, 44, 44, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46495, 45, 45, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46496, 46, 46, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46497, 47, 47, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46498, 48, 48, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46499, 49, 49, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46500, 50, 50, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46501, 51, 51, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46502, 52, 52, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46503, 53, 53, 'mali2');
INSERT INTO sys_activites_a_migrer VALUES ('ML', 6, 18, 63, 46504, 54, 54, 'mali2');


--
-- Data for Name: sys_campagnes_a_migrer; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: sys_debarquements_a_migrer; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17058, 69, 69, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17059, 70, 70, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17060, 71, 71, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17061, 72, 72, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17062, 73, 73, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17063, 74, 74, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17064, 75, 75, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17065, 76, 76, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17066, 77, 77, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17067, 78, 78, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17068, 79, 79, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17069, 80, 80, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17070, 81, 81, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17071, 82, 82, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17072, 83, 83, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17282, 40, 40, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17283, 41, 41, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17284, 42, 42, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17285, 43, 43, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17286, 44, 44, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17287, 45, 45, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17288, 46, 46, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17289, 47, 47, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17290, 48, 48, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17291, 49, 49, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17292, 50, 50, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17293, 51, 51, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17294, 52, 52, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17295, 53, 53, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17296, 54, 54, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17297, 55, 55, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17298, 56, 56, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17299, 57, 57, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17300, 58, 58, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17301, 59, 59, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17302, 60, 60, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17303, 61, 61, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17304, 62, 62, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17305, 63, 63, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17306, 64, 64, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17307, 65, 65, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17308, 66, 66, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17309, 67, 67, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17310, 68, 68, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17578, 19, 19, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17579, 20, 20, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17580, 21, 21, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17581, 22, 22, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17582, 23, 23, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17583, 24, 24, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17584, 25, 25, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17585, 26, 26, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17586, 27, 27, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17587, 28, 28, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17588, 29, 29, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17589, 30, 30, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17590, 31, 31, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17591, 32, 32, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17592, 33, 33, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17593, 34, 34, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17594, 35, 35, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17595, 36, 36, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17596, 37, 37, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17597, 38, 38, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17598, 39, 39, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17933, 1, 1, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17934, 2, 2, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17935, 3, 3, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17936, 4, 4, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17937, 5, 5, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17938, 6, 6, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17939, 7, 7, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17940, 8, 8, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17941, 9, 9, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17942, 10, 10, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17943, 11, 11, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17944, 12, 12, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17945, 13, 13, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17946, 14, 14, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17947, 15, 15, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17948, 16, 16, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17949, 17, 17, 'mali2');
INSERT INTO sys_debarquements_a_migrer VALUES ('ML', 6, 18, 63, 17950, 18, 18, 'mali2');


--
-- Data for Name: sys_periodes_enquete; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO sys_periodes_enquete VALUES (1, 'ML', 6, 18, 63, '1994-10-17', '1994-10-22', 'mali2');
INSERT INTO sys_periodes_enquete VALUES (2, 'ML', 6, 18, 63, '1994-09-26', '1994-10-01', 'mali2');
INSERT INTO sys_periodes_enquete VALUES (3, 'ML', 6, 18, 63, '1994-08-29', '1994-09-03', 'mali2');
INSERT INTO sys_periodes_enquete VALUES (4, 'ML', 6, 18, 63, '1994-08-03', '1994-08-06', 'mali2');


--
-- Name: ar_origine_kb_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_origine_kb
    ADD CONSTRAINT ar_origine_kb_pkey PRIMARY KEY (id);


--
-- Name: art_agglomeration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_agglomeration
    ADD CONSTRAINT art_agglomeration_pkey PRIMARY KEY (id);


--
-- Name: art_artivite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_artivite_pkey PRIMARY KEY (id);


--
-- Name: art_categorie_socio_professionnelle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_categorie_socio_professionnelle
    ADD CONSTRAINT art_categorie_socio_professionnelle_pkey PRIMARY KEY (id);


--
-- Name: art_debarquement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_debarquement_pkey PRIMARY KEY (id);


--
-- Name: art_debarquement_rec_pkey; Type: CONSTRAINT; Schema: public; Owner: devppeao; Tablespace: 
--

ALTER TABLE ONLY art_debarquement_rec
    ADD CONSTRAINT art_debarquement_rec_pkey PRIMARY KEY (id);


--
-- Name: art_engin_activite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_engin_activite
    ADD CONSTRAINT art_engin_activite_pkey PRIMARY KEY (id);


--
-- Name: art_engin_peche_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_engin_peche
    ADD CONSTRAINT art_engin_peche_pkey PRIMARY KEY (id);


--
-- Name: art_etat_ciel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_etat_ciel
    ADD CONSTRAINT art_etat_ciel_pkey PRIMARY KEY (id);


--
-- Name: art_fraction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_fraction
    ADD CONSTRAINT art_fraction_pkey PRIMARY KEY (id);


--
-- Name: art_fraction_rec_pkey; Type: CONSTRAINT; Schema: public; Owner: devppeao; Tablespace: 
--

ALTER TABLE ONLY art_fraction_rec
    ADD CONSTRAINT art_fraction_rec_pkey PRIMARY KEY (id);


--
-- Name: art_grand_type_engin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_grand_type_engin
    ADD CONSTRAINT art_grand_type_engin_pkey PRIMARY KEY (id);


--
-- Name: art_lieu_de_peche_id_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_lieu_de_peche
    ADD CONSTRAINT art_lieu_de_peche_id_pkey PRIMARY KEY (id);


--
-- Name: art_millieu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_millieu
    ADD CONSTRAINT art_millieu_pkey PRIMARY KEY (id);


--
-- Name: art_poisson_mesure_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_poisson_mesure
    ADD CONSTRAINT art_poisson_mesure_pkey PRIMARY KEY (id);


--
-- Name: art_stat_gt_pkey; Type: CONSTRAINT; Schema: public; Owner: devppeao; Tablespace: 
--

ALTER TABLE ONLY art_stat_gt
    ADD CONSTRAINT art_stat_gt_pkey PRIMARY KEY (id);


--
-- Name: art_stat_gt_sp_pkey; Type: CONSTRAINT; Schema: public; Owner: devppeao; Tablespace: 
--

ALTER TABLE ONLY art_stat_gt_sp
    ADD CONSTRAINT art_stat_gt_sp_pkey PRIMARY KEY (id);


--
-- Name: art_stat_sp_pkey; Type: CONSTRAINT; Schema: public; Owner: devppeao; Tablespace: 
--

ALTER TABLE ONLY art_stat_sp
    ADD CONSTRAINT art_stat_sp_pkey PRIMARY KEY (id);


--
-- Name: art_stat_totale_pkey; Type: CONSTRAINT; Schema: public; Owner: devppeao; Tablespace: 
--

ALTER TABLE ONLY art_stat_totale
    ADD CONSTRAINT art_stat_totale_pkey PRIMARY KEY (id);


--
-- Name: art_taille_gt_sp_pkey; Type: CONSTRAINT; Schema: public; Owner: devppeao; Tablespace: 
--

ALTER TABLE ONLY art_taille_gt_sp
    ADD CONSTRAINT art_taille_gt_sp_pkey PRIMARY KEY (id);


--
-- Name: art_taille_sp_pkey; Type: CONSTRAINT; Schema: public; Owner: devppeao; Tablespace: 
--

ALTER TABLE ONLY art_taille_sp
    ADD CONSTRAINT art_taille_sp_pkey PRIMARY KEY (id);


--
-- Name: art_tyepe_sortie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_type_sortie
    ADD CONSTRAINT art_tyepe_sortie_pkey PRIMARY KEY (id);


--
-- Name: art_type_activite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_type_activite
    ADD CONSTRAINT art_type_activite_pkey PRIMARY KEY (id);


--
-- Name: art_type_agglomeration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_type_agglomeration
    ADD CONSTRAINT art_type_agglomeration_pkey PRIMARY KEY (id);


--
-- Name: art_type_engin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_type_engin
    ADD CONSTRAINT art_type_engin_pkey PRIMARY KEY (id);


--
-- Name: art_unite_peche_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_unite_peche
    ADD CONSTRAINT art_unite_peche_pkey PRIMARY KEY (id);


--
-- Name: art_vent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_vent
    ADD CONSTRAINT art_vent_pkey PRIMARY KEY (id);


--
-- Name: exp_campagne_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_campagne
    ADD CONSTRAINT exp_campagne_pkey PRIMARY KEY (id);


--
-- Name: exp_contenu_biologie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_trophique
    ADD CONSTRAINT exp_contenu_biologie_pkey PRIMARY KEY (id);


--
-- Name: exp_contenu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_contenu
    ADD CONSTRAINT exp_contenu_pkey PRIMARY KEY (id);


--
-- Name: exp_cp_peche_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_coup_peche
    ADD CONSTRAINT exp_cp_peche_pkey PRIMARY KEY (id);


--
-- Name: exp_debris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_debris
    ADD CONSTRAINT exp_debris_pkey PRIMARY KEY (id);


--
-- Name: exp_environnement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_environnement
    ADD CONSTRAINT exp_environnement_pkey PRIMARY KEY (id);


--
-- Name: exp_force_courant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_force_courant
    ADD CONSTRAINT exp_force_courant_pkey PRIMARY KEY (id);


--
-- Name: exp_position_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_position
    ADD CONSTRAINT exp_position_pkey PRIMARY KEY (id);


--
-- Name: exp_qualite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_qualite
    ADD CONSTRAINT exp_qualite_pkey PRIMARY KEY (id);


--
-- Name: exp_remplissage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_remplissage
    ADD CONSTRAINT exp_remplissage_pkey PRIMARY KEY (id);


--
-- Name: exp_sediment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_sediment
    ADD CONSTRAINT exp_sediment_pkey PRIMARY KEY (id);


--
-- Name: exp_sens_courant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_sens_courant
    ADD CONSTRAINT exp_sens_courant_pkey PRIMARY KEY (id);


--
-- Name: exp_sexe_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_sexe
    ADD CONSTRAINT exp_sexe_pkey PRIMARY KEY (id);


--
-- Name: exp_stade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_stade
    ADD CONSTRAINT exp_stade_pkey PRIMARY KEY (id);


--
-- Name: exp_station_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_station
    ADD CONSTRAINT exp_station_pkey PRIMARY KEY (id);


--
-- Name: exp_vegetation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_vegetation
    ADD CONSTRAINT exp_vegetation_pkey PRIMARY KEY (id);


--
-- Name: pg_ts_cfg_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pg_ts_cfg
    ADD CONSTRAINT pg_ts_cfg_pkey PRIMARY KEY (ts_name);


--
-- Name: pg_ts_cfgmap_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pg_ts_cfgmap
    ADD CONSTRAINT pg_ts_cfgmap_pkey PRIMARY KEY (ts_name, tok_alias);


--
-- Name: pg_ts_dict_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pg_ts_dict
    ADD CONSTRAINT pg_ts_dict_pkey PRIMARY KEY (dict_name);


--
-- Name: pg_ts_parser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pg_ts_parser
    ADD CONSTRAINT pg_ts_parser_pkey PRIMARY KEY (prs_name);


--
-- Name: ref_biologie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_biologie
    ADD CONSTRAINT ref_biologie_pkey PRIMARY KEY (id);


--
-- Name: ref_categorie_ecologique_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_categorie_ecologique
    ADD CONSTRAINT ref_categorie_ecologique_pkey PRIMARY KEY (id);


--
-- Name: ref_categorie_trophique_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_categorie_trophique
    ADD CONSTRAINT ref_categorie_trophique_pkey PRIMARY KEY (id);


--
-- Name: ref_engin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_engin
    ADD CONSTRAINT ref_engin_pkey PRIMARY KEY (id);


--
-- Name: ref_espece_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_espece
    ADD CONSTRAINT ref_espece_pkey PRIMARY KEY (id);


--
-- Name: ref_famille_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_famille
    ADD CONSTRAINT ref_famille_pkey PRIMARY KEY (id);


--
-- Name: ref_fraction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_fraction
    ADD CONSTRAINT ref_fraction_pkey PRIMARY KEY (id);


--
-- Name: ref_ordre_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_ordre
    ADD CONSTRAINT ref_ordre_pkey PRIMARY KEY (id);


--
-- Name: ref_pays_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_pays
    ADD CONSTRAINT ref_pays_pkey PRIMARY KEY (id);


--
-- Name: ref_secteur_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_secteur
    ADD CONSTRAINT ref_secteur_pkey PRIMARY KEY (id);


--
-- Name: ref_systeme_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_systeme
    ADD CONSTRAINT ref_systeme_pkey PRIMARY KEY (id);


--
-- Name: sys_activites_a_migrer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sys_activites_a_migrer
    ADD CONSTRAINT sys_activites_a_migrer_pkey PRIMARY KEY (id);


--
-- Name: sys_campagnes_a_migrer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sys_campagnes_a_migrer
    ADD CONSTRAINT sys_campagnes_a_migrer_pkey PRIMARY KEY (id);


--
-- Name: sys_debarquements_a_migrer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sys_debarquements_a_migrer
    ADD CONSTRAINT sys_debarquements_a_migrer_pkey PRIMARY KEY (id);


--
-- Name: sys_periodes_enquete_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sys_periodes_enquete
    ADD CONSTRAINT sys_periodes_enquete_pkey PRIMARY KEY (id);


--
-- Name: art_activite_art_type_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_activite_art_type_activite_id_fkey FOREIGN KEY (art_type_activite_id) REFERENCES art_type_activite(id);


--
-- Name: art_activite_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_engin_activite
    ADD CONSTRAINT art_activite_id FOREIGN KEY (art_activite_id) REFERENCES art_activite(id);


--
-- Name: art_agglomeration_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_agglomeration_id FOREIGN KEY (art_agglomeration_id) REFERENCES art_agglomeration(id);


--
-- Name: art_agglomeration_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_agglomeration_id FOREIGN KEY (art_agglomeration_id) REFERENCES art_agglomeration(id);


--
-- Name: art_categorie_socio_professionnelle_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_unite_peche
    ADD CONSTRAINT art_categorie_socio_professionnelle_id FOREIGN KEY (art_categorie_socio_professionnelle_id) REFERENCES art_categorie_socio_professionnelle(id);


--
-- Name: art_debarquement_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_engin_peche
    ADD CONSTRAINT art_debarquement_id FOREIGN KEY (art_debarquement_id) REFERENCES art_debarquement(id);


--
-- Name: art_debarquement_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_fraction
    ADD CONSTRAINT art_debarquement_id FOREIGN KEY (art_debarquement_id) REFERENCES art_debarquement(id);


--
-- Name: art_debarquement_rec_art_debarquement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: devppeao
--

ALTER TABLE ONLY art_debarquement_rec
    ADD CONSTRAINT art_debarquement_rec_art_debarquement_id_fkey FOREIGN KEY (art_debarquement_id) REFERENCES art_debarquement(id);


--
-- Name: art_engin_activite_art_type_engin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_engin_activite
    ADD CONSTRAINT art_engin_activite_art_type_engin_id_fkey FOREIGN KEY (art_type_engin_id) REFERENCES art_type_engin(id);


--
-- Name: art_engin_peche_art_type_engin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_engin_peche
    ADD CONSTRAINT art_engin_peche_art_type_engin_id_fkey FOREIGN KEY (art_type_engin_id) REFERENCES art_type_engin(id);


--
-- Name: art_etat_ciel_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_etat_ciel_id FOREIGN KEY (art_etat_ciel_id) REFERENCES art_etat_ciel(id);


--
-- Name: art_fraction_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_poisson_mesure
    ADD CONSTRAINT art_fraction_id FOREIGN KEY (art_fraction_id) REFERENCES art_fraction(id) DEFERRABLE;


--
-- Name: art_fraction_rec_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: devppeao
--

ALTER TABLE ONLY art_fraction_rec
    ADD CONSTRAINT art_fraction_rec_id_fkey FOREIGN KEY (id) REFERENCES art_fraction(id);


--
-- Name: art_grand_type_engin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_grand_type_engin_id FOREIGN KEY (art_grand_type_engin_id) REFERENCES art_grand_type_engin(id);


--
-- Name: art_grand_type_engin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_grand_type_engin_id FOREIGN KEY (art_grand_type_engin_id) REFERENCES art_grand_type_engin(id);


--
-- Name: art_lieu_peche_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_lieu_peche_id FOREIGN KEY (art_lieu_de_peche_id) REFERENCES art_lieu_de_peche(id);


--
-- Name: art_millieu_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_millieu_id FOREIGN KEY (art_millieu_id) REFERENCES art_millieu(id);


--
-- Name: art_millieu_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_millieu_id FOREIGN KEY (art_millieu_id) REFERENCES art_millieu(id);


--
-- Name: art_origine_kb_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_espece
    ADD CONSTRAINT art_origine_kb_id FOREIGN KEY (ref_origine_kb_id) REFERENCES ref_origine_kb(id);


--
-- Name: art_stat_gt_art_stat_totale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: devppeao
--

ALTER TABLE ONLY art_stat_gt
    ADD CONSTRAINT art_stat_gt_art_stat_totale_id_fkey FOREIGN KEY (art_stat_totale_id) REFERENCES art_stat_totale(id);


--
-- Name: art_stat_gt_sp_art_stat_gt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: devppeao
--

ALTER TABLE ONLY art_stat_gt_sp
    ADD CONSTRAINT art_stat_gt_sp_art_stat_gt_id_fkey FOREIGN KEY (art_stat_gt_id) REFERENCES art_stat_gt(id);


--
-- Name: art_stat_sp_art_stat_totale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: devppeao
--

ALTER TABLE ONLY art_stat_sp
    ADD CONSTRAINT art_stat_sp_art_stat_totale_id_fkey FOREIGN KEY (art_stat_totale_id) REFERENCES art_stat_totale(id);


--
-- Name: art_stat_totale_art_agglomeration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: devppeao
--

ALTER TABLE ONLY art_stat_totale
    ADD CONSTRAINT art_stat_totale_art_agglomeration_id_fkey FOREIGN KEY (art_agglomeration_id) REFERENCES art_agglomeration(id);


--
-- Name: art_taille_gt_sp_art_stat_gt_sp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: devppeao
--

ALTER TABLE ONLY art_taille_gt_sp
    ADD CONSTRAINT art_taille_gt_sp_art_stat_gt_sp_id_fkey FOREIGN KEY (art_stat_gt_sp_id) REFERENCES art_stat_gt_sp(id);


--
-- Name: art_taille_sp_art_stat_sp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: devppeao
--

ALTER TABLE ONLY art_taille_sp
    ADD CONSTRAINT art_taille_sp_art_stat_sp_id_fkey FOREIGN KEY (art_stat_sp_id) REFERENCES art_stat_sp(id);


--
-- Name: art_type_agglomeration_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_agglomeration
    ADD CONSTRAINT art_type_agglomeration_id FOREIGN KEY (art_type_agglomeration_id) REFERENCES art_type_agglomeration(id);


--
-- Name: art_type_engin_art_grand_type_engin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_type_engin
    ADD CONSTRAINT art_type_engin_art_grand_type_engin_id_fkey FOREIGN KEY (art_grand_type_engin_id) REFERENCES art_grand_type_engin(id);


--
-- Name: art_type_sortie_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_type_sortie_id FOREIGN KEY (art_type_sortie_id) REFERENCES art_type_sortie(id);


--
-- Name: art_type_sortie_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_type_sortie_id FOREIGN KEY (art_type_sortie_id) REFERENCES art_type_sortie(id);


--
-- Name: art_unite_peche_art_agglomeration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_unite_peche
    ADD CONSTRAINT art_unite_peche_art_agglomeration_id_fkey FOREIGN KEY (art_agglomeration_id) REFERENCES art_agglomeration(id);


--
-- Name: art_unite_peche_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_unite_peche_id FOREIGN KEY (art_unite_peche_id) REFERENCES art_unite_peche(id);


--
-- Name: art_unite_peche_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_unite_peche_id FOREIGN KEY (art_unite_peche_id) REFERENCES art_unite_peche(id);


--
-- Name: art_vent_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_vent_id FOREIGN KEY (art_vent_id) REFERENCES art_vent(id);


--
-- Name: exp_biologie_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_trophique
    ADD CONSTRAINT exp_biologie_id FOREIGN KEY (exp_biologie_id) REFERENCES exp_biologie(id);


--
-- Name: exp_campagne_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_coup_peche
    ADD CONSTRAINT exp_campagne_id FOREIGN KEY (exp_campagne_id) REFERENCES exp_campagne(id);


--
-- Name: exp_contenu_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_trophique
    ADD CONSTRAINT exp_contenu_id FOREIGN KEY (exp_contenu_id) REFERENCES exp_contenu(id);


--
-- Name: exp_coup_peche_exp_engin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_coup_peche
    ADD CONSTRAINT exp_coup_peche_exp_engin_id_fkey FOREIGN KEY (exp_engin_id) REFERENCES exp_engin(id);


--
-- Name: exp_coup_peche_exp_environnement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_coup_peche
    ADD CONSTRAINT exp_coup_peche_exp_environnement_id_fkey FOREIGN KEY (exp_environnement_id) REFERENCES exp_environnement(id);


--
-- Name: exp_cp_peche_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_fraction
    ADD CONSTRAINT exp_cp_peche_id FOREIGN KEY (exp_coup_peche_id) REFERENCES exp_coup_peche(id);


--
-- Name: exp_debris_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_station
    ADD CONSTRAINT exp_debris_id FOREIGN KEY (exp_debris_id) REFERENCES exp_debris(id);


--
-- Name: exp_force_courant_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_environnement
    ADD CONSTRAINT exp_force_courant_id FOREIGN KEY (exp_force_courant_id) REFERENCES exp_force_courant(id);


--
-- Name: exp_fraction_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_biologie
    ADD CONSTRAINT exp_fraction_id FOREIGN KEY (exp_fraction_id) REFERENCES exp_fraction(id);


--
-- Name: exp_position_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_station
    ADD CONSTRAINT exp_position_id FOREIGN KEY (exp_position_id) REFERENCES exp_position(id);


--
-- Name: exp_qualite_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_coup_peche
    ADD CONSTRAINT exp_qualite_id FOREIGN KEY (exp_qualite_id) REFERENCES exp_qualite(id);


--
-- Name: exp_remplissage_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_biologie
    ADD CONSTRAINT exp_remplissage_id FOREIGN KEY (exp_remplissage_id) REFERENCES exp_remplissage(id);


--
-- Name: exp_secteur_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_station
    ADD CONSTRAINT exp_secteur_id FOREIGN KEY (ref_secteur_id) REFERENCES ref_secteur(id);


--
-- Name: exp_sediment_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_station
    ADD CONSTRAINT exp_sediment_id FOREIGN KEY (exp_sediment_id) REFERENCES exp_sediment(id);


--
-- Name: exp_sens_courant_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_environnement
    ADD CONSTRAINT exp_sens_courant_id FOREIGN KEY (exp_sens_courant_id) REFERENCES exp_sens_courant(id);


--
-- Name: exp_sexe_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_biologie
    ADD CONSTRAINT exp_sexe_id FOREIGN KEY (exp_sexe_id) REFERENCES exp_sexe(id);


--
-- Name: exp_stade_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_biologie
    ADD CONSTRAINT exp_stade_id FOREIGN KEY (exp_stade_id) REFERENCES exp_stade(id);


--
-- Name: exp_station_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_coup_peche
    ADD CONSTRAINT exp_station_id FOREIGN KEY (exp_station_id) REFERENCES exp_station(id);


--
-- Name: exp_vegetation_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_station
    ADD CONSTRAINT exp_vegetation_id FOREIGN KEY (exp_vegetation_id) REFERENCES exp_vegetation(id);


--
-- Name: ref_categorie_ecologique_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_espece
    ADD CONSTRAINT ref_categorie_ecologique_id FOREIGN KEY (ref_categorie_ecologique_id) REFERENCES ref_categorie_ecologique(id);


--
-- Name: ref_categorie_trophique_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_espece
    ADD CONSTRAINT ref_categorie_trophique_id FOREIGN KEY (ref_categorie_trophique_id) REFERENCES ref_categorie_trophique(id);


--
-- Name: ref_espece_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_fraction
    ADD CONSTRAINT ref_espece_id FOREIGN KEY (ref_espece_id) REFERENCES ref_espece(id);


--
-- Name: ref_espece_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_espece
    ADD CONSTRAINT ref_espece_id FOREIGN KEY (id) REFERENCES ref_espece(id);


--
-- Name: ref_espece_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_fraction
    ADD CONSTRAINT ref_espece_id FOREIGN KEY (ref_espece_id) REFERENCES ref_espece(id);


--
-- Name: ref_famille_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_espece
    ADD CONSTRAINT ref_famille_id FOREIGN KEY (ref_famille_id) REFERENCES ref_famille(id);


--
-- Name: ref_ordre_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_famille
    ADD CONSTRAINT ref_ordre_id FOREIGN KEY (ref_ordre_id) REFERENCES ref_ordre(id);


--
-- Name: ref_pays_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_systeme
    ADD CONSTRAINT ref_pays_id FOREIGN KEY (ref_pays_id) REFERENCES ref_pays(id);


--
-- Name: ref_secteur_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_agglomeration
    ADD CONSTRAINT ref_secteur_id FOREIGN KEY (ref_secteur_id) REFERENCES ref_secteur(id);


--
-- Name: ref_secteur_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_lieu_de_peche
    ADD CONSTRAINT ref_secteur_id FOREIGN KEY (ref_secteur_id) REFERENCES ref_secteur(id);


--
-- Name: ref_systeme_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_campagne
    ADD CONSTRAINT ref_systeme_id FOREIGN KEY (ref_systeme_id) REFERENCES ref_systeme(id);


--
-- Name: ref_systeme_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_secteur
    ADD CONSTRAINT ref_systeme_id FOREIGN KEY (ref_systeme_id) REFERENCES ref_systeme(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

