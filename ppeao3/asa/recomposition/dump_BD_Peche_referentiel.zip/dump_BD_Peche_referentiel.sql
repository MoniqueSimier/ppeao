--
-- PostgreSQL database dump
--

SET client_encoding = 'LATIN9';
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: 
--

CREATE PROCEDURAL LANGUAGE plpgsql;


SET search_path = public, pg_catalog;

--
-- Name: dblink_pkey_results; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE dblink_pkey_results AS (
	"position" integer,
	colname text
);


ALTER TYPE public.dblink_pkey_results OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: art_activite; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_activite (
    id integer DEFAULT nextval(('"public"."art_activite_id_seq"'::text)::regclass) NOT NULL,
    art_unite_peche_id integer,
    art_agglomeration_id integer,
    art_type_sortie_id integer,
    art_grand_type_engin_id character varying(10),
    art_millieu_id integer,
    date_activite date,
    nbre_unite_recencee integer,
    annee integer,
    mois integer,
    code integer,
    nbre_hommes integer,
    nbre_femmes integer,
    nbre_enfants integer,
    art_type_activite_id character varying(10)
);


ALTER TABLE public.art_activite OWNER TO postgres;

--
-- Name: art_agglomeration; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_agglomeration (
    id integer NOT NULL,
    art_type_agglomeration_id integer,
    ref_secteur_id integer,
    nom character varying(50),
    longitude character varying(50),
    latitude character varying(50),
    memo text
);


ALTER TABLE public.art_agglomeration OWNER TO postgres;

--
-- Name: ref_pays; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_pays (
    id character varying(10) NOT NULL,
    nom character varying(50)
);


ALTER TABLE public.ref_pays OWNER TO postgres;

--
-- Name: ref_secteur; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_secteur (
    id integer NOT NULL,
    id_dans_systeme integer,
    nom character varying(50),
    superficie real,
    ref_systeme_id integer
);


ALTER TABLE public.ref_secteur OWNER TO postgres;

--
-- Name: ref_systeme; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_systeme (
    id integer NOT NULL,
    libelle character varying(50),
    ref_pays_id character varying(10),
    superficie real
);


ALTER TABLE public.ref_systeme OWNER TO postgres;

--
-- Name: ComptACT; Type: VIEW; Schema: public; Owner: devpechartexp
--

CREATE VIEW "ComptACT" AS
    SELECT ref_pays.nom AS pays, ref_systeme.libelle, ref_secteur.nom AS secteur, art_agglomeration.nom AS agglo, art_agglomeration.id AS num1, count(art_activite.id) AS n1 FROM ref_pays, ref_systeme, ref_secteur, art_agglomeration, art_activite WHERE (((((ref_pays.id)::text = (ref_systeme.ref_pays_id)::text) AND (ref_systeme.id = ref_secteur.ref_systeme_id)) AND (ref_secteur.id = art_agglomeration.ref_secteur_id)) AND (art_agglomeration.id = art_activite.art_agglomeration_id)) GROUP BY ref_pays.nom, ref_systeme.libelle, ref_secteur.nom, art_agglomeration.nom, art_agglomeration.id ORDER BY ref_pays.nom, ref_systeme.libelle, ref_secteur.nom, art_agglomeration.nom;


ALTER TABLE public."ComptACT" OWNER TO devpechartexp;

--
-- Name: art_debarquement; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_debarquement (
    id integer DEFAULT nextval(('"public"."art_debarquement_id_seq"'::text)::regclass) NOT NULL,
    art_millieu_id integer,
    art_vent_id integer,
    art_etat_ciel_id integer,
    art_agglomeration_id integer,
    art_lieu_de_peche_id integer,
    art_unite_peche_id integer,
    art_grand_type_engin_id character varying(10),
    art_type_sortie_id integer,
    date_depart date,
    heure_depart time without time zone,
    heure time without time zone,
    heure_pose_engin time without time zone,
    nbre_coups_de_peche integer,
    poids_total real,
    glaciere integer,
    distance_lieu_peche real,
    annee integer,
    mois integer,
    memo text,
    code integer,
    nbre_hommes integer,
    nbre_femmes integer,
    nbre_enfants integer,
    date_debarquement date
);


ALTER TABLE public.art_debarquement OWNER TO postgres;

--
-- Name: ComptDBQ; Type: VIEW; Schema: public; Owner: devpechartexp
--

CREATE VIEW "ComptDBQ" AS
    SELECT ref_pays.nom AS pays, ref_systeme.libelle, ref_secteur.nom AS secteur, art_agglomeration.nom AS agglo, count(art_debarquement.id) AS n1 FROM ref_pays, ref_systeme, ref_secteur, art_agglomeration, art_debarquement WHERE (((((ref_pays.id)::text = (ref_systeme.ref_pays_id)::text) AND (ref_systeme.id = ref_secteur.ref_systeme_id)) AND (ref_secteur.id = art_agglomeration.ref_secteur_id)) AND (art_agglomeration.id = art_debarquement.art_agglomeration_id)) GROUP BY ref_pays.nom, ref_systeme.libelle, ref_secteur.nom, art_agglomeration.nom ORDER BY ref_pays.nom, ref_systeme.libelle, ref_secteur.nom, art_agglomeration.nom;


ALTER TABLE public."ComptDBQ" OWNER TO devpechartexp;

--
-- Name: art_fraction; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_fraction (
    id character varying(15) NOT NULL,
    code integer,
    poids real,
    nbre_poissons integer,
    debarquee integer,
    ref_espece_id character varying(10),
    art_debarquement_id integer,
    prix double precision,
    CONSTRAINT art_fraction_debarquee_check CHECK (((debarquee = 0) OR (debarquee = 1)))
);


ALTER TABLE public.art_fraction OWNER TO postgres;

--
-- Name: art_poisson_mesure; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_poisson_mesure (
    id integer DEFAULT nextval(('"public"."art_poisson_mesure_id_seq"'::text)::regclass) NOT NULL,
    code integer,
    taille integer,
    art_fraction_id character varying(15)
);


ALTER TABLE public.art_poisson_mesure OWNER TO postgres;

--
-- Name: ComptDFT; Type: VIEW; Schema: public; Owner: devpechartexp
--

CREATE VIEW "ComptDFT" AS
    SELECT ref_pays.nom AS pays, ref_systeme.libelle, count(art_poisson_mesure.id) AS n2 FROM ref_pays, ref_systeme, ref_secteur, art_agglomeration, art_debarquement, art_fraction, art_poisson_mesure WHERE (((((((ref_pays.id)::text = (ref_systeme.ref_pays_id)::text) AND (ref_systeme.id = ref_secteur.ref_systeme_id)) AND (ref_secteur.id = art_agglomeration.ref_secteur_id)) AND (art_agglomeration.id = art_debarquement.art_agglomeration_id)) AND (art_debarquement.id = art_fraction.art_debarquement_id)) AND ((art_fraction.id)::text = (art_poisson_mesure.art_fraction_id)::text)) GROUP BY ref_pays.nom, ref_systeme.libelle ORDER BY ref_pays.nom, ref_systeme.libelle;


ALTER TABLE public."ComptDFT" OWNER TO devpechartexp;

--
-- Name: ComptFdbq; Type: VIEW; Schema: public; Owner: devpechartexp
--

CREATE VIEW "ComptFdbq" AS
    SELECT ref_pays.nom AS pays, ref_systeme.libelle, ref_secteur.nom AS secteur, art_agglomeration.nom AS agglo, art_agglomeration.id AS num1, count(art_fraction.id) AS n2 FROM ref_pays, ref_systeme, ref_secteur, art_agglomeration, art_debarquement, art_fraction WHERE ((((((ref_pays.id)::text = (ref_systeme.ref_pays_id)::text) AND (ref_systeme.id = ref_secteur.ref_systeme_id)) AND (ref_secteur.id = art_agglomeration.ref_secteur_id)) AND (art_agglomeration.id = art_debarquement.art_agglomeration_id)) AND (art_debarquement.id = art_fraction.art_debarquement_id)) GROUP BY ref_pays.nom, ref_systeme.libelle, ref_secteur.nom, art_agglomeration.nom, art_agglomeration.id ORDER BY ref_pays.nom, ref_systeme.libelle, ref_secteur.nom, art_agglomeration.nom;


ALTER TABLE public."ComptFdbq" OWNER TO devpechartexp;

--
-- Name: ComptFdbq02; Type: VIEW; Schema: public; Owner: devpechartexp
--

CREATE VIEW "ComptFdbq02" AS
    SELECT ref_pays.nom AS pays, ref_systeme.libelle, count(art_fraction.id) AS n2 FROM ref_pays, ref_systeme, ref_secteur, art_agglomeration, art_debarquement, art_fraction WHERE ((((((ref_pays.id)::text = (ref_systeme.ref_pays_id)::text) AND (ref_systeme.id = ref_secteur.ref_systeme_id)) AND (ref_secteur.id = art_agglomeration.ref_secteur_id)) AND (art_agglomeration.id = art_debarquement.art_agglomeration_id)) AND (art_debarquement.id = art_fraction.art_debarquement_id)) GROUP BY ref_pays.nom, ref_systeme.libelle ORDER BY ref_pays.nom, ref_systeme.libelle;


ALTER TABLE public."ComptFdbq02" OWNER TO devpechartexp;

--
-- Name: art_activite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_activite_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_activite_id_seq OWNER TO postgres;

--
-- Name: art_activite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_activite_id_seq', 1, false);


--
-- Name: art_agglomeration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_agglomeration_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_agglomeration_id_seq OWNER TO postgres;

--
-- Name: art_agglomeration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_agglomeration_id_seq', 1, false);


--
-- Name: art_caracteristiques_unite_peche_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_caracteristiques_unite_peche_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_caracteristiques_unite_peche_id_seq OWNER TO postgres;

--
-- Name: art_caracteristiques_unite_peche_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_caracteristiques_unite_peche_id_seq', 1, false);


--
-- Name: art_categorie_socio_professionnelle; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_categorie_socio_professionnelle (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.art_categorie_socio_professionnelle OWNER TO postgres;

--
-- Name: art_categorie_socio_professionnelle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_categorie_socio_professionnelle_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_categorie_socio_professionnelle_id_seq OWNER TO postgres;

--
-- Name: art_categorie_socio_professionnelle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_categorie_socio_professionnelle_id_seq', 1, false);


--
-- Name: art_condition_physico_chimique_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_condition_physico_chimique_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_condition_physico_chimique_id_seq OWNER TO postgres;

--
-- Name: art_condition_physico_chimique_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_condition_physico_chimique_id_seq', 1, false);


--
-- Name: art_debarquement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_debarquement_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_debarquement_id_seq OWNER TO postgres;

--
-- Name: art_debarquement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_debarquement_id_seq', 1, false);


--
-- Name: art_engin_activite; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_engin_activite (
    id integer DEFAULT nextval(('"public"."art_engin_activite_id_seq"'::text)::regclass) NOT NULL,
    code integer,
    nbre integer,
    art_activite_id integer,
    art_type_engin_id character varying(10)
);


ALTER TABLE public.art_engin_activite OWNER TO postgres;

--
-- Name: art_engin_activite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_engin_activite_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_engin_activite_id_seq OWNER TO postgres;

--
-- Name: art_engin_activite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_engin_activite_id_seq', 1, false);


--
-- Name: art_engin_peche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_engin_peche (
    id integer DEFAULT nextval(('"public"."art_engin_peche_id_seq"'::text)::regclass) NOT NULL,
    code integer,
    longueur integer,
    hauteur real,
    nbre_nap real,
    nombre real,
    nbre_eff integer,
    nbre_mail_ham real,
    num_ham integer,
    proprietaire integer,
    art_type_engin_id character varying(10),
    art_debarquement_id integer
);


ALTER TABLE public.art_engin_peche OWNER TO postgres;

--
-- Name: art_engin_peche_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_engin_peche_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_engin_peche_id_seq OWNER TO postgres;

--
-- Name: art_engin_peche_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_engin_peche_id_seq', 1, false);


--
-- Name: art_enqueteur_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_enqueteur_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_enqueteur_id_seq OWNER TO postgres;

--
-- Name: art_enqueteur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_enqueteur_id_seq', 1, false);


--
-- Name: art_etat_ciel; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_etat_ciel (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.art_etat_ciel OWNER TO postgres;

--
-- Name: art_etat_ciel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_etat_ciel_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_etat_ciel_id_seq OWNER TO postgres;

--
-- Name: art_etat_ciel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_etat_ciel_id_seq', 1, false);


--
-- Name: art_fraction_debarquee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_fraction_debarquee_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_fraction_debarquee_id_seq OWNER TO postgres;

--
-- Name: art_fraction_debarquee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_fraction_debarquee_id_seq', 1, false);


--
-- Name: art_fraction_id1_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_fraction_id1_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_fraction_id1_seq OWNER TO postgres;

--
-- Name: art_fraction_id1_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_fraction_id1_seq', 1, false);


--
-- Name: art_fraction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_fraction_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_fraction_id_seq OWNER TO postgres;

--
-- Name: art_fraction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_fraction_id_seq', 1, false);


--
-- Name: art_fraction_non_debarquee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_fraction_non_debarquee_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_fraction_non_debarquee_id_seq OWNER TO postgres;

--
-- Name: art_fraction_non_debarquee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_fraction_non_debarquee_id_seq', 1, false);


--
-- Name: art_grand_type_engin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_grand_type_engin (
    id character varying(10) NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.art_grand_type_engin OWNER TO postgres;

--
-- Name: art_lieu_de_peche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_lieu_de_peche (
    id integer DEFAULT nextval(('"public"."art_lieu_de_peche_id_seq"'::text)::regclass) NOT NULL,
    ref_secteur_id integer,
    libelle character varying(50),
    code integer
);


ALTER TABLE public.art_lieu_de_peche OWNER TO postgres;

--
-- Name: art_lieu_de_peche_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_lieu_de_peche_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_lieu_de_peche_id_seq OWNER TO postgres;

--
-- Name: art_lieu_de_peche_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_lieu_de_peche_id_seq', 1, false);


--
-- Name: art_millieu; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_millieu (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.art_millieu OWNER TO postgres;

--
-- Name: art_millieu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_millieu_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_millieu_id_seq OWNER TO postgres;

--
-- Name: art_millieu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_millieu_id_seq', 1, false);


--
-- Name: art_mode_calcul_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_mode_calcul_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_mode_calcul_id_seq OWNER TO postgres;

--
-- Name: art_mode_calcul_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_mode_calcul_id_seq', 1, false);


--
-- Name: art_origine_kb_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_origine_kb_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_origine_kb_id_seq OWNER TO postgres;

--
-- Name: art_origine_kb_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_origine_kb_id_seq', 1, false);


--
-- Name: art_poisson_mesure_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_poisson_mesure_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_poisson_mesure_id_seq OWNER TO postgres;

--
-- Name: art_poisson_mesure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_poisson_mesure_id_seq', 1, false);


--
-- Name: art_type_activite; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_type_activite (
    raison character varying(50),
    libelle character varying(255),
    id character varying(10) NOT NULL
);


ALTER TABLE public.art_type_activite OWNER TO postgres;

--
-- Name: art_type_activite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_type_activite_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_type_activite_id_seq OWNER TO postgres;

--
-- Name: art_type_activite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_type_activite_id_seq', 1, false);


--
-- Name: art_type_agglomeration; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_type_agglomeration (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.art_type_agglomeration OWNER TO postgres;

--
-- Name: art_type_agglomeration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_type_agglomeration_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_type_agglomeration_id_seq OWNER TO postgres;

--
-- Name: art_type_agglomeration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_type_agglomeration_id_seq', 1, false);


--
-- Name: art_type_engin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_type_engin (
    id character varying(10) NOT NULL,
    art_grand_type_engin_id character varying(10),
    libelle character varying(50)
);


ALTER TABLE public.art_type_engin OWNER TO postgres;

--
-- Name: art_type_engin_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_type_engin_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_type_engin_id_seq OWNER TO postgres;

--
-- Name: art_type_engin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_type_engin_id_seq', 1, false);


--
-- Name: art_type_sortie; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_type_sortie (
    id integer NOT NULL,
    libelle character varying(100)
);


ALTER TABLE public.art_type_sortie OWNER TO postgres;

--
-- Name: art_type_sortie_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_type_sortie_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_type_sortie_id_seq OWNER TO postgres;

--
-- Name: art_type_sortie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_type_sortie_id_seq', 1, false);


--
-- Name: art_unite_peche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_unite_peche (
    id integer DEFAULT nextval(('"public"."art_unite_peche_id_seq"'::text)::regclass) NOT NULL,
    art_categorie_socio_professionnelle_id integer,
    libelle character varying(50),
    libelle_menage character varying(50),
    code integer,
    art_agglomeration_id integer,
    base_pays character varying(50)
);


ALTER TABLE public.art_unite_peche OWNER TO postgres;

--
-- Name: art_unite_peche_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_unite_peche_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_unite_peche_id_seq OWNER TO postgres;

--
-- Name: art_unite_peche_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_unite_peche_id_seq', 1, false);


--
-- Name: art_vent; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE art_vent (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.art_vent OWNER TO postgres;

--
-- Name: art_vent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_vent_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_vent_id_seq OWNER TO postgres;

--
-- Name: art_vent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_vent_id_seq', 1, false);


--
-- Name: art_village_attache_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE art_village_attache_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.art_village_attache_id_seq OWNER TO postgres;

--
-- Name: art_village_attache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('art_village_attache_id_seq', 1, false);


--
-- Name: exp_biologie; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_biologie (
    id integer NOT NULL,
    longueur integer,
    longueur_totale integer,
    poids integer,
    exp_sexe_id character varying(10),
    exp_stade_id integer,
    exp_remplissage_id character varying(10),
    exp_fraction_id integer,
    memo text,
    valeur_estimee integer,
    CONSTRAINT exp_biologie_poids_estime_check CHECK (((valeur_estimee = 0) OR (valeur_estimee = 1)))
);


ALTER TABLE public.exp_biologie OWNER TO postgres;

--
-- Name: exp_biologie_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_biologie_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_biologie_id_seq OWNER TO postgres;

--
-- Name: exp_biologie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_biologie_id_seq', 1, false);


--
-- Name: exp_campagne; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_campagne (
    id integer DEFAULT nextval(('"public"."exp_campagne_id_seq"'::text)::regclass) NOT NULL,
    ref_systeme_id integer,
    numero_campagne integer,
    date_debut date,
    date_fin date,
    libelle character varying(100)
);


ALTER TABLE public.exp_campagne OWNER TO postgres;

--
-- Name: exp_campagne_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_campagne_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_campagne_id_seq OWNER TO postgres;

--
-- Name: exp_campagne_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_campagne_id_seq', 1, false);


--
-- Name: exp_contenu; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_contenu (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_contenu OWNER TO postgres;

--
-- Name: exp_contenu_biologie_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_contenu_biologie_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_contenu_biologie_id_seq OWNER TO postgres;

--
-- Name: exp_contenu_biologie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_contenu_biologie_id_seq', 1, false);


--
-- Name: exp_contenu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_contenu_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_contenu_id_seq OWNER TO postgres;

--
-- Name: exp_contenu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_contenu_id_seq', 1, false);


--
-- Name: exp_coup_peche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_coup_peche (
    id integer DEFAULT nextval(('"public"."exp_cp_peche_id_seq"'::text)::regclass) NOT NULL,
    date_cp date,
    longitude character varying(50),
    latitude character varying(50),
    memo text,
    profondeur real,
    exp_qualite_id integer,
    exp_campagne_id integer,
    exp_station_id character varying(10),
    numero_filet integer,
    numero_coup integer,
    exp_engin_id character varying(10),
    protocole integer,
    heure_debut time without time zone,
    heure_fin time without time zone,
    exp_environnement_id integer
);


ALTER TABLE public.exp_coup_peche OWNER TO postgres;

--
-- Name: exp_cp_peche_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_cp_peche_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_cp_peche_id_seq OWNER TO postgres;

--
-- Name: exp_cp_peche_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_cp_peche_id_seq', 1, false);


--
-- Name: exp_debris; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_debris (
    id character varying(10) NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_debris OWNER TO postgres;

--
-- Name: exp_engin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_engin (
    id character varying(10) NOT NULL,
    libelle character varying(50),
    longueur real,
    chute real,
    maille integer,
    memo text
);


ALTER TABLE public.exp_engin OWNER TO postgres;

--
-- Name: exp_environnement; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_environnement (
    id integer NOT NULL,
    transparence real,
    salinite_surface real,
    salinite_fond real,
    temperature_surface real,
    temperature_fond real,
    oxygene_surface real,
    oxygene_fond real,
    chlorophylle_surface real,
    chlorophylle_fond real,
    mot_surface real,
    mop_surface real,
    mot_fond real,
    mop_fond real,
    conductivite_surface real,
    conductivite_fond real,
    memo text,
    exp_force_courant_id integer,
    exp_sens_courant_id integer
);


ALTER TABLE public.exp_environnement OWNER TO postgres;

--
-- Name: exp_environnement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_environnement_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_environnement_id_seq OWNER TO postgres;

--
-- Name: exp_environnement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_environnement_id_seq', 1, false);


--
-- Name: exp_force_courant; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_force_courant (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_force_courant OWNER TO postgres;

--
-- Name: exp_force_courant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_force_courant_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_force_courant_id_seq OWNER TO postgres;

--
-- Name: exp_force_courant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_force_courant_id_seq', 1, false);


--
-- Name: exp_fraction; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_fraction (
    id integer NOT NULL,
    nombre_total integer,
    poids_total integer,
    memo text,
    ref_espece_id character varying(10),
    exp_coup_peche_id integer,
    nombre_estime integer,
    CONSTRAINT exp_fraction_nombre_estime_check CHECK (((nombre_estime = 0) OR (nombre_estime = 1)))
);


ALTER TABLE public.exp_fraction OWNER TO postgres;

--
-- Name: exp_fraction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_fraction_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_fraction_id_seq OWNER TO postgres;

--
-- Name: exp_fraction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_fraction_id_seq', 1, false);


--
-- Name: exp_position; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_position (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_position OWNER TO postgres;

--
-- Name: exp_position_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_position_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_position_id_seq OWNER TO postgres;

--
-- Name: exp_position_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_position_id_seq', 1, false);


--
-- Name: exp_qualite; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_qualite (
    id integer NOT NULL,
    libelle character varying(100)
);


ALTER TABLE public.exp_qualite OWNER TO postgres;

--
-- Name: exp_qualite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_qualite_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_qualite_id_seq OWNER TO postgres;

--
-- Name: exp_qualite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_qualite_id_seq', 1, false);


--
-- Name: exp_remplissage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_remplissage (
    id character varying(10) NOT NULL,
    libelle character varying(100)
);


ALTER TABLE public.exp_remplissage OWNER TO postgres;

--
-- Name: exp_remplissage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_remplissage_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_remplissage_id_seq OWNER TO postgres;

--
-- Name: exp_remplissage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_remplissage_id_seq', 1, false);


--
-- Name: exp_sediment; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_sediment (
    id character varying(10) NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_sediment OWNER TO postgres;

--
-- Name: exp_sens_courant; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_sens_courant (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_sens_courant OWNER TO postgres;

--
-- Name: exp_sens_courant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_sens_courant_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_sens_courant_id_seq OWNER TO postgres;

--
-- Name: exp_sens_courant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_sens_courant_id_seq', 1, false);


--
-- Name: exp_sexe; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_sexe (
    id character varying(10) NOT NULL,
    libelle character varying(100)
);


ALTER TABLE public.exp_sexe OWNER TO postgres;

--
-- Name: exp_stade; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_stade (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_stade OWNER TO postgres;

--
-- Name: exp_stade_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exp_stade_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.exp_stade_id_seq OWNER TO postgres;

--
-- Name: exp_stade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exp_stade_id_seq', 1, false);


--
-- Name: exp_station; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_station (
    id character varying(10) NOT NULL,
    nom character varying(50),
    site character varying(50),
    latitude character varying(50),
    longitude character varying(50),
    memo text,
    ref_secteur_id integer,
    exp_position_id integer,
    exp_vegetation_id character varying(10),
    exp_debris_id character varying(10),
    exp_sediment_id character varying(10),
    distance_embouchure real
);


ALTER TABLE public.exp_station OWNER TO postgres;

--
-- Name: exp_trophique; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_trophique (
    id integer DEFAULT nextval(('"public"."exp_contenu_biologie_id_seq"'::text)::regclass) NOT NULL,
    exp_biologie_id integer NOT NULL,
    exp_contenu_id integer NOT NULL,
    quantite real
);


ALTER TABLE public.exp_trophique OWNER TO postgres;

--
-- Name: exp_vegetation; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exp_vegetation (
    id character varying(10) NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.exp_vegetation OWNER TO postgres;

--
-- Name: pg_ts_cfg; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pg_ts_cfg (
    ts_name text NOT NULL,
    prs_name text NOT NULL,
    locale text
);


ALTER TABLE public.pg_ts_cfg OWNER TO postgres;

--
-- Name: pg_ts_cfgmap; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pg_ts_cfgmap (
    ts_name text NOT NULL,
    tok_alias text NOT NULL,
    dict_name text[]
);


ALTER TABLE public.pg_ts_cfgmap OWNER TO postgres;

--
-- Name: pg_ts_dict; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pg_ts_dict (
    dict_name text NOT NULL,
    dict_init regprocedure,
    dict_initoption text,
    dict_lexize regprocedure NOT NULL,
    dict_comment text
);


ALTER TABLE public.pg_ts_dict OWNER TO postgres;

--
-- Name: pg_ts_parser; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE pg_ts_parser (
    prs_name text NOT NULL,
    prs_start regprocedure NOT NULL,
    prs_nexttoken regprocedure NOT NULL,
    prs_end regprocedure NOT NULL,
    prs_headline regprocedure NOT NULL,
    prs_lextype regprocedure NOT NULL,
    prs_comment text
);


ALTER TABLE public.pg_ts_parser OWNER TO postgres;

--
-- Name: ref_categorie_ecologique; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_categorie_ecologique (
    id character varying(10) NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.ref_categorie_ecologique OWNER TO postgres;

--
-- Name: ref_categorie_trophique; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_categorie_trophique (
    id character varying(10) NOT NULL,
    libelle character varying(100)
);


ALTER TABLE public.ref_categorie_trophique OWNER TO postgres;

--
-- Name: ref_espece; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_espece (
    id character varying(10) NOT NULL,
    libelle character varying(50),
    info character varying(255),
    ref_famille_id integer,
    ref_categorie_ecologique_id character varying(10),
    ref_categorie_trophique_id character varying(10),
    coefficient_k real,
    coefficient_b real,
    ref_origine_kb_id integer,
    ref_espece_id character varying(10)
);


ALTER TABLE public.ref_espece OWNER TO postgres;

--
-- Name: ref_famille; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_famille (
    id integer NOT NULL,
    libelle character varying(50),
    ref_ordre_id integer,
    non_poisson integer,
    CONSTRAINT ref_famille_non_poisson_check CHECK (((non_poisson = 0) OR (non_poisson = 1)))
);


ALTER TABLE public.ref_famille OWNER TO postgres;

--
-- Name: ref_famille_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_famille_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ref_famille_id_seq OWNER TO postgres;

--
-- Name: ref_famille_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_famille_id_seq', 1, false);


--
-- Name: ref_ordre; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_ordre (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.ref_ordre OWNER TO postgres;

--
-- Name: ref_ordre_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_ordre_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ref_ordre_id_seq OWNER TO postgres;

--
-- Name: ref_ordre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_ordre_id_seq', 1, false);


--
-- Name: ref_origine_kb; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_origine_kb (
    id integer NOT NULL,
    libelle character varying(50)
);


ALTER TABLE public.ref_origine_kb OWNER TO postgres;

--
-- Name: ref_secteur_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_secteur_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ref_secteur_id_seq OWNER TO postgres;

--
-- Name: ref_secteur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_secteur_id_seq', 1, false);


--
-- Name: ref_systeme_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_systeme_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ref_systeme_id_seq OWNER TO postgres;

--
-- Name: ref_systeme_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_systeme_id_seq', 1, false);


--
-- Name: sys_activites_a_migrer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sys_activites_a_migrer (
    pays character varying(10),
    systeme integer,
    secteur integer,
    agglomeration integer,
    activite_source integer,
    activite_cible integer,
    id serial NOT NULL,
    base_pays character varying(50)
);


ALTER TABLE public.sys_activites_a_migrer OWNER TO postgres;

--
-- Name: sys_activites_a_migrer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sys_activites_a_migrer', 'id'), 1, false);


--
-- Name: sys_campagnes_a_migrer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sys_campagnes_a_migrer (
    pays character varying(10),
    systeme integer,
    campagne_source bigint,
    campagne_cible bigint,
    id serial NOT NULL
);


ALTER TABLE public.sys_campagnes_a_migrer OWNER TO postgres;

--
-- Name: sys_campagnes_a_migrer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sys_campagnes_a_migrer', 'id'), 1, false);


--
-- Name: sys_debarquements_a_migrer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sys_debarquements_a_migrer (
    pays character varying(10),
    systeme integer,
    secteur integer,
    agglomeration integer,
    debarquement_source integer,
    debarquement_cible integer,
    id serial NOT NULL,
    base_pays character varying(50)
);


ALTER TABLE public.sys_debarquements_a_migrer OWNER TO postgres;

--
-- Name: sys_debarquements_a_migrer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sys_debarquements_a_migrer', 'id'), 1, false);


--
-- Name: sys_groupe_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sys_groupe_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sys_groupe_id_seq OWNER TO postgres;

--
-- Name: sys_groupe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sys_groupe_id_seq', 1, false);


--
-- Name: sys_periodes_enquete; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sys_periodes_enquete (
    id serial NOT NULL,
    pays_id character varying(10),
    systeme_id integer,
    secteur_id integer,
    agglomeration_id integer,
    date_debut date,
    date_fin date,
    base_pays character varying(50)
);


ALTER TABLE public.sys_periodes_enquete OWNER TO postgres;

--
-- Name: sys_periodes_enquete_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sys_periodes_enquete', 'id'), 1, false);


--
-- Name: sys_utilisateur_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sys_utilisateur_id_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sys_utilisateur_id_seq OWNER TO postgres;

--
-- Name: sys_utilisateur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sys_utilisateur_id_seq', 1, false);


--
-- Data for Name: art_activite; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_agglomeration; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_categorie_socio_professionnelle; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_debarquement; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_engin_activite; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_engin_peche; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_etat_ciel; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_fraction; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_grand_type_engin; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_lieu_de_peche; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_millieu; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_poisson_mesure; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_type_activite; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_type_agglomeration; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_type_engin; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_type_sortie; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_unite_peche; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: art_vent; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_biologie; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_campagne; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_contenu; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_coup_peche; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_debris; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_engin; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_environnement; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_force_courant; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_fraction; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_position; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_qualite; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_remplissage; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_sediment; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_sens_courant; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_sexe; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_stade; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_station; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_trophique; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: exp_vegetation; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: pg_ts_cfg; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: pg_ts_cfgmap; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: pg_ts_dict; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: pg_ts_parser; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ref_categorie_ecologique; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_categorie_ecologique VALUES ('C', 'Continentale');
INSERT INTO ref_categorie_ecologique VALUES ('Ce', 'Continentale � affinit� estuarienne');
INSERT INTO ref_categorie_ecologique VALUES ('Co', 'Continentale occasionnelle');
INSERT INTO ref_categorie_ecologique VALUES ('Ec', 'Estuarienne d''origine continentale');
INSERT INTO ref_categorie_ecologique VALUES ('Em', 'Estuarienne d''origine marine');
INSERT INTO ref_categorie_ecologique VALUES ('Es', 'Estuarienne stricte');
INSERT INTO ref_categorie_ecologique VALUES ('Ma', 'Marine accessoire');
INSERT INTO ref_categorie_ecologique VALUES ('ME', 'Marine-estuarienne');
INSERT INTO ref_categorie_ecologique VALUES ('Mo', 'Marine occasionnelle');


--
-- Data for Name: ref_categorie_trophique; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_categorie_trophique VALUES ('he-de', 'Herbivore d�tritivore ou brouteur');
INSERT INTO ref_categorie_trophique VALUES ('he-ph', 'Herbivore � pr�dominance phytoplanctonophage ou microphytophage');
INSERT INTO ref_categorie_trophique VALUES ('om-ge', 'Omnivore g�n�raliste');
INSERT INTO ref_categorie_trophique VALUES ('om-in', 'Omnivore � pr�dominance insectivore');
INSERT INTO ref_categorie_trophique VALUES ('p1-bt', 'Pr�dateur de premier niveau � pr�dominance benthophage (mollusques,vers)');
INSERT INTO ref_categorie_trophique VALUES ('p1-in', 'Pr�dateur de premier niveau � pr�dominance insectivore');
INSERT INTO ref_categorie_trophique VALUES ('p1-mc', 'Pr�dateur de premier niveau g�n�raliste (crustac�s,insectes)');
INSERT INTO ref_categorie_trophique VALUES ('p1-zo', 'Zooplanctonophagie dominante');
INSERT INTO ref_categorie_trophique VALUES ('p2-ge', 'Pr�dateur de deuxi�me niveau g�n�raliste (poisson et autres proies)');
INSERT INTO ref_categorie_trophique VALUES ('p2-pi', 'Pr�dateur de deuxi�me niveau � pr�dominance piscivore');


--
-- Data for Name: ref_espece; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_espece VALUES ('AAM', 'Hemicaranx bicolor', NULL, 15, 'Mo', 'p2-ge', 1.4933, 3.0334001, 9, NULL);
INSERT INTO ref_espece VALUES ('ABA', 'Alestes baremoze', NULL, 3, 'Co', 'om-ge', 2.6429999, 2.868, 2, NULL);
INSERT INTO ref_espece VALUES ('ABI', 'Auchenoglanis biscutatus', NULL, 10, 'C', NULL, 5.0900002, 2.885, 2, NULL);
INSERT INTO ref_espece VALUES ('ACI', 'Alectis ciliaris', NULL, 15, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ACS', 'Porogobius schlegelii', NULL, 41, 'Es', 'om-ge', 2.5190001, 2.743, 1, NULL);
INSERT INTO ref_espece VALUES ('ADE', 'Alestes dentex', NULL, 3, 'C', NULL, 2.6229999, 2.8959999, 2, NULL);
INSERT INTO ref_espece VALUES ('AGA', 'Arius latiscutatus', NULL, 9, 'ME', 'p2-ge', 1.3200001, 2.994, 4, NULL);
INSERT INTO ref_espece VALUES ('AGI', 'Arius gigas', NULL, 9, 'C', NULL, 1, 3, 0, NULL);
INSERT INTO ref_espece VALUES ('AGU', 'Engraulis encrasicolus', NULL, 35, 'Ma', 'p1-zo', 0, 0, 0, NULL);
INSERT INTO ref_espece VALUES ('AHE', 'Arius heudelotii', NULL, 9, 'ME', 'p2-ge', 0.67510003, 3.1124001, 9, NULL);
INSERT INTO ref_espece VALUES ('AHI', 'Ablennes hians', NULL, 13, 'Mo', 'p2-pi', 0.0040000002, 3.322, 8, NULL);
INSERT INTO ref_espece VALUES ('ALE', 'Alestes spp.', 'JME 15/05/03', 3, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ALI', 'Brycinus imberi', NULL, 3, 'Co', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ALO', 'Brycinus longipinnis', NULL, 3, 'Ce', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('AMA', 'Brycinus macrolepidotus', NULL, 3, 'Ce', 'om-ge', 2.6429999, 2.868, 2, NULL);
INSERT INTO ref_espece VALUES ('AMI', 'Apogon imberbis', NULL, 8, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('AMO', 'Acanthurus monroviae', NULL, 1, 'Mo', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ANO', 'Antennarius striatus', NULL, 5, 'Ma', NULL, 3.03, 3.036, 4, NULL);
INSERT INTO ref_espece VALUES ('ANU', 'Brycinus nurse', NULL, 3, 'Co', 'om-ge', 2.3099999, 2.9590001, 7, NULL);
INSERT INTO ref_espece VALUES ('AOC', 'Auchenoglanis occidentalis', NULL, 10, 'C', NULL, 3.553, 2.9230001, 2, NULL);
INSERT INTO ref_espece VALUES ('APA', 'Antennarius pardalis', NULL, 5, 'Mo', 'p2-ge', 0, 0, 0, 'ANO');
INSERT INTO ref_espece VALUES ('APY', 'Aplysia spp.', NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ARA', 'Aplocheilichthys rancureli', NULL, 27, 'Co', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ARE', 'Argyrosomus regius', NULL, 86, 'Mo', 'p2-pi', 0.99800003, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('ARI', 'Arius spp.', NULL, 9, NULL, NULL, 1.36, 2.9909999, 4, NULL);
INSERT INTO ref_espece VALUES ('ARP', 'Arius parkii', NULL, 9, 'ME', 'p2-pi', 0.50650001, 3.1677999, 9, NULL);
INSERT INTO ref_espece VALUES ('ASE', 'Arca senilis', 'Demande JME 21/06/04', 108, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ASP', 'Aplocheilichthys spilauchen', NULL, 27, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ATH', 'Auxis thazard', NULL, 87, 'Ma', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ATR', 'Atherina sp.', 'VDG - Pgm Saloum', 109, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('AUC', 'Auchenoglanis spp.', 'JME 15/05/03', 10, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('AVU', 'Albula vulpes', NULL, 2, 'Mo', 'p1-bt', 1.176, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('BAB', 'Barbus ablabes', NULL, 26, 'Co', NULL, 0, 0, 0, 'BOC');
INSERT INTO ref_espece VALUES ('BAG', 'Bagrus spp.', 'JME 15/05/03', 10, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BAL', 'Balistes spp.', NULL, 11, 'Ma', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BAR', 'Barbus spp.', NULL, 26, 'C', NULL, 0, 0, 0, 'BDS');
INSERT INTO ref_espece VALUES ('BAU', 'Brachydeuterus auritus', NULL, 45, 'ME', 'om-ge', 0.89999998, 3.1159999, 4, NULL);
INSERT INTO ref_espece VALUES ('BBA', 'Synodontis batensoda', NULL, 57, 'Co', 'om-ge', 4.8070002, 2.925, 2, NULL);
INSERT INTO ref_espece VALUES ('BBO', 'Boops boops', NULL, 92, 'Mo', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BDM', 'Bagrus bajad', NULL, 10, 'C', NULL, 0.57099998, 3.132, 2, NULL);
INSERT INTO ref_espece VALUES ('BDO', 'Bagrus docmak', NULL, 10, 'C', NULL, 1.04, 3.076, 8, NULL);
INSERT INTO ref_espece VALUES ('BDS', 'Barbus perince', NULL, 26, 'C', NULL, 0.21699999, 3.5, 2, NULL);
INSERT INTO ref_espece VALUES ('BES', 'Strongylura senegalensis', NULL, 13, 'Em', 'p2-ge', 4.2410002, 2.4130001, 1, NULL);
INSERT INTO ref_espece VALUES ('BFI', 'Bagrus filamentosus', NULL, 10, 'C', NULL, 0, 0, 0, 'BDO');
INSERT INTO ref_espece VALUES ('BKO', 'Butis koilomatodon', 'VDG - Pgm Saloum', 33, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BLB', 'Batanga lebretonis', NULL, 33, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BLE', 'Parablennius goreensis', 'Paro... corrige en Para... le 27/03/6 (LT)', 14, 'Es', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BLI', 'Batrachoides liberiensis', NULL, 12, 'Ma', 'p1-mc', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BLN', 'Blennius sp.', 'VDG - Pgm Saloum', 14, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BMA', 'Barbus macrops', NULL, 26, 'C', NULL, 0, 0, 0, 'BDS');
INSERT INTO ref_espece VALUES ('BOC', 'Barbus bynni occidentalis', 'V�rifi� dans L�v�que, Paugy, Teugels, 90 (7/02/02)', 26, 'C', NULL, 0.21699999, 3.5, 2, NULL);
INSERT INTO ref_espece VALUES ('BRL', 'Brycinus leuciscus', NULL, 3, 'C', NULL, 3, 3, 2, NULL);
INSERT INTO ref_espece VALUES ('BRY', 'Brycinus spp.', 'JME 15/05/03', 3, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BSO', 'Bathygobius soporator', NULL, 41, 'Es', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('BWA', 'Barbus bynni waldroni', 'V�rifi� dans L�v�que, Paugy, Teugels, 90 (7/02/02)', 26, 'Co', NULL, 0, 0, 0, 'BOC');
INSERT INTO ref_espece VALUES ('CAA', 'Callinectes amnicola', NULL, 78, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CAL', 'Callinectes sp.', NULL, 78, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CAR', 'Caranx spp.', NULL, 15, NULL, NULL, 1.67, 3.036, 4, NULL);
INSERT INTO ref_espece VALUES ('CAS', 'Caranx senegallus', 'corrig� le 26/02/02', 15, 'ME', 'p2-ge', 6.4400001, 2.7190001, 4, NULL);
INSERT INTO ref_espece VALUES ('CCE', 'Dalophis cephalopeltis', NULL, 70, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CCH', 'Carcharhinus spp.', NULL, 16, NULL, NULL, 0, 0, 0, 'RCE');
INSERT INTO ref_espece VALUES ('CCI', 'Citharinus citharus', NULL, 21, 'C', NULL, 2.168, 3.0610001, 2, NULL);
INSERT INTO ref_espece VALUES ('CCR', 'Caranx crysos', 'demande JME 03/03', 15, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CFI', 'Chrysichthys auratus', NULL, 10, 'Ec', 'p1-bt', 1.6, 2.8800001, 8, NULL);
INSERT INTO ref_espece VALUES ('CGA', 'Clarias gariepinus', NULL, 22, 'Co', NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('CGL', 'Callinectes pallidus', NULL, 78, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CGP', 'Crevette Grosse Pince', 'VDG Saloum 2001-2003', 111, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CHG', 'Chaetodipterus goreensis', NULL, 36, 'Mo', 'p1-bt', 0, 0, 0, 'CLI');
INSERT INTO ref_espece VALUES ('CHI', 'Caranx hippos', NULL, 15, 'ME', 'p2-ge', 1.37, 3.0829999, 10, NULL);
INSERT INTO ref_espece VALUES ('CHL', 'Chloroscombrus chrysurus', NULL, 15, 'ME', 'p2-ge', 1.17, 3.053, 4, NULL);
INSERT INTO ref_espece VALUES ('CHM', 'Chromis chromis', NULL, 77, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CHO', 'Chaetodon hoefleri', NULL, 18, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CHY', 'Chrysichthys spp.', NULL, 10, NULL, NULL, 2.73, 2.8829999, 4, NULL);
INSERT INTO ref_espece VALUES ('CIL', 'Citharinus latus', NULL, 21, 'C', NULL, 0, 0, 3, 'CCI');
INSERT INTO ref_espece VALUES ('CIT', 'Citharinus spp.', '18/11/02', 21, 'C', NULL, 0, 0, 0, 'CCI');
INSERT INTO ref_espece VALUES ('CJO', 'Chrysichthys johnelsi', NULL, 10, 'Ce', 'p1-bt', 0, 0, 0, 'CHY');
INSERT INTO ref_espece VALUES ('CKI', 'Ctenopoma kingsleyae', NULL, 4, 'Co', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CLA', 'Clarotes laticeps', NULL, 10, 'Co', NULL, 1.531, 3.01, 2, NULL);
INSERT INTO ref_espece VALUES ('CLC', 'Carcharhinus leucas', 'Bamboung 09', 16, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CLE', 'Clarias ebriensis', NULL, 22, 'Es', NULL, 0, 0, 0, NULL);
INSERT INTO ref_espece VALUES ('CLI', 'Chaetodipterus lippei', NULL, 36, 'Ma', 'p1-bt', 3.4319999, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('CLL', 'Clarias laeviceps', NULL, 22, 'C', NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('CLM', 'Carcharhinus limbatus', 'JME 25/02/05', 16, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CLP', 'Clarias spp.', NULL, 22, NULL, NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('CLR', 'Clarioides spp.', NULL, 22, NULL, NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('CLS', 'Clarias anguillaris', NULL, 22, 'Co', 'p1-mc', 0.93400002, 3.0339999, 2, NULL);
INSERT INTO ref_espece VALUES ('CMB', 'Cymbium sp.', NULL, 102, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CNI', 'Chrysichthys nigrodigitatus', NULL, 10, 'Ec', 'p1-bt', 2.1300001, 2.9170001, 4, NULL);
INSERT INTO ref_espece VALUES ('COR', 'Corvina spp.', NULL, 86, NULL, NULL, 0, 0, 0, 'PSS');
INSERT INTO ref_espece VALUES ('CRA', 'Crabe non Callinectes', 'VDG Saloum 2001-2003', 111, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CRG', 'Crassostrea gasar', 'Demande JME 21/06/04', 107, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CRH', 'Caranx rhonchus', NULL, 15, 'Mo', 'p1-bt', 0, 0, 0, 'CAR');
INSERT INTO ref_espece VALUES ('CRV', 'Crevette non p�n�ide', 'VDG Saloum 2001-2003', 111, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CST', 'Citharichthys stampflii', NULL, 72, 'Em', 'p2-ge', 0.23, 3.1470001, 4, NULL);
INSERT INTO ref_espece VALUES ('CTA', 'Campylomormyrus tamandua', NULL, 60, 'C', NULL, 0, 0, 0, 'PBA');
INSERT INTO ref_espece VALUES ('CTL', 'Ctenogobius lepturus', 'Baran (21/12/01)', 41, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CTR', 'Scomberomorus tritor', NULL, 87, 'Ma', 'p2-pi', 1.08, 2.9849999, 4, NULL);
INSERT INTO ref_espece VALUES ('CVO', 'Dactylopterus volitans', 'corrig� le 26/02/02', 28, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('CWA', 'Chrysichthys maurus', NULL, 10, 'Ec', 'p1-bt', 1.77, 2.983, 4, NULL);
INSERT INTO ref_espece VALUES ('CYM', 'Cynoglossus monodi', NULL, 25, 'Mo', 'p1-bt', 0, 0, 0, 'CYS');
INSERT INTO ref_espece VALUES ('CYN', 'Cynoglossus spp.', NULL, 25, NULL, NULL, 0, 0, 0, 'CYS');
INSERT INTO ref_espece VALUES ('CYS', 'Cynoglossus senegalensis', NULL, 25, 'Em', 'p1-bt', 0.31999999, 2.9860001, 4, NULL);
INSERT INTO ref_espece VALUES ('DAF', 'Drepane africana', NULL, 31, 'ME', 'p1-bt', 0.69, 3.2720001, 4, NULL);
INSERT INTO ref_espece VALUES ('DAM', 'Dasyatis margaritella', NULL, 29, 'Em', 'p1-bt', 0, 0, 0, 'DMA');
INSERT INTO ref_espece VALUES ('DAS', 'Dasyatis spp.', NULL, 29, NULL, NULL, 4.039, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('DBE', 'Diplodus bellottii', NULL, 92, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DBR', 'Distichodus brevipinnis', NULL, 21, 'C', NULL, 0, 0, 0, 'DRO');
INSERT INTO ref_espece VALUES ('DCA', 'Dentex canariensis', NULL, 92, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DEN', 'Distichodus engrycephalus', NULL, 21, 'C', NULL, 0, 0, 0, 'DRO');
INSERT INTO ref_espece VALUES ('DEP', 'Decapterus punctatus', NULL, 15, 'Ma', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DIM', 'Diodon holocanthus', NULL, 30, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DIS', 'Distichodus spp.', 'JME 15/05/03', 21, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DIV', 'Divers-Melange', NULL, 49, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DMA', 'Dasyatis margarita', NULL, 29, 'Em', 'p1-bt', 16.83, 2.7479999, 6, NULL);
INSERT INTO ref_espece VALUES ('DPU', 'Dicentrarchus punctatus', NULL, 61, 'Mo', 'p2-ge', 1.245, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('DRO', 'Distichodus rostratus', NULL, 21, 'Co', NULL, 1.99, 3, 7, NULL);
INSERT INTO ref_espece VALUES ('DSA', 'Diplodus sargus', 'ss-esp. cadenati seule pr�sente sur zone (7/02/02)', 92, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DUK', 'Dasyatis ukpam', NULL, 29, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('DVU', 'Diplodus vulgaris', NULL, 92, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('EAE', 'Epinephelus aeneus', NULL, 90, 'ME', 'p2-pi', 1.33, 2.9760001, 4, NULL);
INSERT INTO ref_espece VALUES ('EAL', 'Euthynnus alletteratus', NULL, 87, 'Ma', NULL, 0, 0, 0, NULL);
INSERT INTO ref_espece VALUES ('ECH', 'Epiplatys chaperi', NULL, 6, 'Ce', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('EDA', 'Eleotris daganensis', NULL, 33, 'Es', NULL, 0, 0, 0, 'ELE');
INSERT INTO ref_espece VALUES ('EES', 'Epinephelus esonue', NULL, 90, 'Mo', NULL, 0, 0, 0, 'EAE');
INSERT INTO ref_espece VALUES ('EFI', 'Ethmalosa fimbriata', NULL, 23, 'Em', 'he-ph', 0.75, 3.1719999, 4, NULL);
INSERT INTO ref_espece VALUES ('EGU', 'Ephippion guttifer', NULL, 98, 'ME', 'p1-bt', 5.6399999, 2.8239999, 4, NULL);
INSERT INTO ref_espece VALUES ('ELA', 'Elops lacerta', NULL, 34, 'ME', 'p2-ge', 0.93000001, 2.9890001, 4, NULL);
INSERT INTO ref_espece VALUES ('ELE', 'Eleotris spp.', NULL, 33, NULL, NULL, 0.83999997, 3.075, 4, NULL);
INSERT INTO ref_espece VALUES ('ELS', 'Elops senegalensis', NULL, 34, 'Ma', 'p2-ge', 0, 0, 0, 'ELA');
INSERT INTO ref_espece VALUES ('EME', 'Schilbe mandibularis', NULL, 85, 'Ce', 'p2-ge', 0.34599999, 3.187, 1, NULL);
INSERT INTO ref_espece VALUES ('ENA', 'Echeneis naucrates', NULL, 32, 'Mo', 'p1-zo', 0.23800001, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('ENI', 'Schilbe niloticus', NULL, 85, 'C', NULL, 0.59200001, 3.154, 2, NULL);
INSERT INTO ref_espece VALUES ('EPG', 'Epinephelus guaza', 'syst�matique d`apres Seret et Leveque - remplace code EGA de VDG', 90, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('ESE', 'Eleotris senegalensis', NULL, 33, 'Es', NULL, 8.2290001, 2.6170001, 1, NULL);
INSERT INTO ref_espece VALUES ('EVI', 'Eleotris vittata', NULL, 33, 'Es', NULL, 3.79, 2.7909999, 5, NULL);
INSERT INTO ref_espece VALUES ('FAC', 'Fodiator acutus', NULL, 37, 'Ma', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('FTA', 'Fistularia tabacaria', NULL, 38, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('FVI', 'Fistularia petimba', NULL, 38, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GAL', 'Galathea spp.', NULL, 39, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GAN', 'Gobioides sagitta', NULL, 41, 'Es', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GDE', 'Galeoides decadactylus', NULL, 75, 'ME', 'p1-bt', 0.89999998, 3.1459999, 4, NULL);
INSERT INTO ref_espece VALUES ('GER', 'Gerres spp.', NULL, 40, NULL, NULL, 1.09, 3.135, 4, NULL);
INSERT INTO ref_espece VALUES ('GGU', 'Chonophorus lateristriga', NULL, 41, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GME', 'Eucinostomus melanopterus', NULL, 40, 'ME', 'om-ge', 0.5, 3.29, 4, NULL);
INSERT INTO ref_espece VALUES ('GMI', 'Gymnura micrura', NULL, 44, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GNE', 'Breinomyrus niger', NULL, 60, 'C', NULL, 0, 0, 0, 'PBA');
INSERT INTO ref_espece VALUES ('GNI', 'Gerres nigri', NULL, 40, 'Es', 'om-ge', 1.52, 3.056, 5, NULL);
INSERT INTO ref_espece VALUES ('GOB', 'Gobiidae spp.', NULL, 41, NULL, NULL, 0, 0, 0, 'ACS');
INSERT INTO ref_espece VALUES ('GRU', 'Gobius rubropunctatus', 'Baran (21/12/01)', 41, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GSE', 'Marcusenius senegalensis', NULL, 60, 'C', NULL, 0, 0, 0, 'MRU');
INSERT INTO ref_espece VALUES ('GTH', 'Yongeichthys thomasi', NULL, 41, 'Es', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GYA', 'Gymnura altavela', NULL, 44, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('GYM', 'Gymnarchus spp.', NULL, 43, NULL, NULL, 0, 0, 0, 'GYN');
INSERT INTO ref_espece VALUES ('GYN', 'Gymnarchus niloticus', NULL, 43, 'C', NULL, 0.38999999, 2.9779999, 0, NULL);
INSERT INTO ref_espece VALUES ('HAF', 'Bostrychus africanus', NULL, 33, 'Es', 'p1-mc', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HBA', 'Hemiramphus balao', NULL, 46, 'Em', 'p1-zo', 0, 0, 0, 'HPI');
INSERT INTO ref_espece VALUES ('HBI', 'Hemichromis bimaculatus', NULL, 20, 'Co', NULL, 7.3330002, 2.8770001, 3, NULL);
INSERT INTO ref_espece VALUES ('HBL', 'Haplochromis bloyeti', NULL, 20, 'C', NULL, 1.378, 0.30599999, 3, NULL);
INSERT INTO ref_espece VALUES ('HBO', 'Hyperopisus bebe', 'ss-esp. occidentalis supprim�e le 7/02/02', 60, 'Co', 'p1-bt', 0.34999999, 3.151, 2, NULL);
INSERT INTO ref_espece VALUES ('HBR', 'Hemiramphus brasiliensis', NULL, 46, 'Em', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HEB', 'Heterobranchus bidorsalis', NULL, 22, 'Co', NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('HET', 'Heterobranchus spp.', '18/11/02', 22, 'C', NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('HFA', 'Hemichromis fasciatus', NULL, 20, 'Ec', 'p2-ge', 0.33000001, 3.3340001, 4, NULL);
INSERT INTO ref_espece VALUES ('HFO', 'Hydrocynus forskahlii', 'LT 19/04/07 (ajout du h)', 3, 'Co', 'p2-pi', 0.78899997, 3.098, 2, NULL);
INSERT INTO ref_espece VALUES ('HHA', 'Hippopotamyrus harringtoni', NULL, 60, 'C', NULL, 0, 0, 0, 'PBA');
INSERT INTO ref_espece VALUES ('HIN', 'Rhabdalestes septentrionalis', NULL, 3, 'Co', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HIP', 'Hippopotamyrus pictus', 'Mali 03', 60, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HIS', 'Heterobranchus isopterus', NULL, 22, 'Ce', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HLA', 'Hypleurochilus langi', 'Bamboung 09', 14, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HLO', 'Heterobranchus longifilis', NULL, 22, 'Ce', NULL, 0, 0, 0, 'CLS');
INSERT INTO ref_espece VALUES ('HME', 'Synodontis membranaceus', NULL, 57, 'Co', NULL, 1.46, 3.119, 8, NULL);
INSERT INTO ref_espece VALUES ('HNI', 'Heterotis niloticus', NULL, 71, 'Co', NULL, 3.0150001, 2.865, 2, NULL);
INSERT INTO ref_espece VALUES ('HOD', 'Hepsetus odoe', NULL, 47, 'Co', 'p2-ge', 0, 0, 0, 'HYB');
INSERT INTO ref_espece VALUES ('HPI', 'Hyporamphus picarti', NULL, 46, 'Ma', 'he-de', 3.5190001, 2.6029999, 1, NULL);
INSERT INTO ref_espece VALUES ('HPU', 'Hippocampus algiricus', NULL, 96, 'Ma', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('HYB', 'Hydrocynus brevis', NULL, 3, 'Co', 'p2-pi', 0.55000001, 3.201, 3, NULL);
INSERT INTO ref_espece VALUES ('HYD', 'Hydrocynus spp.', 'JME 15/05/03', 3, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('IAF', 'Ilisha africana', NULL, 23, 'Em', 'p1-zo', 2.73, 2.7909999, 4, NULL);
INSERT INTO ref_espece VALUES ('INC', 'Inconnu', NULL, 49, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('IND', 'Ind�termin�', 'VDG - Pgm Saloum', 49, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('KKR', 'Kribia kribensis', 'Baran (21/12/01)', 33, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LAB', 'Labeo spp.', 'JME 15/05/03', 26, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LAD', 'Laeviscutella dekimpei', NULL, 23, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LAF', 'Gymnothorax afer', NULL, 64, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LAG', 'Lutjanus agennes', 'Baran (21/12/01)', 53, 'Mo', NULL, 0, 0, 0, 'LGO');
INSERT INTO ref_espece VALUES ('LAT', 'Lethrinus atlanticus', NULL, 50, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LBA', 'Liza bandialensis', 'JME - 16/12/05 - espece nouvelle pgme Saloum - cf these PSD; 96', 62, NULL, NULL, 0, 0, 0, 'LGR');
INSERT INTO ref_espece VALUES ('LCO', 'Labeo coubie', NULL, 26, 'Co', NULL, 3.3469999, 2.9679999, 2, NULL);
INSERT INTO ref_espece VALUES ('LDU', 'Liza dumerili', NULL, 62, 'Em', 'he-de', 3.9100001, 2.7750001, 6, NULL);
INSERT INTO ref_espece VALUES ('LED', 'Lepidotrigla cadmani', NULL, 101, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LEN', 'Lutjanus endecacanthus', 'Baran (21/12/01)', 53, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LEP', 'Leptoc�phale', 'VDG - Pgm Saloum', 49, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LFA', 'Liza falcipinnis', NULL, 62, 'Em', 'he-de', 1.1900001, 2.987, 4, NULL);
INSERT INTO ref_espece VALUES ('LGL', 'Trachinotus ovatus', NULL, 15, 'Ma', 'p1-bt', 6.0320001, 2.6960001, 1, NULL);
INSERT INTO ref_espece VALUES ('LGO', 'Lutjanus goreensis', NULL, 53, 'Ma', 'p2-ge', 2.95, 2.8829999, 4, NULL);
INSERT INTO ref_espece VALUES ('LGR', 'Liza grandisquamis', NULL, 62, 'Em', 'he-de', 1.5700001, 2.9590001, 4, NULL);
INSERT INTO ref_espece VALUES ('LIA', 'Lichia amia', NULL, 15, 'Ma', 'p2-pi', 0, 0, 0, 'LGL');
INSERT INTO ref_espece VALUES ('LIZ', 'Liza spp', 'Demande JME 21/06/04', 62, NULL, NULL, 0, 0, 0, 'LFA');
INSERT INTO ref_espece VALUES ('LLA', 'Lagocephalus laevigatus', NULL, 98, 'Ma', 'p2-ge', 0, 0, 0, NULL);
INSERT INTO ref_espece VALUES ('LMO', 'Lithognathus mormyrus', NULL, 92, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LNI', 'Lates niloticus', NULL, 17, 'Co', 'p2-pi', 0.77399999, 3.089, 7, NULL);
INSERT INTO ref_espece VALUES ('LPA', 'Labeo parvus', 'Mali 03', 26, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('LSE', 'Labeo senegalensis', NULL, 26, 'C', NULL, 2.3840001, 2.9949999, 2, NULL);
INSERT INTO ref_espece VALUES ('LSU', 'Lobotes surinamensis', NULL, 51, 'Mo', 'p2-ge', 0.042800002, 2.8399999, 8, NULL);
INSERT INTO ref_espece VALUES ('LUD', 'Lutjanus dentatus', NULL, 53, 'Mo', 'p2-ge', 0, 0, 0, 'LGO');
INSERT INTO ref_espece VALUES ('LUT', 'Lutjanus spp.', NULL, 53, NULL, NULL, 0, 0, 0, 'LGO');
INSERT INTO ref_espece VALUES ('MAN', 'Mormyrops anguilloides', NULL, 60, 'Co', 'p2-ge', 0, 0, 0, 'MDE');
INSERT INTO ref_espece VALUES ('MAR', 'Marcusenius spp.', 'JME 15/05/03', 60, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MBA', 'Mugil bananensis', NULL, 62, 'ME', 'he-de', 0.86000001, 3.0969999, 6, NULL);
INSERT INTO ref_espece VALUES ('MBR', 'Marcusenius ussheri', 'anc. M. bruyerei (corr. 19/04/07 MS)', 60, 'Co', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MCE', 'Mugil cephalus', NULL, 62, 'ME', 'he-ph', 0, 0, 0, 'MUG');
INSERT INTO ref_espece VALUES ('MCU', 'Mugil curema', NULL, 62, 'Em', 'he-ph', 1.02, 3.0650001, 4, NULL);
INSERT INTO ref_espece VALUES ('MCY', 'Marcusenius cyprinoides', NULL, 60, 'C', NULL, 0, 0, 0, 'MRU');
INSERT INTO ref_espece VALUES ('MDE', 'Mormyrops deliciosus', NULL, 60, 'C', NULL, 1.5, 2.8699999, 7, NULL);
INSERT INTO ref_espece VALUES ('MED', 'Meduse', NULL, 111, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MEL', 'Malapterurus electricus', NULL, 55, 'Co', NULL, 1.08, 3.069, 7, NULL);
INSERT INTO ref_espece VALUES ('MFU', 'Marcusenius furcidens', NULL, 60, 'Co', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MHA', 'Mormyrus hasselquistii', NULL, 60, 'Co', NULL, 1.6900001, 2.7449999, 8, NULL);
INSERT INTO ref_espece VALUES ('MIB', 'Microphis brachyurus', NULL, 96, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MIC', 'Micralestes spp.', 'JME - 18/12/02', 3, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MIE', 'Micralestes elongatus', 'JME - 18/12/02', 3, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MMA', 'Mormyrus macrophthalmus', NULL, 60, 'C', NULL, 1.288, 2.9330001, 2, NULL);
INSERT INTO ref_espece VALUES ('MOO', 'Mormyrops spp.', 'JME 15/05/03', 60, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MOR', 'Mormyrus spp.', 'JME 15/05/03', 60, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MOU', 'Mormyrops oudoti', NULL, 60, 'C', NULL, 0, 0, 0, 'MDE');
INSERT INTO ref_espece VALUES ('MPL', 'Myrophis plumbeus', NULL, 70, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MRU', 'Mormyrus rume', NULL, 60, 'Co', NULL, 1.288, 2.9330001, 2, NULL);
INSERT INTO ref_espece VALUES ('MTH', 'Marcusenius thomasi', NULL, 60, 'Co', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MUG', 'Mugilidae', NULL, 62, NULL, NULL, 1.45, 2.9749999, 4, NULL);
INSERT INTO ref_espece VALUES ('MUL', 'Mugil spp', 'Demande JME 21/06/04', 62, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MUR', 'Murex sp.', NULL, 65, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('MVO', 'Macrobrachius volenvoli', NULL, 66, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('NHA', 'Nematopalaemon hastatus', '18/11/02', 105, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('NMA', 'Nematogobius maindroni', NULL, 41, 'Es', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('NUD', 'Nudibranche', 'demande JME 03/03', 111, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('OAU', 'Oreochromis aureus', NULL, 20, 'C', NULL, 0, 0, 0, 'TNI');
INSERT INTO ref_espece VALUES ('OLI', 'Calamar', NULL, 52, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('OOC', 'Gobionellus occidentalis', NULL, 41, 'Es', 'p1-bt', 118.5, 1.841, 1, NULL);
INSERT INTO ref_espece VALUES ('OUN', 'Orcynopsis unicolor', NULL, 87, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('OVU', 'Octopus vulgaris', NULL, 69, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PAA', 'Papyrocranus afer', 'corrig� le 16/05/08 (enlev� le h) - cf Fishbase et le Paugy', 68, 'Co', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PAB', 'Pagellus bellotii', 'Demande JME 21/06/04', 92, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PAF', 'Panopeus africanus', NULL, 103, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PAN', 'Protopterus annectens', NULL, 80, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PAT', 'Parapenaeopsis atlantica', 'corrig� le 18/11/02 (anc. Parapeneus atlanticus ??)', 73, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PBA', 'Petrocephalus bane', NULL, 60, 'C', NULL, 0.76899999, 3.1760001, 2, NULL);
INSERT INTO ref_espece VALUES ('PBE', 'Psettodes belcheri', NULL, 81, 'Mo', 'p2-ge', 0.0057000001, 3.2218001, 8, NULL);
INSERT INTO ref_espece VALUES ('PBI', 'Polypterus bichir', NULL, 76, 'C', NULL, 0, 0, 0, 'PEN');
INSERT INTO ref_espece VALUES ('PBO', 'Petrocephalus bovei', NULL, 60, 'Co', 'p1-mc', 0, 0, 0, 'PBA');
INSERT INTO ref_espece VALUES ('PBR', 'Pseudotolithus brachygnathus', NULL, 86, 'ME', 'p2-ge', 0.36000001, 3.135, 4, NULL);
INSERT INTO ref_espece VALUES ('PDU', 'Penaeus notialis', NULL, 73, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PEA', 'Petrocephalus ansorgii', 'LTDM - Mali 01', 60, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PEF', 'Pellonula leonensis', NULL, 23, 'Ec', 'p1-mc', 2.02, 2.855, 4, NULL);
INSERT INTO ref_espece VALUES ('PEH', 'Pagrus caeruleostictus', NULL, 92, 'Ma', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PEL', 'Pseudotolithus elongatus', NULL, 86, 'Em', 'p2-ge', 0.27000001, 3.1930001, 4, NULL);
INSERT INTO ref_espece VALUES ('PEM', 'Penaeus monodon', 'Gambie 02', 73, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PEN', 'Polypterus endlicheri', NULL, 76, 'Co', 'p2-ge', 0.84799999, 3.0150001, 8, NULL);
INSERT INTO ref_espece VALUES ('PEP', 'Pseudotolithus epipercus', NULL, 86, 'Mo', 'p2-ge', 0, 0, 0, 'PSS');
INSERT INTO ref_espece VALUES ('PER', 'Thysia ansorgii', NULL, 20, 'Co', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PET', 'Petrocephalus spp.', 'demande JME 03/03', 60, 'C', NULL, 0, 0, 0, 'PBA');
INSERT INTO ref_espece VALUES ('PGU', 'Chromidotilapia guentheri', NULL, 20, 'Co', 'p1-mc', 2.1329999, 2.9860001, 3, NULL);
INSERT INTO ref_espece VALUES ('PHP', 'Parailia pellucida', NULL, 85, 'Ce', 'p1-bt', 0.43000001, 3.3710001, 8, NULL);
INSERT INTO ref_espece VALUES ('PIN', 'Pomadasys incisus', NULL, 45, 'Ma', 'p1-bt', 0, 0, 0, 'POM');
INSERT INTO ref_espece VALUES ('PIS', 'Pisodonophis semicinctus', 'Pisonodophis corrige en Pisodonophis le 27/03/06 (LT)', 70, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PJU', 'Pomadasys jubelini', NULL, 45, 'Em', 'p1-bt', 1.23, 3.043, 4, NULL);
INSERT INTO ref_espece VALUES ('PKE', 'Penaeus kerathurus', NULL, 73, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PLA', 'Pegusa lascaris', 'Casamance - demande JME 05/07', 91, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PLG', 'Solitas gruveli', NULL, 74, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PLM', 'Plectorhinchus macrolepis', NULL, 45, 'Em', 'p2-pi', 3.1400001, 2.915, 4, NULL);
INSERT INTO ref_espece VALUES ('PLO', 'Parapenaeus longirostris', '18/11/02', 73, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PMA', 'Parakuhlia macrophthalmus', 'Saloum 34 - Mars 04 - JDD', 45, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PME', 'Plectorhinchus mediterraneus', 'JME 25/02/05 -corrig� le 25/10/07 (2r)', 45, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PMO', 'Pseudotolithus moorii', NULL, 86, 'Ma', 'p1-bt', 0, 0, 0, 'PSS');
INSERT INTO ref_espece VALUES ('PNI', 'Cephalopholis nigri', NULL, 90, 'Mo', NULL, 0, 0, 0, 'EAE');
INSERT INTO ref_espece VALUES ('POB', 'Parachanna obscura', NULL, 19, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('POL', 'Polypterus spp.', NULL, 76, NULL, NULL, 0, 0, 0, 'PEN');
INSERT INTO ref_espece VALUES ('POM', 'Pomadasys spp.', NULL, 45, NULL, NULL, 3.1700001, 2.868, 4, NULL);
INSERT INTO ref_espece VALUES ('POQ', 'Polydactylus quadrifilis', NULL, 75, 'ME', 'p2-ge', 0.76999998, 3.0929999, 4, NULL);
INSERT INTO ref_espece VALUES ('PPA', 'Periophthalmus barbarus', 'corrig� le 16/05/08 (ajout� le second h) - cf Fishbase et le Paugy', 41, 'Es', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PPE', 'Pomadasys perotaei', NULL, 45, 'Em', 'p1-bt', 8.71, 2.677, 6, NULL);
INSERT INTO ref_espece VALUES ('PPR', 'Pseudupeneus prayensis', NULL, 63, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PQQ', 'Pentanemus quinquarius', NULL, 75, 'Ma', 'p2-ge', 0.1851, 3.3912001, 9, NULL);
INSERT INTO ref_espece VALUES ('PRA', 'Priacanthus arenatus', NULL, 79, 'Mo', 'p1-mc', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PRO', 'Pomadasys rogerii', NULL, 45, 'Mo', 'p1-bt', 0, 0, 0, 'POM');
INSERT INTO ref_espece VALUES ('PSB', 'Monodactylus sebae', NULL, 59, 'Es', 'p2-ge', 10.28, 2.7479999, 4, NULL);
INSERT INTO ref_espece VALUES ('PSE', 'Polypterus senegalus', 'ss-esp.  Senegalus supprim�e le 7/02/02', 76, 'C', NULL, 0, 0, 0, 'PEN');
INSERT INTO ref_espece VALUES ('PSN', 'Pseudotolithus senegalensis', NULL, 86, 'Ma', 'p2-ge', 0.30000001, 3.1819999, 4, NULL);
INSERT INTO ref_espece VALUES ('PSO', 'Petrocephalus soudanensis', 'LTDM - Mali 01', 60, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PSS', 'Pseudotolithus spp.', NULL, 86, NULL, NULL, 0.56, 3.0550001, 4, NULL);
INSERT INTO ref_espece VALUES ('PSU', 'Pomadasys suillus', NULL, 45, 'Mo', NULL, 0, 0, 0, 'POM');
INSERT INTO ref_espece VALUES ('PTB', 'Pteromylaeus bovinus', 'BBG 10 (27/03/06)', 67, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PTE', 'Petrocephalus tenuicauda', NULL, 60, 'Co', 'p1-mc', 0, 0, 0, 'PBA');
INSERT INTO ref_espece VALUES ('PTP', 'Pteroscion peli', NULL, 86, 'ME', 'p2-ge', 6.1500001, 2.6949999, 5, NULL);
INSERT INTO ref_espece VALUES ('PTR', 'Pegusa triophthalma', 'LT 19/04/07 (ajout du 2nd h)', 91, 'Ma', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PTY', 'Pseudotolithus typus', NULL, 86, 'ME', 'p2-ge', 0.2613, 3.1503, 9, NULL);
INSERT INTO ref_espece VALUES ('PVA', 'Portunus validus', 'Bamboung 6', 78, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('PYM', 'Pythonichthys macrurus', NULL, 48, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('RAC', 'Rhizoprionodon acutus', NULL, 16, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('RAL', 'Rhinobatos albomaculatus', NULL, 83, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('RBO', 'Rhinoptera bonasus', NULL, 67, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('RCA', 'Rachycentron canadum', NULL, 82, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('RCE', 'Rhinobatos cemiculus', NULL, 83, 'Ma', 'p2-ge', 9.1400003, 2.4579999, 6, NULL);
INSERT INTO ref_espece VALUES ('RHI', 'Rhinobatos spp.', NULL, 83, NULL, NULL, 0, 0, 0, 'RCE');
INSERT INTO ref_espece VALUES ('RNI', 'Raiamas nigeriensis', NULL, 26, 'C', NULL, 0, 0, 0, 'BDS');
INSERT INTO ref_espece VALUES ('RSE', 'Raiamas senegalensis', NULL, 26, 'C', NULL, 0, 0, 0, 'BDS');
INSERT INTO ref_espece VALUES ('SAC', 'Sarotherodon caudomarginatus', 'Baran (21/12/01)', 20, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SAL', 'Alectis alexandrinus', NULL, 15, 'Mo', 'p1-bt', 1.826, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('SAN', 'Scorpaena angolensis', NULL, 88, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SAR', 'Sardinella spp.', NULL, 23, NULL, NULL, 0, 0, 0, 'SEB');
INSERT INTO ref_espece VALUES ('SAU', 'Sardinella aurita', NULL, 23, 'Ma', 'om-ge', 0, 0, 0, 'SEB');
INSERT INTO ref_espece VALUES ('SBA', 'Synodontis bastiani', NULL, 57, 'Co', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SBU', 'Synodontis budgetti', NULL, 57, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SCA', 'Synaptura cadenati', NULL, 91, 'Mo', 'p1-bt', 0.63700002, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('SCH', 'Schilbe spp.', '18/11/02', 85, 'C', NULL, 0, 0, 0, 'SMY');
INSERT INTO ref_espece VALUES ('SCL', 'Synodontis clarias', NULL, 57, 'C', NULL, 2.2490001, 3.0699999, 2, NULL);
INSERT INTO ref_espece VALUES ('SCM', 'Scorpaena maderensis', 'corrig� le 16/05/08 (madurensis en maderensis) - cf Fishbase', 88, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SCO', 'Synodontys courteti', NULL, 57, 'C', NULL, 0, 0, 0, 'SYO');
INSERT INTO ref_espece VALUES ('SCR', 'Selar crumenophtalmus', NULL, 15, 'Ma', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SCS', 'Scorpaena scrofa', NULL, 88, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SCU', 'Sarmatum curvatum', NULL, 111, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SEB', 'Sardinella maderensis', NULL, 23, 'ME', 'om-ge', 1.61, 2.9779999, 4, NULL);
INSERT INTO ref_espece VALUES ('SEP', 'Sepia sp.', NULL, 89, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SEU', 'Synodontis eupterus', NULL, 57, 'C', NULL, 9.1739998, 2.779, 2, NULL);
INSERT INTO ref_espece VALUES ('SFI', 'Stromateus fiatola', NULL, 95, 'Mo', 'p2-ge', 1.9299999, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('SGA', 'Sarotherodon galilaeus', NULL, 20, 'C', NULL, 1.778, 3.04, 11, NULL);
INSERT INTO ref_espece VALUES ('SGU', 'Sphyraena guachancho', NULL, 93, 'ME', 'p2-pi', 0, 0, 0, 'SPI');
INSERT INTO ref_espece VALUES ('SHI', 'Stephanolepis hispidus', NULL, 58, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SHO', 'Scarus hoefleri', NULL, 84, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SHU', 'Sesarma (chiromantes) huzardi', NULL, 42, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SIA', 'Siluranodon auritus', NULL, 85, 'C', NULL, 3, 3, 2, NULL);
INSERT INTO ref_espece VALUES ('SIN', 'Schilbe intermedius', NULL, 85, 'Ce', 'p1-mc', 0.2701, 3.2593, 9, NULL);
INSERT INTO ref_espece VALUES ('SKA', 'Enneacampus kaupi', NULL, 96, 'Es', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SLE', 'Sierrathrissa leonensis', NULL, 23, 'C', NULL, 0, 0, 0, 'PEF');
INSERT INTO ref_espece VALUES ('SLU', 'Synaptura lusitanica', NULL, 91, 'Ma', 'p1-bt', 0.63700002, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('SMI', 'Schilbe micropogon', NULL, 85, 'Co', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SMY', 'Schilbe mystus', NULL, 85, 'Ce', NULL, 6.447, 2.5680001, 1, NULL);
INSERT INTO ref_espece VALUES ('SNE', 'Synodontis nigrita', NULL, 57, 'C', NULL, 7.3940001, 2.8429999, 2, NULL);
INSERT INTO ref_espece VALUES ('SOC', 'Synodontis ocellifer', NULL, 57, 'C', NULL, 2.28, 2.9920001, 7, NULL);
INSERT INTO ref_espece VALUES ('SOL', 'Solea spp.', NULL, 91, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SPA', 'Saurida brasiliensis', NULL, 97, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SPE', 'Syngnathus pelagicus', 'Bamboung 02', 96, 'Ma', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SPH', 'Sphyraena spp.', 'JME 15/05/03', 93, NULL, NULL, 0, 0, 0, 'SPI');
INSERT INTO ref_espece VALUES ('SPI', 'Sphyraena afra', NULL, 93, 'ME', 'p2-pi', 1.84, 2.8010001, 4, NULL);
INSERT INTO ref_espece VALUES ('SQM', 'Squilla mantis', NULL, 94, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SSC', 'Synodontis schall', NULL, 57, 'Co', 'om-ge', 3.9860001, 2.951, 2, NULL);
INSERT INTO ref_espece VALUES ('SSO', 'Synodontis sorex', NULL, 57, 'C', NULL, 2.0239999, 3.0369999, 2, NULL);
INSERT INTO ref_espece VALUES ('SSP', 'Sphoeroides spengleri', NULL, 98, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SST', 'Scorpaena stephanica', '25/11/02 (Saloum 31)', 88, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('STE', 'Stenorynchus', NULL, 54, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SY1', 'Synodontis sp. 1', 'Mali 03', 57, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SYF', 'Synodontis filamentosus', NULL, 57, 'C', NULL, 3, 3, 2, NULL);
INSERT INTO ref_espece VALUES ('SYG', 'Synodontis gambiensis', NULL, 57, 'Ce', 'om-ge', 0.14910001, 3.4765, 9, NULL);
INSERT INTO ref_espece VALUES ('SYN', 'Syngnathidae', NULL, 96, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('SYO', 'Synodontis spp.', NULL, 57, NULL, NULL, 0.389, 3.29, 11, NULL);
INSERT INTO ref_espece VALUES ('SZY', 'Sphyrna zygaena', 'Casamance - demande JME 05/07', 112, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TAT', 'Megalops atlanticus', NULL, 56, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TBR', 'Tilapia brevimanus', NULL, 20, 'Co', 'om-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TBU', 'Tilapia buttikoferi', 'Baran (21/12/01)', 20, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TCR', 'Tylosurus crocodilus', NULL, 13, 'Mo', 'p2-pi', 0, 0, 0, 'HPI');
INSERT INTO ref_espece VALUES ('TDA', 'Tilapia dageti', NULL, 20, 'C', NULL, 0, 0, 0, 'TIL');
INSERT INTO ref_espece VALUES ('TET', 'Tetraodon sp.', NULL, 98, NULL, NULL, 0, 0, 0, 'LLA');
INSERT INTO ref_espece VALUES ('TFA', 'Trachinotus teraia', NULL, 15, 'Em', 'p1-bt', 1.84, 3.049, 4, NULL);
INSERT INTO ref_espece VALUES ('TGO', 'Trachinotus goreensis', 'Demande JME 21/06/04', 15, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TGU', 'Tilapia guineensis', NULL, 20, 'Es', 'he-ph', 3.6900001, 2.898, 4, NULL);
INSERT INTO ref_espece VALUES ('THE', 'Sarotherodon melanotheron', NULL, 20, 'Es', 'he-ph', 6.7800002, 2.7780001, 4, NULL);
INSERT INTO ref_espece VALUES ('TIL', 'Tilapia spp.', NULL, 20, NULL, NULL, 4.5799999, 2.8559999, 4, NULL);
INSERT INTO ref_espece VALUES ('TIN', 'Tylochromis intermedius', NULL, 20, 'Co', 'he-de', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TJE', 'Tylochromis jentinki', NULL, 20, 'Es', 'he-de', 1.378, 3.0580001, 1, NULL);
INSERT INTO ref_espece VALUES ('TLE', 'Trichiurus lepturus', NULL, 100, 'ME', 'p2-pi', 0.003, 3.473, 4, NULL);
INSERT INTO ref_espece VALUES ('TLI', 'Tetraodon lineatus', NULL, 98, 'C', NULL, 3.1800001, 3, 8, NULL);
INSERT INTO ref_espece VALUES ('TMA', 'Tilapia mariae', NULL, 20, 'Ec', 'om-ge', 0, 0, 0, 'TIL');
INSERT INTO ref_espece VALUES ('TMY', 'Trachinocephalus myops', 'Bamboung 8', 97, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TNI', 'Oreochromis niloticus', NULL, 20, 'Co', NULL, 2.1329999, 2.9860001, 2, NULL);
INSERT INTO ref_espece VALUES ('TOM', 'Torpedo marmorata', NULL, 99, 'Mo', 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TOR', 'Torpedo sp.', NULL, 99, NULL, 'p2-ge', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TRA', 'Tylosurus acus rafale', NULL, 13, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TRM', 'Trachinotus maxillosus', 'Demande JME 21/06/04', 15, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TSU', 'Tylochromis sudanensis', 'DCN (4/02/02)', 20, 'C', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TTR', 'Trachurus trecae', NULL, 15, 'Mo', 'p1-zo', 0, 0, 0, 'CAR');
INSERT INTO ref_espece VALUES ('TYL', 'Tylochromis leonensis', NULL, 20, 'Co', 'he-de', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('TZI', 'Tilapia zillii', NULL, 20, 'C', NULL, 2.138, 2.96, 11, NULL);
INSERT INTO ref_espece VALUES ('UAF', 'Urogymnus asperrimus', NULL, 29, 'Mo', NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('UCA', 'Umbrina canariensis', NULL, 86, NULL, NULL, 1.1, 3, 12, NULL);
INSERT INTO ref_espece VALUES ('ULE', 'Uroconger lepturus', NULL, 24, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('URO', 'Umbrina ronchus', 'Gambie 02', 86, 'Mo', 'p1-bt', NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('UTA', 'Uca tangeri', '18/11/02', 106, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO ref_espece VALUES ('VSE', 'Selene dorsalis', NULL, 15, 'ME', 'p2-ge', 6.0300002, 2.7190001, 4, NULL);
INSERT INTO ref_espece VALUES ('ZFA', 'Zeus faber', NULL, 104, 'Mo', 'p2-pi', NULL, NULL, NULL, NULL);


--
-- Data for Name: ref_famille; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_famille VALUES (17, 'Centropomidae', 23, 0);
INSERT INTO ref_famille VALUES (104, 'Zeidae', 35, 0);
INSERT INTO ref_famille VALUES (8, 'Apogonidae', 23, 0);
INSERT INTO ref_famille VALUES (57, 'Mochokidae', 29, 0);
INSERT INTO ref_famille VALUES (22, 'Clariidae', 29, 0);
INSERT INTO ref_famille VALUES (54, 'Magidae', 13, 1);
INSERT INTO ref_famille VALUES (36, 'Ephippidae', 23, 0);
INSERT INTO ref_famille VALUES (72, 'Paralichthyidae', 24, 0);
INSERT INTO ref_famille VALUES (18, 'Chaetodontidae', 23, 0);
INSERT INTO ref_famille VALUES (6, 'Aplocheilidae', 12, 0);
INSERT INTO ref_famille VALUES (84, 'Scaridae', 23, 0);
INSERT INTO ref_famille VALUES (29, 'Dasyatidae', 26, 0);
INSERT INTO ref_famille VALUES (67, 'Myliobatidae', 26, 0);
INSERT INTO ref_famille VALUES (85, 'Schilbeidae', 29, 0);
INSERT INTO ref_famille VALUES (64, 'Muraenidae', 2, 0);
INSERT INTO ref_famille VALUES (24, 'Congridae', 2, 0);
INSERT INTO ref_famille VALUES (75, 'Polynemidae', 23, 0);
INSERT INTO ref_famille VALUES (53, 'Lutjanidae', 23, 0);
INSERT INTO ref_famille VALUES (44, 'Gymnuridae', 26, 0);
INSERT INTO ref_famille VALUES (94, 'Squillidae', 30, 1);
INSERT INTO ref_famille VALUES (77, 'Pomacentridae', 23, 0);
INSERT INTO ref_famille VALUES (12, 'Batrachoididae', 5, 0);
INSERT INTO ref_famille VALUES (61, 'Moronidae', 23, 0);
INSERT INTO ref_famille VALUES (31, 'Drepaneidae', 23, 0);
INSERT INTO ref_famille VALUES (59, 'Monodactylidae', 23, 0);
INSERT INTO ref_famille VALUES (30, 'Diodontidae', 32, 0);
INSERT INTO ref_famille VALUES (106, 'Ocypodidae', 13, 1);
INSERT INTO ref_famille VALUES (37, 'Exocoetidae', 6, 0);
INSERT INTO ref_famille VALUES (13, 'Belonidae', 6, 0);
INSERT INTO ref_famille VALUES (15, 'Carangidae', 23, 0);
INSERT INTO ref_famille VALUES (68, 'Notopteridae', 22, 0);
INSERT INTO ref_famille VALUES (52, 'Loliginidae', 33, 1);
INSERT INTO ref_famille VALUES (103, 'Xanthidae', 13, 1);
INSERT INTO ref_famille VALUES (7, 'Aplysiidae', 21, 1);
INSERT INTO ref_famille VALUES (88, 'Scorpaenidae', 27, 0);
INSERT INTO ref_famille VALUES (65, 'Muricidae', 19, 1);
INSERT INTO ref_famille VALUES (93, 'Sphyraenidae', 23, 0);
INSERT INTO ref_famille VALUES (20, 'Cichlidae', 23, 0);
INSERT INTO ref_famille VALUES (28, 'Dactylopteridae', 27, 0);
INSERT INTO ref_famille VALUES (76, 'Polypteridae', 25, 0);
INSERT INTO ref_famille VALUES (92, 'Sparidae', 23, 0);
INSERT INTO ref_famille VALUES (51, 'Lobotidae', 23, 0);
INSERT INTO ref_famille VALUES (14, 'Blenniidae', 23, 0);
INSERT INTO ref_famille VALUES (46, 'Hemiramphidae', 6, 0);
INSERT INTO ref_famille VALUES (66, 'Mycetophilidae', 18, 1);
INSERT INTO ref_famille VALUES (42, 'Grapsidae', 13, 1);
INSERT INTO ref_famille VALUES (2, 'Albulidae', 1, 0);
INSERT INTO ref_famille VALUES (56, 'Megalopidae', 14, 0);
INSERT INTO ref_famille VALUES (43, 'Gymnarchidae', 22, 0);
INSERT INTO ref_famille VALUES (58, 'Monacanthidae', 32, 0);
INSERT INTO ref_famille VALUES (74, 'Platycephalidae', 27, 0);
INSERT INTO ref_famille VALUES (55, 'Malapterudidae', 29, 0);
INSERT INTO ref_famille VALUES (79, 'Priacanthidae', 23, 0);
INSERT INTO ref_famille VALUES (102, 'Volutidae', 7, 1);
INSERT INTO ref_famille VALUES (71, 'Osteoglossidae', 22, 0);
INSERT INTO ref_famille VALUES (90, 'Serranidae', 23, 0);
INSERT INTO ref_famille VALUES (83, 'Rhinobatidae', 26, 0);
INSERT INTO ref_famille VALUES (23, 'Clupeidae', 10, 0);
INSERT INTO ref_famille VALUES (111, 'Inconnu non poisson', 39, 1);
INSERT INTO ref_famille VALUES (38, 'Fistulariidae', 31, 0);
INSERT INTO ref_famille VALUES (112, 'Sphyrnidae', 8, 0);
INSERT INTO ref_famille VALUES (96, 'Syngnathidae', 31, 0);
INSERT INTO ref_famille VALUES (45, 'Haemulidae', 23, 0);
INSERT INTO ref_famille VALUES (10, 'Bagridae', 29, 0);
INSERT INTO ref_famille VALUES (34, 'Elopidae', 14, 0);
INSERT INTO ref_famille VALUES (108, 'Arcidae', 37, 1);
INSERT INTO ref_famille VALUES (105, 'Palaemonidae', 13, 1);
INSERT INTO ref_famille VALUES (21, 'Citharinidae', 9, 0);
INSERT INTO ref_famille VALUES (89, 'Sepiidae', 28, 1);
INSERT INTO ref_famille VALUES (39, 'Galatheidae', 13, 1);
INSERT INTO ref_famille VALUES (82, 'Rhachycentridae', 23, 0);
INSERT INTO ref_famille VALUES (73, 'Penaeidae', 13, 1);
INSERT INTO ref_famille VALUES (16, 'Carcharhinidae', 8, 0);
INSERT INTO ref_famille VALUES (107, 'Ostreidae', 36, 1);
INSERT INTO ref_famille VALUES (35, 'Engraulidae', 10, 0);
INSERT INTO ref_famille VALUES (25, 'Cynoglossidae', 24, 0);
INSERT INTO ref_famille VALUES (5, 'Antennariidae', 17, 0);
INSERT INTO ref_famille VALUES (4, 'Anabantidae', 23, 0);
INSERT INTO ref_famille VALUES (97, 'Synodontidae', 4, 0);
INSERT INTO ref_famille VALUES (101, 'Triglidae', 27, 0);
INSERT INTO ref_famille VALUES (26, 'Cyprinidae', 11, 0);
INSERT INTO ref_famille VALUES (32, 'Echeneidae', 23, 0);
INSERT INTO ref_famille VALUES (98, 'Tetraodontidae', 32, 0);
INSERT INTO ref_famille VALUES (60, 'Mormyridae', 22, 0);
INSERT INTO ref_famille VALUES (3, 'Alestiidae', 9, 0);
INSERT INTO ref_famille VALUES (78, 'Portunidae', 13, 1);
INSERT INTO ref_famille VALUES (40, 'Gerreidae', 23, 0);
INSERT INTO ref_famille VALUES (50, 'Lethrinidae', 23, 0);
INSERT INTO ref_famille VALUES (87, 'Scombridae', 23, 0);
INSERT INTO ref_famille VALUES (1, 'Acanthuridae', 23, 0);
INSERT INTO ref_famille VALUES (27, 'Cyprinodontidae', 12, 0);
INSERT INTO ref_famille VALUES (33, 'Eleotridae', 23, 0);
INSERT INTO ref_famille VALUES (70, 'Ophichthidae', 2, 0);
INSERT INTO ref_famille VALUES (11, 'Balistidae', 32, 0);
INSERT INTO ref_famille VALUES (109, 'Atherinidae', 38, 0);
INSERT INTO ref_famille VALUES (100, 'Trichiuridae', 23, 0);
INSERT INTO ref_famille VALUES (91, 'Soleidae', 24, 0);
INSERT INTO ref_famille VALUES (49, 'Inconnu Poisson', 15, 0);
INSERT INTO ref_famille VALUES (81, 'Psettodidae', 24, 0);
INSERT INTO ref_famille VALUES (63, 'Mullidae', 23, 0);
INSERT INTO ref_famille VALUES (48, 'Heterenchelyidae', 2, 0);
INSERT INTO ref_famille VALUES (41, 'Gobiidae', 23, 0);
INSERT INTO ref_famille VALUES (95, 'Stromateidae', 23, 0);
INSERT INTO ref_famille VALUES (80, 'Protopteridae', 16, 0);
INSERT INTO ref_famille VALUES (99, 'Torpedinidae', 34, 0);
INSERT INTO ref_famille VALUES (62, 'Mugilidae', 23, 0);
INSERT INTO ref_famille VALUES (69, 'Octopodidae', 20, 1);
INSERT INTO ref_famille VALUES (86, 'Sciaenidae', 23, 0);
INSERT INTO ref_famille VALUES (19, 'Channidae', 23, 0);
INSERT INTO ref_famille VALUES (47, 'Hepsetidae', 9, 0);
INSERT INTO ref_famille VALUES (9, 'Ariidae', 29, 0);


--
-- Data for Name: ref_ordre; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_ordre VALUES (1, 'Albuliformes');
INSERT INTO ref_ordre VALUES (2, 'Anguilliformes');
INSERT INTO ref_ordre VALUES (4, 'Aulopiformes');
INSERT INTO ref_ordre VALUES (5, 'Batrachoidiformes');
INSERT INTO ref_ordre VALUES (6, 'Beloniformes');
INSERT INTO ref_ordre VALUES (7, 'Caenogast�ropodes');
INSERT INTO ref_ordre VALUES (8, 'Carcharhiniformes');
INSERT INTO ref_ordre VALUES (9, 'Characiformes');
INSERT INTO ref_ordre VALUES (10, 'Clup�iformes');
INSERT INTO ref_ordre VALUES (11, 'Cypriniformes');
INSERT INTO ref_ordre VALUES (12, 'Cyprinodontiformes');
INSERT INTO ref_ordre VALUES (13, 'D�capodes');
INSERT INTO ref_ordre VALUES (14, 'Elopiformes');
INSERT INTO ref_ordre VALUES (15, 'Inconnu Poisson');
INSERT INTO ref_ordre VALUES (16, 'Lepidosir�niformes');
INSERT INTO ref_ordre VALUES (17, 'Lophiiformes');
INSERT INTO ref_ordre VALUES (18, 'Nematoc�res');
INSERT INTO ref_ordre VALUES (19, 'Neogast�ropodes');
INSERT INTO ref_ordre VALUES (20, 'Octopodes');
INSERT INTO ref_ordre VALUES (21, 'Opisthobranches');
INSERT INTO ref_ordre VALUES (22, 'Ost�oglossiformes');
INSERT INTO ref_ordre VALUES (23, 'Perciformes');
INSERT INTO ref_ordre VALUES (24, 'Pleuronectiformes');
INSERT INTO ref_ordre VALUES (25, 'Polypt�riformes');
INSERT INTO ref_ordre VALUES (26, 'Rajiformes');
INSERT INTO ref_ordre VALUES (27, 'Scorpaeniformes');
INSERT INTO ref_ordre VALUES (28, 'Sepiida');
INSERT INTO ref_ordre VALUES (29, 'Siluriformes');
INSERT INTO ref_ordre VALUES (30, 'Stomatopodes');
INSERT INTO ref_ordre VALUES (31, 'Syngnathiformes');
INSERT INTO ref_ordre VALUES (32, 'T�traodontiformes');
INSERT INTO ref_ordre VALUES (33, 'Teutho�d�s');
INSERT INTO ref_ordre VALUES (34, 'Torp�diniformes');
INSERT INTO ref_ordre VALUES (35, 'Zeiformes');
INSERT INTO ref_ordre VALUES (36, 'Filibranches');
INSERT INTO ref_ordre VALUES (37, 'Arcoida');
INSERT INTO ref_ordre VALUES (38, 'Atheriniformes');
INSERT INTO ref_ordre VALUES (39, 'Inconnu non poisson');


--
-- Data for Name: ref_origine_kb; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_origine_kb VALUES (0, 'Inconnu');
INSERT INTO ref_origine_kb VALUES (1, 'Bert & Ecoutin, 1982');
INSERT INTO ref_origine_kb VALUES (2, 'Delta Central du Niger');
INSERT INTO ref_origine_kb VALUES (3, 'Lacs Maliens');
INSERT INTO ref_origine_kb VALUES (4, 'Ecoutin & Albaret, 2003');
INSERT INTO ref_origine_kb VALUES (5, 'Lagune Ebri� (Ecoutin & Albaret, 2003)');
INSERT INTO ref_origine_kb VALUES (6, 'Sin� Saloum (Ecoutin & Albaret, 2003)');
INSERT INTO ref_origine_kb VALUES (7, 'Fishbase (mediane)');
INSERT INTO ref_origine_kb VALUES (8, 'Fishbase (article)');
INSERT INTO ref_origine_kb VALUES (9, 'Estuaire de la Gambie');
INSERT INTO ref_origine_kb VALUES (10, 'Toutes donnees MEL');
INSERT INTO ref_origine_kb VALUES (11, 'Peuplements Lacs Maliens');
INSERT INTO ref_origine_kb VALUES (12, 'Moyenne b=3');


--
-- Data for Name: ref_pays; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_pays VALUES ('BN', 'Benin');
INSERT INTO ref_pays VALUES ('GA', 'Gambia, The');
INSERT INTO ref_pays VALUES ('GH', 'Ghana');
INSERT INTO ref_pays VALUES ('GV', 'Guinee');
INSERT INTO ref_pays VALUES ('IN', 'Inconnu');
INSERT INTO ref_pays VALUES ('IV', 'Cote d''Ivoire');
INSERT INTO ref_pays VALUES ('LI', 'Liberia');
INSERT INTO ref_pays VALUES ('ML', 'Mali');
INSERT INTO ref_pays VALUES ('MR', 'Mauritanie');
INSERT INTO ref_pays VALUES ('NG', 'Niger');
INSERT INTO ref_pays VALUES ('PU', 'Guinee Bissau');
INSERT INTO ref_pays VALUES ('SG', 'Senegal');
INSERT INTO ref_pays VALUES ('SL', 'Sierra Leone');
INSERT INTO ref_pays VALUES ('TO', 'Togo');
INSERT INTO ref_pays VALUES ('UV', 'Burkina Faso');


--
-- Data for Name: ref_secteur; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_secteur VALUES (1, 1, 'Inconnu', 0, 1);
INSERT INTO ref_secteur VALUES (2, 1, 'Secteur I', 22, 3);
INSERT INTO ref_secteur VALUES (3, 2, 'Secteur II', 62, 3);
INSERT INTO ref_secteur VALUES (4, 3, 'Secteur III', 71, 3);
INSERT INTO ref_secteur VALUES (5, 4, 'Secteur IV', 86, 3);
INSERT INTO ref_secteur VALUES (6, 5, 'Secteur V', 170, 3);
INSERT INTO ref_secteur VALUES (7, 6, 'Secteur VI', 135, 3);
INSERT INTO ref_secteur VALUES (8, 1, 'Niger Amont', 0, 4);
INSERT INTO ref_secteur VALUES (9, 2, 'Djenneri', 0, 4);
INSERT INTO ref_secteur VALUES (10, 3, 'Diaka', 0, 4);
INSERT INTO ref_secteur VALUES (11, 4, 'Lacs', 2240, 4);
INSERT INTO ref_secteur VALUES (12, 5, 'Nord Dunaire', 0, 4);
INSERT INTO ref_secteur VALUES (13, 6, 'Niger Aval', 0, 4);
INSERT INTO ref_secteur VALUES (14, 1, 'Barrage', 0, 5);
INSERT INTO ref_secteur VALUES (15, 2, 'Centre', 0, 5);
INSERT INTO ref_secteur VALUES (16, 3, 'Amont', 0, 5);
INSERT INTO ref_secteur VALUES (18, 1, 'Barrage', 0, 6);
INSERT INTO ref_secteur VALUES (19, 2, 'Sankarani', 0, 6);
INSERT INTO ref_secteur VALUES (20, 3, 'Bale', 0, 6);
INSERT INTO ref_secteur VALUES (21, 1, 'Secteur I', 0, 7);
INSERT INTO ref_secteur VALUES (22, 2, 'Secteur II', 0, 7);
INSERT INTO ref_secteur VALUES (23, 1, 'Aval', 0, 10);
INSERT INTO ref_secteur VALUES (24, 2, 'Centre', 0, 10);
INSERT INTO ref_secteur VALUES (25, 3, 'Amont', 0, 10);
INSERT INTO ref_secteur VALUES (26, 1, 'Bandiala Aval', 0, 8);
INSERT INTO ref_secteur VALUES (27, 2, 'Bandiala Centre', 0, 8);
INSERT INTO ref_secteur VALUES (28, 3, 'Bandiala Amont', 0, 8);
INSERT INTO ref_secteur VALUES (29, 4, 'Diomboss', 0, 8);
INSERT INTO ref_secteur VALUES (30, 5, 'Saloum aval', 0, 8);
INSERT INTO ref_secteur VALUES (31, 6, 'Saloum zone 6', 0, 8);
INSERT INTO ref_secteur VALUES (32, 7, 'Saloum zone 7', 0, 8);
INSERT INTO ref_secteur VALUES (33, 8, 'Saloum amont', 0, 8);
INSERT INTO ref_secteur VALUES (34, 1, 'Nord', 0, 2);
INSERT INTO ref_secteur VALUES (35, 2, 'Sud', 0, 2);
INSERT INTO ref_secteur VALUES (36, 3, 'Tendo', 0, 2);
INSERT INTO ref_secteur VALUES (37, 4, 'Ehy', 0, 2);
INSERT INTO ref_secteur VALUES (38, 9, 'Mer devant Saloum', 0, 8);
INSERT INTO ref_secteur VALUES (39, 1, 'Aval', 0, 12);
INSERT INTO ref_secteur VALUES (40, 2, 'Centre', 0, 12);
INSERT INTO ref_secteur VALUES (41, 3, 'Amont', 0, 12);
INSERT INTO ref_secteur VALUES (42, 1, 'Dangara', 0, 13);
INSERT INTO ref_secteur VALUES (43, 1, 'Embouchure', 0, 14);
INSERT INTO ref_secteur VALUES (44, 2, 'Aval', 0, 14);
INSERT INTO ref_secteur VALUES (45, 3, 'Centre', 0, 14);
INSERT INTO ref_secteur VALUES (46, 4, 'Amont', 0, 14);
INSERT INTO ref_secteur VALUES (47, 4, 'Bale Centre', 0, 6);
INSERT INTO ref_secteur VALUES (48, 5, 'Bale Amont', 0, 6);
INSERT INTO ref_secteur VALUES (49, 6, 'Sankarani Centre', 0, 6);
INSERT INTO ref_secteur VALUES (50, 7, 'Sankarani Amont', 0, 6);
INSERT INTO ref_secteur VALUES (51, 1, 'Bolong Bamboung', 0, 17);
INSERT INTO ref_secteur VALUES (52, 1, 'Bijagos', 0, 15);
INSERT INTO ref_secteur VALUES (53, 1, 'Rio Buba', 0, 16);


--
-- Data for Name: ref_systeme; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO ref_systeme VALUES (1, 'Inconnu', 'IN', 0);
INSERT INTO ref_systeme VALUES (2, 'Lagune Aby', 'IV', 424);
INSERT INTO ref_systeme VALUES (3, 'Lagune Ebrie', 'IV', 566);
INSERT INTO ref_systeme VALUES (4, 'Delta Central du Niger', 'ML', 27986);
INSERT INTO ref_systeme VALUES (5, 'Lac de Manantali', 'ML', 485);
INSERT INTO ref_systeme VALUES (6, 'Lac de Selingue', 'ML', 409);
INSERT INTO ref_systeme VALUES (7, 'Lac Togo', 'TO', 64);
INSERT INTO ref_systeme VALUES (8, 'Sine Saloum', 'SG', 900);
INSERT INTO ref_systeme VALUES (9, 'Lac de Korientze', 'ML', 0);
INSERT INTO ref_systeme VALUES (10, 'Estuaire de la Gambie', 'GA', 864);
INSERT INTO ref_systeme VALUES (11, 'Lagune de Grand Lahou', 'IV', 190);
INSERT INTO ref_systeme VALUES (12, 'Casamance', 'SG', 0);
INSERT INTO ref_systeme VALUES (13, 'Dangara', 'GV', 0);
INSERT INTO ref_systeme VALUES (14, 'Estuaire de la Fatala', 'GV', 0);
INSERT INTO ref_systeme VALUES (15, 'Archipel des Bijagos', 'PU', 0);
INSERT INTO ref_systeme VALUES (16, 'Rio Buba', 'PU', 0);
INSERT INTO ref_systeme VALUES (17, 'Bolong Bamboung', 'SG', 0.68000001);


--
-- Data for Name: sys_activites_a_migrer; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: sys_campagnes_a_migrer; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: sys_debarquements_a_migrer; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: sys_periodes_enquete; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: ar_origine_kb_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_origine_kb
    ADD CONSTRAINT ar_origine_kb_pkey PRIMARY KEY (id);


--
-- Name: art_agglomeration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_agglomeration
    ADD CONSTRAINT art_agglomeration_pkey PRIMARY KEY (id);


--
-- Name: art_artivite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_artivite_pkey PRIMARY KEY (id);


--
-- Name: art_categorie_socio_professionnelle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_categorie_socio_professionnelle
    ADD CONSTRAINT art_categorie_socio_professionnelle_pkey PRIMARY KEY (id);


--
-- Name: art_debarquement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_debarquement_pkey PRIMARY KEY (id);


--
-- Name: art_engin_activite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_engin_activite
    ADD CONSTRAINT art_engin_activite_pkey PRIMARY KEY (id);


--
-- Name: art_engin_peche_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_engin_peche
    ADD CONSTRAINT art_engin_peche_pkey PRIMARY KEY (id);


--
-- Name: art_etat_ciel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_etat_ciel
    ADD CONSTRAINT art_etat_ciel_pkey PRIMARY KEY (id);


--
-- Name: art_fraction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_fraction
    ADD CONSTRAINT art_fraction_pkey PRIMARY KEY (id);


--
-- Name: art_grand_type_engin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_grand_type_engin
    ADD CONSTRAINT art_grand_type_engin_pkey PRIMARY KEY (id);


--
-- Name: art_lieu_de_peche_id_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_lieu_de_peche
    ADD CONSTRAINT art_lieu_de_peche_id_pkey PRIMARY KEY (id);


--
-- Name: art_millieu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_millieu
    ADD CONSTRAINT art_millieu_pkey PRIMARY KEY (id);


--
-- Name: art_poisson_mesure_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_poisson_mesure
    ADD CONSTRAINT art_poisson_mesure_pkey PRIMARY KEY (id);


--
-- Name: art_tyepe_sortie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_type_sortie
    ADD CONSTRAINT art_tyepe_sortie_pkey PRIMARY KEY (id);


--
-- Name: art_type_activite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_type_activite
    ADD CONSTRAINT art_type_activite_pkey PRIMARY KEY (id);


--
-- Name: art_type_agglomeration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_type_agglomeration
    ADD CONSTRAINT art_type_agglomeration_pkey PRIMARY KEY (id);


--
-- Name: art_type_engin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_type_engin
    ADD CONSTRAINT art_type_engin_pkey PRIMARY KEY (id);


--
-- Name: art_unite_peche_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_unite_peche
    ADD CONSTRAINT art_unite_peche_pkey PRIMARY KEY (id);


--
-- Name: art_vent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY art_vent
    ADD CONSTRAINT art_vent_pkey PRIMARY KEY (id);


--
-- Name: exp_campagne_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_campagne
    ADD CONSTRAINT exp_campagne_pkey PRIMARY KEY (id);


--
-- Name: exp_contenu_biologie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_trophique
    ADD CONSTRAINT exp_contenu_biologie_pkey PRIMARY KEY (id);


--
-- Name: exp_contenu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_contenu
    ADD CONSTRAINT exp_contenu_pkey PRIMARY KEY (id);


--
-- Name: exp_cp_peche_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_coup_peche
    ADD CONSTRAINT exp_cp_peche_pkey PRIMARY KEY (id);


--
-- Name: exp_debris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_debris
    ADD CONSTRAINT exp_debris_pkey PRIMARY KEY (id);


--
-- Name: exp_environnement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_environnement
    ADD CONSTRAINT exp_environnement_pkey PRIMARY KEY (id);


--
-- Name: exp_force_courant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_force_courant
    ADD CONSTRAINT exp_force_courant_pkey PRIMARY KEY (id);


--
-- Name: exp_position_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_position
    ADD CONSTRAINT exp_position_pkey PRIMARY KEY (id);


--
-- Name: exp_qualite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_qualite
    ADD CONSTRAINT exp_qualite_pkey PRIMARY KEY (id);


--
-- Name: exp_remplissage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_remplissage
    ADD CONSTRAINT exp_remplissage_pkey PRIMARY KEY (id);


--
-- Name: exp_sediment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_sediment
    ADD CONSTRAINT exp_sediment_pkey PRIMARY KEY (id);


--
-- Name: exp_sens_courant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_sens_courant
    ADD CONSTRAINT exp_sens_courant_pkey PRIMARY KEY (id);


--
-- Name: exp_sexe_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_sexe
    ADD CONSTRAINT exp_sexe_pkey PRIMARY KEY (id);


--
-- Name: exp_stade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_stade
    ADD CONSTRAINT exp_stade_pkey PRIMARY KEY (id);


--
-- Name: exp_station_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_station
    ADD CONSTRAINT exp_station_pkey PRIMARY KEY (id);


--
-- Name: exp_vegetation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_vegetation
    ADD CONSTRAINT exp_vegetation_pkey PRIMARY KEY (id);


--
-- Name: pg_ts_cfg_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pg_ts_cfg
    ADD CONSTRAINT pg_ts_cfg_pkey PRIMARY KEY (ts_name);


--
-- Name: pg_ts_cfgmap_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pg_ts_cfgmap
    ADD CONSTRAINT pg_ts_cfgmap_pkey PRIMARY KEY (ts_name, tok_alias);


--
-- Name: pg_ts_dict_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pg_ts_dict
    ADD CONSTRAINT pg_ts_dict_pkey PRIMARY KEY (dict_name);


--
-- Name: pg_ts_parser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pg_ts_parser
    ADD CONSTRAINT pg_ts_parser_pkey PRIMARY KEY (prs_name);


--
-- Name: ref_biologie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_biologie
    ADD CONSTRAINT ref_biologie_pkey PRIMARY KEY (id);


--
-- Name: ref_categorie_ecologique_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_categorie_ecologique
    ADD CONSTRAINT ref_categorie_ecologique_pkey PRIMARY KEY (id);


--
-- Name: ref_categorie_trophique_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_categorie_trophique
    ADD CONSTRAINT ref_categorie_trophique_pkey PRIMARY KEY (id);


--
-- Name: ref_engin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_engin
    ADD CONSTRAINT ref_engin_pkey PRIMARY KEY (id);


--
-- Name: ref_espece_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_espece
    ADD CONSTRAINT ref_espece_pkey PRIMARY KEY (id);


--
-- Name: ref_famille_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_famille
    ADD CONSTRAINT ref_famille_pkey PRIMARY KEY (id);


--
-- Name: ref_fraction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exp_fraction
    ADD CONSTRAINT ref_fraction_pkey PRIMARY KEY (id);


--
-- Name: ref_ordre_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_ordre
    ADD CONSTRAINT ref_ordre_pkey PRIMARY KEY (id);


--
-- Name: ref_pays_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_pays
    ADD CONSTRAINT ref_pays_pkey PRIMARY KEY (id);


--
-- Name: ref_secteur_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_secteur
    ADD CONSTRAINT ref_secteur_pkey PRIMARY KEY (id);


--
-- Name: ref_systeme_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_systeme
    ADD CONSTRAINT ref_systeme_pkey PRIMARY KEY (id);


--
-- Name: sys_activites_a_migrer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sys_activites_a_migrer
    ADD CONSTRAINT sys_activites_a_migrer_pkey PRIMARY KEY (id);


--
-- Name: sys_campagnes_a_migrer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sys_campagnes_a_migrer
    ADD CONSTRAINT sys_campagnes_a_migrer_pkey PRIMARY KEY (id);


--
-- Name: sys_debarquements_a_migrer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sys_debarquements_a_migrer
    ADD CONSTRAINT sys_debarquements_a_migrer_pkey PRIMARY KEY (id);


--
-- Name: sys_periodes_enquete_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sys_periodes_enquete
    ADD CONSTRAINT sys_periodes_enquete_pkey PRIMARY KEY (id);


--
-- Name: art_activite_art_type_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_activite_art_type_activite_id_fkey FOREIGN KEY (art_type_activite_id) REFERENCES art_type_activite(id);


--
-- Name: art_activite_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_engin_activite
    ADD CONSTRAINT art_activite_id FOREIGN KEY (art_activite_id) REFERENCES art_activite(id);


--
-- Name: art_agglomeration_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_agglomeration_id FOREIGN KEY (art_agglomeration_id) REFERENCES art_agglomeration(id);


--
-- Name: art_agglomeration_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_agglomeration_id FOREIGN KEY (art_agglomeration_id) REFERENCES art_agglomeration(id);


--
-- Name: art_categorie_socio_professionnelle_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_unite_peche
    ADD CONSTRAINT art_categorie_socio_professionnelle_id FOREIGN KEY (art_categorie_socio_professionnelle_id) REFERENCES art_categorie_socio_professionnelle(id);


--
-- Name: art_debarquement_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_engin_peche
    ADD CONSTRAINT art_debarquement_id FOREIGN KEY (art_debarquement_id) REFERENCES art_debarquement(id);


--
-- Name: art_debarquement_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_fraction
    ADD CONSTRAINT art_debarquement_id FOREIGN KEY (art_debarquement_id) REFERENCES art_debarquement(id);


--
-- Name: art_engin_activite_art_type_engin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_engin_activite
    ADD CONSTRAINT art_engin_activite_art_type_engin_id_fkey FOREIGN KEY (art_type_engin_id) REFERENCES art_type_engin(id);


--
-- Name: art_engin_peche_art_type_engin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_engin_peche
    ADD CONSTRAINT art_engin_peche_art_type_engin_id_fkey FOREIGN KEY (art_type_engin_id) REFERENCES art_type_engin(id);


--
-- Name: art_etat_ciel_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_etat_ciel_id FOREIGN KEY (art_etat_ciel_id) REFERENCES art_etat_ciel(id);


--
-- Name: art_fraction_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_poisson_mesure
    ADD CONSTRAINT art_fraction_id FOREIGN KEY (art_fraction_id) REFERENCES art_fraction(id) DEFERRABLE;


--
-- Name: art_grand_type_engin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_grand_type_engin_id FOREIGN KEY (art_grand_type_engin_id) REFERENCES art_grand_type_engin(id);


--
-- Name: art_grand_type_engin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_grand_type_engin_id FOREIGN KEY (art_grand_type_engin_id) REFERENCES art_grand_type_engin(id);


--
-- Name: art_lieu_peche_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_lieu_peche_id FOREIGN KEY (art_lieu_de_peche_id) REFERENCES art_lieu_de_peche(id);


--
-- Name: art_millieu_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_millieu_id FOREIGN KEY (art_millieu_id) REFERENCES art_millieu(id);


--
-- Name: art_millieu_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_millieu_id FOREIGN KEY (art_millieu_id) REFERENCES art_millieu(id);


--
-- Name: art_origine_kb_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_espece
    ADD CONSTRAINT art_origine_kb_id FOREIGN KEY (ref_origine_kb_id) REFERENCES ref_origine_kb(id);


--
-- Name: art_type_agglomeration_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_agglomeration
    ADD CONSTRAINT art_type_agglomeration_id FOREIGN KEY (art_type_agglomeration_id) REFERENCES art_type_agglomeration(id);


--
-- Name: art_type_engin_art_grand_type_engin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_type_engin
    ADD CONSTRAINT art_type_engin_art_grand_type_engin_id_fkey FOREIGN KEY (art_grand_type_engin_id) REFERENCES art_grand_type_engin(id);


--
-- Name: art_type_sortie_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_type_sortie_id FOREIGN KEY (art_type_sortie_id) REFERENCES art_type_sortie(id);


--
-- Name: art_type_sortie_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_type_sortie_id FOREIGN KEY (art_type_sortie_id) REFERENCES art_type_sortie(id);


--
-- Name: art_unite_peche_art_agglomeration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_unite_peche
    ADD CONSTRAINT art_unite_peche_art_agglomeration_id_fkey FOREIGN KEY (art_agglomeration_id) REFERENCES art_agglomeration(id);


--
-- Name: art_unite_peche_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_activite
    ADD CONSTRAINT art_unite_peche_id FOREIGN KEY (art_unite_peche_id) REFERENCES art_unite_peche(id);


--
-- Name: art_unite_peche_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_unite_peche_id FOREIGN KEY (art_unite_peche_id) REFERENCES art_unite_peche(id);


--
-- Name: art_vent_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_debarquement
    ADD CONSTRAINT art_vent_id FOREIGN KEY (art_vent_id) REFERENCES art_vent(id);


--
-- Name: exp_biologie_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_trophique
    ADD CONSTRAINT exp_biologie_id FOREIGN KEY (exp_biologie_id) REFERENCES exp_biologie(id);


--
-- Name: exp_campagne_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_coup_peche
    ADD CONSTRAINT exp_campagne_id FOREIGN KEY (exp_campagne_id) REFERENCES exp_campagne(id);


--
-- Name: exp_contenu_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_trophique
    ADD CONSTRAINT exp_contenu_id FOREIGN KEY (exp_contenu_id) REFERENCES exp_contenu(id);


--
-- Name: exp_coup_peche_exp_engin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_coup_peche
    ADD CONSTRAINT exp_coup_peche_exp_engin_id_fkey FOREIGN KEY (exp_engin_id) REFERENCES exp_engin(id);


--
-- Name: exp_coup_peche_exp_environnement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_coup_peche
    ADD CONSTRAINT exp_coup_peche_exp_environnement_id_fkey FOREIGN KEY (exp_environnement_id) REFERENCES exp_environnement(id);


--
-- Name: exp_cp_peche_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_fraction
    ADD CONSTRAINT exp_cp_peche_id FOREIGN KEY (exp_coup_peche_id) REFERENCES exp_coup_peche(id);


--
-- Name: exp_debris_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_station
    ADD CONSTRAINT exp_debris_id FOREIGN KEY (exp_debris_id) REFERENCES exp_debris(id);


--
-- Name: exp_force_courant_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_environnement
    ADD CONSTRAINT exp_force_courant_id FOREIGN KEY (exp_force_courant_id) REFERENCES exp_force_courant(id);


--
-- Name: exp_fraction_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_biologie
    ADD CONSTRAINT exp_fraction_id FOREIGN KEY (exp_fraction_id) REFERENCES exp_fraction(id);


--
-- Name: exp_position_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_station
    ADD CONSTRAINT exp_position_id FOREIGN KEY (exp_position_id) REFERENCES exp_position(id);


--
-- Name: exp_qualite_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_coup_peche
    ADD CONSTRAINT exp_qualite_id FOREIGN KEY (exp_qualite_id) REFERENCES exp_qualite(id);


--
-- Name: exp_remplissage_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_biologie
    ADD CONSTRAINT exp_remplissage_id FOREIGN KEY (exp_remplissage_id) REFERENCES exp_remplissage(id);


--
-- Name: exp_secteur_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_station
    ADD CONSTRAINT exp_secteur_id FOREIGN KEY (ref_secteur_id) REFERENCES ref_secteur(id);


--
-- Name: exp_sediment_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_station
    ADD CONSTRAINT exp_sediment_id FOREIGN KEY (exp_sediment_id) REFERENCES exp_sediment(id);


--
-- Name: exp_sens_courant_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_environnement
    ADD CONSTRAINT exp_sens_courant_id FOREIGN KEY (exp_sens_courant_id) REFERENCES exp_sens_courant(id);


--
-- Name: exp_sexe_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_biologie
    ADD CONSTRAINT exp_sexe_id FOREIGN KEY (exp_sexe_id) REFERENCES exp_sexe(id);


--
-- Name: exp_stade_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_biologie
    ADD CONSTRAINT exp_stade_id FOREIGN KEY (exp_stade_id) REFERENCES exp_stade(id);


--
-- Name: exp_station_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_coup_peche
    ADD CONSTRAINT exp_station_id FOREIGN KEY (exp_station_id) REFERENCES exp_station(id);


--
-- Name: exp_vegetation_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_station
    ADD CONSTRAINT exp_vegetation_id FOREIGN KEY (exp_vegetation_id) REFERENCES exp_vegetation(id);


--
-- Name: ref_categorie_ecologique_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_espece
    ADD CONSTRAINT ref_categorie_ecologique_id FOREIGN KEY (ref_categorie_ecologique_id) REFERENCES ref_categorie_ecologique(id);


--
-- Name: ref_categorie_trophique_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_espece
    ADD CONSTRAINT ref_categorie_trophique_id FOREIGN KEY (ref_categorie_trophique_id) REFERENCES ref_categorie_trophique(id);


--
-- Name: ref_espece_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_fraction
    ADD CONSTRAINT ref_espece_id FOREIGN KEY (ref_espece_id) REFERENCES ref_espece(id);


--
-- Name: ref_espece_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_espece
    ADD CONSTRAINT ref_espece_id FOREIGN KEY (id) REFERENCES ref_espece(id);


--
-- Name: ref_espece_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_fraction
    ADD CONSTRAINT ref_espece_id FOREIGN KEY (ref_espece_id) REFERENCES ref_espece(id);


--
-- Name: ref_famille_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_espece
    ADD CONSTRAINT ref_famille_id FOREIGN KEY (ref_famille_id) REFERENCES ref_famille(id);


--
-- Name: ref_ordre_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_famille
    ADD CONSTRAINT ref_ordre_id FOREIGN KEY (ref_ordre_id) REFERENCES ref_ordre(id);


--
-- Name: ref_pays_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_systeme
    ADD CONSTRAINT ref_pays_id FOREIGN KEY (ref_pays_id) REFERENCES ref_pays(id);


--
-- Name: ref_secteur_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_agglomeration
    ADD CONSTRAINT ref_secteur_id FOREIGN KEY (ref_secteur_id) REFERENCES ref_secteur(id);


--
-- Name: ref_secteur_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY art_lieu_de_peche
    ADD CONSTRAINT ref_secteur_id FOREIGN KEY (ref_secteur_id) REFERENCES ref_secteur(id);


--
-- Name: ref_systeme_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exp_campagne
    ADD CONSTRAINT ref_systeme_id FOREIGN KEY (ref_systeme_id) REFERENCES ref_systeme(id);


--
-- Name: ref_systeme_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_secteur
    ADD CONSTRAINT ref_systeme_id FOREIGN KEY (ref_systeme_id) REFERENCES ref_systeme(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

